// Enum EEventDisplayType.EEventDisplayType
enum class EEventDisplayType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	NewEnumerator2 = 3,
	EEventDisplayType_MAX = 4
};

