// BlueprintGeneratedClass DefaultGamepadLookManager.DefaultGamepadLookManager_C
// Size: 0xe8 (Inherited: 0xe8)
struct UDefaultGamepadLookManager_C : UKSGamepadCurvedLookSpeedManager {
};

