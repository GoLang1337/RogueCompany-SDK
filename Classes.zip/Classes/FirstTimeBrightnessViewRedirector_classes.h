// BlueprintGeneratedClass FirstTimeBrightnessViewRedirector.FirstTimeBrightnessViewRedirector_C
// Size: 0x30 (Inherited: 0x30)
struct UFirstTimeBrightnessViewRedirector_C : UKSViewRedirector_LocalSetting {
};

