// WidgetBlueprintGeneratedClass PlayerHealthMeterSegment.PlayerHealthMeterSegment_C
// Size: 0x342 (Inherited: 0x238)
struct UPlayerHealthMeterSegment_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UWidgetAnimation* DownedPulse; // 0x240(0x08)
	struct UWidgetAnimation* ImmunePulse; // 0x248(0x08)
	struct UWidgetAnimation* DisableImmune; // 0x250(0x08)
	struct UWidgetAnimation* EnableImmune; // 0x258(0x08)
	struct UWidgetAnimation* DamagePulse; // 0x260(0x08)
	struct UImage* Dot_Lower; // 0x268(0x08)
	struct UImage* Dot_Upper; // 0x270(0x08)
	struct UCanvasPanel* Dots; // 0x278(0x08)
	struct UImage* EnemyDownedBG; // 0x280(0x08)
	struct UImage* Image_120; // 0x288(0x08)
	struct UWidgetSwitcher* IsDownedSwitcher; // 0x290(0x08)
	struct UWidgetSwitcher* SegmentBGSwitcher; // 0x298(0x08)
	struct UOverlay* SliceArmor; // 0x2a0(0x08)
	struct UImage* SliceArmorDamaged; // 0x2a8(0x08)
	struct UImage* SliceArmorFill; // 0x2b0(0x08)
	struct UImage* SliceArmorTrim; // 0x2b8(0x08)
	struct USpacer* SliceDepleted; // 0x2c0(0x08)
	struct UImage* SliceDownedFill_2; // 0x2c8(0x08)
	struct UImage* SliceDownedTrim_2; // 0x2d0(0x08)
	struct UOverlay* SliceHealth; // 0x2d8(0x08)
	struct UImage* SliceHealthDamaged; // 0x2e0(0x08)
	struct UImage* SliceHealthFill; // 0x2e8(0x08)
	struct UImage* SliceHealthTrim; // 0x2f0(0x08)
	struct UImage* SliceImmuneFill; // 0x2f8(0x08)
	struct UOverlay* SliceImmuneOverlay; // 0x300(0x08)
	struct UOverlay* SliceInactive; // 0x308(0x08)
	struct UImage* SliceInactiveFill; // 0x310(0x08)
	struct UOverlay* SliceOverheal; // 0x318(0x08)
	struct UImage* SliceOverhealDamaged; // 0x320(0x08)
	struct UImage* SliceOverhealFill; // 0x328(0x08)
	struct UImage* SliceOverhealTrim; // 0x330(0x08)
	struct UImage* StandardBG; // 0x338(0x08)
	bool bIsEnemyHealth; // 0x340(0x01)
	enum class EColorVisionDeficiency ColorCorrection; // 0x341(0x01)

	void SequenceEvent__ENTRYPOINTPlayerHealthMeterSegment_2(struct UOverlay* SliceImmuneOverlay); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SequenceEvent__ENTRYPOINTPlayerHealthMeterSegment_2 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SequenceEvent__ENTRYPOINTPlayerHealthMeterSegment_1(struct UOverlay* SliceImmuneOverlay); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SequenceEvent__ENTRYPOINTPlayerHealthMeterSegment_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Get Enemy Health Color By Color Correction(struct FLinearColor& Healthy, struct FLinearColor& HealthyHighlight, struct FLinearColor& Downed, struct FLinearColor& DownedHighlight, struct FLinearColor& DownedEnemyBackground); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.Get Enemy Health Color By Color Correction // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void SetHealthColors(); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SetHealthColors // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetIsDowned(bool IsDowned); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SetIsDowned // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetImmune(bool bEnabled, bool bImmediate); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SetImmune // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetDotVisibility(bool IsVisible); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SetDotVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayDamagePulse(); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.PlayDamagePulse // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetBonusState(bool IsBonus); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SetBonusState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetSliceValues(int32_t Health, int32_t Armor, int32_t Overheal, int32_t Depleted, int32_t Inactive); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.SetSliceValues // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnDisableImmuneParams(struct UOverlay* SliceImmuneOverlay); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.OnDisableImmuneParams // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnEnableImmuneParams(struct UOverlay* SliceImmuneOverlay); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.OnEnableImmuneParams // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_PlayerHealthMeterSegment(int32_t EntryPoint); // Function PlayerHealthMeterSegment.PlayerHealthMeterSegment_C.ExecuteUbergraph_PlayerHealthMeterSegment // (Final|UbergraphFunction) // @ game+0x24d5b40
};

