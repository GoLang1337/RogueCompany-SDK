// WidgetBlueprintGeneratedClass BrightLobbyHeader.BrightLobbyHeader_C
// Size: 0x538 (Inherited: 0x518)
struct UBrightLobbyHeader_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct TArray<enum class EPUMG_LoginState> LoggedOutStates; // 0x520(0x10)
	struct UPUMG_LoginDataFactory* LoginDataFactory; // 0x530(0x08)

	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function BrightLobbyHeader.BrightLobbyHeader_C.StartShowSequence // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleLobbyStartMenuInputAction(); // Function BrightLobbyHeader.BrightLobbyHeader_C.HandleLobbyStartMenuInputAction // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function BrightLobbyHeader.BrightLobbyHeader_C.StartHideSequence // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_BrightLobbyHeader(int32_t EntryPoint); // Function BrightLobbyHeader.BrightLobbyHeader_C.ExecuteUbergraph_BrightLobbyHeader // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

