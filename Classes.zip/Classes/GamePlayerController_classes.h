// BlueprintGeneratedClass GamePlayerController.GamePlayerController_C
// Size: 0xeb8 (Inherited: 0xeb0)
struct AGamePlayerController_C : AGamePlayerControllerNoHUD_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xeb0(0x08)

	void ReceiveBeginPlay(); // Function GamePlayerController.GamePlayerController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveTick(float DeltaSeconds); // Function GamePlayerController.GamePlayerController_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_GamePlayerController(int32_t EntryPoint); // Function GamePlayerController.GamePlayerController_C.ExecuteUbergraph_GamePlayerController // (Final|UbergraphFunction) // @ game+0x24d5b40
};

