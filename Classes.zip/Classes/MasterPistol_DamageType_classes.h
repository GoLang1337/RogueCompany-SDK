// BlueprintGeneratedClass MasterPistol_DamageType.MasterPistol_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UMasterPistol_DamageType_C : UMasterGun_DamageType_C {
};

