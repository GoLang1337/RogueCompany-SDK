// Enum E_RoundEndReason.E_RoundEndReason
enum class E_RoundEndReason : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	E_MAX = 4
};

