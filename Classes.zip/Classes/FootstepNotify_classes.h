// DynamicClass FootstepNotify.FootstepNotify_C
// Size: 0x58 (Inherited: 0x48)
struct UFootstepNotify_C : UKSAnimNotify_Footstep {
	enum class StepType StepType; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	struct FName BoneName; // 0x4c(0x08)
	char pad_54[0x4]; // 0x54(0x04)

	bool Received_Notify(struct USkeletalMeshComponent* bpp__MeshComp__pf, struct UAnimSequenceBase* bpp__Animation__pf); // Function FootstepNotify.FootstepNotify_C.Received_Notify // (Native|Event|Public|BlueprintCallable|Const) // @ game+0x182ed40
	void GetSFXMaterial(struct UAnimInstance* bpp__AnimInstance__pf, struct FName bpp__BonexName__pfT, struct FName& bpp__MaterialxReturn__pfT, struct AActor*& bpp__ActorxReturn__pfT); // Function FootstepNotify.FootstepNotify_C.GetSFXMaterial // (Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x182e390
	struct FName GetBoneName(); // Function FootstepNotify.FootstepNotify_C.GetBoneName // (Native|Event|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x182e350
};

