// DynamicClass ExplosiveStakeMeleeWeaponComponent.ExplosiveStakeMeleeWeaponComponent_C
// Size: 0x15f0 (Inherited: 0x15a0)
struct UExplosiveStakeMeleeWeaponComponent_C : UMasterMelee_WeaponComponent_C {
	bool IsPlayingAbilityVO; // 0x15a0(0x01)
	char pad_15A1[0x3]; // 0x15a1(0x03)
	float K2Node_Event_DeltaSeconds; // 0x15a4(0x04)
	enum class EWeaponStateNew K2Node_Event_OldState; // 0x15a8(0x01)
	enum class EWeaponStateNew K2Node_Event_NewState; // 0x15a9(0x01)
	bool K2Node_SwitchEnum_CmpSuccess; // 0x15aa(0x01)
	char pad_15AB[0x5]; // 0x15ab(0x05)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst; // 0x15b0(0x08)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable; // 0x15b8(0x10)
	struct FName Temp_name_Variable; // 0x15c8(0x08)
	int32_t CallFunc_GetAudioEvent_Priority; // 0x15d0(0x04)
	struct FDelegate Temp_delegate_Variable; // 0x15d4(0x10)
	char pad_15E4[0xc]; // 0x15e4(0x0c)

	void Resolve Combat State when Aiming Throw on Zipline(); // Function ExplosiveStakeMeleeWeaponComponent.ExplosiveStakeMeleeWeaponComponent_C.Resolve Combat State when Aiming Throw on Zipline // (Native|Public|BlueprintCallable) // @ game+0x1822c10
};

