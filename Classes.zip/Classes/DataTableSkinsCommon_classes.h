// Class DataTableSkinsCommon.DynamicSkinTable
// Size: 0x298 (Inherited: 0x28)
struct UDynamicSkinTable : UObject {
	struct TArray<struct FDataTableInfo> ActiveDataTables; // 0x28(0x10)
	struct TArray<struct FDataTableInfo> InactiveDataTables; // 0x38(0x10)
	struct FMulticastInlineDelegate OnFinishedAllPendingLoadsDel; // 0x48(0x10)
	char pad_58[0x220]; // 0x58(0x220)
	char bWantsToBeRecycled : 1; // 0x278(0x01)
	char pad_278_1 : 7; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
	struct TScriptInterface<ISkinTagAssetInterface> SkinTagAsset; // 0x280(0x10)
	char pad_290[0x8]; // 0x290(0x08)

	void RemoveDataTables(struct TArray<struct UDataTable*>& InTables); // Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTables // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc51b60
	void RemoveDataTable(struct UDataTable* InTable); // Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTable // (Final|Native|Public|BlueprintCallable) // @ game+0xc51ae0
	bool IsTablePendingAssetLoad(); // Function DataTableSkinsCommon.DynamicSkinTable.IsTablePendingAssetLoad // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51ab0
	struct UTexture* GetTexture(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51910
	struct UStaticMesh* GetStaticMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetStaticMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51770
	struct USkeletalMesh* GetSkeletalMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetSkeletalMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51590
	struct USelectiveAkAudioEvent* GetSelectiveAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetSelectiveAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc513f0
	struct UPoseAsset* GetPoseAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetPoseAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51250
	struct UPhysicsAsset* GetPhysicsAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetPhysicsAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc510b0
	struct UParticleSystem* GetParticleSystem(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetParticleSystem // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50f10
	struct FName GetNameField(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetNameField // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50d50
	struct UMaterialInterface* GetMaterialInterface(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetMaterialInterface // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50bb0
	struct FLinearColor GetLinearColor(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetLinearColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xc509f0
	int32_t GetInt(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50850
	float GetFloat(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc506b0
	struct UObject* GetClass(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50510
	bool GetBool(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50370
	struct UAkAudioEvent* GetAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc501d0
	struct UAnimSequence* GetAnimSequence(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimSequence // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4ff60
	struct UAnimMontage* GetAnimMontage(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimMontage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4fdc0
	struct UBlendSpace* GetAnimBlendSpace(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimBlendSpace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4fc20
	struct UAnimationAsset* GetAnimationAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimationAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50100
	struct UAimOffsetBlendSpace* GetAnimAimOffset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimAimOffset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4fa80
	void GetAllKeywords(struct TSet<struct FName>& InOutKeywords); // Function DataTableSkinsCommon.DynamicSkinTable.GetAllKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4f820
	void AddDataTableWithQuery(struct UDataTable* InTable, int32_t InPriority, struct FGameplayTagQuery& InQuery); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTableWithQuery // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc4f490
	void AddDataTables(struct TArray<struct FDataTableInfo>& InTableInfos); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTables // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc4f5f0
	void AddDataTable(struct UDataTable* InTable, int32_t InPriority); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTable // (Final|Native|Public|BlueprintCallable) // @ game+0xc4f3d0
};

// Class DataTableSkinsCommon.MultiSkinObject
// Size: 0x1d0 (Inherited: 0x28)
struct UMultiSkinObject : UObject {
	struct TArray<struct UMultiSkinObject*> ParentSkinnedObjects; // 0x28(0x10)
	struct TArray<struct TWeakObjectPtr<struct UMultiSkinObject>> ChildSkinnedObjects; // 0x38(0x10)
	struct TSet<struct FName> SubscribedKeywords; // 0x48(0x50)
	struct TSet<struct FName> SubscribedMaterialPrefixes; // 0x98(0x50)
	char bSubscribeToAllKeywords : 1; // 0xe8(0x01)
	char bWantsToBeRecycled : 1; // 0xe8(0x01)
	char pad_E8_2 : 6; // 0xe8(0x01)
	char pad_E9[0x1f]; // 0xe9(0x1f)
	struct FMulticastInlineDelegate OnFinishedAllPendingLoadsDel; // 0x108(0x10)
	char pad_118[0x18]; // 0x118(0x18)
	struct TMap<int32_t, struct FDynamicSkinTableMapEntry> DynamicSkinTables; // 0x130(0x50)
	struct TMap<struct FName, struct FCachedRowsEntry> CachedRows; // 0x180(0x50)

	void UnsubscribeToKeywords(struct TArray<struct FName>& InKeywords); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc53320
	void UnsubscribeToKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeyword // (Final|Native|Public|BlueprintCallable) // @ game+0xc532a0
	void UnsubscribeToAllKeywords(); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToAllKeywords // (Final|Native|Public|BlueprintCallable) // @ game+0xc53280
	void SubscribeToKeywords(struct TArray<struct FName>& InKeywords); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc531d0
	void SubscribeToKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeyword // (Final|Native|Public|BlueprintCallable) // @ game+0xc53150
	void SubscribeToAllKeywords(); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToAllKeywords // (Final|Native|Public|BlueprintCallable) // @ game+0xc53130
	void RemoveParent(struct UMultiSkinObject* InParent); // Function DataTableSkinsCommon.MultiSkinObject.RemoveParent // (Final|Native|Public|BlueprintCallable) // @ game+0xc51c10
	struct UTexture* GetTexture(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc519e0
	struct UStaticMesh* GetStaticMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetStaticMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51840
	struct USkeletalMesh* GetSkeletalMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetSkeletalMesh // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51660
	struct USelectiveAkAudioEvent* GetSelectiveAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetSelectiveAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc514c0
	struct UPoseAsset* GetPoseAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetPoseAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51320
	struct UPhysicsAsset* GetPhysicsAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetPhysicsAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51180
	struct UParticleSystem* GetParticleSystem(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetParticleSystem // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50fe0
	struct FName GetNameField(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetNameField // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50e30
	struct UMaterialInterface* GetMaterialInterface(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetMaterialInterface // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50c80
	struct FLinearColor GetLinearColor(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetLinearColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50ad0
	int32_t GetInt(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50920
	float GetFloat(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50780
	struct UObject* GetClass(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc505e0
	bool GetBool(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50440
	struct UAkAudioEvent* GetAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAudioEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc502a0
	struct UAnimSequence* GetAnimSequence(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimSequence // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc50030
	struct UAnimMontage* GetAnimMontage(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimMontage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4fe90
	struct UBlendSpace* GetAnimBlendSpace(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimBlendSpace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4fcf0
	struct UAimOffsetBlendSpace* GetAnimAimOffset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimAimOffset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4fb50
	void GetAllSkinKeywords(struct TSet<struct FName>& InOutKeywords); // Function DataTableSkinsCommon.MultiSkinObject.GetAllSkinKeywords // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xc4f950
	void AddParent(struct UMultiSkinObject* InParent); // Function DataTableSkinsCommon.MultiSkinObject.AddParent // (Final|Native|Public|BlueprintCallable) // @ game+0xc4f6f0
};

// Class DataTableSkinsCommon.SkinnableSkeletalMeshComponent
// Size: 0xd00 (Inherited: 0xbb0)
struct USkinnableSkeletalMeshComponent : USkeletalMeshComponentBudgeted {
	bool bDelaySkinUpdatesUntilTick; // 0xbb0(0x01)
	bool bSkinUpdateIsQueued; // 0xbb1(0x01)
	char pad_BB2[0x2]; // 0xbb2(0x02)
	struct FName SkeletalMeshKeyword; // 0xbb4(0x08)
	char pad_BBC[0x4]; // 0xbbc(0x04)
	struct USkeletalMesh* FailSafeSkeletalMesh; // 0xbc0(0x08)
	struct FName PhysicsAssetKeyword; // 0xbc8(0x08)
	struct UPhysicsAsset* FailSafePhysicsAsset; // 0xbd0(0x08)
	struct FName AnimInstanceClassKeyword; // 0xbd8(0x08)
	struct UAnimInstance* FailSafeAnimClass; // 0xbe0(0x08)
	struct UAnimInstance* LastSkinnedAnimClass; // 0xbe8(0x08)
	bool bForceAnimationUpdateOnSkinUpdate; // 0xbf0(0x01)
	char pad_BF1[0x7]; // 0xbf1(0x07)
	struct UMultiSkinObject* SkinObject; // 0xbf8(0x08)
	struct FMulticastInlineDelegate OnAnimInitializedOnSkinnableMeshDel; // 0xc00(0x10)
	char pad_C10[0x30]; // 0xc10(0x30)
	bool bAllowMaterialSkinning; // 0xc40(0x01)
	char pad_C41[0x7]; // 0xc41(0x07)
	struct TArray<struct FString> MaterialSkinningPrefixes; // 0xc48(0x10)
	struct TSet<struct FName> MaterialSkinningPrefixes_New; // 0xc58(0x50)
	char pad_CA8[0x48]; // 0xca8(0x48)
	int32_t ForcedLodModel_Skinned; // 0xcf0(0x04)
	char pad_CF4[0xc]; // 0xcf4(0x0c)

	void StaticSetForcedLOD(struct USkinnedMeshComponent* InMeshComp, int32_t InForcedLOD); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.StaticSetForcedLOD // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xc53080
	void SetSkeletalMeshKeyword(struct FName InKeyword, struct USkeletalMesh* InFailSafeSkeletalMesh); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetSkeletalMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0xc52de0
	void SetPhysicsAssetKeyword(struct FName InKeyword, struct UPhysicsAsset* InFailSafePhysicsAsset); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPhysicsAssetKeyword // (Native|Public|BlueprintCallable) // @ game+0xc52d10
	int32_t SetPersistentVectorParameterOnAllMaterials(struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentVectorParameterOnAllMaterials // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xc52b50
	int32_t SetPersistentVectorParameter(int32_t MaterialSlot, struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentVectorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xc52930
	int32_t SetPersistentTextureParameterOnAllMaterials(struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentTextureParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0xc527b0
	int32_t SetPersistentTextureParameter(int32_t MaterialSlot, struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentTextureParameter // (Final|Native|Public|BlueprintCallable) // @ game+0xc525b0
	int32_t SetPersistentScalarParameterOnAllMaterials(struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentScalarParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0xc52410
	int32_t SetPersistentScalarParameter(int32_t MaterialSlot, struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentScalarParameter // (Final|Native|Public|BlueprintCallable) // @ game+0xc52210
	int32_t SetPersistentMaterialOverrideOnAllSlots(struct UMaterialInterface* MaterialInterface); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentMaterialOverrideOnAllSlots // (Final|Native|Public|BlueprintCallable) // @ game+0xc520f0
	int32_t SetPersistentMaterialOverride(int32_t MaterialSlot, struct UMaterialInterface* MaterialInterface); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentMaterialOverride // (Final|Native|Public|BlueprintCallable) // @ game+0xc51f70
	void SetForcedLOD_Skinned(int32_t InNewForcedLOD); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetForcedLOD_Skinned // (Final|Native|Public|BlueprintCallable) // @ game+0xc51ef0
	void SetAnimClassKeyword(struct FName InKeyword, struct UAnimInstance* InFailSafeAnimClass); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetAnimClassKeyword // (Native|Public|BlueprintCallable) // @ game+0xc51e20
	void RemovePersistentMaterialParameter(int32_t ParameterId); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.RemovePersistentMaterialParameter // (Final|Native|Public|BlueprintCallable) // @ game+0xc51c90
	struct UMultiSkinObject* GetSkinObject(); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.GetSkinObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51730
	void ForwardAnimInitialized(); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ForwardAnimInitialized // (Final|Native|Private) // @ game+0xc4f800
};

// Class DataTableSkinsCommon.SkinnableMergedMeshComponent
// Size: 0xd50 (Inherited: 0xd00)
struct USkinnableMergedMeshComponent : USkinnableSkeletalMeshComponent {
	struct FMulticastInlineDelegate OnMeshMergeComplete; // 0xcf8(0x10)
	struct TArray<struct FName> CompositeSkeletalMeshKeywords; // 0xd08(0x10)
	bool bAlwaysUseTheFailsafeMeshWhileMerging; // 0xd18(0x01)
	struct FName MeshNeedsCPUAccessKeyword; // 0xd1c(0x08)
	bool bDelayFullSkinUpdateUntilMeshMergingIsComplete; // 0xd24(0x01)
	struct USkeletalMesh* BestPlaceHolderMesh; // 0xd28(0x08)
	bool bMergeMarkedComplete; // 0xd30(0x01)
	char pad_D33[0x5]; // 0xd33(0x05)
	struct USkeletalMesh* CachedMergeResult; // 0xd38(0x08)
	char pad_D40[0x10]; // 0xd40(0x10)

	void SetSkeletalMeshKeywords(struct TArray<struct FName>& InKeywords, struct USkeletalMesh* InFailSafeSkeletalMesh); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.SetSkeletalMeshKeywords // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc52eb0
	void RemoveSkeletalMeshKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.RemoveSkeletalMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0xc51d90
	void OnMeshMergeComplete__DelegateSignature(); // DelegateFunction DataTableSkinsCommon.SkinnableMergedMeshComponent.OnMeshMergeComplete__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24d5b40
	void AddSkeletalMeshKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.AddSkeletalMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0xc4f770
};

// Class DataTableSkinsCommon.SkinnableStaticMeshComponent
// Size: 0x5b0 (Inherited: 0x4f0)
struct USkinnableStaticMeshComponent : UStaticMeshComponent {
	bool bDelaySkinUpdatesUntilTick; // 0x4e8(0x01)
	bool bSkinUpdateIsQueued; // 0x4e9(0x01)
	struct FName StaticMeshKeyword; // 0x4ec(0x08)
	struct UStaticMesh* FailSafeStaticMesh; // 0x4f8(0x08)
	struct UMultiSkinObject* SkinObject; // 0x500(0x08)
	bool bAllowMaterialSkinning; // 0x508(0x01)
	char pad_50B[0x5]; // 0x50b(0x05)
	struct TSet<struct FName> MaterialSkinningPrefixes; // 0x510(0x50)
	char pad_560[0x50]; // 0x560(0x50)

	void SetStaticMeshKeyword(struct FName InKeyword, struct UStaticMesh* InFailSafeStaticMesh); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetStaticMeshKeyword // (Native|Public|BlueprintCallable) // @ game+0xc52fb0
	int32_t SetPersistentVectorParameterOnAllMaterials(struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameterOnAllMaterials // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xc52c30
	int32_t SetPersistentVectorParameter(int32_t MaterialSlot, struct FName ParameterName, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameter // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xc52a40
	int32_t SetPersistentTextureParameterOnAllMaterials(struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0xc52870
	int32_t SetPersistentTextureParameter(int32_t MaterialSlot, struct FName ParameterName, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameter // (Final|Native|Public|BlueprintCallable) // @ game+0xc526b0
	int32_t SetPersistentScalarParameterOnAllMaterials(struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameterOnAllMaterials // (Final|Native|Public|BlueprintCallable) // @ game+0xc524e0
	int32_t SetPersistentScalarParameter(int32_t MaterialSlot, struct FName ParameterName, float ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameter // (Final|Native|Public|BlueprintCallable) // @ game+0xc52310
	int32_t SetPersistentMaterialOverrideOnAllSlots(struct UMaterialInterface* MaterialInterface); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentMaterialOverrideOnAllSlots // (Final|Native|Public|BlueprintCallable) // @ game+0xc52180
	int32_t SetPersistentMaterialOverride(int32_t MaterialSlot, struct UMaterialInterface* MaterialInterface); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentMaterialOverride // (Final|Native|Public|BlueprintCallable) // @ game+0xc52030
	void RemovePersistentMaterialParameter(int32_t ParameterId); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.RemovePersistentMaterialParameter // (Final|Native|Public|BlueprintCallable) // @ game+0xc51d10
	struct UMultiSkinObject* GetSkinObject(); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.GetSkinObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc51750
};

// Class DataTableSkinsCommon.SkinObjectManagerComponent
// Size: 0x150 (Inherited: 0xb0)
struct USkinObjectManagerComponent : UActorComponent {
	struct TMap<struct FName, struct UMultiSkinObject*> SkinObjects; // 0xb0(0x50)
	struct TSet<struct UMultiSkinObject*> SkinObjectsSet; // 0x100(0x50)
};

// Class DataTableSkinsCommon.SkinTagAssetInterface
// Size: 0x28 (Inherited: 0x28)
struct USkinTagAssetInterface : UInterface {
};

