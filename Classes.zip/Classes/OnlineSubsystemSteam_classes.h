// Class OnlineSubsystemSteam.SteamAuthComponentModuleInterface
// Size: 0x28 (Inherited: 0x28)
struct USteamAuthComponentModuleInterface : UHandlerComponentFactory {
};

// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x1b28 (Inherited: 0x1b20)
struct USteamNetConnection : UIpConnection {
	bool bIsPassthrough; // 0x1b20(0x01)
	char pad_1B21[0x7]; // 0x1b21(0x07)
};

// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x7f0 (Inherited: 0x7e8)
struct USteamNetDriver : UIpNetDriver {
	char pad_7E8[0x8]; // 0x7e8(0x08)
};

