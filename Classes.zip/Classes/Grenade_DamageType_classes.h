// BlueprintGeneratedClass Grenade_DamageType.Grenade_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UGrenade_DamageType_C : UMasterExplosion_DamageType_C {
};

