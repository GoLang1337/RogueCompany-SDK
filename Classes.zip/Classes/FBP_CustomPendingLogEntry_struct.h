// ScriptStruct FBP_CustomPendingLogEntry.FBP_CustomPendingLogEntry
// Size: 0x18 (Inherited: 0x00)
struct FFBP_CustomPendingLogEntry {
	struct UKSPlayerInfo* PlayerInfo_2_4CDA19BE44095765294C98812FFACA2A; // 0x00(0x08)
	struct TArray<struct FText> Logs_6_441E60114FCBB05DF4DBFB833D073740; // 0x08(0x10)
};

