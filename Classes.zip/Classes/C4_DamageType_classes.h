// BlueprintGeneratedClass C4_DamageType.C4_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UC4_DamageType_C : UMasterExplosion_DamageType_C {
};

