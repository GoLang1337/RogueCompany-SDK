// WidgetBlueprintGeneratedClass NamePromptTempClone.NamePromptTempClone_C
// Size: 0x550 (Inherited: 0x518)
struct UNamePromptTempClone_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UTextBlock* ErrorMessageDisplay; // 0x520(0x08)
	struct UImage* Image_144; // 0x528(0x08)
	struct UEditableTextBox* PlayerName; // 0x530(0x08)
	struct UPopupButton_C* PopupButton_C_371; // 0x538(0x08)
	struct UImage* WarningIcon; // 0x540(0x08)
	struct UPUMG_LoginDataFactory* LoginDataFac; // 0x548(0x08)

	void BndEvt__PlayerName_K2Node_ComponentBoundEvent_0_OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Function NamePromptTempClone.NamePromptTempClone_C.BndEvt__PlayerName_K2Node_ComponentBoundEvent_0_OnEditableTextBoxCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__PopupButton_C_370_K2Node_ComponentBoundEvent_25_OnClicked__DelegateSignature(int32_t Index); // Function NamePromptTempClone.NamePromptTempClone_C.BndEvt__PopupButton_C_370_K2Node_ComponentBoundEvent_25_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void HandleErrorMessage(struct FText MessageText, int32_t MessageId); // Function NamePromptTempClone.NamePromptTempClone_C.HandleErrorMessage // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function NamePromptTempClone.NamePromptTempClone_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_NamePromptTempClone(int32_t EntryPoint); // Function NamePromptTempClone.NamePromptTempClone_C.ExecuteUbergraph_NamePromptTempClone // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

