// BlueprintGeneratedClass BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C
// Size: 0x6b8 (Inherited: 0x6b0)
struct ABP_BrightLobbyHUDMinimal_C : AKSLobbyHUDNew {
	struct USceneComponent* DefaultSceneRoot; // 0x6b0(0x08)

	void CallRemoveTopViewRoute(bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C.CallRemoveTopViewRoute // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void CallAddViewRoute(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C.CallAddViewRoute // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

