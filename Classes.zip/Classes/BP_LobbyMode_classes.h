// BlueprintGeneratedClass BP_LobbyMode.BP_LobbyMode_C
// Size: 0x3d0 (Inherited: 0x3c8)
struct ABP_LobbyMode_C : APGame_GameModeBase {
	struct USceneComponent* DefaultSceneRoot; // 0x3c8(0x08)
};

