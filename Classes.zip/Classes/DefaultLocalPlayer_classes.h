// BlueprintGeneratedClass DefaultLocalPlayer.DefaultLocalPlayer_C
// Size: 0x298 (Inherited: 0x298)
struct UDefaultLocalPlayer_C : UKSLocalPlayer {
};

