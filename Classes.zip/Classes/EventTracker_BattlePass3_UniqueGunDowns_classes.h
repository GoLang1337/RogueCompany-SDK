// BlueprintGeneratedClass EventTracker_BattlePass3_UniqueGunDowns.EventTracker_BattlePass3_UniqueGunDowns_C
// Size: 0x230 (Inherited: 0x208)
struct UEventTracker_BattlePass3_UniqueGunDowns_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	struct TArray<int32_t> ItemIds; // 0x210(0x10)
	struct TArray<int32_t> LootTableItemIds; // 0x220(0x10)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_BattlePass3_UniqueGunDowns.EventTracker_BattlePass3_UniqueGunDowns_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void OwnedPawnInstigateDamage(struct FCombatEventInfo& DamageInfo); // Function EventTracker_BattlePass3_UniqueGunDowns.EventTracker_BattlePass3_UniqueGunDowns_C.OwnedPawnInstigateDamage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_BattlePass3_UniqueGunDowns(int32_t EntryPoint); // Function EventTracker_BattlePass3_UniqueGunDowns.EventTracker_BattlePass3_UniqueGunDowns_C.ExecuteUbergraph_EventTracker_BattlePass3_UniqueGunDowns // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

