// Class CensorAssets.CensorTable
// Size: 0x40 (Inherited: 0x28)
struct UCensorTable : UObject {
	struct FSoftObjectPath CensorTablePath; // 0x28(0x18)
};

