// BlueprintGeneratedClass P12K_CameraShake_Hipfire.P12K_CameraShake_Hipfire_C
// Size: 0x160 (Inherited: 0x160)
struct UP12K_CameraShake_Hipfire_C : UCameraShake {
};

