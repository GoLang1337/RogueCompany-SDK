// BlueprintGeneratedClass RogueScreenPreviewActor_WithPose.RogueScreenPreviewActor_WithPose_C
// Size: 0x518 (Inherited: 0x518)
struct ARogueScreenPreviewActor_WithPose_C : ARogueScreenPreviewActor_C {

	struct AKSLobbyCharacter* GetLobbyCharacterClassToUse(struct UKSJobItem* JobToUse, struct UKSSkinBundle* SkinToUse); // Function RogueScreenPreviewActor_WithPose.RogueScreenPreviewActor_WithPose_C.GetLobbyCharacterClassToUse // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

