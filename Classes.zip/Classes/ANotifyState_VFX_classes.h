// BlueprintGeneratedClass ANotifyState_VFX.ANotifyState_VFX_C
// Size: 0x68 (Inherited: 0x30)
struct UANotifyState_VFX_C : UAnimNotifyState {
	struct UParticleSystem* ParticleSystem; // 0x30(0x08)
	struct FVector LocationOffset; // 0x38(0x0c)
	struct FRotator RotationOffset; // 0x44(0x0c)
	struct FVector Scale; // 0x50(0x0c)
	bool Attached; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	struct FName SocketName; // 0x60(0x08)

	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_VFX.ANotifyState_VFX_C.Received_NotifyBegin // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_VFX.ANotifyState_VFX_C.Received_NotifyEnd // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

