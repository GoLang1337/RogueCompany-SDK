// ScriptStruct FBP_CustomMatchTeam.FBP_CustomMatchTeam
// Size: 0x28 (Inherited: 0x00)
struct FFBP_CustomMatchTeam {
	int32_t TeamID_7_BAB34AE24596157B7EFD959A8D453F62; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FPUMG_CustomMatchMember> Members_3_15C42158406155E59954E2A8A801EA3D; // 0x08(0x10)
	struct TArray<struct UKSWidget*> Widgets_11_6E324FD94AEEDB2A614F75A909EA63D9; // 0x18(0x10)
};

