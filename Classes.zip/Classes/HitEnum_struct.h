// Enum HitEnum.HitEnum
enum class HitEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	HitEnum_MAX = 4
};

