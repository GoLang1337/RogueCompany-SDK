// WidgetBlueprintGeneratedClass NewMenuMain.NewMenuMain_C
// Size: 0x568 (Inherited: 0x518)
struct UNewMenuMain_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWidgetAnimation* Hover; // 0x520(0x08)
	struct UOverlay* Button; // 0x528(0x08)
	struct UOverlay* ContentWrapper; // 0x530(0x08)
	struct UButton* HitTarget; // 0x538(0x08)
	struct UImage* Icon; // 0x540(0x08)
	struct FName LastRoute; // 0x548(0x08)
	struct FName CurrentRoute; // 0x550(0x08)
	struct UAkAudioEvent* HoveredNewMenuMainSFX; // 0x558(0x08)
	struct UAkAudioEvent* ClickNewMenuMainSFX; // 0x560(0x08)

	void OnInputStateChanged(enum class PGAME_INPUT_STATE InputState); // Function NewMenuMain.NewMenuMain_C.OnInputStateChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HideMenuButtonFinished(); // Function NewMenuMain.NewMenuMain_C.HideMenuButtonFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HideMenuButtonAnim(float ElapsedTime, float ElapsedAlpha); // Function NewMenuMain.NewMenuMain_C.HideMenuButtonAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitHideAnimation(); // Function NewMenuMain.NewMenuMain_C.InitHideAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StartShowAnim(); // Function NewMenuMain.NewMenuMain_C.StartShowAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeTickAnimations(); // Function NewMenuMain.NewMenuMain_C.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void StartHideAnim(); // Function NewMenuMain.NewMenuMain_C.StartHideAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function NewMenuMain.NewMenuMain_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function NewMenuMain.NewMenuMain_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function NewMenuMain.NewMenuMain_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ShowMenuButtonFinished(); // Function NewMenuMain.NewMenuMain_C.ShowMenuButtonFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ShowMenuButtonAnim(float ElapsedTime, float ElapsedAlpha); // Function NewMenuMain.NewMenuMain_C.ShowMenuButtonAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnInitialized(); // Function NewMenuMain.NewMenuMain_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_NewMenuMain(int32_t EntryPoint); // Function NewMenuMain.NewMenuMain_C.ExecuteUbergraph_NewMenuMain // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

