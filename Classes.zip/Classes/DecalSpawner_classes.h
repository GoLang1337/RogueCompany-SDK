// BlueprintGeneratedClass DecalSpawner.DecalSpawner_C
// Size: 0xd8 (Inherited: 0xb0)
struct UDecalSpawner_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct UMaterialInterface* Decal Material; // 0xb8(0x08)
	struct FVector Size; // 0xc0(0x0c)
	struct FVector Relative Location; // 0xcc(0x0c)

	void Spawn(struct FRotator Rotation, float Lifetime); // Function DecalSpawner.DecalSpawner_C.Spawn // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SpawnRandomRotation(float Lifetime); // Function DecalSpawner.DecalSpawner_C.SpawnRandomRotation // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SpawnRaycastRandomRotation(float Lifetime, struct FVector Direction); // Function DecalSpawner.DecalSpawner_C.SpawnRaycastRandomRotation // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SpawnRaycast(struct FVector Direction, struct FRotator Rotation, float Lifetime); // Function DecalSpawner.DecalSpawner_C.SpawnRaycast // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Reset(); // Function DecalSpawner.DecalSpawner_C.Reset // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function DecalSpawner.DecalSpawner_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_DecalSpawner(int32_t EntryPoint); // Function DecalSpawner.DecalSpawner_C.ExecuteUbergraph_DecalSpawner // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

