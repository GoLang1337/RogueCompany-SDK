// ScriptStruct NavButtonData.NavButtonData
// Size: 0x28 (Inherited: 0x00)
struct FNavButtonData {
	struct FText Label_5_E708A15F41F9928931B559975526FEF6; // 0x00(0x18)
	struct FName ViewRoute_15_BA6F69D240B98E901BBFCA85C785392C; // 0x18(0x08)
	bool Disabled_1_7035040B4C82B313E854728D83CA821B; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

