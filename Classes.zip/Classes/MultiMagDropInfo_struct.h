// ScriptStruct MultiMagDropInfo.MultiMagDropInfo
// Size: 0x60 (Inherited: 0x00)
struct FMultiMagDropInfo {
	struct FName DropBone_2_2CFC9A8F4F2664ED22B08296FB92E731; // 0x00(0x08)
	bool DropBoneOnWeapon_5_BC9F11844B79F021078C9BA149D169AA; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UStaticMesh* DropMesh_15_6B58EE524E651CF10CEB8EA7288C667F; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct FTransform DropMultiMagSpawnOffset_21_594C51714E03815BC1D89E92B11A2550; // 0x20(0x30)
	struct FVector DropMultiMagVelocityOverride_22_71C6708D4D1C99CFB8A9DF90ED02BA49; // 0x50(0x0c)
	char pad_5C[0x4]; // 0x5c(0x04)
};

