// BlueprintGeneratedClass EventTracker_Reputation.EventTracker_Reputation_C
// Size: 0x238 (Inherited: 0x208)
struct UEventTracker_Reputation_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	struct AKSPlayerState* PlayerState; // 0x210(0x08)
	float BaseProgress; // 0x218(0x04)
	float AccumulatedProgress; // 0x21c(0x04)
	float ReputationPerMinute; // 0x220(0x04)
	float WinMultiplier; // 0x224(0x04)
	struct FString BonusKey; // 0x228(0x10)

	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessBoosterBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessEventBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_Reputation.EventTracker_Reputation_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessWinBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessQueueBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ComputeBaseProgress // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Reputation.EventTracker_Reputation_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Reputation.EventTracker_Reputation_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_Reputation.EventTracker_Reputation_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Reputation(int32_t EntryPoint); // Function EventTracker_Reputation.EventTracker_Reputation_C.ExecuteUbergraph_EventTracker_Reputation // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

