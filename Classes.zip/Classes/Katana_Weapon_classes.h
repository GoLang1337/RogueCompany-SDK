// BlueprintGeneratedClass Katana_Weapon.Katana_Weapon_C
// Size: 0x900 (Inherited: 0x900)
struct AKatana_Weapon_C : AWeapon_Melee_C {
};

