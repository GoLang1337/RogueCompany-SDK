// ScriptStruct HiRezAnimGraphRuntime.AnimNode_BlendByDedicatedServer
// Size: 0x48 (Inherited: 0x20)
struct FAnimNode_BlendByDedicatedServer : FAnimNode_Base {
	struct FPoseLink NotDedicatedServer; // 0x20(0x10)
	struct FPoseLink DedicatedServer; // 0x30(0x10)
	char pad_40[0x8]; // 0x40(0x08)
};

// ScriptStruct HiRezAnimGraphRuntime.AnimNode_BlendByLOD
// Size: 0xb0 (Inherited: 0xa8)
struct FAnimNode_BlendByLOD : FAnimNode_BlendListBase {
	int32_t LOD; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct HiRezAnimGraphRuntime.AnimNode_RigidBodySkipServer
// Size: 0x5b0 (Inherited: 0x5b0)
struct FAnimNode_RigidBodySkipServer : FAnimNode_RigidBody {
	bool bIsDedicatedServer; // 0x5a8(0x01)
};

