// Enum ESpeed.ESpeed
enum class ESpeed : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ESpeed_MAX = 3
};

