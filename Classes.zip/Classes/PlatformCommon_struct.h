// Enum PlatformCommon.EPCOM_SessionUpdateEvent
enum class EPCOM_SessionUpdateEvent : uint8 {
	Unknown = 0,
	JoinFailure = 1,
	JoinFailure_NoOpenConnections = 2,
	JoinFailure_SessionNotAvailable = 3,
	JoinSuccess = 4,
	EPCOM_MAX = 5
};

// Enum PlatformCommon.EPCOM_PrivilegeStatus
enum class EPCOM_PrivilegeStatus : uint8 {
	Unchecked = 0,
	Pending = 1,
	Denied = 2,
	Allowed = 3,
	EPCOM_MAX = 4
};

// ScriptStruct PlatformCommon.SerializedMctsNetId
// Size: 0x08 (Inherited: 0x00)
struct FSerializedMctsNetId {
	uint64_t A; // 0x00(0x08)
};

// ScriptStruct PlatformCommon.SerializedMatchId
// Size: 0x10 (Inherited: 0x00)
struct FSerializedMatchId {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct PlatformCommon.SerializedInstanceId
// Size: 0x10 (Inherited: 0x00)
struct FSerializedInstanceId {
	char pad_0[0x10]; // 0x00(0x10)
};

