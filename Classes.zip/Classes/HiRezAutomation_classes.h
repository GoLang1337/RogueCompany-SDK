// Class HiRezAutomation.PGame_PerformanceCaptureSettings
// Size: 0x70 (Inherited: 0x28)
struct UPGame_PerformanceCaptureSettings : UObject {
	float FOV; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FString> StatsToCollect; // 0x30(0x10)
	struct TArray<struct FString> MapsToProfile; // 0x40(0x10)
	float StartingOffsetTime; // 0x50(0x04)
	int32_t NumberOfSamples; // 0x54(0x04)
	float TimeBetweenSamples; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TArray<struct FPGame_PerformanceCaptureProfile> Profiles; // 0x60(0x10)
};

// Class HiRezAutomation.PerfSpline
// Size: 0x2d0 (Inherited: 0x220)
struct APerfSpline : AActor {
	struct USplineComponent* SplineCamPosComponent; // 0x220(0x08)
	struct AActor* CamComponent; // 0x228(0x08)
	struct USplineComponent* SplineCamLookAtComponent; // 0x230(0x08)
	float SplineDuration; // 0x238(0x04)
	int32_t NumOfCaptures; // 0x23c(0x04)
	char pad_240[0x90]; // 0x240(0x90)

	void InitPerfMovementAndCapture(); // Function HiRezAutomation.PerfSpline.InitPerfMovementAndCapture // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void CaptureStats(); // Function HiRezAutomation.PerfSpline.CaptureStats // (Final|Native|Public|BlueprintCallable) // @ game+0xa6a770
};

