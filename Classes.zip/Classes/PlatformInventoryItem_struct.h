// Enum PlatformInventoryItem.EExternalSkuSource
enum class EExternalSkuSource : uint8 {
	ESS_No_Souce = 0,
	ESS_Sony = 1,
	ESS_Nintendo = 2,
	ESS_Microsoft_Xbox = 3,
	ESS_Microsoft_Xbox_GDK = 4,
	ESS_Epic = 5,
	ESS_Valve = 6,
	ESS_MAX = 7
};

// ScriptStruct PlatformInventoryItem.IconReference
// Size: 0x70 (Inherited: 0x00)
struct FIconReference {
	struct FName IconType; // 0x00(0x08)
	struct TSoftObjectPtr<UTexture2D> Icon; // 0x08(0x28)
	struct FSoftObjectPath IconPath; // 0x30(0x18)
	struct TSoftObjectPtr<UTexture2D> LegacySoftTexture; // 0x48(0x28)
};

