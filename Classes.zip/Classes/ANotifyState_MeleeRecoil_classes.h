// BlueprintGeneratedClass ANotifyState_MeleeRecoil.ANotifyState_MeleeRecoil_C
// Size: 0x90 (Inherited: 0x30)
struct UANotifyState_MeleeRecoil_C : UAnimNotifyState {
	struct FRecoilInfo Melee Swing Recoil; // 0x30(0x60)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_MeleeRecoil.ANotifyState_MeleeRecoil_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_MeleeRecoil.ANotifyState_MeleeRecoil_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

