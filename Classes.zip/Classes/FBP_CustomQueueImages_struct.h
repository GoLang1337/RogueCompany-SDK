// ScriptStruct FBP_CustomQueueImages.FBP_CustomQueueImages
// Size: 0x10 (Inherited: 0x00)
struct FFBP_CustomQueueImages {
	int32_t QueueId_2_82475B2249830443CA7F8B9358C2DF6C; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UTexture2D* QueueImage_5_50476DB54010C8D7D4A60A87F29551A7; // 0x08(0x08)
};

