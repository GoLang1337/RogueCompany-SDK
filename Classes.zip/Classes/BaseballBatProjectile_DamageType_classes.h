// BlueprintGeneratedClass BaseballBatProjectile_DamageType.BaseballBatProjectile_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UBaseballBatProjectile_DamageType_C : UMasterMelee_DamageType_C {
};

