// BlueprintGeneratedClass LobbyAnnouncer.LobbyAnnouncer_C
// Size: 0x380 (Inherited: 0x340)
struct ALobbyAnnouncer_C : AKSAnnouncer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x340(0x08)
	struct UAkAudioEvent* Play Music Event; // 0x348(0x08)
	struct UAkAudioEvent* Stop Music Event; // 0x350(0x08)
	struct UAkAudioEvent* Lobby Music Start Event; // 0x358(0x08)
	struct UAkAudioEvent* Lobby Match Found Event; // 0x360(0x08)
	struct UAkAudioEvent* Lobby To Loading Screen Event; // 0x368(0x08)
	struct UAkAudioEvent* Lobby End of Match; // 0x370(0x08)
	struct UKSGameInstance* GameInstance; // 0x378(0x08)

	void OnLoadingScreenEnded(); // Function LobbyAnnouncer.LobbyAnnouncer_C.OnLoadingScreenEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnLobbyWidgetReady(); // Function LobbyAnnouncer.LobbyAnnouncer_C.OnLobbyWidgetReady // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function LobbyAnnouncer.LobbyAnnouncer_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnViewStateChangedStarted(struct FName CurrentRoute, struct FName NextRoute, enum class EViewManagerLayer Layer); // Function LobbyAnnouncer.LobbyAnnouncer_C.OnViewStateChangedStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function LobbyAnnouncer.LobbyAnnouncer_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void EventQueueInGame(); // Function LobbyAnnouncer.LobbyAnnouncer_C.EventQueueInGame // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LobbyAnnouncer(int32_t EntryPoint); // Function LobbyAnnouncer.LobbyAnnouncer_C.ExecuteUbergraph_LobbyAnnouncer // (Final|UbergraphFunction) // @ game+0x24d5b40
};

