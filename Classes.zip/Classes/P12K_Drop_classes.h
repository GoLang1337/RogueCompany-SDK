// BlueprintGeneratedClass P12K_Drop.P12K_Drop_C
// Size: 0x848 (Inherited: 0x848)
struct AP12K_Drop_C : AKSWeaponAssetDrop {
};

