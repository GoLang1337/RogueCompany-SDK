// BlueprintGeneratedClass EventTracker_Conditional_DamageSingle.EventTracker_Conditional_DamageSingle_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_Conditional_DamageSingle_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Conditional_DamageSingle.EventTracker_Conditional_DamageSingle_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void OwnedPawnInstigateDamage(struct FCombatEventInfo& DamageInfo); // Function EventTracker_Conditional_DamageSingle.EventTracker_Conditional_DamageSingle_C.OwnedPawnInstigateDamage // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Conditional_DamageSingle(int32_t EntryPoint); // Function EventTracker_Conditional_DamageSingle.EventTracker_Conditional_DamageSingle_C.ExecuteUbergraph_EventTracker_Conditional_DamageSingle // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

