// BlueprintGeneratedClass Kukri_DamageType.Kukri_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UKukri_DamageType_C : UMasterMelee_DamageType_C {
};

