// BlueprintGeneratedClass Katana_Projectile.Katana_Projectile_C
// Size: 0x988 (Inherited: 0x988)
struct AKatana_Projectile_C : AMelee_Projectile_C {
};

