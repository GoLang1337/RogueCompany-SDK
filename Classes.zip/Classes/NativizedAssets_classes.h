// Class NativizedAssets.__Delegates__UDirectReviveDroneModInst_C__pf3770280971
// Size: 0x28 (Inherited: 0x28)
struct U__Delegates__UDirectReviveDroneModInst_C__pf3770280971 : UObject {
};

// Class NativizedAssets.__Delegates__UGatlingGun_StateMachineModInst_C__pf903058024
// Size: 0x28 (Inherited: 0x28)
struct U__Delegates__UGatlingGun_StateMachineModInst_C__pf903058024 : UObject {
};

// Class NativizedAssets.__Delegates__UWBP_AsyncIcon_C__pf48234980
// Size: 0x28 (Inherited: 0x28)
struct U__Delegates__UWBP_AsyncIcon_C__pf48234980 : UObject {
};

