// BlueprintGeneratedClass SemtexGrenade_StuckDamageType.SemtexGrenade_StuckDamageType_C
// Size: 0x138 (Inherited: 0x138)
struct USemtexGrenade_StuckDamageType_C : UKSDamageTypeStuck {
};

