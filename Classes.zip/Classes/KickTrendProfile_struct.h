// ScriptStruct KickTrendProfile.KickTrendProfile
// Size: 0x1c (Inherited: 0x00)
struct FKickTrendProfile {
	int32_t StartingShotIndex_2_AF3181EC472A16B774B5C98BCB67A5CA; // 0x00(0x04)
	float MinimumHorizontalKick_5_FEA75293411D195820D85BAB34847371; // 0x04(0x04)
	float MaximumHorizontalKick_7_5D06359B48B7729939CFEDA82219DF53; // 0x08(0x04)
	float PositiveHorizontalKickChance_9_2232430A494CB894D9D3A4801EBAE9DC; // 0x0c(0x04)
	float MinimumVerticalKick_11_281B33B449A60EDE39E9D3BB45D2E8D9; // 0x10(0x04)
	float MaximumVerticalKick_13_249E469A4B76A025ECAB59BBE18D85C9; // 0x14(0x04)
	float PositiveVerticalKickChance_15_4B720E5249C0C55CCDE0BABD1527D8BF; // 0x18(0x04)
};

