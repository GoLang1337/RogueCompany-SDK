// ScriptStruct LastHitImpulse.LastHitImpulse
// Size: 0x40 (Inherited: 0x00)
struct FLastHitImpulse {
	struct AActor* Instigator_20_5676A25747AAE4C1CAE6F7904A72E838; // 0x00(0x08)
	struct UObject* DamageTypeClass_8_14D8CFB249FFF88F6E22558B9519E6BC; // 0x08(0x08)
	float Damage_26_4F432E834F2E7B32B65B2DB29767FD53; // 0x10(0x04)
	float DamageImpulse_31_89A6727F4083948B82A5FDB503B7442B; // 0x14(0x04)
	struct FVector HitPosition_14_120F8D2B490F19F3A4CEBB901F6115CC; // 0x18(0x0c)
	struct FVector HitDirection_13_8E0293204787B83EDA90D29AEF408597; // 0x24(0x0c)
	struct FName HitBoneName_16_43F2A6864AE18D72112E449F4233747C; // 0x30(0x08)
	enum class HitEnum SideHit_23_F8CB69E84C39514126DE2A8BB7DD8631; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

