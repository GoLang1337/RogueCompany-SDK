// BlueprintGeneratedClass P12K_CameraShake.P12K_CameraShake_C
// Size: 0x160 (Inherited: 0x160)
struct UP12K_CameraShake_C : UCameraShake {
};

