// BlueprintGeneratedClass FirstTimeLanguageViewRedirector.FirstTimeLanguageViewRedirector_C
// Size: 0x30 (Inherited: 0x30)
struct UFirstTimeLanguageViewRedirector_C : UKSViewRedirector_LocalSetting {
};

