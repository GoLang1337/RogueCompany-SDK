// BlueprintGeneratedClass FirstTimeSafeZoneViewRedirector.FirstTimeSafeZoneViewRedirector_C
// Size: 0x30 (Inherited: 0x30)
struct UFirstTimeSafeZoneViewRedirector_C : UKSViewRedirector_LocalSetting {

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function FirstTimeSafeZoneViewRedirector.FirstTimeSafeZoneViewRedirector_C.DoesLocalSettingApply // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

