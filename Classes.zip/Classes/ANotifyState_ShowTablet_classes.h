// BlueprintGeneratedClass ANotifyState_ShowTablet.ANotifyState_ShowTablet_C
// Size: 0x32 (Inherited: 0x30)
struct UANotifyState_ShowTablet_C : UAnimNotifyState {
	bool bReverse; // 0x30(0x01)
	bool bKeepTabletUnhidden; // 0x31(0x01)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_ShowTablet.ANotifyState_ShowTablet_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_ShowTablet.ANotifyState_ShowTablet_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

