// WidgetBlueprintGeneratedClass LoginTwoFactor.LoginTwoFactor_C
// Size: 0x570 (Inherited: 0x518)
struct ULoginTwoFactor_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UStandardButton_C* BackButton; // 0x520(0x08)
	struct UImage* BG; // 0x528(0x08)
	struct UEditableText* CodeField; // 0x530(0x08)
	struct UStandardButton_C* NextButton; // 0x538(0x08)
	struct UWidgetSwitcher* NextSwitcher; // 0x540(0x08)
	struct UOutlineContainer_C* OutlineContainer; // 0x548(0x08)
	struct UImage* TitleLogo_2; // 0x550(0x08)
	struct UImage* WarningIcon; // 0x558(0x08)
	struct UTextBlock* WarningText; // 0x560(0x08)
	struct UWBP_ModalPopupContainer_C* WBP_ModalPopupContainer; // 0x568(0x08)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function LoginTwoFactor.LoginTwoFactor_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Handle Text Committed(struct FText& Text, enum class ETextCommit CommitMethod); // Function LoginTwoFactor.LoginTwoFactor_C.Handle Text Committed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__NextButton_K2Node_ComponentBoundEvent_6_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginTwoFactor.LoginTwoFactor_C.BndEvt__NextButton_K2Node_ComponentBoundEvent_6_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void Handle Text Changed(struct FText& Text); // Function LoginTwoFactor.LoginTwoFactor_C.Handle Text Changed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__BackButton_K2Node_ComponentBoundEvent_26_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginTwoFactor.LoginTwoFactor_C.BndEvt__BackButton_K2Node_ComponentBoundEvent_26_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void Submit Code(); // Function LoginTwoFactor.LoginTwoFactor_C.Submit Code // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function LoginTwoFactor.LoginTwoFactor_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void Handle CodeField Gamepad Confirm(); // Function LoginTwoFactor.LoginTwoFactor_C.Handle CodeField Gamepad Confirm // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Handle Login Error(struct FText MessageText, int32_t MessageId); // Function LoginTwoFactor.LoginTwoFactor_C.Handle Login Error // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoginTwoFactor(int32_t EntryPoint); // Function LoginTwoFactor.LoginTwoFactor_C.ExecuteUbergraph_LoginTwoFactor // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

