// Class PlatformGameFramework.DistributionVectorUniformParameter
// Size: 0x60 (Inherited: 0x38)
struct UDistributionVectorUniformParameter : UDistributionVector {
	struct FName MaxParamName; // 0x38(0x08)
	struct FName MinParamName; // 0x40(0x08)
	struct FVector DefaultMaxValue; // 0x48(0x0c)
	struct FVector DefaultMinValue; // 0x54(0x0c)
};

// Class PlatformGameFramework.PGame_BlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPGame_BlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	void ShowSkinnedMeshMaterialSection(struct USkinnedMeshComponent* SkinnedMeshComponent, int32_t MaterialID, int32_t SectionIndex, bool bShow, int32_t LODIndex); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ShowSkinnedMeshMaterialSection // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa6b280
	void SetLightingChannels(struct UPrimitiveComponent* PrimitiveComponent, struct FLightingChannels NewLightingChannels); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.SetLightingChannels // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa6b1c0
	bool ServerTravelWithGameMode(struct UObject* WorldContextObject, struct TSoftObjectPtr<UWorld>& Map, struct TSoftClassPtr<UObject>& GameMode, struct TArray<struct FString>& Options, bool bSeamless); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ServerTravelWithGameMode // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa6ae50
	bool ServerTravel(struct UObject* WorldContextObject, struct TSoftObjectPtr<UWorld>& Map, struct TSoftClassPtr<UObject>& GameMode, struct TArray<struct FString>& Options, bool bSeamless, bool bPreserveCurrentOptions); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ServerTravel // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa6abc0
	bool IsSteamClient(); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsSteamClient // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6a610
	bool IsPlatformType(bool IsConsole, bool IsPC, bool IsMobile); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsPlatformType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6a500
	bool IsPlatform(bool IsXboxOne, bool IsPS4, bool IsSwitch, bool IsWindows, bool IsMac, bool IsLinux, bool IsIOS, bool IsAndroid, bool IsXSX, bool IsPS5); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsPlatform // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6a210
	bool IsGameBit(enum class EGameBits GameBit); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsGameBit // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6a190
	bool IsAnonymousLogin(); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.IsAnonymousLogin // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6a160
	float GetPropertyClampedValue(struct FPGame_Property Prop); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.GetPropertyClampedValue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa69da0
	enum class EGameLocalizationType GetGameLocalizationType(); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.GetGameLocalizationType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa69cd0
	void FrameDelay(struct UObject* WorldContextObject, int32_t NumFramesToDelay, struct FLatentActionInfo LatentInfo); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.FrameDelay // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa69970
	struct FLightingChannels ConvertToEngineLightingChannels(struct FPGame_BlueprintableLightingChannels BlueprintableLightingChannels); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ConvertToEngineLightingChannels // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa69600
	struct FPGame_BlueprintableLightingChannels ConvertToBlueprintableLightingChannels(struct FLightingChannels EngineLightChannels); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.ConvertToBlueprintableLightingChannels // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa69570
	bool AreMeshComponentTexturesFullyStreamedIn(struct UMeshComponent* InMeshComponent); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.AreMeshComponentTexturesFullyStreamedIn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa692c0
	bool AreActorTexturesFullyStreamedIn(struct AActor* InActor); // Function PlatformGameFramework.PGame_BlueprintFunctionLibrary.AreActorTexturesFullyStreamedIn // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa69240
};

// Class PlatformGameFramework.PGame_Character
// Size: 0x500 (Inherited: 0x4c0)
struct APGame_Character : ACharacter {
	char pad_4C0[0x8]; // 0x4c0(0x08)
	struct UPGame_EffectManagerComponent* m_EffectManager; // 0x4c8(0x08)
	struct FTweenInfo r_TweenInfo; // 0x4d0(0x14)
	struct FChargeInfo r_ChargeInfo; // 0x4e4(0x1c)

	void OnRep_Tween(); // Function PlatformGameFramework.PGame_Character.OnRep_Tween // (Native|Protected) // @ game+0xa6a790
	void OnRep_Charge(); // Function PlatformGameFramework.PGame_Character.OnRep_Charge // (Native|Protected) // @ game+0xa6a6a0
};

// Class PlatformGameFramework.PGame_CharacterMovementComponent
// Size: 0x6e0 (Inherited: 0x680)
struct UPGame_CharacterMovementComponent : UCharacterMovementComponent {
	char pad_680[0x20]; // 0x680(0x20)
	bool bUseTweenWalkingPhysics; // 0x6a0(0x01)
	char pad_6A1[0x7]; // 0x6a1(0x07)
	struct FChargeInfo r_ChargeInfo; // 0x6a8(0x1c)
	struct FTweenInfo r_TweenInfo; // 0x6c4(0x14)
	char pad_6D8[0x8]; // 0x6d8(0x08)

	void StopTween(); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StopTween // (Native|Public) // @ game+0xa6b710
	void StopCharge(); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StopCharge // (Native|Public) // @ game+0xa6b6f0
	void StartTween(char TweenType, struct FVector& TweenDestination, float TweenTime); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StartTween // (Native|Public|HasOutParms|HasDefaults) // @ game+0xa6b5d0
	void StartCharge(char ChargeType, float& ChargeInitialYaw, struct FVector& ChargeInitialLocation, float ChargeSpeed, float ChargeRange); // Function PlatformGameFramework.PGame_CharacterMovementComponent.StartCharge // (Native|Public|HasOutParms|HasDefaults) // @ game+0xa6b400
	void OnRep_Tween(struct FTweenInfo& TweenInfo); // Function PlatformGameFramework.PGame_CharacterMovementComponent.OnRep_Tween // (Native|Public|HasOutParms) // @ game+0xa6a7b0
	void OnRep_Charge(struct FChargeInfo& ChargeInfo); // Function PlatformGameFramework.PGame_CharacterMovementComponent.OnRep_Charge // (Native|Public|HasOutParms) // @ game+0xa6a6c0
};

// Class PlatformGameFramework.PGame_CheatComponent
// Size: 0xb0 (Inherited: 0xb0)
struct UPGame_CheatComponent : UActorComponent {

	void TestFubarRewardPostLogin(); // Function PlatformGameFramework.PGame_CheatComponent.TestFubarRewardPostLogin // (Final|Exec|Native|Protected) // @ game+0xa6b780
	void TestFubarRewardPosted(); // Function PlatformGameFramework.PGame_CheatComponent.TestFubarRewardPosted // (Final|Exec|Native|Protected) // @ game+0xa6b7d0
	void TestFubar(); // Function PlatformGameFramework.PGame_CheatComponent.TestFubar // (Final|Exec|Native|Protected) // @ game+0xa6b730
	void ServerTestFubarRewardPostLogin(); // Function PlatformGameFramework.PGame_CheatComponent.ServerTestFubarRewardPostLogin // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xa6ab20
	void ServerTestFubarRewardPosted(); // Function PlatformGameFramework.PGame_CheatComponent.ServerTestFubarRewardPosted // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xa6ab70
	void ServerTestFubar(); // Function PlatformGameFramework.PGame_CheatComponent.ServerTestFubar // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xa6aad0
	void ServerExecCall(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.ServerExecCall // (Net|Native|Event|Protected|NetServer|NetValidate) // @ game+0xa6aa10
	void ServerExec(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.ServerExec // (Exec|Native|Protected) // @ game+0xa6a970
	void Logout(); // Function PlatformGameFramework.PGame_CheatComponent.Logout // (Final|Exec|Native|Protected) // @ game+0xa6a660
	void gmJoinQueue(int32_t QueueId); // Function PlatformGameFramework.PGame_CheatComponent.gmJoinQueue // (Final|Exec|Native|Protected) // @ game+0xa6b8c0
	void gmCommand(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.gmCommand // (Final|Exec|Native|Protected) // @ game+0xa6b820
	void gmC(struct FString request); // Function PlatformGameFramework.PGame_CheatComponent.gmC // (Final|Exec|Native|Protected) // @ game+0xa6b820
	void ForceCrash(); // Function PlatformGameFramework.PGame_CheatComponent.ForceCrash // (Final|Exec|Native|Protected) // @ game+0xa69950
	void DumpAnimationStats(); // Function PlatformGameFramework.PGame_CheatComponent.DumpAnimationStats // (Final|Exec|Native|Protected) // @ game+0xa69860
	void CustomForceStart(); // Function PlatformGameFramework.PGame_CheatComponent.CustomForceStart // (Final|Exec|Native|Protected) // @ game+0xa69840
};

// Class PlatformGameFramework.PGame_CombatLogVisualizer
// Size: 0x230 (Inherited: 0x220)
struct APGame_CombatLogVisualizer : AActor {
	struct FString LogFileName; // 0x220(0x10)

	void Visualize(); // Function PlatformGameFramework.PGame_CombatLogVisualizer.Visualize // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void LoadCombatLog(); // Function PlatformGameFramework.PGame_CombatLogVisualizer.LoadCombatLog // (Final|Native|Public) // @ game+0xa6a640
	void ClearVisualization(); // Function PlatformGameFramework.PGame_CombatLogVisualizer.ClearVisualization // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class PlatformGameFramework.PGame_EffectManagerComponent
// Size: 0x380 (Inherited: 0xb0)
struct UPGame_EffectManagerComponent : UActorComponent {
	char pad_B0[0x28]; // 0xb0(0x28)
	struct FPGame_PersistentEffectRepDataContainer r_ReplicatedEffectData; // 0xd8(0x120)
	struct FPGame_EffectManagerPropertyContainer r_ReplicatedProperties; // 0x1f8(0x170)
	char pad_368[0x18]; // 0x368(0x18)

	void OnRep_EffectData(); // Function PlatformGameFramework.PGame_EffectManagerComponent.OnRep_EffectData // (Native|Public) // @ game+0xa6a750
	void InstantEffectBroadcast(struct FPGame_InstantEffectRepData repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.InstantEffectBroadcast // (Net|Native|Event|NetMulticast|Public) // @ game+0xa6a090
	int32_t GetPropertyValueIntFromBlueprint(int32_t PropertyId); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetPropertyValueIntFromBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69f30
	float GetPropertyValueFromBlueprint(int32_t PropertyId); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetPropertyValueFromBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69e90
	struct UPGame_EffectGroupPersistent* GetDefaultEffectGroupForPersistentRepData(struct FPGame_PersistentEffectRepData& repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetDefaultEffectGroupForPersistentRepData // (Final|Native|Public|HasOutParms|Const) // @ game+0xa69b50
	struct UPGame_EffectGroupInstant* GetDefaultEffectGroupForInstantRepData(struct FPGame_InstantEffectRepData& repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.GetDefaultEffectGroupForInstantRepData // (Final|Native|Public|HasOutParms|Const) // @ game+0xa69a90
	struct UPGame_EffectAttachment* CreatePersistentAttachment(struct FPGame_PersistentEffectRepData& repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.CreatePersistentAttachment // (Native|Public|HasOutParms) // @ game+0xa69750
	void CreateInstantAttachment(struct FPGame_InstantEffectRepData& repData); // Function PlatformGameFramework.PGame_EffectManagerComponent.CreateInstantAttachment // (Native|Public|HasOutParms) // @ game+0xa696a0
};

// Class PlatformGameFramework.PGame_EffectAttachment
// Size: 0xb0 (Inherited: 0xb0)
struct UPGame_EffectAttachment : UActorComponent {
};

// Class PlatformGameFramework.PGame_EffectGroup
// Size: 0x80 (Inherited: 0x28)
struct UPGame_EffectGroup : UObject {
	struct FGameplayTagContainer m_EffectGroupTypes; // 0x28(0x20)
	struct FGameplayTagContainer m_BehaviorCategories; // 0x48(0x20)
	struct TArray<struct UPGame_Effect*> m_Effects; // 0x68(0x10)
	struct UPGame_EffectAttachment* m_AttachmentClass; // 0x78(0x08)
};

// Class PlatformGameFramework.PGame_EffectGroupPersistent
// Size: 0xa0 (Inherited: 0x80)
struct UPGame_EffectGroupPersistent : UPGame_EffectGroup {
	struct FGameplayTag m_StackingCategory; // 0x80(0x08)
	enum class EEffectGroupApplicationRule m_ApplicationRule; // 0x88(0x04)
	char m_nMaxStackCount; // 0x8c(0x01)
	bool m_bApplyInstantOnInterval; // 0x8d(0x01)
	bool m_bApplyStackOnInterval; // 0x8e(0x01)
	char pad_8F[0x1]; // 0x8f(0x01)
	float m_fStartDuration; // 0x90(0x04)
	float m_fDuration; // 0x94(0x04)
	float m_fIntervalDuration; // 0x98(0x04)
	float m_fApplicationStrength; // 0x9c(0x04)
};

// Class PlatformGameFramework.PGame_EffectGroupInstant
// Size: 0x80 (Inherited: 0x80)
struct UPGame_EffectGroupInstant : UPGame_EffectGroup {
};

// Class PlatformGameFramework.PGame_Effect
// Size: 0x50 (Inherited: 0x28)
struct UPGame_Effect : UObject {
	struct FPGame_Property m_Property; // 0x28(0x24)
	bool m_bApplyOnInternal; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
};

// Class PlatformGameFramework.PGame_Effectable
// Size: 0x28 (Inherited: 0x28)
struct UPGame_Effectable : UInterface {

	int32_t GetIntPropertyValue(int32_t propIdInt); // Function PlatformGameFramework.PGame_Effectable.GetIntPropertyValue // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69d00
	float GetFloatPropertyValue(int32_t propIdInt); // Function PlatformGameFramework.PGame_Effectable.GetFloatPropertyValue // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69c30
};

// Class PlatformGameFramework.PGame_EffectSource
// Size: 0x28 (Inherited: 0x28)
struct UPGame_EffectSource : UInterface {
};

// Class PlatformGameFramework.PGame_GameInstance
// Size: 0x250 (Inherited: 0x198)
struct UPGame_GameInstance : UGameInstance {
	char pad_198[0x50]; // 0x198(0x50)
	struct FString LastSonyMatchId; // 0x1e8(0x10)
	char pad_1F8[0x40]; // 0x1f8(0x40)
	bool bStartHotfixProcessingOnUpdateAppSettings; // 0x238(0x01)
	char pad_239[0x17]; // 0x239(0x17)

	void ProvideSonyMatchFeedback(bool bReviewTeamOnly); // Function PlatformGameFramework.PGame_GameInstance.ProvideSonyMatchFeedback // (Final|Native|Public|BlueprintCallable) // @ game+0xa6a840
	bool HasValidSonyMatch(); // Function PlatformGameFramework.PGame_GameInstance.HasValidSonyMatch // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69fe0
	void EndLoadingScreen(struct UWorld* World); // Function PlatformGameFramework.PGame_GameInstance.EndLoadingScreen // (Native|Protected) // @ game+0xa69880
	void BeginLoadingScreen(struct FString mapName); // Function PlatformGameFramework.PGame_GameInstance.BeginLoadingScreen // (Native|Protected) // @ game+0xa69340
};

// Class PlatformGameFramework.PGame_GameModeBase
// Size: 0x3c8 (Inherited: 0x308)
struct APGame_GameModeBase : AGameMode {
	char pad_308[0x80]; // 0x308(0x80)
	struct FString PersistentMapSuffix; // 0x388(0x10)
	struct TArray<struct FString> SublevelSuffixes; // 0x398(0x10)
	struct TArray<struct FString> HighMemorySublevelSuffixes; // 0x3a8(0x10)
	struct TArray<struct FString> LowMemorySublevelSuffixes; // 0x3b8(0x10)
};

// Class PlatformGameFramework.PGame_GameMode
// Size: 0x498 (Inherited: 0x3c8)
struct APGame_GameMode : APGame_GameModeBase {
	char pad_3C8[0x18]; // 0x3c8(0x18)
	bool bAutoEnableCombatLog; // 0x3e0(0x01)
	bool bUploadCombatLogOverride; // 0x3e1(0x01)
	char pad_3E2[0x4e]; // 0x3e2(0x4e)
	bool bFubarForCPUFramerate; // 0x430(0x01)
	bool bFubarForPacketLoss; // 0x431(0x01)
	char pad_432[0x2]; // 0x432(0x02)
	float FubarShutdownWaitTimeoutTime; // 0x434(0x04)
	char pad_438[0x8]; // 0x438(0x08)
	struct FString SonyActivityId; // 0x440(0x10)
	float SonyMatchOwnerNetTimeout; // 0x450(0x04)
	char pad_454[0x4]; // 0x454(0x04)
	struct FPGame_SonyMatchData SonyMatchData; // 0x458(0x18)
	struct TArray<uint32_t> SonyIneligibleMatchOwners; // 0x470(0x10)
	char pad_480[0x8]; // 0x480(0x08)
	struct TArray<struct FPGame_InactivePlayerStateEntry> PGame_InactivePlayerArray; // 0x488(0x10)

	void OnFubarShutdownTimeout(); // Function PlatformGameFramework.PGame_GameMode.OnFubarShutdownTimeout // (Final|Native|Protected) // @ game+0xa6a680
	void InactivePlayerStateDestroyed(struct AActor* InActor); // Function PlatformGameFramework.PGame_GameMode.InactivePlayerStateDestroyed // (Final|Native|Private) // @ game+0xa6a010
	void FinalShutdown(); // Function PlatformGameFramework.PGame_GameMode.FinalShutdown // (Final|Native|Protected) // @ game+0xa69910
	void FinalizeMatchEnded(); // Function PlatformGameFramework.PGame_GameMode.FinalizeMatchEnded // (Native|Protected) // @ game+0xa69930
};

// Class PlatformGameFramework.PGame_GameState
// Size: 0x2a0 (Inherited: 0x290)
struct APGame_GameState : AGameState {
	struct FString r_SonyMatchIdForPlayerFeedback; // 0x290(0x10)

	void OnRep_SonyMatchIdForPlayerFeedback(); // Function PlatformGameFramework.PGame_GameState.OnRep_SonyMatchIdForPlayerFeedback // (Final|Native|Public) // @ game+0xa6a770
};

// Class PlatformGameFramework.PGame_LandingPanelJSONHandler
// Size: 0x170 (Inherited: 0x28)
struct UPGame_LandingPanelJSONHandler : UObject {
	struct FMulticastInlineDelegate OnHandlerObjectReady; // 0x28(0x10)
	struct FMulticastInlineDelegate OnJsonDownloaded; // 0x38(0x10)
	struct FMulticastInlineDelegate OnJsonReady; // 0x48(0x10)
	struct FMulticastInlineDelegate OnImagesDownloaded; // 0x58(0x10)
	char pad_68[0xb8]; // 0x68(0xb8)
	struct TMap<struct FString, struct UTexture2DDynamic*> mapFilePathToTexture; // 0x120(0x50)

	void RequestNewJson(); // Function PlatformGameFramework.PGame_LandingPanelJSONHandler.RequestNewJson // (Final|Native|Private) // @ game+0xa6a950
};

// Class PlatformGameFramework.PGame_PlayerController
// Size: 0x6b0 (Inherited: 0x588)
struct APGame_PlayerController : APlayerController {
	char pad_588[0xd0]; // 0x588(0xd0)
	struct FString SonyMatchId; // 0x658(0x10)
	struct FString SonyActivityId; // 0x668(0x10)
	enum class ESonyMatchState SonyMatchState; // 0x678(0x01)
	enum class ESonyMatchState QueuedSonyMatchState; // 0x679(0x01)
	bool bIsSonyMatchOwner; // 0x67a(0x01)
	bool bIsEligibleSonyMatchOwner; // 0x67b(0x01)
	bool bIsExclusiveSonyMatchOwner; // 0x67c(0x01)
	char pad_67D[0x13]; // 0x67d(0x13)
	struct UPGame_CheatComponent* m_CheatComponentClass; // 0x690(0x08)
	struct UPGame_CheatComponent* r_CheatComponent; // 0x698(0x08)
	struct FSerializedMctsNetId r_ReplicatedNetId; // 0x6a0(0x08)
	struct UInputComponent* InputComponentClass; // 0x6a8(0x08)

	void ServerUpdateSonyMatchOwnerEligibility(bool bIsEligible); // Function PlatformGameFramework.PGame_PlayerController.ServerUpdateSonyMatchOwnerEligibility // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0xa6b130
	void ServerUpdateSonyMatchData(struct FString InMatchId); // Function PlatformGameFramework.PGame_PlayerController.ServerUpdateSonyMatchData // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0xa6b090
	void ClientUpdateSonyMatchData(struct FString InMatchId, struct FString InActivityId); // Function PlatformGameFramework.PGame_PlayerController.ClientUpdateSonyMatchData // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xa69480
	void ClientGameFubared(enum class EFubarReason Reason); // Function PlatformGameFramework.PGame_PlayerController.ClientGameFubared // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xa69400
	void ClientCheckSonyMatchOwnerEligibility(); // Function PlatformGameFramework.PGame_PlayerController.ClientCheckSonyMatchOwnerEligibility // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xa693e0
};

// Class PlatformGameFramework.PGame_PlayerInputDefault
// Size: 0x30 (Inherited: 0x28)
struct UPGame_PlayerInputDefault : UObject {
	bool bRestrictInvalidInputType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class PlatformGameFramework.PGame_PlayerInput
// Size: 0x1330 (Inherited: 0x12f0)
struct UPGame_PlayerInput : UPlayerInput {
	char pad_12F0[0x20]; // 0x12f0(0x20)
	float KeyMouseSwitchDelta; // 0x1310(0x04)
	char pad_1314[0x4]; // 0x1314(0x04)
	float GamepadSwitchDelta; // 0x1318(0x04)
	char pad_131C[0x14]; // 0x131c(0x14)
};

// Class PlatformGameFramework.PGame_HierarchicalInputComponent
// Size: 0x198 (Inherited: 0x138)
struct UPGame_HierarchicalInputComponent : UInputComponent {
	char pad_138[0x60]; // 0x138(0x60)
};

// Class PlatformGameFramework.PGame_PlayerState
// Size: 0x320 (Inherited: 0x320)
struct APGame_PlayerState : APlayerState {
};

// Class PlatformGameFramework.PGame_PositionHistoryComponent
// Size: 0xe8 (Inherited: 0xb0)
struct UPGame_PositionHistoryComponent : UActorComponent {
	enum class EPositionHistoryRecordMode PositionRecordMode; // 0xb0(0x01)
	bool ExtrapolateFromLastEntry; // 0xb1(0x01)
	bool bAutoPopulateOnBeginPlay; // 0xb2(0x01)
	char pad_B3[0x15]; // 0xb3(0x15)
	struct TArray<struct FPrimitivePriority> TrackedPrimitives; // 0xc8(0x10)
	char pad_D8[0x10]; // 0xd8(0x10)

	void RemoveTrackedPrimitive(struct UPrimitiveComponent* InPrimitive); // Function PlatformGameFramework.PGame_PositionHistoryComponent.RemoveTrackedPrimitive // (Final|Native|Public|BlueprintCallable) // @ game+0xa6a8d0
	void AddTrackedPrimitive(struct UPrimitiveComponent* InPrimitive, int32_t Priority); // Function PlatformGameFramework.PGame_PositionHistoryComponent.AddTrackedPrimitive // (Final|Native|Public|BlueprintCallable) // @ game+0xa69180
};

// Class PlatformGameFramework.PGame_ShippingConsole
// Size: 0x138 (Inherited: 0x138)
struct UPGame_ShippingConsole : UShippingConsole {
};

// Class PlatformGameFramework.PGame_WorldSettings
// Size: 0x3d0 (Inherited: 0x3a0)
struct APGame_WorldSettings : AWorldSettings {
	struct TArray<struct AActor*> ActorsToAlwaysSpawn; // 0x3a0(0x10)
	struct TArray<struct FString> HighMemorySublevelSuffixes; // 0x3b0(0x10)
	struct TArray<struct FString> LowMemorySublevelSuffixes; // 0x3c0(0x10)
};

// Class PlatformGameFramework.PGameBTComposite_ParallelSequence
// Size: 0x90 (Inherited: 0x90)
struct UPGameBTComposite_ParallelSequence : UBTCompositeNode {
};

// Class PlatformGameFramework.PGameBTComposite_Random
// Size: 0xa0 (Inherited: 0x90)
struct UPGameBTComposite_Random : UBTCompositeNode {
	struct TArray<float> Probabilities; // 0x90(0x10)
};

// Class PlatformGameFramework.PGameBTComposite_Random_Selector
// Size: 0xa0 (Inherited: 0xa0)
struct UPGameBTComposite_Random_Selector : UPGameBTComposite_Random {
};

// Class PlatformGameFramework.PGameBTComposite_Random_Sequence
// Size: 0xa0 (Inherited: 0xa0)
struct UPGameBTComposite_Random_Sequence : UPGameBTComposite_Random {
};

// Class PlatformGameFramework.PGameBTTask_AlwaysReturn
// Size: 0x78 (Inherited: 0x70)
struct UPGameBTTask_AlwaysReturn : UBTTaskNode {
	enum class EBTNodeResult AlwaysReturn; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class PlatformGameFramework.PGameBTTask_ClearBlackboardKey
// Size: 0x98 (Inherited: 0x98)
struct UPGameBTTask_ClearBlackboardKey : UBTTask_BlackboardBase {
};

