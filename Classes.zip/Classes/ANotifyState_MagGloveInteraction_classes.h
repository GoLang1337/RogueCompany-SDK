// BlueprintGeneratedClass ANotifyState_MagGloveInteraction.ANotifyState_MagGloveInteraction_C
// Size: 0x30 (Inherited: 0x30)
struct UANotifyState_MagGloveInteraction_C : UAnimNotifyState {

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_MagGloveInteraction.ANotifyState_MagGloveInteraction_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_MagGloveInteraction.ANotifyState_MagGloveInteraction_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

