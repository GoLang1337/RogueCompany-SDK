// DynamicClass NameplateWidget.NameplateWidget_C
// Size: 0x528 (Inherited: 0x238)
struct UNameplateWidget_C : UUserWidget {
	char pad_238[0x8]; // 0x238(0x08)
	struct UImage* BG; // 0x240(0x08)
	struct UCanvasPanel* CanvasPanel_1; // 0x248(0x08)
	struct USizeBox* CrackedState; // 0x250(0x08)
	struct UImage* CrackedStateIcon; // 0x258(0x08)
	struct UImage* DownedArrow; // 0x260(0x08)
	struct UWidgetSwitcher* DownedPlayer; // 0x268(0x08)
	struct UImage* ObjectiveIcon; // 0x270(0x08)
	struct USizeBox* ObjectiveWrapper; // 0x278(0x08)
	struct UPlayerHealthMeter_C* PlayerHealthMeter; // 0x280(0x08)
	struct UTextBlock* PlayerName; // 0x288(0x08)
	struct UUserWidget* RogueIcon; // 0x290(0x08)
	struct APlayerState* Nameplate_PlayerState; // 0x298(0x08)
	struct AKSCharacter* Nameplate_Character; // 0x2a0(0x08)
	bool Killcam_Enabled; // 0x2a8(0x01)
	char pad_2A9[0x3]; // 0x2a9(0x03)
	struct FName HoverState; // 0x2ac(0x08)
	float ResidualFadeAlpha; // 0x2b4(0x04)
	float ResidualFadeDelayTime; // 0x2b8(0x04)
	struct FVector2D DamageLerpEndpoints; // 0x2bc(0x08)
	float ResidualFadeTime; // 0x2c4(0x04)
	float Manual Tick Delta Time; // 0x2c8(0x04)
	float ResidualFadeDelayTimer; // 0x2cc(0x04)
	float DamageLerpAlpha; // 0x2d0(0x04)
	float ResidualFadePower; // 0x2d4(0x04)
	float DamageLerpPower; // 0x2d8(0x04)
	float DamageLerpTime; // 0x2dc(0x04)
	float PreviousHealth; // 0x2e0(0x04)
	struct FPlayerHealthMeterState CurrentMeterState; // 0x2e4(0x18)
	bool HasDeferredUpdate; // 0x2fc(0x01)
	bool ShowObjective; // 0x2fd(0x01)
	bool ForceAlwaysShowObjectivePlayer; // 0x2fe(0x01)
	enum class EColorVisionDeficiency ColorCorrection; // 0x2ff(0x01)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State; // 0x300(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x308(0x01)
	char pad_309[0x3]; // 0x309(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0x30c(0x10)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct AKSCharacterBase* K2Node_CustomEvent_Character; // 0x320(0x08)
	struct AKSGameState* K2Node_DynamicCast_AsKSGame_State; // 0x328(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0x330(0x01)
	char pad_331[0x3]; // 0x331(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0x334(0x10)
	char pad_344[0x4]; // 0x344(0x04)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState; // 0x348(0x08)
	struct AKSGameState* K2Node_DynamicCast_AsKSGame_State_2; // 0x350(0x08)
	bool K2Node_DynamicCast_bSuccess_3; // 0x358(0x01)
	char pad_359[0x7]; // 0x359(0x07)
	struct UKSPlayerMod* K2Node_CustomEvent_Mod_2; // 0x360(0x08)
	struct UKSPlayerModInstance* K2Node_CustomEvent_ModInstance_2; // 0x368(0x08)
	struct UKSPlayerMod* K2Node_CustomEvent_Mod; // 0x370(0x08)
	struct UKSPlayerModInstance* K2Node_CustomEvent_ModInstance; // 0x378(0x08)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState_2; // 0x380(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0x388(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0x398(0x10)
	struct TScriptInterface<IKSObjective> CallFunc_BindToObjectiveStateChanged_self_CastInput; // 0x3a8(0x10)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable; // 0x3b8(0x01)
	bool K2Node_Event_IsDesignTime; // 0x3b9(0x01)
	char pad_3BA[0x6]; // 0x3ba(0x06)
	struct TScriptInterface<IKSObjective> K2Node_CustomEvent_GameObjective; // 0x3c0(0x10)
	struct UKSGameUserSettings* K2Node_DynamicCast_AsKSGame_User_Settings; // 0x3d0(0x08)
	bool K2Node_DynamicCast_bSuccess_4; // 0x3d8(0x01)
	char pad_3D9[0x3]; // 0x3d9(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0x3dc(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x3ec(0x10)
	char pad_3FC[0x4]; // 0x3fc(0x04)
	struct UKSLocalPlayer* K2Node_DynamicCast_AsKSLocal_Player; // 0x400(0x08)
	bool K2Node_DynamicCast_bSuccess_5; // 0x408(0x01)
	bool Temp_bool_Has_Been_Initd_Variable; // 0x409(0x01)
	char pad_40A[0x6]; // 0x40a(0x06)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState_3; // 0x410(0x08)
	bool K2Node_CustomEvent_IsEnabled; // 0x418(0x01)
	char pad_419[0x7]; // 0x419(0x07)
	struct AKSCharacterBase* K2Node_CustomEvent_Character_2; // 0x420(0x08)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_2; // 0x428(0x08)
	bool K2Node_DynamicCast_bSuccess_6; // 0x430(0x01)
	char pad_431[0x7]; // 0x431(0x07)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter; // 0x438(0x08)
	bool K2Node_DynamicCast_bSuccess_7; // 0x440(0x01)
	char pad_441[0x3]; // 0x441(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7; // 0x444(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8; // 0x454(0x10)
	char pad_464[0x4]; // 0x464(0x04)
	struct APlayerState* K2Node_Event_PlayerState; // 0x468(0x08)
	struct AKSCharacter* K2Node_Event_Character; // 0x470(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9; // 0x478(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10; // 0x488(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11; // 0x498(0x10)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_3; // 0x4a8(0x08)
	bool K2Node_DynamicCast_bSuccess_8; // 0x4b0(0x01)
	char pad_4B1[0x3]; // 0x4b1(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12; // 0x4b4(0x10)
	bool Temp_bool_IsClosed_Variable; // 0x4c4(0x01)
	char pad_4C5[0x3]; // 0x4c5(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13; // 0x4c8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14; // 0x4d8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15; // 0x4e8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16; // 0x4f8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_17; // 0x508(0x10)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_4; // 0x518(0x08)
	bool K2Node_DynamicCast_bSuccess_9; // 0x520(0x01)
	char pad_521[0x7]; // 0x521(0x07)

	void Update Visibility(float bpp__DeltaSeconds__pf, bool bpp__ForceUpdate__pf); // Function NameplateWidget.NameplateWidget_C.Update Visibility // (Native|Public|BlueprintCallable) // @ game+0x1857030
	void UpdateColorCorrectionValue(enum class EColorVisionDeficiency bpp__ColorCorrection__pf); // Function NameplateWidget.NameplateWidget_C.UpdateColorCorrectionValue // (Native|Public|BlueprintCallable) // @ game+0x1856fb0
	void Unbind Events From PlayerState(); // Function NameplateWidget.NameplateWidget_C.Unbind Events From PlayerState // (Native|Public|BlueprintCallable) // @ game+0x1856f90
	void Should Show Enemy Nameplate(bool& bpp__ShouldShow__pf); // Function NameplateWidget.NameplateWidget_C.Should Show Enemy Nameplate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1856ef0
	void SetObjectiveMarkerFromGameState(bool bpp__ShowObjective__pf, struct UTexture2D* bpp__ObjectiveIcon__pf, bool bpp__ForceAlways__pf); // Function NameplateWidget.NameplateWidget_C.SetObjectiveMarkerFromGameState // (Native|Public|BlueprintCallable) // @ game+0x1856de0
	void SetNamePlateColor(struct AKSPlayerState* bpp__PlayerxState__pfT); // Function NameplateWidget.NameplateWidget_C.SetNamePlateColor // (Native|Public|BlueprintCallable) // @ game+0x181d790
	void PreConstruct(bool bpp__IsDesignTime__pf); // Function NameplateWidget.NameplateWidget_C.PreConstruct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x1856d30
	void Player Is Blinded(bool& bpp__IsxBlind__pfT); // Function NameplateWidget.NameplateWidget_C.Player Is Blinded // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1856c90
	void OnUnhovered(); // Function NameplateWidget.NameplateWidget_C.OnUnhovered // (Native|Event|Public|BlueprintCallable) // @ game+0x181d100
	void OnSettingsApplied(struct FName bpp__SettingName__pf); // Function NameplateWidget.NameplateWidget_C.OnSettingsApplied // (Native|Public|BlueprintCallable) // @ game+0x1856c00
	void OnPossession(struct APlayerState* bpp__PlayerState__pf, struct AKSCharacter* bpp__Character__pf); // Function NameplateWidget.NameplateWidget_C.OnPossession // (Native|Event|Public|BlueprintCallable) // @ game+0x1856b30
	void OnPlayerUINeedsUpdate(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.OnPlayerUINeedsUpdate // (Native|Public|BlueprintCallable) // @ game+0x1856aa0
	void OnPlayerDownedChanged_Event(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.OnPlayerDownedChanged_Event // (Native|Public|BlueprintCallable) // @ game+0x1856a10
	void OnModRemoved(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // Function NameplateWidget.NameplateWidget_C.OnModRemoved // (Native|Public|BlueprintCallable) // @ game+0x1856940
	void OnModAdded(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // Function NameplateWidget.NameplateWidget_C.OnModAdded // (Native|Public|BlueprintCallable) // @ game+0x1856870
	void OnKillCamEnabled(bool bpp__IsEnabled__pf); // Function NameplateWidget.NameplateWidget_C.OnKillCamEnabled // (Native|Public|BlueprintCallable) // @ game+0x18567e0
	void OnHovered(); // Function NameplateWidget.NameplateWidget_C.OnHovered // (Native|Event|Public|BlueprintCallable) // @ game+0xb589b0
	void OnDead(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.OnDead // (Native|Public|BlueprintCallable) // @ game+0x1856750
	void Manual Tick(); // Function NameplateWidget.NameplateWidget_C.Manual Tick // (Native|Public|BlueprintCallable) // @ game+0xb58e10
	void Handle Overheal Changed(struct AKSCharacterBase* bpp__Character__pf__const); // Function NameplateWidget.NameplateWidget_C.Handle Overheal Changed // (Native|Public|BlueprintCallable) // @ game+0x18566c0
	void Handle Job Changed(); // Function NameplateWidget.NameplateWidget_C.Handle Job Changed // (Native|Public|BlueprintCallable) // @ game+0x18566a0
	void HandleObjectiveStateChanged(struct TScriptInterface<IKSObjective>& bpp__Objective__pf); // Function NameplateWidget.NameplateWidget_C.HandleObjectiveStateChanged // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1856600
	void HandleNameChanged(struct AKSPlayerState* bpp__InKSPlayerState__pf); // Function NameplateWidget.NameplateWidget_C.HandleNameChanged // (Native|Public|BlueprintCallable) // @ game+0x1856570
	void HandleModActivationChanged(struct UKSPlayerMod_Activated* bpp__ActivatedxMod__pfT, bool bpp__Active__pf); // Function NameplateWidget.NameplateWidget_C.HandleModActivationChanged // (Native|Public|BlueprintCallable) // @ game+0x18564a0
	void HandleGameObjectiveRegistered(struct TScriptInterface<IKSObjective>& bpp__GameObjective__pf); // Function NameplateWidget.NameplateWidget_C.HandleGameObjectiveRegistered // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1856400
	void HandleGameObjectiveChanged(struct TScriptInterface<IKSObjective>& bpp__GameObjective__pf); // Function NameplateWidget.NameplateWidget_C.HandleGameObjectiveChanged // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1856360
	void ExecuteUbergraph_NameplateWidget_6(int32_t bpp__EntryPoint__pf); // Function NameplateWidget.NameplateWidget_C.ExecuteUbergraph_NameplateWidget_6 // (Final|Native|Public) // @ game+0x18562e0
	void Destruct(); // Function NameplateWidget.NameplateWidget_C.Destruct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x1856130
	void Deferred Player State Open(); // Function NameplateWidget.NameplateWidget_C.Deferred Player State Open // (Native|Public|BlueprintCallable) // @ game+0x1856110
	void Construct(); // Function NameplateWidget.NameplateWidget_C.Construct // (BlueprintCosmetic|Native|Event|Public) // @ game+0xb59fe0
	void CheckMods(struct AKSPlayerState* bpp__PlayerState__pf); // Function NameplateWidget.NameplateWidget_C.CheckMods // (Native|Public|BlueprintCallable) // @ game+0x1856080
	void CharacterHealthChange(struct AKSCharacterBase* bpp__Character__pf__const); // Function NameplateWidget.NameplateWidget_C.CharacterHealthChange // (Native|Public|BlueprintCallable) // @ game+0x181d5f0
	void OnUIRelevantPlayerStateChanged__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnUIRelevantPlayerStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnPlayerModActivationChange__DelegateSignature(struct UKSPlayerMod_Activated* bpp__ActivatedMod__pf, bool bpp__Active__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnPlayerModActivationChange__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnPlayerEliminated__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnPlayerEliminated__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnPlayerDownedChanged__DelegateSignature(struct AKSPlayerState* bpp__PlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnPlayerDownedChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnModRemoved__DelegateSignature(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnModRemoved__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnModAdded__DelegateSignature(struct UKSPlayerMod* bpp__Mod__pf, struct UKSPlayerModInstance* bpp__ModInstance__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnModAdded__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnLocalSettingSaved__DelegateSignature(struct FName bpp__SettingName__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnLocalSettingSaved__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnKSPlayerStateTeamChanged__DelegateSignature(struct AKSPlayerState* bpp__KSPlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnKSPlayerStateTeamChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnKSPlayerStateNameChanged__DelegateSignature(struct AKSPlayerState* bpp__KSPlayerState__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnKSPlayerStateNameChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnKillCamEnabled__DelegateSignature(bool bpp__bEnabled__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnKillCamEnabled__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnJobChanged__DelegateSignature(); // DelegateFunction NameplateWidget.NameplateWidget_C.OnJobChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnHealthChanged__DelegateSignature(struct AKSCharacterBase* bpp__Character__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnHealthChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnGameObjectiveChanged__DelegateSignature(struct TScriptInterface<IKSObjective>& bpp__GameObjective__pf); // DelegateFunction NameplateWidget.NameplateWidget_C.OnGameObjectiveChanged__DelegateSignature // (Public|Delegate|HasOutParms) // @ game+0x24d5b40
};

