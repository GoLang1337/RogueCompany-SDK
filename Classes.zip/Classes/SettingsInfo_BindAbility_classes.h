// BlueprintGeneratedClass SettingsInfo_BindAbility.SettingsInfo_BindAbility_C
// Size: 0x128 (Inherited: 0x128)
struct USettingsInfo_BindAbility_C : UKSSettingsInfo_Binding {
};

