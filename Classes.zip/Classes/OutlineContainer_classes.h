// WidgetBlueprintGeneratedClass OutlineContainer.OutlineContainer_C
// Size: 0x580 (Inherited: 0x518)
struct UOutlineContainer_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UImage* BG; // 0x520(0x08)
	struct UNamedSlot* ContentSlot; // 0x528(0x08)
	struct UButton* HitTarget; // 0x530(0x08)
	struct UImage* Hover; // 0x538(0x08)
	struct UImage* Outline; // 0x540(0x08)
	struct UObject* OutlineTexture; // 0x548(0x08)
	struct FMargin OutlineMargin; // 0x550(0x10)
	struct FMulticastInlineDelegate Gamepad Confirm; // 0x560(0x10)
	struct UAkAudioEvent* ClickOutlineContainerSFX; // 0x570(0x08)
	struct UAkAudioEvent* HoverOutlineContainerSFX; // 0x578(0x08)

	bool NavigateConfirm(); // Function OutlineContainer.OutlineContainer_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function OutlineContainer.OutlineContainer_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadHover(); // Function OutlineContainer.OutlineContainer_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadUnhover(); // Function OutlineContainer.OutlineContainer_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void Do Hover(); // Function OutlineContainer.OutlineContainer_C.Do Hover // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Do Unhover(); // Function OutlineContainer.OutlineContainer_C.Do Unhover // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function OutlineContainer.OutlineContainer_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function OutlineContainer.OutlineContainer_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function OutlineContainer.OutlineContainer_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_OutlineContainer(int32_t EntryPoint); // Function OutlineContainer.OutlineContainer_C.ExecuteUbergraph_OutlineContainer // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void Gamepad Confirm__DelegateSignature(); // Function OutlineContainer.OutlineContainer_C.Gamepad Confirm__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

