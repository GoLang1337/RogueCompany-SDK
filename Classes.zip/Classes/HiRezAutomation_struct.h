// ScriptStruct HiRezAutomation.PGame_PerformanceCaptureProfile
// Size: 0x1c (Inherited: 0x00)
struct FPGame_PerformanceCaptureProfile {
	struct FName ProfileName; // 0x00(0x08)
	int32_t ScalabilityBucket; // 0x08(0x04)
	int32_t ResolutionX; // 0x0c(0x04)
	int32_t ResolutionY; // 0x10(0x04)
	int32_t VsyncInterval; // 0x14(0x04)
	bool bFullScreen; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
};

