// BlueprintGeneratedClass MasterGun_DamageType.MasterGun_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UMasterGun_DamageType_C : UMaster_DamageType_C {
};

