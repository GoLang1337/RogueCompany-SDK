// BlueprintGeneratedClass EventTracker_Gunsmith.EventTracker_Gunsmith_C
// Size: 0x218 (Inherited: 0x208)
struct UEventTracker_Gunsmith_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	int32_t Primary2_PurchaseCount; // 0x210(0x04)
	int32_t Primary1_PurchaseCount; // 0x214(0x04)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Gunsmith.EventTracker_Gunsmith_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Gunsmith.EventTracker_Gunsmith_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void Handle OnShopItemPurchase(struct FShopItem ShopItem); // Function EventTracker_Gunsmith.EventTracker_Gunsmith_C.Handle OnShopItemPurchase // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Gunsmith(int32_t EntryPoint); // Function EventTracker_Gunsmith.EventTracker_Gunsmith_C.ExecuteUbergraph_EventTracker_Gunsmith // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

