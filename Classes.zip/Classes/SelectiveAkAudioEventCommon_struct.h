// ScriptStruct SelectiveAkAudioEventCommon.SelectiveEventStopPair
// Size: 0x18 (Inherited: 0x00)
struct FSelectiveEventStopPair {
	struct UAkAudioEvent* Event; // 0x00(0x08)
	struct FString EventName; // 0x08(0x10)
};

