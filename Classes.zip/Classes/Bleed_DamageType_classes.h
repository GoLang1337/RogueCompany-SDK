// BlueprintGeneratedClass Bleed_DamageType.Bleed_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UBleed_DamageType_C : UMaster_DamageType_C {
};

