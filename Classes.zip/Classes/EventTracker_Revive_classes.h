// BlueprintGeneratedClass EventTracker_Revive.EventTracker_Revive_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_Revive_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void OnPlayerRevive_Event_1(struct AKSPlayerState* Revivee, struct AKSPlayerState* Reviver, int32_t ExpBonus); // Function EventTracker_Revive.EventTracker_Revive_C.OnPlayerRevive_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Revive.EventTracker_Revive_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Revive.EventTracker_Revive_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Revive(int32_t EntryPoint); // Function EventTracker_Revive.EventTracker_Revive_C.ExecuteUbergraph_EventTracker_Revive // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

