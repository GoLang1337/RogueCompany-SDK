// WidgetBlueprintGeneratedClass LoginExisting.LoginExisting_C
// Size: 0x6ac (Inherited: 0x518)
struct ULoginExisting_C : UKSLoginExistingBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWidgetAnimation* MobileLayout; // 0x520(0x08)
	struct UButton* AnonLoginButton; // 0x528(0x08)
	struct UGamepadPromptBasic_C* AnonLoginPromptGamepad; // 0x530(0x08)
	struct UGamepadPromptBasic_C* AnonLoginPromptMouse; // 0x538(0x08)
	struct UWidgetSwitcher* AnonLoginPromptSwitcher; // 0x540(0x08)
	struct UImage* bkg; // 0x548(0x08)
	struct UHorizontalBox* change_user_prompt; // 0x550(0x08)
	struct UWBP_KeyCallout_C* ConsoleLoginPrompt; // 0x558(0x08)
	struct UTextBlock* ErrorCode; // 0x560(0x08)
	struct UHorizontalBox* ErrorWrapper; // 0x568(0x08)
	struct UImage* Gradient; // 0x570(0x08)
	struct UImage* highlightborder; // 0x578(0x08)
	struct UImage* hirez_logo; // 0x580(0x08)
	struct UImage* Image_47; // 0x588(0x08)
	struct UImage* Image_531; // 0x590(0x08)
	struct UImage* Image_607; // 0x598(0x08)
	struct UImage* Image_610; // 0x5a0(0x08)
	struct UImage* Image_689; // 0x5a8(0x08)
	struct UImage* Image_874; // 0x5b0(0x08)
	struct UImage* Image_1029; // 0x5b8(0x08)
	struct UHorizontalBox* login_prompt_wrapper; // 0x5c0(0x08)
	struct UTextBlock* LoginAsGamertagText; // 0x5c8(0x08)
	struct ULoginDownloadProgressBar_C* LoginDownloadProgressBar; // 0x5d0(0x08)
	struct UCanvasPanel* LoginInterfaceAnonymous; // 0x5d8(0x08)
	struct UCanvasPanel* LoginInterfaceConsole; // 0x5e0(0x08)
	struct UCanvasPanel* LoginInterfacePC; // 0x5e8(0x08)
	struct UWidgetSwitcher* LoginInterfaceSwitcher; // 0x5f0(0x08)
	struct UTextBlock* LoginPrompt; // 0x5f8(0x08)
	struct UTextBlock* Password_Required_Msg; // 0x600(0x08)
	struct UWBP_error_report_C* PasswordError; // 0x608(0x08)
	struct UEditableTextBox* PasswordField; // 0x610(0x08)
	struct UPopupButton_C* PCCreateButton; // 0x618(0x08)
	struct UPopupButton_C* PCLoginButton; // 0x620(0x08)
	struct UOutlineContainer_C* PCPassword; // 0x628(0x08)
	struct UOutlineContainer_C* PCUsername; // 0x630(0x08)
	struct UImage* roco_logo; // 0x638(0x08)
	struct UTextBlock* Username_Required_Msg; // 0x640(0x08)
	struct UWBP_error_report_C* UsernameError; // 0x648(0x08)
	struct UEditableTextBox* UsernameField; // 0x650(0x08)
	struct UTextBlock* VersionDisplay; // 0x658(0x08)
	struct UImage* WarningIcon; // 0x660(0x08)
	struct UTextBlock* WarningText; // 0x668(0x08)
	struct UWBP_GameNotification_C* WBP_GameNotification; // 0x670(0x08)
	struct UWBP_text_button_C* WBP_text_button_C_1; // 0x678(0x08)
	struct UWBP_text_button_C* WBP_text_button_C_2; // 0x680(0x08)
	struct UButton* XboxCalloutWrapper; // 0x688(0x08)
	struct UWBP_KeyCallout_C* XboxChangeUserPrompt; // 0x690(0x08)
	struct UPUMG_LoginDataFactory* LoginDataFac; // 0x698(0x08)
	bool FirstLogin; // 0x6a0(0x01)
	char pad_6A1[0x3]; // 0x6a1(0x03)
	struct FName ProfileChangeAction; // 0x6a4(0x08)

	void Set Mobile HACK Username(); // Function LoginExisting.LoginExisting_C.Set Mobile HACK Username // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetCacheErrorMsg(); // Function LoginExisting.LoginExisting_C.SetCacheErrorMsg // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdatePlayerName(); // Function LoginExisting.LoginExisting_C.UpdatePlayerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool NavigateBack(); // Function LoginExisting.LoginExisting_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool NavigateConfirm(); // Function LoginExisting.LoginExisting_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetPlatformSpecificInterface(); // Function LoginExisting.LoginExisting_C.SetPlatformSpecificInterface // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleLoginError(struct FText ErrorMsg, int32_t ErrorId); // Function LoginExisting.LoginExisting_C.HandleLoginError // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__PopupButton_C_233_K2Node_ComponentBoundEvent_38_OnClicked__DelegateSignature(int32_t Index); // Function LoginExisting.LoginExisting_C.BndEvt__PopupButton_C_233_K2Node_ComponentBoundEvent_38_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function LoginExisting.LoginExisting_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnShown(); // Function LoginExisting.LoginExisting_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__PasswordField_K2Node_ComponentBoundEvent_25_OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Function LoginExisting.LoginExisting_C.BndEvt__PasswordField_K2Node_ComponentBoundEvent_25_OnEditableTextBoxCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__UsernameField_K2Node_ComponentBoundEvent_36_OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // Function LoginExisting.LoginExisting_C.BndEvt__UsernameField_K2Node_ComponentBoundEvent_36_OnEditableTextBoxCommittedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__UsernameField_K2Node_ComponentBoundEvent_60_OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Function LoginExisting.LoginExisting_C.BndEvt__UsernameField_K2Node_ComponentBoundEvent_60_OnEditableTextBoxChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__PasswordField_K2Node_ComponentBoundEvent_63_OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Function LoginExisting.LoginExisting_C.BndEvt__PasswordField_K2Node_ComponentBoundEvent_63_OnEditableTextBoxChangedEvent__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void Handle Input State Changed(enum class PGAME_INPUT_STATE InputState); // Function LoginExisting.LoginExisting_C.Handle Input State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ConfirmClicked(); // Function LoginExisting.LoginExisting_C.ConfirmClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnHide(); // Function LoginExisting.LoginExisting_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__PCCreateButton_K2Node_ComponentBoundEvent_57_OnClicked__DelegateSignature(int32_t Index); // Function LoginExisting.LoginExisting_C.BndEvt__PCCreateButton_K2Node_ComponentBoundEvent_57_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function LoginExisting.LoginExisting_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__AnonLoginButton_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature(); // Function LoginExisting.LoginExisting_C.BndEvt__AnonLoginButton_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__XboxCalloutWrapper_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function LoginExisting.LoginExisting_C.BndEvt__XboxCalloutWrapper_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function LoginExisting.LoginExisting_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnProfileChangeRequested(); // Function LoginExisting.LoginExisting_C.OnProfileChangeRequested // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Gamepad Select Username(); // Function LoginExisting.LoginExisting_C.Gamepad Select Username // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Gamepad Select Password(); // Function LoginExisting.LoginExisting_C.Gamepad Select Password // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoginExisting(int32_t EntryPoint); // Function LoginExisting.LoginExisting_C.ExecuteUbergraph_LoginExisting // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

