// BlueprintGeneratedClass Molotov_DamageType.Molotov_DamageType_C
// Size: 0x140 (Inherited: 0x140)
struct UMolotov_DamageType_C : UMasterFire_DamageType_C {
};

