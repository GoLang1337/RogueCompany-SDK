// WidgetBlueprintGeneratedClass LoginLinkPrompt.LoginLinkPrompt_C
// Size: 0x570 (Inherited: 0x518)
struct ULoginLinkPrompt_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UStandardButton_C* CreateButton; // 0x520(0x08)
	struct UStandardButton_C* DeclineButton; // 0x528(0x08)
	struct UStandardButton_C* ExistingButton; // 0x530(0x08)
	struct UImage* highlight_stroke; // 0x538(0x08)
	struct UImage* highlightborder; // 0x540(0x08)
	struct UImage* Image_56; // 0x548(0x08)
	struct UImage* Image_297; // 0x550(0x08)
	struct UImage* Image_531; // 0x558(0x08)
	struct UWidgetSwitcher* NextSwitcher; // 0x560(0x08)
	struct UImage* TitleLogo; // 0x568(0x08)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function LoginLinkPrompt.LoginLinkPrompt_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__DeclineButton_K2Node_ComponentBoundEvent_174_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginLinkPrompt.LoginLinkPrompt_C.BndEvt__DeclineButton_K2Node_ComponentBoundEvent_174_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function LoginLinkPrompt.LoginLinkPrompt_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__ExistingButton_K2Node_ComponentBoundEvent_50_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginLinkPrompt.LoginLinkPrompt_C.BndEvt__ExistingButton_K2Node_ComponentBoundEvent_50_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__CreateButton_K2Node_ComponentBoundEvent_67_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginLinkPrompt.LoginLinkPrompt_C.BndEvt__CreateButton_K2Node_ComponentBoundEvent_67_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoginLinkPrompt(int32_t EntryPoint); // Function LoginLinkPrompt.LoginLinkPrompt_C.ExecuteUbergraph_LoginLinkPrompt // (Final|UbergraphFunction) // @ game+0x24d5b40
};

