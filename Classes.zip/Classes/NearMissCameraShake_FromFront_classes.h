// BlueprintGeneratedClass NearMissCameraShake_FromFront.NearMissCameraShake_FromFront_C
// Size: 0x160 (Inherited: 0x160)
struct UNearMissCameraShake_FromFront_C : UCameraShake {
};

