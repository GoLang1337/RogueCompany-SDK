// BlueprintGeneratedClass NearMissCurveComponent.NearMissCurveComponent_C
// Size: 0x138 (Inherited: 0x130)
struct UNearMissCurveComponent_C : UKSNearMissComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x130(0x08)

	void UpdateScalarTrack(struct FName TrackName, float TrackValue); // Function NearMissCurveComponent.NearMissCurveComponent_C.UpdateScalarTrack // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_NearMissCurveComponent(int32_t EntryPoint); // Function NearMissCurveComponent.NearMissCurveComponent_C.ExecuteUbergraph_NearMissCurveComponent // (Final|UbergraphFunction) // @ game+0x24d5b40
};

