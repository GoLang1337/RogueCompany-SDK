// BlueprintGeneratedClass MainCharacterVOComponent.MainCharacterVOComponent_C
// Size: 0xb40 (Inherited: 0x180)
struct UMainCharacterVOComponent_C : UKSVOComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x180(0x08)
	struct FKSVoicelineEvent UnderFire; // 0x188(0x38)
	struct FKSVoicelineEvent TakingDamage; // 0x1c0(0x38)
	float AngleThresholdForShotFromBehind; // 0x1f8(0x04)
	char pad_1FC[0x4]; // 0x1fc(0x04)
	struct FKSVoicelineEvent ShotFromBehind; // 0x200(0x38)
	struct FKSVoicelineEvent AbilityOnCooldown; // 0x238(0x38)
	struct FKSVoicelineEvent PrimaryPickedUp; // 0x270(0x38)
	struct FKSVoicelineEvent GadgetPickedUp; // 0x2a8(0x38)
	struct FKSVoicelineEvent MeleePickedUp; // 0x2e0(0x38)
	struct FKSVoicelineEvent MedPackPickedUp; // 0x318(0x38)
	struct FKSVoicelineEvent Revived; // 0x350(0x38)
	struct FKSVoicelineEvent RevivedOther; // 0x388(0x38)
	struct FKSVoicelineEvent RevivedOtherRemote; // 0x3c0(0x38)
	struct FKSVoicelineEvent LastManStanding; // 0x3f8(0x38)
	struct FKSVoicelineEvent Zipline; // 0x430(0x38)
	struct FKSVoicelineEvent Upline; // 0x468(0x38)
	struct FKSVoicelineEvent Landed; // 0x4a0(0x38)
	struct FKSVoicelineEvent Mantle; // 0x4d8(0x38)
	struct FKSVoicelineEvent Jumped; // 0x510(0x38)
	struct FKSVoicelineEvent DodgeRoll; // 0x548(0x38)
	struct FKSVoicelineEvent GetObjective; // 0x580(0x38)
	struct FKSVoicelineEvent Victory; // 0x5b8(0x38)
	struct FKSVoicelineEvent Skydive; // 0x5f0(0x38)
	struct FKSVoicelineEvent LethalGadget; // 0x628(0x38)
	struct FKSVoicelineEvent UtilityGadget; // 0x660(0x38)
	struct FKSVoicelineEvent UtilityDeployable; // 0x698(0x38)
	struct FKSVoicelineEvent LethalDeployable; // 0x6d0(0x38)
	struct FKSVoicelineEvent InteractObjective; // 0x708(0x38)
	struct FKSVoicelineEvent Select; // 0x740(0x38)
	struct FKSVoicelineEvent ShopPurchase; // 0x778(0x38)
	struct UKSShopRuleComponent* ShopRuleComponent; // 0x7b0(0x08)
	struct FKSVoicelineEvent Intro; // 0x7b8(0x38)
	struct FKSVoicelineEvent ReviveMe; // 0x7f0(0x38)
	struct FKSVoicelineEvent Acknowledged; // 0x828(0x38)
	struct FKSVoicelineEvent CancelThat; // 0x860(0x38)
	struct FKSVoicelineEvent SuddenDeath; // 0x898(0x38)
	struct TMap<enum class EPingMessage, struct FKSVoicelineEvent> PingVOMap; // 0x8d0(0x50)
	struct FKSVoicelineEvent BombPickedUp; // 0x920(0x38)
	struct FKSVoicelineEvent BombPlant; // 0x958(0x38)
	struct FKSVoicelineEvent BombSpottedArmed; // 0x990(0x38)
	struct FKSVoicelineEvent BombSpottedUnarmed; // 0x9c8(0x38)
	struct FKSVoicelineEvent BombDefusing; // 0xa00(0x38)
	struct AKSPlayerState* PlayerState; // 0xa38(0x08)
	struct FKSVoicelineEvent SprintStart; // 0xa40(0x38)
	struct FKSVoicelineEvent SprintEnd; // 0xa78(0x38)
	bool SprintStarted; // 0xab0(0x01)
	char pad_AB1[0x7]; // 0xab1(0x07)
	struct FKSVoicelineEvent SprintEndStop; // 0xab8(0x38)
	bool SprintPlaying; // 0xaf0(0x01)
	char pad_AF1[0x3]; // 0xaf1(0x03)
	float SprintingTimer; // 0xaf4(0x04)
	bool SprintTimerExhale; // 0xaf8(0x01)
	char pad_AF9[0x7]; // 0xaf9(0x07)
	struct FTimerHandle SprintTimerHandle; // 0xb00(0x08)
	struct FKSVoicelineEvent Ouch; // 0xb08(0x38)

	void On Take Damage(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.On Take Damage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void EnemyBehind(struct AActor* EnemyActor, bool& Behind); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.EnemyBehind // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void BindToGameStateEvents(struct AKSGameState* GameState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToGameStateEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnLastManStanding(struct AKSPlayerState* LastPlayer); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnLastManStanding // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnWinnerSet(int32_t TeamNumber); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnWinnerSet // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnRoundSetup(struct FRoundInitState& RoundInitState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnRoundSetup // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnPhaseChange(struct FMatchPhase NewPhase, struct FMatchPhase PreviousPhase); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnPhaseChange // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BindToPingManagerEvents(struct UKSPingManager* PingManager); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToPingManagerEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void PingAdded(struct FPingInfo& PingInfo); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.PingAdded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PingAcknowledged(int32_t PingId, struct AKSPlayerState* PingingPlayer, struct AKSPlayerState* AcknowledgingPlayer); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.PingAcknowledged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SentVoiceLineOnly(enum class EPingMessage PingMessage, struct AKSPlayerState* SendingPlayer); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.SentVoiceLineOnly // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnItemPickedUp(struct AKSCharacter* Character, struct AKSItemDrop* ItemDrop, struct UKSItem* Item); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnItemPickedUp // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnReviveCompleted(struct AKSCharacter* Reviver, struct AKSCharacter* Revivee); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnReviveCompleted // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BindToCharacterEvents(struct AKSCharacter* Character); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToCharacterEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnInteractStart(struct AActor* Target, float Duration); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnInteractStart // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnLanded(struct FVector Velocity); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnLanded // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnMantleChanged(bool IsMantling); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnMantleChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnDOdgeRollChanged(bool IsDodgeRolling); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnDOdgeRollChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnJumped(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnJumped // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnCharacterFreeFallStarted(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnCharacterFreeFallStarted // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnWeaponInventoryChanged(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnWeaponInventoryChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BuildWeaponStateChanged(struct AKSWeapon* Weapon, enum class EWeaponStateNew OldState, enum class EWeaponStateNew NewState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BuildWeaponStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GadgetWeaponStateChanged(struct AKSWeapon* Weapon, enum class EWeaponStateNew OldState, enum class EWeaponStateNew NewState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.GadgetWeaponStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ResetObjectiveVO(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ResetObjectiveVO // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnStartReviveOther(struct AKSCharacter* Reviver, struct AKSCharacter* Revivee, float ReviveTime, bool bRemote); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnStartReviveOther // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnnounceBombSpotted(bool Armed); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.AnnounceBombSpotted // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnDeathStateChanged(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnDeathStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnSprintChanged(bool IsSprinting); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnSprintChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void FinalExhaleTimerSet(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.FinalExhaleTimerSet // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void DoOnceResetDefusing(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.DoOnceResetDefusing // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void DoOnceResetInteractObj(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.DoOnceResetInteractObj // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void DoOnceResetPlanting(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.DoOnceResetPlanting // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ModFailedToActivate(struct UKSModInst_Activated* AttemptedMod, enum class EKSAbilityUsageFailureType AbilityFailureType); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ModFailedToActivate // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BindToPlayerStateEvents(struct AKSPlayerState* PlayerState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToPlayerStateEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void BindToActivatableModEvents(struct UKSModInst_Activated* ActivatableMod); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToActivatableModEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void BindToEvents(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void BindToTeamStateEvents(struct AKSTeamState* TeamState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToTeamStateEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void BindToPlayerControllerEvents(struct AKSPlayerController* PlayerController); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.BindToPlayerControllerEvents // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnJobChanged(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnJobChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ShopItemChanged(struct FShopItem ShopItem); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ShopItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnPlayerDownedChanged(struct AKSPlayerState* PlayerState); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.OnPlayerDownedChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ModTriggered(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ModTriggered // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ModSetup(); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ModSetup // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ModActivated(bool bActive); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ModActivated // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_MainCharacterVOComponent(int32_t EntryPoint); // Function MainCharacterVOComponent.MainCharacterVOComponent_C.ExecuteUbergraph_MainCharacterVOComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

