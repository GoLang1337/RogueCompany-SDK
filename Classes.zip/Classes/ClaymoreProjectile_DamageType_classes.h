// BlueprintGeneratedClass ClaymoreProjectile_DamageType.ClaymoreProjectile_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UClaymoreProjectile_DamageType_C : UMasterMelee_DamageType_C {
};

