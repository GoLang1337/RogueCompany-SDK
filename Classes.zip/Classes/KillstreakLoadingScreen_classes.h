// Class KillstreakLoadingScreen.KSLoadingScreenSettings
// Size: 0xb0 (Inherited: 0x38)
struct UKSLoadingScreenSettings : UDeveloperSettings {
	struct FSoftObjectPath DefaultLoadingScreen; // 0x38(0x18)
	struct FSoftObjectPath ThrobberPiece; // 0x50(0x18)
	struct FSoftObjectPath HorizontalRule; // 0x68(0x18)
	struct FSoftObjectPath HeadingFont; // 0x80(0x18)
	struct FSoftObjectPath DefaultFont; // 0x98(0x18)
};

