// BlueprintGeneratedClass EventTracker_Conditional_MultiDowns.EventTracker_Conditional_MultiDowns_C
// Size: 0x211 (Inherited: 0x208)
struct UEventTracker_Conditional_MultiDowns_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	bool IsConditionMet; // 0x210(0x01)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Conditional_MultiDowns.EventTracker_Conditional_MultiDowns_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Conditional_MultiDowns.EventTracker_Conditional_MultiDowns_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MultiDownAchieved(int32_t DownCount, struct FCombatEventInfoContainer CombatEventContainer); // Function EventTracker_Conditional_MultiDowns.EventTracker_Conditional_MultiDowns_C.MultiDownAchieved // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Conditional_MultiDowns(int32_t EntryPoint); // Function EventTracker_Conditional_MultiDowns.EventTracker_Conditional_MultiDowns_C.ExecuteUbergraph_EventTracker_Conditional_MultiDowns // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

