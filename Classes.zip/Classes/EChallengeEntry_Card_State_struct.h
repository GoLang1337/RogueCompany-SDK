// Enum EChallengeEntry_Card_State.EChallengeEntry_Card_State
enum class EChallengeEntry_Card_State : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	NewEnumerator6 = 3,
	EChallengeEntry_Card_MAX = 4
};

