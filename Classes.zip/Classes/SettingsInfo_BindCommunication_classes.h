// BlueprintGeneratedClass SettingsInfo_BindCommunication.SettingsInfo_BindCommunication_C
// Size: 0x128 (Inherited: 0x128)
struct USettingsInfo_BindCommunication_C : UKSSettingsInfo_Binding {
};

