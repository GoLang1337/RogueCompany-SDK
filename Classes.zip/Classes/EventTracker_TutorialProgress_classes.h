// BlueprintGeneratedClass EventTracker_TutorialProgress.EventTracker_TutorialProgress_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_TutorialProgress_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void TutorialComplete(); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.TutorialComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_TutorialProgress(int32_t EntryPoint); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.ExecuteUbergraph_EventTracker_TutorialProgress // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

