// BlueprintGeneratedClass AttackBomb_Weapon.AttackBomb_Weapon_C
// Size: 0x878 (Inherited: 0x878)
struct AAttackBomb_Weapon_C : AKSWeapon_MacGuffin {
};

