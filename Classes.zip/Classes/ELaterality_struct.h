// Enum ELaterality.ELaterality
enum class ELaterality : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	ELaterality_MAX = 2
};

