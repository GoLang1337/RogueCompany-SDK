// WidgetBlueprintGeneratedClass GamepadPrompt_Bright.GamepadPrompt_Bright_C
// Size: 0x2a0 (Inherited: 0x238)
struct UGamepadPrompt_Bright_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UImage* GamepadIcon; // 0x240(0x08)
	struct UTextBlock* PromptText; // 0x248(0x08)
	struct FText Prompt; // 0x250(0x18)
	struct FName Action; // 0x268(0x08)
	bool IsConfirmGamepad; // 0x270(0x01)
	bool IsCancelGamepad; // 0x271(0x01)
	char pad_272[0x6]; // 0x272(0x06)
	struct FSlateColor FontColor; // 0x278(0x28)

	void Construct(); // Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_GamepadPrompt_Bright(int32_t EntryPoint); // Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.ExecuteUbergraph_GamepadPrompt_Bright // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

