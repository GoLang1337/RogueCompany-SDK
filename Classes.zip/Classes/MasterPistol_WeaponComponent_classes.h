// DynamicClass MasterPistol_WeaponComponent.MasterPistol_WeaponComponent_C
// Size: 0x1230 (Inherited: 0x1230)
struct UMasterPistol_WeaponComponent_C : UMaster_WeaponComponent_C {
};

