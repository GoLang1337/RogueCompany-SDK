// Enum KillstreakUINew.EEOMProgressionType
enum class EEOMProgressionType : uint8 {
	Unknown = 0,
	Account_XP = 1,
	Reputation = 2,
	Rogue_Mastery_XP = 3,
	Mini_Battlepass_XP = 4,
	Ranked_XP = 5,
	Placement_Matches = 6,
	Battlepass_XP = 7,
	Event_Challenge = 8,
	EEOMProgressionType_MAX = 9
};

// Enum KillstreakUINew.EKSPlayerQueryError
enum class EKSPlayerQueryError : uint8 {
	None = 0,
	NoResults = 1,
	TimedOut = 2,
	QueryError = 3,
	EKSPlayerQueryError_MAX = 4
};

// Enum KillstreakUINew.EPerkTreeNodeState
enum class EPerkTreeNodeState : uint8 {
	NODE_OFF = 0,
	NODE_ERROR = 1,
	NODE_UNREACHABLE = 2,
	NODE_UNAFFORDABLE = 3,
	NODE_UNLOCKABLE = 4,
	NODE_OWNED = 5,
	NODE_OWNED_EQUIPPED = 6,
	NODE_MAX = 7
};

// Enum KillstreakUINew.ESpecialtyItemType
enum class ESpecialtyItemType : uint8 {
	ESpecItemType_SpecialtyPerk = 0,
	ESpecItemType_GlobalPerk = 1,
	ESpecItemType_Killstreak = 2,
	ESpecItemType_Gadget = 3,
	ESpecItemType_PistolAttachment = 4,
	ESpecItemType_Pistol = 5,
	ESpecItemType_Specialty = 6,
	ESpecItemType_AutoEquippedPerk = 7,
	ESpecItemType_SecondaryAbility = 8,
	ESpecItemType_LoadoutClass = 9,
	ESpecItemType_LoadoutBundle = 10,
	ESpecItemType_MAX = 11
};

// Enum KillstreakUINew.EContextPromptHoldReleaseState
enum class EContextPromptHoldReleaseState : uint8 {
	HoldReleaseState_Started = 0,
	HoldReleaseState_Canceled = 1,
	HoldReleaseState_Completed = 2,
	HoldReleaseState_MAX = 3
};

// Enum KillstreakUINew.ERewardState
enum class ERewardState : uint8 {
	locked = 0,
	available = 1,
	claimed = 2,
	ERewardState_MAX = 3
};

// Enum KillstreakUINew.EQueueType
enum class EQueueType : uint8 {
	QT_Test = 0,
	QT_Training = 1,
	QT_PVP = 2,
	QT_PVE = 3,
	QT_Custom = 4,
	QT_Ranked = 5,
	QT_LimitedTime = 6,
	QT_None = 7,
	QT_MAX = 8
};

// Enum KillstreakUINew.EKSSocialOverlaySection
enum class EKSSocialOverlaySection : uint8 {
	Invalid = 0,
	PartyMembers = 1,
	MatchTeamMembers = 2,
	PartyInvitations = 3,
	FriendInvites = 4,
	OnlineMctsFriends = 5,
	OnlinePortalFriends = 6,
	OfflineMctsFriends = 7,
	Blocked = 8,
	SearchResults = 9,
	Pending = 10,
	RecentlyPlayed = 11,
	SuggestedFriends = 12,
	MAX = 13
};

// Enum KillstreakUINew.EKSInviteSelectResult
enum class EKSInviteSelectResult : uint8 {
	NoChange = 0,
	Selected = 1,
	Deselected = 2,
	EKSInviteSelectResult_MAX = 3
};

// Enum KillstreakUINew.EKSInviteCloseAction
enum class EKSInviteCloseAction : uint8 {
	None = 0,
	Submit = 1,
	EKSInviteCloseAction_MAX = 2
};

// Enum KillstreakUINew.EKSVoiceActivityAudioState
enum class EKSVoiceActivityAudioState : uint8 {
	Disconnected = 0,
	Connecting = 1,
	Connected = 2,
	Disconnecting = 3,
	EKSVoiceActivityAudioState_MAX = 4
};

// Enum KillstreakUINew.ECombatEventType
enum class ECombatEventType : uint8 {
	CombatEvent_Down = 0,
	CombatEvent_Elim = 1,
	CombatEvent_MAX = 2
};

// Enum KillstreakUINew.EConfigPropertyGuidedCalloutScenes
enum class EConfigPropertyGuidedCalloutScenes : uint8 {
	NONE = 0,
	ROGUE_SCENE = 1,
	ROGUE_CUSTOMIZATION = 2,
	QUEUE_SELECT = 3,
	ARMORY = 4,
	WEAPON_DETAILS = 5,
	ROGUE_SCREEN_ARMORY = 6,
	MAX_DO_NOT_GO_OVER = 32,
	EConfigPropertyGuidedCalloutScenes_MAX = 33
};

// Enum KillstreakUINew.EAllyMarkerState
enum class EAllyMarkerState : uint8 {
	Normal = 0,
	Downed = 1,
	Reviving = 2,
	Dead = 3,
	Hidden = 4,
	EAllyMarkerState_MAX = 5
};

// Enum KillstreakUINew.EKSAutoTeamType
enum class EKSAutoTeamType : uint8 {
	LocalTeam = 0,
	ExactTeamNum = 1,
	RelativeEnemyTeam = 2,
	EKSAutoTeamType_MAX = 3
};

// Enum KillstreakUINew.EChallengeEntryCardState
enum class EChallengeEntryCardState : uint8 {
	Empty = 0,
	Incomplete = 1,
	Complete = 2,
	Locked = 3,
	EChallengeEntryCardState_MAX = 4
};

// Enum KillstreakUINew.EContextPromptAnchoring
enum class EContextPromptAnchoring : uint8 {
	AnchorLeft = 0,
	AnchorRight = 1,
	AnchorCenter = 2,
	EContextPromptAnchoring_MAX = 3
};

// Enum KillstreakUINew.EContextPromptType
enum class EContextPromptType : uint8 {
	PromptTypeStandard = 0,
	PromptTypeCycle = 1,
	PromptTypeHoldRelease = 2,
	EContextPromptType_MAX = 3
};

// Enum KillstreakUINew.EViewSide
enum class EViewSide : uint8 {
	Left = 0,
	Right = 1,
	None = 2,
	EViewSide_MAX = 3
};

// Enum KillstreakUINew.EQueueDataFactoryAction
enum class EQueueDataFactoryAction : uint8 {
	SwapPlayerCustomMatch = 0,
	KickFromCustomMatch = 1,
	EQueueDataFactoryAction_MAX = 2
};

// Enum KillstreakUINew.EPartyDataFactoryAction
enum class EPartyDataFactoryAction : uint8 {
	KickMember = 0,
	PromoteToLeader = 1,
	AcceptInvite = 2,
	DenyInvite = 3,
	LeaveParty = 4,
	EPartyDataFactoryAction_MAX = 5
};

// Enum KillstreakUINew.EFriendDataFactoryAction
enum class EFriendDataFactoryAction : uint8 {
	AddFriend = 0,
	RemoveFriend = 1,
	CancelFriendRequest = 2,
	AcceptFriendRequest = 3,
	RejectFriendRequest = 4,
	EFriendDataFactoryAction_MAX = 5
};

// Enum KillstreakUINew.EPlayerContextOptions
enum class EPlayerContextOptions : uint8 {
	AddFriend = 0,
	AddRoCoFriend = 1,
	PartyInvite = 2,
	LobbySwapTeam = 3,
	LobbyKickPlayer = 4,
	LobbyPromotePlayer = 5,
	PartyKick = 6,
	Whisper = 7,
	ViewProfile = 8,
	ViewPlatformProfile = 9,
	RemoveFriend = 10,
	CancelRequest = 11,
	AcceptFriendRequest = 12,
	RejectFriendRequest = 13,
	PromotePartyLeader = 14,
	AcceptPartyInvite = 15,
	DeclinePartyInvite = 16,
	LeaveParty = 17,
	Mute = 18,
	Unmute = 19,
	ReportPlayer = 20,
	None = 21,
	EPlayerContextOptions_MAX = 22
};

// Enum KillstreakUINew.EPlayerContextMenuContext
enum class EPlayerContextMenuContext : uint8 {
	Friends = 0,
	Party = 1,
	CustomLobby = 2,
	InGame = 3,
	Default = 4,
	EPlayerContextMenuContext_MAX = 5
};

// Enum KillstreakUINew.EKSCategoryOpenMode
enum class EKSCategoryOpenMode : uint8 {
	ClosedByDefault = 0,
	OpenByDefault = 1,
	EKSCategoryOpenMode_MAX = 2
};

// Enum KillstreakUINew.EConsoleCommandParamType
enum class EConsoleCommandParamType : uint8 {
	None = 0,
	Bool = 1,
	String = 2,
	EConsoleCommandParamType_MAX = 3
};

// Enum KillstreakUINew.EEquipAllType
enum class EEquipAllType : uint8 {
	None = 0,
	EquipToJob = 1,
	EquipToWeapon = 2,
	EEquipAllType_MAX = 3
};

// Enum KillstreakUINew.ESocialMessageType
enum class ESocialMessageType : uint8 {
	EInvite = 0,
	EInviteResponse = 1,
	EInviteExpired = 2,
	EInviteError = 3,
	EGenericMsg = 4,
	ESocialMessageType_MAX = 5
};

// Enum KillstreakUINew.ELowAmmoState
enum class ELowAmmoState : uint8 {
	Normal = 0,
	NeedsReload = 1,
	LowAmmo = 2,
	NoAmmo = 3,
	ELowAmmoState_MAX = 4
};

// Enum KillstreakUINew.EIconMarkerScreenRegion
enum class EIconMarkerScreenRegion : uint8 {
	Normal = 0,
	Center = 1,
	Edge = 2,
	EIconMarkerScreenRegion_MAX = 3
};

// Enum KillstreakUINew.EIconHoverState
enum class EIconHoverState : uint8 {
	Unhovered = 0,
	Hovering = 1,
	Hovered = 2,
	Unhovering = 3,
	EIconHoverState_MAX = 4
};

// Enum KillstreakUINew.EMinimapWidgetClampStyle
enum class EMinimapWidgetClampStyle : uint8 {
	Circular = 0,
	Square = 1,
	SquareByAngle = 2,
	SquareByProjection = 3,
	EMinimapWidgetClampStyle_MAX = 4
};

// Enum KillstreakUINew.ENewsActions
enum class ENewsActions : uint8 {
	ENewsActions_Unknown = 0,
	ENewsActions_ExternalURL = 1,
	ENewsActions_NavToRoute = 2,
	ENewsActions_NavToStoreItem = 3,
	ENewsActions_NavToRogueDetails = 4,
	ENewsActions_NavToCustomization = 5,
	ENewsActions_MAX = 6
};

// Enum KillstreakUINew.EPerkTreeEdgeState
enum class EPerkTreeEdgeState : uint8 {
	EDGE_OFF = 0,
	EDGE_ERROR = 1,
	EDGE_UNREACHABLE = 2,
	EDGE_TO_UNLOCKABLE = 3,
	EDGE_OWNED = 4,
	EDGE_MAX = 5
};

// Enum KillstreakUINew.EPerkTreeEdgeType
enum class EPerkTreeEdgeType : uint8 {
	EDGE_TOP = 0,
	EDGE_LEFT = 1,
	EDGE_DIAGONAL = 2,
	EDGE_BACK_DIAGONAL = 3,
	EDGE_MAX = 4
};

// Enum KillstreakUINew.EPlayerSelectionState
enum class EPlayerSelectionState : uint8 {
	EPlayerState_Selecting = 0,
	EPlayerState_Selected = 1,
	EPlayerState_LockedIn = 2,
	EPlayerState_MAX = 3
};

// Enum KillstreakUINew.EPointObjectiveMarkerTeamState
enum class EPointObjectiveMarkerTeamState : uint8 {
	Neutral = 0,
	AllyOwned = 1,
	EnemyOwned = 2,
	Contested = 3,
	EPointObjectiveMarkerTeamState_MAX = 4
};

// Enum KillstreakUINew.EKSQueueJoinError
enum class EKSQueueJoinError : uint8 {
	None = 0,
	SystemError = 1,
	QueueUnavailable = 2,
	DeserterPenaltyActive = 3,
	PlayerLevelRequirement = 4,
	PartyMemberLevelRequirement = 5,
	PartyMinMemberRequirement = 6,
	PartyMaxMemberRequirement = 7,
	InQueue = 8,
	PartyMemberRankRequirement = 9,
	PartyMemberPlatformRequirement = 10,
	EKSQueueJoinError_MAX = 11
};

// Enum KillstreakUINew.EQueueTimerState
enum class EQueueTimerState : uint8 {
	Unknown = 0,
	DeserterPenaltyActive = 1,
	WaitingForLeader = 2,
	Queued = 3,
	EnteringMatch = 4,
	EQueueTimerState_MAX = 5
};

// Enum KillstreakUINew.EQuickPlayQueueState
enum class EQuickPlayQueueState : uint8 {
	Unknown = 0,
	NoQueuesAvailable = 1,
	NoSelectedQueue = 2,
	SelectedQueueUnavailable = 3,
	DeserterPenaltyActive = 4,
	SelectedQueuePartyMinLimit = 5,
	SelectedQueuePartyMaxLimit = 6,
	ReadyToJoin = 7,
	WaitingForLeader = 8,
	Queued = 9,
	EnteringMatch = 10,
	ReadyToRejoin = 11,
	PlayerLevelRequirement = 12,
	PartyLevelRequirement = 13,
	PartyRankRequirement = 14,
	PartyPlatformRequirement = 15,
	EQuickPlayQueueState_MAX = 16
};

// Enum KillstreakUINew.EAmmoState
enum class EAmmoState : uint8 {
	EAmmoState_Full = 0,
	EAmmoState_NeedsReload = 1,
	EAmmoState_LowAmmo = 2,
	EAmmoState_CriticallyLowAmmo = 3,
	EAmmoState_NoAmmo = 4,
	EAmmoState_MAX = 5
};

// Enum KillstreakUINew.ERogueDetailsWidgetFocusGroups
enum class ERogueDetailsWidgetFocusGroups : uint8 {
	MAIN_TABS = 0,
	CUSTOMIZE_PANEL = 1,
	MASTERY_PANEL = 2,
	ARMORY_PANEL = 3,
	PRIMARY_SELECT_PANEL = 4,
	ERogueDetailsWidgetFocusGroups_MAX = 5
};

// Enum KillstreakUINew.EKSSettingType
enum class EKSSettingType : uint8 {
	Bool = 0,
	Int = 1,
	Float = 2,
	Key = 3,
	Invalid = 4,
	EKSSettingType_MAX = 5
};

// Enum KillstreakUINew.EPUMG_ShopItemUpgradeSegmentType
enum class EPUMG_ShopItemUpgradeSegmentType : uint8 {
	Single = 0,
	First = 1,
	Middle = 2,
	Last = 3,
	EPUMG_MAX = 4
};

// Enum KillstreakUINew.EKSSocialFriendSection
enum class EKSSocialFriendSection : uint8 {
	Invalid = 0,
	PartyMembers = 1,
	MatchTeamMembers = 2,
	PartyInvitations = 3,
	OnlineMctsFriends = 4,
	OnlinePortalFriends = 5,
	OfflineMctsFriends = 6,
	Blocked = 7,
	Pending = 8,
	MAX = 9
};

// Enum KillstreakUINew.EKSSocialPanelDisplayOption
enum class EKSSocialPanelDisplayOption : uint8 {
	HideIfEmpty = 0,
	ShowIfEmpty = 1,
	EKSSocialPanelDisplayOption_MAX = 2
};

// Enum KillstreakUINew.EStoreItemWidgetType
enum class EStoreItemWidgetType : uint8 {
	ELargePanel = 0,
	ETallPanel = 1,
	ESmallPanel = 2,
	STORE_WIDGET_TYPE_MAX = 3,
	EStoreItemWidgetType_MAX = 4
};

// Enum KillstreakUINew.ETargetMarkerViewState
enum class ETargetMarkerViewState : uint8 {
	Hidden = 0,
	Showing = 1,
	Shown = 2,
	HidingNeutral = 3,
	HidingActivated = 4,
	HidingFailed = 5,
	ETargetMarkerViewState_MAX = 6
};

// Enum KillstreakUINew.EToastCategory
enum class EToastCategory : uint8 {
	ETOAST_INFO = 0,
	ETOAST_ERROR = 1,
	ETOAST_FRIEND = 2,
	ETOAST_PARTY = 3,
	ETOAST_CHALLENGE = 4,
	ETOAST_MERC_MASTERY = 5,
	ETOAST_ITEM_UNLOCK = 6,
	ETOAST_AWARD = 7,
	ETOAST_BATTLEPASS_TIER = 8,
	ETOAST_BOOST_ACTIVATION = 9,
	ETOAST_PLAYER_LEVEL = 10,
	ETOAST_EVENT_CHALLENGE = 11,
	ETOAST_WEAPON_MASTERY = 12,
	ETOAST_MAX = 13
};

// Enum KillstreakUINew.EReportPlayerReason
enum class EReportPlayerReason : uint8 {
	Unknown_None = 0,
	Harassment = 1,
	Cheating = 2,
	Teaming = 3,
	IntentionalFeeding = 4,
	StreamSniping = 5,
	LeavingTheGame_AFK = 6,
	OtherReason = 7,
	AFK = 8,
	EReportPlayerReason_MAX = 9
};

// Enum KillstreakUINew.EExperimentalFeatureName
enum class EExperimentalFeatureName : uint8 {
	Unknown_None = 0,
	HUD_Announcement_V2 = 1,
	WeaponShopRarity = 2,
	EOMMilestonesAnyProgress = 3,
	EExperimentalFeatureName_MAX = 4
};

// Enum KillstreakUINew.EKSVendorTypes
enum class EKSVendorTypes : uint8 {
	Unknown = 0,
	Equipment = 1,
	Specialty = 2,
	SpecialtyItem = 3,
	StarterSpecLoadout = 4,
	Apparel = 5,
	StarterApparelLoadout = 6,
	MalwearApparelLoadout = 7,
	MercTwoApparelLoadout = 8,
	HitmanApparelLoadout = 9,
	EKSVendorTypes_MAX = 10
};

// Enum KillstreakUINew.EDamageTargetType
enum class EDamageTargetType : uint8 {
	None = 0,
	Character = 1,
	Gadget = 2,
	EDamageTargetType_MAX = 3
};

// Enum KillstreakUINew.EDamageModifier
enum class EDamageModifier : uint8 {
	None = 0,
	Reduced = 1,
	Resisted = 2,
	Shielded = 3,
	EDamageModifier_MAX = 4
};

// Enum KillstreakUINew.EDamageFlourishType
enum class EDamageFlourishType : uint8 {
	None = 0,
	Headshot = 1,
	Lethal = 2,
	EDamageFlourishType_MAX = 3
};

// Enum KillstreakUINew.EDamageBaseType
enum class EDamageBaseType : uint8 {
	Normal = 0,
	Armored = 1,
	Lethal = 2,
	Special = 3,
	EDamageBaseType_MAX = 4
};

// Enum KillstreakUINew.ERelatedRogueType
enum class ERelatedRogueType : uint8 {
	UsesUnlocked = 0,
	UsesLocked = 1,
	ERelatedRogueType_MAX = 2
};

// Enum KillstreakUINew.ESubPanelAlignment
enum class ESubPanelAlignment : uint8 {
	ESubPanelAlignment_Horizontal = 0,
	ESubPanelAlignment_VerticalLeft = 1,
	ESubPanelAlignment_VerticalRight = 2,
	ESubPanelAlignment_MAX = 3
};

// ScriptStruct KillstreakUINew.PlayerProgression
// Size: 0x170 (Inherited: 0x00)
struct FPlayerProgression {
	struct TArray<struct FActivityTier> ProgressionTiers; // 0x00(0x10)
	int32_t StartingXPValue; // 0x10(0x04)
	int32_t EndingXPValue; // 0x14(0x04)
	struct UKSActivity* ActivityReference; // 0x18(0x08)
	struct UKSActivityInstance* ActivityInstanceReference; // 0x20(0x08)
	struct TMap<enum class ERewardSource, float> ProgressionBySource; // 0x28(0x50)
	struct TMap<struct FString, float> ProgressionByEvent; // 0x78(0x50)
	struct TMap<struct FString, float> ProgressionByBooster; // 0xc8(0x50)
	struct TMap<struct FString, float> ExtraData; // 0x118(0x50)
	enum class EEOMProgressionType ProgressionType; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
};

// ScriptStruct KillstreakUINew.CustomLoadoutItem
// Size: 0x10 (Inherited: 0x00)
struct FCustomLoadoutItem {
	struct UKSItem* Item; // 0x00(0x08)
	enum class ESpecialtyItemType SpecialtyItemType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t LoadoutClassItemId; // 0x0c(0x04)
};

// ScriptStruct KillstreakUINew.LoginRewardItem
// Size: 0x10 (Inherited: 0x00)
struct FLoginRewardItem {
	int32_t RewardDay; // 0x00(0x04)
	enum class ERewardState RewardState; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct UPUMG_StoreItem* RewardStoreItem; // 0x08(0x08)
};

// ScriptStruct KillstreakUINew.ClientQueueInfo
// Size: 0xc8 (Inherited: 0x50)
struct FClientQueueInfo : FPUMG_ClientQueueInfo {
	struct TSoftObjectPtr<UTexture2D> ItemIcon; // 0x50(0x28)
	enum class EQueueType QueueType; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TArray<struct FUIMapInfo> MapRotationInfos; // 0x80(0x10)
	struct TArray<struct FMapDetail> MapList; // 0x90(0x10)
	int32_t MaxPlayerPerSide; // 0xa0(0x04)
	int32_t SortOrder; // 0xa4(0x04)
	int32_t ShelteredMMQueueId; // 0xa8(0x04)
	float ShelteredMMLevelLimit; // 0xac(0x04)
	float ShelteredMMAttemptTimeout; // 0xb0(0x04)
	int32_t ForcedBotMatchQueueId; // 0xb4(0x04)
	char pad_B8[0x4]; // 0xb8(0x04)
	int32_t MercyMatchQueueId; // 0xbc(0x04)
	char pad_C0[0x4]; // 0xc0(0x04)
	bool UsesDeserterPenalty; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
};

// ScriptStruct KillstreakUINew.MapDetail
// Size: 0x48 (Inherited: 0x00)
struct FMapDetail {
	int32_t MapId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FText mapName; // 0x08(0x18)
	struct TSoftObjectPtr<UTexture2D> MapThumbnail; // 0x20(0x28)
};

// ScriptStruct KillstreakUINew.UIMapInfo
// Size: 0x58 (Inherited: 0x08)
struct FUIMapInfo : FTableRowBase {
	struct TArray<int32_t> MapIds; // 0x08(0x10)
	struct FText DisplayName; // 0x18(0x18)
	struct TSoftObjectPtr<UTexture2D> MapThumbnail; // 0x30(0x28)
};

// ScriptStruct KillstreakUINew.TickAnimationParams
// Size: 0x2c (Inherited: 0x00)
struct FTickAnimationParams {
	float Duration; // 0x00(0x04)
	struct FDelegate UpdateEvent; // 0x04(0x10)
	struct FDelegate FinishedEvent; // 0x14(0x10)
	bool IsPlaying; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	float ElapsedTime; // 0x28(0x04)
};

// ScriptStruct KillstreakUINew.EliminationMessage
// Size: 0x30 (Inherited: 0x00)
struct FEliminationMessage {
	struct AKSPlayerState* Victim; // 0x00(0x08)
	struct AKSPlayerState* Instigator; // 0x08(0x08)
	struct FText Message; // 0x10(0x18)
	int32_t DamageDealt; // 0x28(0x04)
	enum class ECombatEventType EventType; // 0x2c(0x01)
	bool ViewedPlayerAssisted; // 0x2d(0x01)
	char pad_2E[0x2]; // 0x2e(0x02)
};

// ScriptStruct KillstreakUINew.HudEditableData
// Size: 0x20 (Inherited: 0x00)
struct FHudEditableData {
	struct FName WidgetName; // 0x00(0x08)
	struct FVector2D AbsolutePosition; // 0x08(0x08)
	bool bHasSetAbsolutePosition; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float Scale; // 0x14(0x04)
	float Opacity; // 0x18(0x04)
	int32_t bIsVisible; // 0x1c(0x04)
};

// ScriptStruct KillstreakUINew.GuidedCalloutSceneData
// Size: 0x40 (Inherited: 0x08)
struct FGuidedCalloutSceneData : FTableRowBase {
	enum class EConfigPropertyGuidedCalloutScenes SceneIndex; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	struct FName AssociatedViewRoute; // 0x0c(0x08)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText HeaderText; // 0x18(0x18)
	struct TArray<struct FGuidedCalloutCardData> CalloutCards; // 0x30(0x10)
};

// ScriptStruct KillstreakUINew.GuidedCalloutCardData
// Size: 0x58 (Inherited: 0x00)
struct FGuidedCalloutCardData {
	struct FText Header; // 0x00(0x18)
	struct FText Description; // 0x18(0x18)
	struct TSoftObjectPtr<UTexture2D> Image; // 0x30(0x28)
};

// ScriptStruct KillstreakUINew.AcquisitionHeaderOverrides
// Size: 0x30 (Inherited: 0x08)
struct FAcquisitionHeaderOverrides : FTableRowBase {
	struct FText Header; // 0x08(0x18)
	struct TArray<int32_t> LootTableItemIds; // 0x20(0x10)
};

// ScriptStruct KillstreakUINew.RouteContextInfo
// Size: 0x10 (Inherited: 0x00)
struct FRouteContextInfo {
	struct TArray<struct UContextActionData*> ActionData; // 0x00(0x10)
};

// ScriptStruct KillstreakUINew.ContextAction
// Size: 0x58 (Inherited: 0x08)
struct FContextAction : FTableRowBase {
	struct FText Text; // 0x08(0x18)
	struct FName ActionName; // 0x20(0x08)
	struct TArray<enum class PGAME_INPUT_STATE> ValidInputTypes; // 0x28(0x10)
	int32_t SortOrder; // 0x38(0x04)
	enum class EContextPromptAnchoring Anchor; // 0x3c(0x01)
	enum class EContextPromptType PromptType; // 0x3d(0x01)
	char pad_3E[0x2]; // 0x3e(0x02)
	struct UKSWidget* PromptWidget; // 0x40(0x08)
	float HoldDuration; // 0x48(0x04)
	bool IsHidden; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	struct UAkAudioEvent* OverrideSFX; // 0x50(0x08)
};

// ScriptStruct KillstreakUINew.RogueCustomizationRelatedInfo
// Size: 0x30 (Inherited: 0x00)
struct FRogueCustomizationRelatedInfo {
	int32_t SwitcherIndex; // 0x00(0x04)
	enum class EMercCosmeticSlot CosmeticSlot; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct UKSNavTabWidget* NavTab; // 0x08(0x08)
	struct UKSScrollBox* ScrollBox; // 0x10(0x08)
	struct UKSSortableGridPanel* SortableGridPanel; // 0x18(0x08)
	struct TArray<struct UKSCosmeticItemSelectorWidget*> CosmeticItemSelectors; // 0x20(0x10)
};

// ScriptStruct KillstreakUINew.DebugMenuCommandInfo
// Size: 0x18 (Inherited: 0x00)
struct FDebugMenuCommandInfo {
	struct FString CommandName; // 0x00(0x10)
	enum class EConsoleCommandParamType ParamType; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct KillstreakUINew.MatchDetail
// Size: 0x38 (Inherited: 0x00)
struct FMatchDetail {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct KillstreakUINew.ExpDisplayInfo
// Size: 0x28 (Inherited: 0x00)
struct FExpDisplayInfo {
	int32_t EventDelta; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FText EventReason; // 0x08(0x18)
	bool bIsBonus; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct KillstreakUINew.ButtonPromptContext
// Size: 0x10 (Inherited: 0x00)
struct FButtonPromptContext {
	struct TArray<struct FButtonPromptData> PromptInfo; // 0x00(0x10)
};

// ScriptStruct KillstreakUINew.ButtonPromptData
// Size: 0x30 (Inherited: 0x00)
struct FButtonPromptData {
	struct FKey Key; // 0x00(0x18)
	struct FText Text; // 0x18(0x18)
};

// ScriptStruct KillstreakUINew.FontPaletteInfo
// Size: 0x58 (Inherited: 0x08)
struct FFontPaletteInfo : FTableRowBase {
	struct FSlateFontInfo FontInfo; // 0x08(0x50)
};

// ScriptStruct KillstreakUINew.ColorPaletteInfo
// Size: 0x18 (Inherited: 0x08)
struct FColorPaletteInfo : FTableRowBase {
	struct FLinearColor LinearColor; // 0x08(0x10)
};

// ScriptStruct KillstreakUINew.MapIconOptions
// Size: 0x18 (Inherited: 0x00)
struct FMapIconOptions {
	struct FVector MarkerWorldPosition; // 0x00(0x0c)
	float AnchorHeight; // 0x0c(0x04)
	struct FVector2D ScreenMargin; // 0x10(0x08)
};

// ScriptStruct KillstreakUINew.MapIconWidgetConfig
// Size: 0x48 (Inherited: 0x00)
struct FMapIconWidgetConfig {
	enum class EDisplayType MapDisplayType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString WidgetPoolType; // 0x08(0x10)
	int32_t Count; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TSoftClassPtr<UObject> MapIconWidget; // 0x20(0x28)
};

// ScriptStruct KillstreakUINew.RoundResultAnnoucement
// Size: 0x20 (Inherited: 0x00)
struct FRoundResultAnnoucement {
	int32_t WinningTeamID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FText ResultText; // 0x08(0x18)
};

// ScriptStruct KillstreakUINew.KSMediaPlayerWidgetPlaylistEntry
// Size: 0x98 (Inherited: 0x08)
struct FKSMediaPlayerWidgetPlaylistEntry : FTableRowBase {
	bool bIsSkippable; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float SkippableAfter; // 0x0c(0x04)
	bool bForceFirstWatch; // 0x10(0x01)
	bool bOnlyWatchOnce; // 0x11(0x01)
	uint16_t MajorVersion; // 0x12(0x02)
	char pad_14[0x4]; // 0x14(0x04)
	struct TSoftObjectPtr<UPlatformMediaSource> PlatformMediaSource; // 0x18(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> PlayEvent; // 0x40(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> StopEvent; // 0x68(0x28)
	struct FName LocalActionName; // 0x90(0x08)
};

// ScriptStruct KillstreakUINew.KSMilestoneCompletedSummaryEntry
// Size: 0xa0 (Inherited: 0x00)
struct FKSMilestoneCompletedSummaryEntry {
	struct UKSWeaponAsset* WeaponAsset; // 0x00(0x08)
	struct UKSActivityInstance* MilestoneInstance; // 0x08(0x08)
	struct FRewardProgress MilestoneProgress; // 0x10(0x90)
};

// ScriptStruct KillstreakUINew.OverlayTabViewRow
// Size: 0x30 (Inherited: 0x08)
struct FOverlayTabViewRow : FTableRowBase {
	struct FText TabName; // 0x08(0x18)
	struct UPUMG_Widget* ViewWidget; // 0x20(0x08)
	struct UKSTabValidator* TabValidator; // 0x28(0x08)
};

// ScriptStruct KillstreakUINew.KSPerkTreeEdgeInfo
// Size: 0x02 (Inherited: 0x00)
struct FKSPerkTreeEdgeInfo {
	enum class EPerkTreeEdgeType EdgeType; // 0x00(0x01)
	enum class EPerkTreeEdgeState EdgeState; // 0x01(0x01)
};

// ScriptStruct KillstreakUINew.PlayerAwardsPanelData
// Size: 0x10 (Inherited: 0x00)
struct FPlayerAwardsPanelData {
	struct UKSActivityInstance* ActivityInstance; // 0x00(0x08)
	int32_t ProgressTierOverride; // 0x08(0x04)
	bool RecentlyUpdated; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct KillstreakUINew.KSPendingProfiles
// Size: 0x28 (Inherited: 0x00)
struct FKSPendingProfiles {
	struct TArray<struct UKSPlayerInfo*> PendingPlayers; // 0x00(0x10)
	char pad_10[0x18]; // 0x10(0x18)
};

// ScriptStruct KillstreakUINew.KSPlayerQueryHandle
// Size: 0x10 (Inherited: 0x00)
struct FKSPlayerQueryHandle {
	struct UKSPlayerQueryDataFactory* Owner; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct KillstreakUINew.KSPointObjectiveMarkerViewState
// Size: 0x04 (Inherited: 0x00)
struct FKSPointObjectiveMarkerViewState {
	enum class EKSObjectiveState ObjectiveState; // 0x00(0x01)
	enum class EKSPOIState POIState; // 0x01(0x01)
	enum class EPointObjectiveMarkerTeamState TeamState; // 0x02(0x01)
	bool IsBombDeployed; // 0x03(0x01)
};

// ScriptStruct KillstreakUINew.ProgressionTallyMiscXPInfo
// Size: 0x20 (Inherited: 0x00)
struct FProgressionTallyMiscXPInfo {
	struct FText TallyDisplayFormat; // 0x00(0x18)
	bool ShouldDisplay; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct KillstreakUINew.QueueSection
// Size: 0x18 (Inherited: 0x00)
struct FQueueSection {
	enum class EQueueType QueueSectionType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FClientQueueInfo> AssociatedQueues; // 0x08(0x10)
};

// ScriptStruct KillstreakUINew.QueueDetail
// Size: 0x48 (Inherited: 0x08)
struct FQueueDetail : FTableRowBase {
	int32_t QueueId; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FText QueueName; // 0x10(0x18)
	struct FText QueueDescription; // 0x28(0x18)
	int32_t SortOrder; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct KillstreakUINew.MasterySectionData
// Size: 0x18 (Inherited: 0x00)
struct FMasterySectionData {
	struct TArray<struct FActivityTier> ActivityTiers; // 0x00(0x10)
	float ProgressPercentage; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct KillstreakUINew.MasteryRewardData
// Size: 0x10 (Inherited: 0x00)
struct FMasteryRewardData {
	struct UPUMG_StoreItem* StoreItem; // 0x00(0x08)
	int32_t BadgeTier; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct KillstreakUINew.KSSettingPropertyId
// Size: 0x0c (Inherited: 0x00)
struct FKSSettingPropertyId {
	struct FName Name; // 0x00(0x08)
	int32_t ID; // 0x08(0x04)
};

// ScriptStruct KillstreakUINew.KSSettingsGroupConfig
// Size: 0x18 (Inherited: 0x00)
struct FKSSettingsGroupConfig {
	struct UKSSettingsContainerConfigAsset* MainSettingContainerAsset; // 0x00(0x08)
	struct TArray<struct UKSSettingsContainerConfigAsset*> SubSettingContainerAssets; // 0x08(0x10)
};

// ScriptStruct KillstreakUINew.ColorOptions
// Size: 0x28 (Inherited: 0x00)
struct FColorOptions {
	struct FText OptionName; // 0x00(0x18)
	struct FLinearColor OptionColor; // 0x18(0x10)
};

// ScriptStruct KillstreakUINew.KSSettingsWidgetConfig
// Size: 0x10 (Inherited: 0x00)
struct FKSSettingsWidgetConfig {
	struct UKSSettingsWidget* WidgetClass; // 0x00(0x08)
	struct UKSSettingsInfoBase* SettingInfo; // 0x08(0x08)
};

// ScriptStruct KillstreakUINew.KSSwitchDockedModeSetting
// Size: 0x02 (Inherited: 0x00)
struct FKSSwitchDockedModeSetting {
	bool ShowDocked; // 0x00(0x01)
	bool ShowHandheld; // 0x01(0x01)
};

// ScriptStruct KillstreakUINew.KSRequiredInputTypes
// Size: 0x03 (Inherited: 0x00)
struct FKSRequiredInputTypes {
	bool Gamepad; // 0x00(0x01)
	bool Mouse; // 0x01(0x01)
	bool Touch; // 0x02(0x01)
};

// ScriptStruct KillstreakUINew.KSAllowedPlatformTypes
// Size: 0x0a (Inherited: 0x00)
struct FKSAllowedPlatformTypes {
	bool XboxOne; // 0x00(0x01)
	bool PS4; // 0x01(0x01)
	bool Switch; // 0x02(0x01)
	bool Windows; // 0x03(0x01)
	bool Mac; // 0x04(0x01)
	bool Linux; // 0x05(0x01)
	bool IOS; // 0x06(0x01)
	bool Android; // 0x07(0x01)
	bool XSX; // 0x08(0x01)
	bool PS5; // 0x09(0x01)
};

// ScriptStruct KillstreakUINew.KSKeyGroup
// Size: 0x1c (Inherited: 0x00)
struct FKSKeyGroup {
	char pad_0[0x1c]; // 0x00(0x1c)
};

// ScriptStruct KillstreakUINew.KSKeyBind
// Size: 0x78 (Inherited: 0x00)
struct FKSKeyBind {
	struct FKey Primary; // 0x00(0x18)
	enum class EKSInputActionType PrimaryInputActionType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FKey Secondary; // 0x20(0x18)
	enum class EKSInputActionType SecondaryInputActionType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FKey Gamepad; // 0x40(0x18)
	struct FKey Combo; // 0x58(0x18)
	enum class EKSInputActionType GamepadInputActionType; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct KillstreakUINew.KSKeyBindInfo
// Size: 0x10 (Inherited: 0x00)
struct FKSKeyBindInfo {
	struct FName Name; // 0x00(0x08)
	float Scale; // 0x08(0x04)
	enum class EKSInputType InputType; // 0x0c(0x01)
	enum class EKSKeyBindType KeyBindType; // 0x0d(0x01)
	bool IsPermanentBinding; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
};

// ScriptStruct KillstreakUINew.KSSocialPanelSectionDef
// Size: 0x03 (Inherited: 0x00)
struct FKSSocialPanelSectionDef {
	char pad_0[0x3]; // 0x00(0x03)
};

// ScriptStruct KillstreakUINew.SpecialtyCustomLoadout
// Size: 0x1a0 (Inherited: 0x00)
struct FSpecialtyCustomLoadout {
	char pad_0[0x8]; // 0x00(0x08)
	int32_t LoadoutClassItemId; // 0x08(0x04)
	int32_t LoadoutBundleItemId; // 0x0c(0x04)
	struct FSpecialtyData SpecialtyOne; // 0x10(0x48)
	struct FSpecialtyData SpecialtyTwo; // 0x58(0x48)
	struct FCustomLoadoutItem PerkOne; // 0xa0(0x10)
	struct FCustomLoadoutItem PerkTwo; // 0xb0(0x10)
	struct FCustomLoadoutItem PerkThree; // 0xc0(0x10)
	struct FCustomLoadoutItem PerkFour; // 0xd0(0x10)
	struct FCustomLoadoutItem PassiveOne; // 0xe0(0x10)
	struct FCustomLoadoutItem PassiveTwo; // 0xf0(0x10)
	struct FCustomLoadoutItem KillstreakOne; // 0x100(0x10)
	struct FCustomLoadoutItem KillstreakTwo; // 0x110(0x10)
	struct FCustomLoadoutItem SecondaryAbilityOne; // 0x120(0x10)
	struct FCustomLoadoutItem SecondaryAbilityTwo; // 0x130(0x10)
	struct FCustomLoadoutItem GadgetOne; // 0x140(0x10)
	struct FCustomLoadoutItem Pistol; // 0x150(0x10)
	struct FCustomLoadoutItem PistolAttachmentOne; // 0x160(0x10)
	struct FCustomLoadoutItem PistolAttachmentTwo; // 0x170(0x10)
	struct FCustomLoadoutItem PistolAttachmentThree; // 0x180(0x10)
	struct FCustomLoadoutItem PrimaryWeapon; // 0x190(0x10)
};

// ScriptStruct KillstreakUINew.SpecialtyData
// Size: 0x48 (Inherited: 0x00)
struct FSpecialtyData {
	struct UKSSpecialty* Specialty; // 0x00(0x08)
	struct FCustomLoadoutItem Killstreak; // 0x08(0x10)
	struct FCustomLoadoutItem SecondaryAbility; // 0x18(0x10)
	struct FCustomLoadoutItem PassiveAbility; // 0x28(0x10)
	struct TArray<int32_t> AssociatedLoadoutItemIds; // 0x38(0x10)
};

// ScriptStruct KillstreakUINew.ToastData
// Size: 0x58 (Inherited: 0x00)
struct FToastData {
	enum class EToastCategory ToastCategory; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText Title; // 0x08(0x18)
	struct FText Message; // 0x20(0x18)
	struct UPUMG_StoreItem* Reward; // 0x38(0x08)
	struct UPlatformInventoryItem* OptionalItemValue; // 0x40(0x08)
	int32_t OptionalIntValue; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct UKSActivity* OptionalActivityValue; // 0x50(0x08)
};

// ScriptStruct KillstreakUINew.ReportPlayerParams
// Size: 0x50 (Inherited: 0x00)
struct FReportPlayerParams {
	int64_t PlayerId; // 0x00(0x08)
	struct FSerializedMatchId MatchID; // 0x08(0x10)
	int32_t LocalPlayerTeamId; // 0x18(0x04)
	int32_t ReportedPlayerTeamId; // 0x1c(0x04)
	int32_t TotalPlayerCount; // 0x20(0x04)
	bool FromBackfillEnabledGame; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	struct FString PlayerName; // 0x28(0x10)
	enum class EReportPlayerReason Reason; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FString ReportComment; // 0x40(0x10)
};

// ScriptStruct KillstreakUINew.SpecialDamageColors
// Size: 0x30 (Inherited: 0x00)
struct FSpecialDamageColors {
	struct FLinearColor FontColor; // 0x00(0x10)
	struct FLinearColor StrokeColor; // 0x10(0x10)
	struct FLinearColor GlowColor; // 0x20(0x10)
};

// ScriptStruct KillstreakUINew.PlayerInventorySlot
// Size: 0x18 (Inherited: 0x00)
struct FPlayerInventorySlot {
	int32_t SlotIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UKSWeaponAsset* WeaponAsset; // 0x08(0x08)
	struct FGameplayTag SlotEquipPoint; // 0x10(0x08)
};

// ScriptStruct KillstreakUINew.WeaponCategoryDetails
// Size: 0xf8 (Inherited: 0x08)
struct FWeaponCategoryDetails : FTableRowBase {
	struct FGameplayTag CategoryTag; // 0x08(0x08)
	struct FText DisplayName; // 0x10(0x18)
	struct FText DisplayNameSingular; // 0x28(0x18)
	struct FText DisplayNameCategory; // 0x40(0x18)
	struct TSoftObjectPtr<UTexture2D> SoftSymbolIcon; // 0x58(0x28)
	struct TSoftObjectPtr<UTexture2D> SoftMasteryIcon; // 0x80(0x28)
	struct TSoftObjectPtr<UTexture2D> SoftVerticalSplash; // 0xa8(0x28)
	struct TSoftObjectPtr<UTexture2D> SoftHorizontalSplash; // 0xd0(0x28)
};

// ScriptStruct KillstreakUINew.KSWeaponMasteryLevelUpSummaryEntry
// Size: 0x48 (Inherited: 0x00)
struct FKSWeaponMasteryLevelUpSummaryEntry {
	struct UPrimaryDataAsset* MasteryAsset; // 0x00(0x08)
	struct FActivityTier MasteryTier; // 0x08(0x40)
};

// ScriptStruct KillstreakUINew.SubPanel
// Size: 0x30 (Inherited: 0x00)
struct FSubPanel {
	struct FText Header; // 0x00(0x18)
	struct FText Desc; // 0x18(0x18)
};

