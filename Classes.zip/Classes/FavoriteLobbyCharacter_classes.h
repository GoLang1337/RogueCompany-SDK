// BlueprintGeneratedClass FavoriteLobbyCharacter.FavoriteLobbyCharacter_C
// Size: 0x3ed8 (Inherited: 0x3eb3)
struct AFavoriteLobbyCharacter_C : ALobbyMainCharacter_C {
	char pad_3EB3[0x5]; // 0x3eb3(0x05)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3eb8(0x08)
	struct UWidgetComponent* WidgetNameplate; // 0x3ec0(0x08)
	bool NeedsToSetNameplate; // 0x3ec8(0x01)
	char pad_3EC9[0x7]; // 0x3ec9(0x07)
	struct UKSPlayerInfo* PendingPlayerInfo; // 0x3ed0(0x08)

	void SetLobbyNameplate(struct UKSPlayerInfo* playerinfo); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.SetLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HideLobbyNameplate(); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.HideLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ShowLobbyNameplate(); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ShowLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveTick(float DeltaSeconds); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_FavoriteLobbyCharacter(int32_t EntryPoint); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ExecuteUbergraph_FavoriteLobbyCharacter // (Final|UbergraphFunction) // @ game+0x24d5b40
};

