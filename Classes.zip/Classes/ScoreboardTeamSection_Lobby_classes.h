// WidgetBlueprintGeneratedClass ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C
// Size: 0x5d0 (Inherited: 0x518)
struct UScoreboardTeamSection_Lobby_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct USizeBox* HeightLimit; // 0x520(0x08)
	struct UVerticalBox* PlayerEntries; // 0x528(0x08)
	struct UScoreboardPlayerStats_Lobby_C* ScoreboardPlayerStats_Lobby; // 0x530(0x08)
	struct UTextBlock* teamScore; // 0x538(0x08)
	struct USizeBox* TeamScoreContainer; // 0x540(0x08)
	struct UImage* TeamScoreGradient; // 0x548(0x08)
	struct UBorder* TeamScoreWrapper; // 0x550(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x558(0x08)
	struct UTextBlock* WinText; // 0x560(0x08)
	struct FTeamStats TeamStruct; // 0x568(0x20)
	struct TArray<struct FPlayerEntryStats> playerStats; // 0x588(0x10)
	struct UPUMG_PlayerDataFactory* PlayerDataFactory; // 0x598(0x08)
	struct TArray<struct UScoreboardPlayerStats_Lobby_C*> Players; // 0x5a0(0x10)
	struct TArray<struct FPlayerEntryStats> TeamPlayerStats; // 0x5b0(0x10)
	struct FMulticastInlineDelegate OnPlayersChanged; // 0x5c0(0x10)

	void GetPlayerDisplays(struct TArray<struct UScoreboardPlayerStats_Lobby_C*>& PlayerEntries); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.GetPlayerDisplays // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void CreatePlayerEntry(int32_t Index, struct FPlayerEntryStats playerStats, struct UScoreboardPlayerStats_Lobby_C*& PlayerEntry); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.CreatePlayerEntry // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetIsVictorious(bool IsVictorious); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.SetIsVictorious // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SortPlayers(struct TArray<struct FPlayerEntryStats>& PlayerEntries, bool DescOrder); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.SortPlayers // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void CreatePlayerEntries(struct TArray<struct FPlayerEntryStats>& PlayerEntries); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.CreatePlayerEntries // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void FindPlayerTeam(int32_t& PlayerTeamNum); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.FindPlayerTeam // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void PopulatePlayer(); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.PopulatePlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Construct(); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetColor(); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.SetColor // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ScoreboardTeamSection_Lobby(int32_t EntryPoint); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.ExecuteUbergraph_ScoreboardTeamSection_Lobby // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void OnPlayersChanged__DelegateSignature(); // Function ScoreboardTeamSection_Lobby.ScoreboardTeamSection_Lobby_C.OnPlayersChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

