// WidgetBlueprintGeneratedClass LoginCreateAccount.LoginCreateAccount_C
// Size: 0x5f8 (Inherited: 0x518)
struct ULoginCreateAccount_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UPopupButton_C* BackButton; // 0x520(0x08)
	struct UImage* bkg; // 0x528(0x08)
	struct UCheckbox_C* CheckBox; // 0x530(0x08)
	struct UWBP_error_report_C* CheckboxError; // 0x538(0x08)
	struct UOutlineContainer_C* EmailContainer; // 0x540(0x08)
	struct UWBP_error_report_C* EmailError; // 0x548(0x08)
	struct UEditableText* EmailField; // 0x550(0x08)
	struct UImage* highlightborder; // 0x558(0x08)
	struct UImage* Image_531; // 0x560(0x08)
	struct UImage* Image_607; // 0x568(0x08)
	struct UTextBlock* LoginPrompt; // 0x570(0x08)
	struct UOutlineContainer_C* PasswordContainer; // 0x578(0x08)
	struct UWBP_error_report_C* PasswordError; // 0x580(0x08)
	struct UEditableText* PasswordField; // 0x588(0x08)
	struct UTextBlock* PasswordMismatchText; // 0x590(0x08)
	struct UOutlineContainer_C* RepeatPasswordContainer; // 0x598(0x08)
	struct UWBP_error_report_C* RepeatPasswordError; // 0x5a0(0x08)
	struct UEditableText* RepeatPasswordField; // 0x5a8(0x08)
	struct UPopupButton_C* SubmitButton; // 0x5b0(0x08)
	struct UImage* TitleLogo; // 0x5b8(0x08)
	struct UOutlineContainer_C* UsernameContainer; // 0x5c0(0x08)
	struct UWBP_error_report_C* UsernameError; // 0x5c8(0x08)
	struct UEditableText* UsernameField; // 0x5d0(0x08)
	struct UImage* WarningIcon; // 0x5d8(0x08)
	struct UTextBlock* WarningText; // 0x5e0(0x08)
	struct UWBP_check_box_C* WBP_check_box; // 0x5e8(0x08)
	struct UWBP_text_button_C* WBP_text_button; // 0x5f0(0x08)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function LoginCreateAccount.LoginCreateAccount_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Handle Text Committed(struct FText& Text, enum class ETextCommit CommitMethod); // Function LoginCreateAccount.LoginCreateAccount_C.Handle Text Committed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__NextButton_K2Node_ComponentBoundEvent_6_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginCreateAccount.LoginCreateAccount_C.BndEvt__NextButton_K2Node_ComponentBoundEvent_6_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void Handle Text Changed(struct FText& Text); // Function LoginCreateAccount.LoginCreateAccount_C.Handle Text Changed // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function LoginCreateAccount.LoginCreateAccount_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void Handle Login Error(struct FText MessageText, int32_t MessageId); // Function LoginCreateAccount.LoginCreateAccount_C.Handle Login Error // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Submit New Account(); // Function LoginCreateAccount.LoginCreateAccount_C.Submit New Account // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Handle Checkbox Changed(bool Checked); // Function LoginCreateAccount.LoginCreateAccount_C.Handle Checkbox Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnShown(); // Function LoginCreateAccount.LoginCreateAccount_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__BackButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(int32_t Index); // Function LoginCreateAccount.LoginCreateAccount_C.BndEvt__BackButton_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void Gamepad Select Email(); // Function LoginCreateAccount.LoginCreateAccount_C.Gamepad Select Email // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Gamepad Select Repeat Password(); // Function LoginCreateAccount.LoginCreateAccount_C.Gamepad Select Repeat Password // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Gamepad Select Password(); // Function LoginCreateAccount.LoginCreateAccount_C.Gamepad Select Password // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Gamepad Select Username(); // Function LoginCreateAccount.LoginCreateAccount_C.Gamepad Select Username // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoginCreateAccount(int32_t EntryPoint); // Function LoginCreateAccount.LoginCreateAccount_C.ExecuteUbergraph_LoginCreateAccount // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

