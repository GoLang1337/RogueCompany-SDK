// Class KillstreakUINew.GuidedMenuCalloutData
// Size: 0x50 (Inherited: 0x28)
struct UGuidedMenuCalloutData : UObject {
	struct FText HeaderText; // 0x28(0x18)
	struct TArray<struct FGuidedCalloutCardData> CalloutCards; // 0x40(0x10)
};

// Class KillstreakUINew.GuidedMenuCalloutsViewRedirector
// Size: 0x38 (Inherited: 0x28)
struct UGuidedMenuCalloutsViewRedirector : UPUMG_ViewRedirecter {
	struct UDataTable* GuidedCalloutsTable; // 0x28(0x08)
	char pad_30[0x8]; // 0x30(0x08)

	void SetNPEGuidedCalloutSeen(enum class EConfigPropertyGuidedCalloutScenes GuidedCalloutScene); // Function KillstreakUINew.GuidedMenuCalloutsViewRedirector.SetNPEGuidedCalloutSeen // (Final|Native|Public) // @ game+0x212bf20
	bool HasSeenNPEGuidedCallout(enum class EConfigPropertyGuidedCalloutScenes GuidedCalloutScene); // Function KillstreakUINew.GuidedMenuCalloutsViewRedirector.HasSeenNPEGuidedCallout // (Final|Native|Public) // @ game+0x212b670
};

// Class KillstreakUINew.KSWidget
// Size: 0x518 (Inherited: 0x4b8)
struct UKSWidget : UPUMG_Widget {
	bool bIsUIOnlyWidget; // 0x4b8(0x01)
	bool bIsExclusiveMenuWidget; // 0x4b9(0x01)
	char pad_4BA[0x2]; // 0x4ba(0x02)
	int32_t AmbientSoundRtpc; // 0x4bc(0x04)
	struct UTickAnimationManager* TickAnimations; // 0x4c0(0x08)
	struct FDelegate ViewportEvent; // 0x4c8(0x10)
	bool bSubstituteKillCamWorld; // 0x4d8(0x01)
	bool bSubstituteKillCamOwningPlayer; // 0x4d9(0x01)
	bool bWantsKillCamCallbacks; // 0x4da(0x01)
	char pad_4DB[0x1d]; // 0x4db(0x1d)
	float OpacityWhenAiming; // 0x4f8(0x04)
	bool DoesFadeOutWhenAiming; // 0x4fc(0x01)
	char pad_4FD[0x3]; // 0x4fd(0x03)
	float AimTransitionProgress; // 0x500(0x04)
	char pad_504[0x14]; // 0x504(0x14)

	void UpdateOpacityWhenAiming(); // Function KillstreakUINew.KSWidget.UpdateOpacityWhenAiming // (Native|Event|Protected|BlueprintEvent) // @ game+0x203e510
	void UnbindFromViewportSizeChange(); // Function KillstreakUINew.KSWidget.UnbindFromViewportSizeChange // (Final|Native|Public|BlueprintCallable) // @ game+0x218d160
	void TriggerGlobalInvalidate(); // Function KillstreakUINew.KSWidget.TriggerGlobalInvalidate // (Final|Native|Public|BlueprintCallable) // @ game+0x218d140
	void StopTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.StopTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x218d0c0
	void SkipToEndTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.SkipToEndTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x218d040
	bool ShouldUpdateOpacityWhenAiming(); // Function KillstreakUINew.KSWidget.ShouldUpdateOpacityWhenAiming // (Native|Event|Protected|BlueprintEvent) // @ game+0x218d010
	void SetPositionRTPC(); // Function KillstreakUINew.KSWidget.SetPositionRTPC // (Final|Native|Public|BlueprintCallable) // @ game+0x218cff0
	void SetAllAnimationsPlaybackSpeed(float PlaybackSpeed); // Function KillstreakUINew.KSWidget.SetAllAnimationsPlaybackSpeed // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x218cdc0
	void ResumeTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.ResumeTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x218cd40
	void RemoveTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.RemoveTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x218ccc0
	void PlayTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.PlayTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x218c700
	void PauseTickAnimation(struct FName AnimName); // Function KillstreakUINew.KSWidget.PauseTickAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x218c680
	bool IsInKillCamPlayback(); // Function KillstreakUINew.KSWidget.IsInKillCamPlayback // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x218c520
	void InitializeTickAnimations(); // Function KillstreakUINew.KSWidget.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleAimStateChange(enum class EKSCharacterAimMode NewAimState); // Function KillstreakUINew.KSWidget.HandleAimStateChange // (Final|Native|Protected) // @ game+0x218c0e0
	bool GetTickAnimationInfo(struct FName AnimName, struct FTickAnimationParams& OutAnimParams); // Function KillstreakUINew.KSWidget.GetTickAnimationInfo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x218bfd0
	struct APlayerController* GetNormalOwningPlayer(); // Function KillstreakUINew.KSWidget.GetNormalOwningPlayer // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x218be70
	struct APlayerController* GetKillCamSpectatorController(); // Function KillstreakUINew.KSWidget.GetKillCamSpectatorController // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x218be20
	struct APlayerController* GetActivePlayerController(); // Function KillstreakUINew.KSWidget.GetActivePlayerController // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x218bdc0
	void BlueprintPrepareKillCamPlayback(); // Function KillstreakUINew.KSWidget.BlueprintPrepareKillCamPlayback // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BlueprintFinishKillCamPlayback(); // Function KillstreakUINew.KSWidget.BlueprintFinishKillCamPlayback // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BindToViewportSizeChange(struct FDelegate& InViewportEvent); // Function KillstreakUINew.KSWidget.BindToViewportSizeChange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x218ba30
	void AddTickAnimation(struct FName AnimName, float Duration, struct FDelegate& UpdateEvent, struct FDelegate& FinishedEvent); // Function KillstreakUINew.KSWidget.AddTickAnimation // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x218b8a0
};

// Class KillstreakUINew.KSAccoladeQueueWidget
// Size: 0x560 (Inherited: 0x518)
struct UKSAccoladeQueueWidget : UKSWidget {
	bool IsBusy; // 0x518(0x01)
	char pad_519[0x3]; // 0x519(0x03)
	int32_t NumInQueue; // 0x51c(0x04)
	struct FMulticastInlineDelegate OnAccoladeReceived; // 0x520(0x10)
	struct FMulticastInlineDelegate OnAccoladeUpdateMultiplier; // 0x530(0x10)
	char pad_540[0x20]; // 0x540(0x20)

	void Queue(struct TArray<struct FAccoladeEventEntry> Accolades); // Function KillstreakUINew.KSAccoladeQueueWidget.Queue // (Final|Native|Protected|BlueprintCallable) // @ game+0x212bb40
	void OnAccoladeRemovedFromScreen(struct FAccoladeDisplayInfo AccoladeRemoved); // Function KillstreakUINew.KSAccoladeQueueWidget.OnAccoladeRemovedFromScreen // (Final|Native|Protected|BlueprintCallable) // @ game+0x212b7e0
	void HandleOnRoundSetup(struct FRoundInitState& RoundInitState); // Function KillstreakUINew.KSAccoladeQueueWidget.HandleOnRoundSetup // (Final|Native|Protected|HasOutParms) // @ game+0x212b1b0
	bool GetNext(struct FAccoladeDisplayInfo& Accolade); // Function KillstreakUINew.KSAccoladeQueueWidget.GetNext // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x212a930
	void ClearAccoladeQueue(); // Function KillstreakUINew.KSAccoladeQueueWidget.ClearAccoladeQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x212a2d0
};

// Class KillstreakUINew.KSAcquisitionModal
// Size: 0x570 (Inherited: 0x518)
struct UKSAcquisitionModal : UKSWidget {
	struct UDataTable* HeaderOverridesTable; // 0x518(0x08)
	struct TMap<int32_t, struct FText> HeaderOverridesFromJson; // 0x520(0x50)

	struct FText GetHeaderText(struct UKSAcquisition* Acquisitition); // Function KillstreakUINew.KSAcquisitionModal.GetHeaderText // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212a840
	struct UKSAcquisitionManager* GetAcquisitionManager(); // Function KillstreakUINew.KSAcquisitionModal.GetAcquisitionManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212a570
};

// Class KillstreakUINew.KSActiveBonusesWidget
// Size: 0x520 (Inherited: 0x518)
struct UKSActiveBonusesWidget : UKSWidget {
	struct UDataTable* EventLookupTable; // 0x518(0x08)

	void GetBonusAppliedToLastMatch(struct TArray<struct FKSLimitedTimeEventMetadataRow>& ActiveEvents); // Function KillstreakUINew.KSActiveBonusesWidget.GetBonusAppliedToLastMatch // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x212a6b0
};

// Class KillstreakUINew.KSPawnWidget
// Size: 0x538 (Inherited: 0x518)
struct UKSPawnWidget : UKSWidget {
	char pad_518[0x20]; // 0x518(0x20)

	void SetPlayerStateUIRelevanceChanged(); // Function KillstreakUINew.KSPawnWidget.SetPlayerStateUIRelevanceChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x212a310
	void SetPawn(struct AKSCharacter* NewPawn); // Function KillstreakUINew.KSPawnWidget.SetPawn // (Final|Native|Public|BlueprintCallable) // @ game+0x2151c90
	void PreClearPlayerState(); // Function KillstreakUINew.KSPawnWidget.PreClearPlayerState // (Native|Event|Protected|BlueprintEvent) // @ game+0x21518c0
	void PreClearPawn(); // Function KillstreakUINew.KSPawnWidget.PreClearPawn // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c010
	void PostSetPlayerState(); // Function KillstreakUINew.KSPawnWidget.PostSetPlayerState // (Native|Event|Protected|BlueprintEvent) // @ game+0x21416e0
	void PostSetPawn(); // Function KillstreakUINew.KSPawnWidget.PostSetPawn // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c030
	void OnBoundPlayerStateDestroyed(struct AActor* DestroyedActor); // Function KillstreakUINew.KSPawnWidget.OnBoundPlayerStateDestroyed // (Final|Native|Protected) // @ game+0x2151740
	void OnBoundPawnDestroyed(struct AActor* DestroyedActor); // Function KillstreakUINew.KSPawnWidget.OnBoundPawnDestroyed // (Final|Native|Protected) // @ game+0x21516c0
	struct AKSPlayerState* GetPlayerState(); // Function KillstreakUINew.KSPawnWidget.GetPlayerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2151010
	struct AKSCharacterBase* GetPawnBase(); // Function KillstreakUINew.KSPawnWidget.GetPawnBase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2150fe0
	struct AKSCharacter* GetPawn(); // Function KillstreakUINew.KSPawnWidget.GetPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2150fa0
};

// Class KillstreakUINew.KSPawnInventoryWidget
// Size: 0x5a8 (Inherited: 0x538)
struct UKSPawnInventoryWidget : UKSPawnWidget {
	struct TMap<struct FKSEquipmentId, struct UKSWeaponComponentWidget*> EquipmentWidgets; // 0x538(0x50)
	char pad_588[0x20]; // 0x588(0x20)

	bool RemoveWidgetFor(struct UKSWeaponComponent* InWeaponComponent); // Function KillstreakUINew.KSPawnInventoryWidget.RemoveWidgetFor // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151b30
	struct UKSWeaponComponentWidget* GetWidgetForWeaponComponent(struct UKSWeaponComponent* InWeaponComponent); // Function KillstreakUINew.KSPawnInventoryWidget.GetWidgetForWeaponComponent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21510b0
	void EquipmentRemoved(struct UKSWeaponComponent* RemovedEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentRemoved // (Native|Event|Protected|BlueprintEvent) // @ game+0x2150bd0
	void EquipmentEndActive(struct UKSWeaponComponent* InactiveEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentEndActive // (Native|Event|Protected|BlueprintEvent) // @ game+0x2150b40
	void EquipmentBecomeActive(struct UKSWeaponComponent* ActiveEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentBecomeActive // (Native|Event|Protected|BlueprintEvent) // @ game+0x2150ab0
	void EquipmentAdded(struct UKSWeaponComponent* AddedEquipment); // Function KillstreakUINew.KSPawnInventoryWidget.EquipmentAdded // (Native|Event|Protected|BlueprintEvent) // @ game+0x2150a20
	struct UKSWeaponComponentWidget* CreateWeaponComponentWidgetFor(struct UObject* WorldContextObject, struct UKSWeaponComponent* InWeaponComponent, struct UKSWeaponComponentWidget* WidgetClass, struct APlayerController* OwningPlayer); // Function KillstreakUINew.KSPawnInventoryWidget.CreateWeaponComponentWidgetFor // (Final|Native|Protected|BlueprintCallable) // @ game+0x21508d0
};

// Class KillstreakUINew.KSActiveWeaponComponentWidget
// Size: 0x5e0 (Inherited: 0x5a8)
struct UKSActiveWeaponComponentWidget : UKSPawnInventoryWidget {
	int32_t ActiveWeaponSlot; // 0x5a8(0x04)
	char pad_5AC[0x4]; // 0x5ac(0x04)
	struct FGameplayTagContainer EquipPointsToIgnore; // 0x5b0(0x20)
	bool bDelayClearUntilNextTick; // 0x5d0(0x01)
	char pad_5D1[0x3]; // 0x5d1(0x03)
	struct TWeakObjectPtr<struct UKSWeaponComponent> WeakActiveWeaponComponentPtr; // 0x5d4(0x08)
	char pad_5DC[0x4]; // 0x5dc(0x04)

	void PreClearActiveWeaponComponent(); // Function KillstreakUINew.KSActiveWeaponComponentWidget.PreClearActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b60
	void PostSetActiveWeaponComponent(); // Function KillstreakUINew.KSActiveWeaponComponentWidget.PostSetActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b40
	struct UKSWeaponComponent* GetActiveWeaponComponent(); // Function KillstreakUINew.KSActiveWeaponComponentWidget.GetActiveWeaponComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x212a5a0
};

// Class KillstreakUINew.KSActivity_ViewRedirector
// Size: 0x38 (Inherited: 0x28)
struct UKSActivity_ViewRedirector : UPUMG_ViewRedirecter {
	struct TArray<struct TSoftObjectPtr<UKSActivity>> ActivitiesToCheck; // 0x28(0x10)

	struct UKSActivityManagerBase* GetRelevantActivityManager(struct UKSGameInstance* GameInstance); // Function KillstreakUINew.KSActivity_ViewRedirector.GetRelevantActivityManager // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x212ae90
};

// Class KillstreakUINew.KSActivityProgress_ViewRedirector
// Size: 0x60 (Inherited: 0x38)
struct UKSActivityProgress_ViewRedirector : UKSActivity_ViewRedirector {
	struct TArray<int32_t> ActivityProgressMilestone; // 0x38(0x10)
	struct FString ActivityProgressMilestoneSetting; // 0x48(0x10)
	bool IncrementActivityProgressBeforeCheck; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class KillstreakUINew.KSAimAssistDebugWidget
// Size: 0x240 (Inherited: 0x238)
struct UKSAimAssistDebugWidget : UUserWidget {
	bool bDrawAimAssistBoundary; // 0x238(0x01)
	bool bDrawHeadAimCorrectionBoundary; // 0x239(0x01)
	bool bDrawMagnetismDebug; // 0x23a(0x01)
	bool bDrawTargetInfo; // 0x23b(0x01)
	char pad_23C[0x4]; // 0x23c(0x04)

	struct AKSPlayerController* GetOwningKSPlayer(); // Function KillstreakUINew.KSAimAssistDebugWidget.GetOwningKSPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x212ab80
	struct UKSAimAssistComponent* GetAimAssistComponent(); // Function KillstreakUINew.KSAimAssistDebugWidget.GetAimAssistComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x212a5e0
};

// Class KillstreakUINew.KSMapIconWidgetBase
// Size: 0x318 (Inherited: 0x238)
struct UKSMapIconWidgetBase : UUserWidget {
	bool bDoesIconRotate; // 0x238(0x01)
	char pad_239[0x3]; // 0x239(0x03)
	float MarkerAnchorHeight; // 0x23c(0x04)
	float HeightThreshold; // 0x240(0x04)
	char pad_244[0x4]; // 0x244(0x04)
	float CachedRawMetersAway; // 0x248(0x04)
	int32_t UniqueId; // 0x24c(0x04)
	struct TWeakObjectPtr<struct AKSPlayerState> CreatingPlayer; // 0x250(0x08)
	enum class EDisplayType ParentMapDisplayType; // 0x258(0x01)
	char pad_259[0x3]; // 0x259(0x03)
	struct TWeakObjectPtr<struct AActor> AssociatedActor; // 0x25c(0x08)
	struct TWeakObjectPtr<struct UObject> AssociatedObject; // 0x264(0x08)
	struct FVector DefaultLocation; // 0x26c(0x0c)
	float Lifespan; // 0x278(0x04)
	struct TWeakObjectPtr<struct UKSMapWidgetBase> ParentMapWidget; // 0x27c(0x08)
	struct FVector2D ScreenMargins; // 0x284(0x08)
	float CenterPercentageWidth; // 0x28c(0x04)
	float CenterPercentageHeight; // 0x290(0x04)
	float OpacityWhenAiming; // 0x294(0x04)
	bool DoesFadeOutWhenAiming; // 0x298(0x01)
	char pad_299[0x3]; // 0x299(0x03)
	float AimTransitionOpacity; // 0x29c(0x04)
	struct FVector IconOffset; // 0x2a0(0x0c)
	char pad_2AC[0x18]; // 0x2ac(0x18)
	float HoverDelaySeconds; // 0x2c4(0x04)
	char pad_2C8[0x18]; // 0x2c8(0x18)
	struct FMulticastInlineDelegate OnMapIconWidgetReady; // 0x2e0(0x10)
	struct FMulticastInlineDelegate OnMapIconWidgetRemove; // 0x2f0(0x10)
	bool bIsWidgetPool; // 0x300(0x01)
	char pad_301[0x7]; // 0x301(0x07)
	struct FString WidgetPoolName; // 0x308(0x10)

	void UpdateScreenRegion(); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateScreenRegion // (Final|Native|Public|BlueprintCallable) // @ game+0x21484f0
	void UpdateOpacityWhenAiming(); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateOpacityWhenAiming // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18566a0
	void UpdateMetersAway(int32_t Meters); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateMetersAway // (Native|Event|Public|BlueprintEvent) // @ game+0x2148460
	void UpdateMeetsHeightThreshold(bool bHeight, bool bDepth); // Function KillstreakUINew.KSMapIconWidgetBase.UpdateMeetsHeightThreshold // (Native|Event|Public|BlueprintEvent) // @ game+0x2148390
	enum class ESlateVisibility Update(); // Function KillstreakUINew.KSMapIconWidgetBase.Update // (Native|Event|Public|BlueprintEvent) // @ game+0x21482e0
	bool ShouldUpdateOpacityWhenAiming(); // Function KillstreakUINew.KSMapIconWidgetBase.ShouldUpdateOpacityWhenAiming // (Native|Event|Public|BlueprintEvent) // @ game+0xb58de0
	bool ShouldUpdateHover(); // Function KillstreakUINew.KSMapIconWidgetBase.ShouldUpdateHover // (Native|Event|Public|BlueprintEvent) // @ game+0x2148150
	bool ShouldUpdate(); // Function KillstreakUINew.KSMapIconWidgetBase.ShouldUpdate // (Native|Event|Public|BlueprintEvent) // @ game+0xb58e30
	void SetScreenRegion(enum class EIconMarkerScreenRegion ScreenRegion); // Function KillstreakUINew.KSMapIconWidgetBase.SetScreenRegion // (Native|Event|Public|BlueprintEvent) // @ game+0x21480d0
	void SetLifeSpan(float InLifespan); // Function KillstreakUINew.KSMapIconWidgetBase.SetLifeSpan // (Final|Native|Public|BlueprintCallable) // @ game+0x2147fc0
	void SetDisplayInfo(int32_t InUniqueId, struct AKSPlayerState* InCreatingPlayer, enum class EDisplayType InParentMapDisplayType, struct AActor* InAssociatedActor, struct UObject* InAssociatedObject, struct FVector InDefaultLocation, float InLifespan); // Function KillstreakUINew.KSMapIconWidgetBase.SetDisplayInfo // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2147db0
	void SetArrowAngle(float Angle); // Function KillstreakUINew.KSMapIconWidgetBase.SetArrowAngle // (Native|Event|Public|BlueprintEvent) // @ game+0x2147d30
	void ResetDisplayInfo(); // Function KillstreakUINew.KSMapIconWidgetBase.ResetDisplayInfo // (Native|Public) // @ game+0xa6a750
	void OnUnhoverTimerComplete(); // Function KillstreakUINew.KSMapIconWidgetBase.OnUnhoverTimerComplete // (Final|Native|Private) // @ game+0x2147c70
	void OnHoverTimerComplete(); // Function KillstreakUINew.KSMapIconWidgetBase.OnHoverTimerComplete // (Final|Native|Private) // @ game+0x2147ad0
	void OnHoverStateChanged(enum class EIconHoverState NewHoverState); // Function KillstreakUINew.KSMapIconWidgetBase.OnHoverStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnAssociatedActorDestroyed(struct AActor* Actor); // Function KillstreakUINew.KSMapIconWidgetBase.OnAssociatedActorDestroyed // (Final|Native|Private) // @ game+0x21479d0
	void OnAimStateChanged(enum class EKSCharacterAimMode NewAimState, float NewAimTransitionOffset); // Function KillstreakUINew.KSMapIconWidgetBase.OnAimStateChanged // (Native|Event|Public|BlueprintEvent) // @ game+0x2147910
	void IsScreenRegion(bool& InsideCenter, bool& InsideMargins); // Function KillstreakUINew.KSMapIconWidgetBase.IsScreenRegion // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2147830
	bool IsInCenteredScreenRect(float PositionX, float PositionY, float XMargin, float YMargin); // Function KillstreakUINew.KSMapIconWidgetBase.IsInCenteredScreenRect // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2147650
	bool IsHovering(); // Function KillstreakUINew.KSMapIconWidgetBase.IsHovering // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xb58c60
	void HandleMapIconWidgetHide(); // Function KillstreakUINew.KSMapIconWidgetBase.HandleMapIconWidgetHide // (Final|Native|Private) // @ game+0x2147590
	float GetWorldYaw(); // Function KillstreakUINew.KSMapIconWidgetBase.GetWorldYaw // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f900e0
	struct FVector GetWorldPosition(); // Function KillstreakUINew.KSMapIconWidgetBase.GetWorldPosition // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x21471c0
	enum class EIconHoverState GetHoverState(); // Function KillstreakUINew.KSMapIconWidgetBase.GetHoverState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2146dd0
	float GetEdgeArrowAngleBase(float Angle); // Function KillstreakUINew.KSMapIconWidgetBase.GetEdgeArrowAngleBase // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2146d40
	float GetDistanceToIcon(); // Function KillstreakUINew.KSMapIconWidgetBase.GetDistanceToIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2146c70
	void GetArrowPosition(bool IsIconVisible, float Angle, struct FVector2D& ArrowPosition); // Function KillstreakUINew.KSMapIconWidgetBase.GetArrowPosition // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2146ae0
};

// Class KillstreakUINew.KSAllyMarkerWidget
// Size: 0x370 (Inherited: 0x318)
struct UKSAllyMarkerWidget : UKSMapIconWidgetBase {
	struct UWidget* ArrowWidget; // 0x318(0x08)
	struct UWidget* NameOrStatusWidget; // 0x320(0x08)
	struct UWidget* DownedSectionWidget; // 0x328(0x08)
	struct FMulticastInlineDelegate OnGameModeModActivationChanged; // 0x330(0x10)
	struct UDataTable* ContextualPingTypesDT; // 0x340(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x348(0x08)
	char pad_350[0x20]; // 0x350(0x20)

	void View_SetSelfPingIcon(enum class EPingType PingType, enum class EPingMessage PingMessage); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetSelfPingIcon // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetRevivePercent(float PercentValue); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetRevivePercent // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetNameText(struct FText& NameText); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetNameText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void View_SetMode(enum class EAllyMarkerState AllyMarkerState, bool HasObjective, bool HasSelfPing); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetMode // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetJob(struct UKSJobItem* Job); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetJob // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetHealthPercent(float PercentValue); // Function KillstreakUINew.KSAllyMarkerWidget.View_SetHealthPercent // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_AcknowledgeSelfPing(struct AKSPlayerState* AcknowledingPlayer); // Function KillstreakUINew.KSAllyMarkerWidget.View_AcknowledgeSelfPing // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool ShouldShowAllyMarkerWidget(); // Function KillstreakUINew.KSAllyMarkerWidget.ShouldShowAllyMarkerWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x212bfc0
	void SetPlayerName(); // Function KillstreakUINew.KSAllyMarkerWidget.SetPlayerName // (Final|Native|Protected) // @ game+0x212bfa0
	void SetMarkerPlayerState(struct AKSPlayerState* pPlayerState); // Function KillstreakUINew.KSAllyMarkerWidget.SetMarkerPlayerState // (Final|Native|Public|BlueprintCallable) // @ game+0x212bea0
	bool IsOwningPlayer(); // Function KillstreakUINew.KSAllyMarkerWidget.IsOwningPlayer // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x212b700
	void HandleUIRelevantChanged(struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSAllyMarkerWidget.HandleUIRelevantChanged // (Final|Native|Protected) // @ game+0x212b5f0
	void HandleRemoveSelfPing(struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSAllyMarkerWidget.HandleRemoveSelfPing // (Final|Native|Protected) // @ game+0x212b570
	void HandlePlayerModActivated(struct UKSPlayerMod_Activated* ActivatedMod, bool Active); // Function KillstreakUINew.KSAllyMarkerWidget.HandlePlayerModActivated // (Final|Native|Protected) // @ game+0x212b4a0
	void HandlePlayerDown(struct FCombatEventInfo CombatEventInfo, int32_t ExpBonus); // Function KillstreakUINew.KSAllyMarkerWidget.HandlePlayerDown // (Final|Native|Protected) // @ game+0x212b360
	void HandlePlayerDeath(struct FCombatEventInfo DeathInfo); // Function KillstreakUINew.KSAllyMarkerWidget.HandlePlayerDeath // (Final|Native|Protected) // @ game+0x212b250
	void HandleOnJobChanged(); // Function KillstreakUINew.KSAllyMarkerWidget.HandleOnJobChanged // (Final|Native|Protected) // @ game+0x212b190
	void HandleObjectiveStateChanged(struct TScriptInterface<IKSObjective> GameObjective); // Function KillstreakUINew.KSAllyMarkerWidget.HandleObjectiveStateChanged // (Final|Native|Protected) // @ game+0x212b0f0
	void HandleChangeSelfPing(struct AKSPlayerState* PingingPlayer, struct AKSPlayerState* AcknowledgingPlayer); // Function KillstreakUINew.KSAllyMarkerWidget.HandleChangeSelfPing // (Final|Native|Protected) // @ game+0x212b030
	void HandleAddSelfPing(struct AKSPlayerState* PingingPlayer, enum class EPingType PingType, enum class EPingMessage PingMessage); // Function KillstreakUINew.KSAllyMarkerWidget.HandleAddSelfPing // (Final|Native|Protected) // @ game+0x212af30
	bool GetPingIconByType(enum class EPingType PingType, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSAllyMarkerWidget.GetPingIconByType // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x212ad90
	bool GetPingIconByMessage(enum class EPingMessage PingMessage, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSAllyMarkerWidget.GetPingIconByMessage // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x212ac90
	bool GetPingColorByType(enum class EPingType PingType, struct FLinearColor& PingColor); // Function KillstreakUINew.KSAllyMarkerWidget.GetPingColorByType // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x212abb0
	struct FVector2D GetArrowPositionFromAngleBlueprint(float Angle); // Function KillstreakUINew.KSAllyMarkerWidget.GetArrowPositionFromAngleBlueprint // (Native|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x212a610
	bool FindRowByType(enum class EPingType PingType, struct FContextualPingTypesRow& ContextualPingTypesRow); // Function KillstreakUINew.KSAllyMarkerWidget.FindRowByType // (Final|Native|Protected|HasOutParms|Const) // @ game+0x212a450
	bool FindRowByMessage(enum class EPingMessage PingMessage, struct FContextualPingMessagesRow& ContextualPingMessagesRow); // Function KillstreakUINew.KSAllyMarkerWidget.FindRowByMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x212a330
	void ChangeOwnerContentVisibility(bool bVisible); // Function KillstreakUINew.KSAllyMarkerWidget.ChangeOwnerContentVisibility // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSAlphaDisclaimer
// Size: 0x518 (Inherited: 0x518)
struct UKSAlphaDisclaimer : UKSWidget {

	bool LoadAlphaDisclaimerText(struct FString& SaveText); // Function KillstreakUINew.KSAlphaDisclaimer.LoadAlphaDisclaimerText // (Final|Native|Static|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x212b730
};

// Class KillstreakUINew.KSWeaponWidget
// Size: 0x520 (Inherited: 0x518)
struct UKSWeaponWidget : UKSWidget {
	char pad_518[0x8]; // 0x518(0x08)

	void SetOwningWeapon(struct AKSWeapon* InWeapon); // Function KillstreakUINew.KSWeaponWidget.SetOwningWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x218cf70
	void PreClearWeapon(); // Function KillstreakUINew.KSWeaponWidget.PreClearWeapon // (Native|Event|Protected|BlueprintEvent) // @ game+0x21518c0
	void PostSetWeapon(); // Function KillstreakUINew.KSWeaponWidget.PostSetWeapon // (Native|Event|Protected|BlueprintEvent) // @ game+0x21416e0
	void OtherWeaponUpdate(); // Function KillstreakUINew.KSWeaponWidget.OtherWeaponUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x212a310
	void OnOwningWeaponDestroyed(struct AActor* DestroyedWeapon); // Function KillstreakUINew.KSWeaponWidget.OnOwningWeaponDestroyed // (Final|Native|Protected) // @ game+0x218c600
	struct AKSWeapon* GetOwningWeapon(); // Function KillstreakUINew.KSWeaponWidget.GetOwningWeapon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2150fa0
};

// Class KillstreakUINew.KSAmmoWidget
// Size: 0x540 (Inherited: 0x520)
struct UKSAmmoWidget : UKSWeaponWidget {
	int32_t CachedAmmoInClip; // 0x520(0x04)
	int32_t CachedClipSize; // 0x524(0x04)
	int32_t CachedInReserve; // 0x528(0x04)
	bool CachedIsReloading; // 0x52c(0x01)
	char pad_52D[0x13]; // 0x52d(0x13)

	void StopReloading(); // Function KillstreakUINew.KSAmmoWidget.StopReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c030
	void StartReloading(); // Function KillstreakUINew.KSAmmoWidget.StartReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c010
	void OnAmmoChanged(int32_t OldInClip, int32_t OldClipSize, int32_t OldReserve, int32_t NewInClip, int32_t NewClipSize, int32_t NewReserve); // Function KillstreakUINew.KSAmmoWidget.OnAmmoChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x212b990
};

// Class KillstreakUINew.KSAnnouncementQueuedMessageWidget
// Size: 0x560 (Inherited: 0x518)
struct UKSAnnouncementQueuedMessageWidget : UKSWidget {
	struct FMulticastInlineDelegate OnEndDisplay; // 0x518(0x10)
	struct FAnnouncementData AnnouncementData; // 0x528(0x38)

	void DisplayAnnouncement(); // Function KillstreakUINew.KSAnnouncementQueuedMessageWidget.DisplayAnnouncement // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x212a310
};

// Class KillstreakUINew.KSAnnouncementQueueWidget
// Size: 0x540 (Inherited: 0x518)
struct UKSAnnouncementQueueWidget : UKSWidget {
	bool IsBusy; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)
	struct FMulticastInlineDelegate OnReadyForNextAnnouncement; // 0x520(0x10)
	char pad_530[0x10]; // 0x530(0x10)

	void Queue(struct FAnnouncementData Announcement); // Function KillstreakUINew.KSAnnouncementQueueWidget.Queue // (Final|Native|Protected|BlueprintCallable) // @ game+0x212bc00
	bool GetNext(struct FAnnouncementData& Announcement); // Function KillstreakUINew.KSAnnouncementQueueWidget.GetNext // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x212aa70
	void ClearAnnoucementQueue(); // Function KillstreakUINew.KSAnnouncementQueueWidget.ClearAnnoucementQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x212a2f0
};

// Class KillstreakUINew.KSTeamWidget
// Size: 0x548 (Inherited: 0x518)
struct UKSTeamWidget : UKSWidget {
	bool bTrackPersistentPlayerData; // 0x518(0x01)
	bool bTrackRelevantPlayerStates; // 0x519(0x01)
	char pad_51A[0x2]; // 0x51a(0x02)
	struct TWeakObjectPtr<struct AKSTeamState> TeamState; // 0x51c(0x08)
	char pad_524[0x24]; // 0x524(0x24)

	void SetTeam(struct AKSTeamState* NewTeam); // Function KillstreakUINew.KSTeamWidget.SetTeam // (Native|Public|BlueprintCallable) // @ game+0x2150ab0
	void PreClearTeam(); // Function KillstreakUINew.KSTeamWidget.PreClearTeam // (Native|Event|Protected|BlueprintEvent) // @ game+0x2139670
	void PostSetTeam(); // Function KillstreakUINew.KSTeamWidget.PostSetTeam // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c010
	void PlayerStateRemovedFromTeam(struct AKSPlayerState* RemovedPlayerState); // Function KillstreakUINew.KSTeamWidget.PlayerStateRemovedFromTeam // (Native|Event|Protected|BlueprintEvent) // @ game+0x2146a30
	void PlayerStateAddedToTeam(struct AKSPlayerState* AddedPlayerState); // Function KillstreakUINew.KSTeamWidget.PlayerStateAddedToTeam // (Native|Event|Protected|BlueprintEvent) // @ game+0x2178ff0
	void PersistentPlayerRemovedFromTeam(struct UKSPersistentPlayerData* RemovedPersistentPlayer); // Function KillstreakUINew.KSTeamWidget.PersistentPlayerRemovedFromTeam // (Native|Event|Protected|BlueprintEvent) // @ game+0x2178f60
	void PersistentPlayerAddedToTeam(struct UKSPersistentPlayerData* AddedPersistentPlayer); // Function KillstreakUINew.KSTeamWidget.PersistentPlayerAddedToTeam // (Native|Event|Protected|BlueprintEvent) // @ game+0x2178ed0
	void OnBoundTeamDestroyed(struct AActor* DestroyedTeam); // Function KillstreakUINew.KSTeamWidget.OnBoundTeamDestroyed // (Final|Native|Protected) // @ game+0x2178c40
	struct AKSTeamState* GetTeam(); // Function KillstreakUINew.KSTeamWidget.GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2177d20
};

// Class KillstreakUINew.KSAutoTeamWidget
// Size: 0x550 (Inherited: 0x548)
struct UKSAutoTeamWidget : UKSTeamWidget {
	enum class EKSAutoTeamType AutoTeamType; // 0x548(0x01)
	char pad_549[0x3]; // 0x549(0x03)
	int32_t TeamNumber; // 0x54c(0x04)

	void TeamAddedToGameState(struct AKSTeamState* InTeam); // Function KillstreakUINew.KSAutoTeamWidget.TeamAddedToGameState // (Final|Native|Private) // @ game+0x212c050
	void SetAutoTeamConfig(enum class EKSAutoTeamType InAutoTeamType, int32_t InTeamNum); // Function KillstreakUINew.KSAutoTeamWidget.SetAutoTeamConfig // (Final|Native|Public|BlueprintCallable) // @ game+0x212bd50
};

// Class KillstreakUINew.KSBoostInventoryWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSBoostInventoryWidget : UKSWidget {
};

// Class KillstreakUINew.KSBoostInventoryItemWidget
// Size: 0x528 (Inherited: 0x518)
struct UKSBoostInventoryItemWidget : UKSWidget {
	struct FAccountConsumableDetails CurrentItemDetails; // 0x518(0x10)

	void View_SetFromItem(struct FAccountConsumableDetails ItemDetails); // Function KillstreakUINew.KSBoostInventoryItemWidget.View_SetFromItem // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ShowBoostPopup(); // Function KillstreakUINew.KSBoostInventoryItemWidget.ShowBoostPopup // (Final|Native|Protected|BlueprintCallable) // @ game+0x212bff0
	void SetItem(struct FAccountConsumableDetails ItemDetails); // Function KillstreakUINew.KSBoostInventoryItemWidget.SetItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x212be10
	void PlayBoostConfirmationSound(); // Function KillstreakUINew.KSBoostInventoryItemWidget.PlayBoostConfirmationSound // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnActivateBoostConfirm(); // Function KillstreakUINew.KSBoostInventoryItemWidget.OnActivateBoostConfirm // (Final|Native|Protected) // @ game+0x212b970
	void OnActivateBoostCancel(); // Function KillstreakUINew.KSBoostInventoryItemWidget.OnActivateBoostCancel // (Final|Native|Protected) // @ game+0xa6a770
};

// Class KillstreakUINew.KSChallengeEntryCardBase
// Size: 0x520 (Inherited: 0x518)
struct UKSChallengeEntryCardBase : UKSWidget {
	char pad_518[0x8]; // 0x518(0x08)

	void SetChallengeData(struct UKSActivityInstance* ActivityInstance); // Function KillstreakUINew.KSChallengeEntryCardBase.SetChallengeData // (Final|Native|Public|BlueprintCallable) // @ game+0x212fc40
	void DisplayRewardItems(struct TArray<struct FTierRewardItemData>& RewardItems); // Function KillstreakUINew.KSChallengeEntryCardBase.DisplayRewardItems // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void ApplyRerollAvailable(bool CanReroll); // Function KillstreakUINew.KSChallengeEntryCardBase.ApplyRerollAvailable // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ApplyLayoutType(enum class EChallengeEntryCardState CardState); // Function KillstreakUINew.KSChallengeEntryCardBase.ApplyLayoutType // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ApplyChallengeProgress(int32_t Progress, int32_t ProgressTotal); // Function KillstreakUINew.KSChallengeEntryCardBase.ApplyChallengeProgress // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ApplyChallengeDescription(struct FText& DescText); // Function KillstreakUINew.KSChallengeEntryCardBase.ApplyChallengeDescription // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSChatDataFactory
// Size: 0x118 (Inherited: 0x118)
struct UKSChatDataFactory : UPUMG_ChatDataFactory {
};

// Class KillstreakUINew.KSComponentReticleWidgetBase
// Size: 0x600 (Inherited: 0x5e0)
struct UKSComponentReticleWidgetBase : UKSActiveWeaponComponentWidget {
	float ShrinkAnimationTime; // 0x5e0(0x04)
	float BlockedShotIconMaxScale; // 0x5e4(0x04)
	float BlockedShotIconMinScale; // 0x5e8(0x04)
	float BlockedShotMinScaleSqDist; // 0x5ec(0x04)
	bool bGrenadeCooking; // 0x5f0(0x01)
	bool bInADS; // 0x5f1(0x01)
	bool bCachedBlockIconVisible; // 0x5f2(0x01)
	char pad_5F3[0x1]; // 0x5f3(0x01)
	float CachedWeaponAccuracy; // 0x5f4(0x04)
	float CachedReticleOffset; // 0x5f8(0x04)
	char pad_5FC[0x4]; // 0x5fc(0x04)

	void ViewedPawnInstigatedDamageNotify(struct FCombatEventInfo& DamageInfo); // Function KillstreakUINew.KSComponentReticleWidgetBase.ViewedPawnInstigatedDamageNotify // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x21309c0
	void UpdateReticleOffset(float OffsetFromCenterScreen); // Function KillstreakUINew.KSComponentReticleWidgetBase.UpdateReticleOffset // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void UpdateBlockedShotIcon(bool IconVisible, struct FVector2D Translation, struct FVector2D IconScale); // Function KillstreakUINew.KSComponentReticleWidgetBase.UpdateBlockedShotIcon // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	void CalculateReticleOffset(float DeltaTime); // Function KillstreakUINew.KSComponentReticleWidgetBase.CalculateReticleOffset // (Final|Native|Protected) // @ game+0x212ea20
	void CalculateBlockedShotIcon(); // Function KillstreakUINew.KSComponentReticleWidgetBase.CalculateBlockedShotIcon // (Final|Native|Protected) // @ game+0x212ea00
};

// Class KillstreakUINew.ContextActionData
// Size: 0xf0 (Inherited: 0x28)
struct UContextActionData : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FName RowName; // 0x30(0x08)
	struct FText FormatAdditive; // 0x38(0x18)
	struct FContextAction RowData; // 0x50(0x58)
	struct FDelegate OnContextAction; // 0xa8(0x10)
	struct FDelegate OnCycleAction; // 0xb8(0x10)
	struct FDelegate OnHoldActionUpdate; // 0xc8(0x10)
	struct FDelegate OnHoldReleaseAction; // 0xd8(0x10)
	char pad_E8[0x8]; // 0xe8(0x08)

	void TriggerHoldReleaseContextAction(enum class EContextPromptHoldReleaseState Status); // Function KillstreakUINew.ContextActionData.TriggerHoldReleaseContextAction // (Final|Native|Public|BlueprintCallable) // @ game+0x2130940
	void TriggerCycleContextActionPrev(); // Function KillstreakUINew.ContextActionData.TriggerCycleContextActionPrev // (Final|Native|Public) // @ game+0x2130920
	void TriggerCycleContextActionNext(); // Function KillstreakUINew.ContextActionData.TriggerCycleContextActionNext // (Final|Native|Public) // @ game+0x2130900
	void TriggerCycleContextAction(bool bNext); // Function KillstreakUINew.ContextActionData.TriggerCycleContextAction // (Final|Native|Public|BlueprintCallable) // @ game+0x2130870
	void TriggerContextAction(); // Function KillstreakUINew.ContextActionData.TriggerContextAction // (Final|Native|Public|BlueprintCallable) // @ game+0x2130850
	void StartTriggerHoldAction(); // Function KillstreakUINew.ContextActionData.StartTriggerHoldAction // (Final|Native|Public) // @ game+0x2130830
	void ClearTriggerHoldAction(); // Function KillstreakUINew.ContextActionData.ClearTriggerHoldAction // (Final|Native|Public) // @ game+0x212ec20
};

// Class KillstreakUINew.KSContextBarWidget
// Size: 0x590 (Inherited: 0x518)
struct UKSContextBarWidget : UKSWidget {
	struct FName GlobalRouteName; // 0x518(0x08)
	struct UDataTable* ContextActionDT; // 0x520(0x08)
	struct TMap<struct FName, struct FRouteContextInfo> RouteContextInfoMap; // 0x528(0x50)
	struct FName ActiveRoute; // 0x578(0x08)
	struct TArray<struct FName> OverrideRouteStack; // 0x580(0x10)

	void UpdateContextActions(struct TArray<struct UContextActionData*>& ContextActions, struct FName CurrentRoute); // Function KillstreakUINew.KSContextBarWidget.UpdateContextActions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void SetPrompts(struct FName Route, struct TArray<struct FName> ContextNames); // Function KillstreakUINew.KSContextBarWidget.SetPrompts // (Final|Native|Public|BlueprintCallable) // @ game+0x2130710
	void SetPromptHoldReleaseAction(struct FName Route, struct FName ContextName, struct FDelegate& UpdateCallback, struct FDelegate& EventCallback); // Function KillstreakUINew.KSContextBarWidget.SetPromptHoldReleaseAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2130580
	void SetPromptCycleAction(struct FName Route, struct FName ContextName, struct FDelegate& EventCallback); // Function KillstreakUINew.KSContextBarWidget.SetPromptCycleAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2130450
	void SetPromptAction(struct FName Route, struct FName ContextName, struct FDelegate& EventCallback); // Function KillstreakUINew.KSContextBarWidget.SetPromptAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2130320
	void SetPrompt(struct FName Route, struct FName ContextName, struct FText FormatAdditive); // Function KillstreakUINew.KSContextBarWidget.SetPrompt // (Final|Native|Public|BlueprintCallable) // @ game+0x21301c0
	void SetInputActions(struct TArray<struct UContextActionData*> ActionData); // Function KillstreakUINew.KSContextBarWidget.SetInputActions // (Final|Native|Protected) // @ game+0x212fdc0
	void SetActiveRoute(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.SetActiveRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x212fbc0
	bool RemoveOverrideRoute(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.RemoveOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x212fb30
	void RefreshContextBar(); // Function KillstreakUINew.KSContextBarWidget.RefreshContextBar // (Final|Native|Protected) // @ game+0x212fa90
	void PushOverrideRoute(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.PushOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x212fa10
	struct FName PopOverrideRoute(); // Function KillstreakUINew.KSContextBarWidget.PopOverrideRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x212f9d0
	struct FName GetCurrentContextRoute(); // Function KillstreakUINew.KSContextBarWidget.GetCurrentContextRoute // (Final|Native|Protected|Const) // @ game+0x212ef30
	void ClearPrompt(struct FName Route, struct FName ContextName); // Function KillstreakUINew.KSContextBarWidget.ClearPrompt // (Final|Native|Public|BlueprintCallable) // @ game+0x212eb60
	void ClearOverrideRouteStack(); // Function KillstreakUINew.KSContextBarWidget.ClearOverrideRouteStack // (Final|Native|Public|BlueprintCallable) // @ game+0x212eb40
	void ClearAllPrompts(struct FName Route); // Function KillstreakUINew.KSContextBarWidget.ClearAllPrompts // (Final|Native|Public|BlueprintCallable) // @ game+0x212eac0
};

// Class KillstreakUINew.KSContextMenu
// Size: 0x568 (Inherited: 0x518)
struct UKSContextMenu : UKSWidget {
	struct FMulticastInlineDelegate OnContextOptionsUpdated; // 0x518(0x10)
	struct FMulticastInlineDelegate OnReportPlayer; // 0x528(0x10)
	enum class EPlayerContextMenuContext MenuContext; // 0x538(0x01)
	bool bAllowReportPlayer; // 0x539(0x01)
	char pad_53A[0x6]; // 0x53a(0x06)
	struct UKSPlayerInfo* CurrentPlayerInfo; // 0x540(0x08)
	struct TArray<struct UKSContextMenuButton*> ContextMenuButtons; // 0x548(0x10)
	enum class EViewSide MenuViewSide; // 0x558(0x01)
	char pad_559[0x3]; // 0x559(0x03)
	int32_t CachedQueuedOrInMatch; // 0x55c(0x04)
	bool bCachedReportedPlayer; // 0x560(0x01)
	char pad_561[0x7]; // 0x561(0x07)

	void SetOptionsVisibility(); // Function KillstreakUINew.KSContextMenu.SetOptionsVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x2130030
	struct FVector2D SetMenuPosition(struct UKSWidget* WidgetToMove, struct FMargin WidgetPadding, enum class EViewSide side, float menuWidth, float menuHeight); // Function KillstreakUINew.KSContextMenu.SetMenuPosition // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x212fea0
	void SetCurrentPlayerInfo(struct UKSPlayerInfo* playerinfo); // Function KillstreakUINew.KSContextMenu.SetCurrentPlayerInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x212fd40
	void RemoveContextMenuButton(struct UKSContextMenuButton* ContextButton); // Function KillstreakUINew.KSContextMenu.RemoveContextMenuButton // (Final|Native|Public|BlueprintCallable) // @ game+0x212fab0
	bool OnOptionSelected(enum class EPlayerContextOptions ContextOption); // Function KillstreakUINew.KSContextMenu.OnOptionSelected // (Final|Native|Public|BlueprintCallable) // @ game+0x212f7c0
	void HandleOnQueueStatusChange(enum class EPUMG_MatchStatus QueueStatus); // Function KillstreakUINew.KSContextMenu.HandleOnQueueStatusChange // (Final|Native|Protected) // @ game+0x212f600
	struct UPUMG_QueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSContextMenu.GetQueueDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212f370
	struct UKSPlayerDataFactory* GetPlayerDataFactory(); // Function KillstreakUINew.KSContextMenu.GetPlayerDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212f340
	struct UPUMG_PartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSContextMenu.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212efa0
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSContextMenu.GetFriendDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212ef70
	struct UKSContextMenuButton* GetContextButtonByEnum(enum class EPlayerContextOptions ContextOption); // Function KillstreakUINew.KSContextMenu.GetContextButtonByEnum // (Final|Native|Public|BlueprintCallable) // @ game+0x212ee80
	void ClearAllContextMenuButton(); // Function KillstreakUINew.KSContextMenu.ClearAllContextMenuButton // (Final|Native|Public|BlueprintCallable) // @ game+0x212eaa0
	void AddContextMenuButton(struct UKSContextMenuButton* ContextButton); // Function KillstreakUINew.KSContextMenu.AddContextMenuButton // (Final|Native|Public|BlueprintCallable) // @ game+0x212e980
};

// Class KillstreakUINew.KSContextMenuButton
// Size: 0x520 (Inherited: 0x518)
struct UKSContextMenuButton : UKSWidget {
	enum class EPlayerContextOptions ContextOption; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)

	void SetContextOption(enum class EPlayerContextOptions Context); // Function KillstreakUINew.KSContextMenuButton.SetContextOption // (Final|Native|Public|BlueprintCallable) // @ game+0x212fcc0
	void HandleVisibility(bool isVisibility); // Function KillstreakUINew.KSContextMenuButton.HandleVisibility // (Native|Event|Public|BlueprintEvent) // @ game+0x212f680
	void HandleActive(bool IsActive); // Function KillstreakUINew.KSContextMenuButton.HandleActive // (Native|Event|Public|BlueprintEvent) // @ game+0x212f3a0
	enum class EPlayerContextOptions GetContextOption(); // Function KillstreakUINew.KSContextMenuButton.GetContextOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x212ef10
};

// Class KillstreakUINew.KSContextualPingMarkerWidget
// Size: 0x3a0 (Inherited: 0x318)
struct UKSContextualPingMarkerWidget : UKSMapIconWidgetBase {
	struct FMulticastInlineDelegate OnPingRemovedCalled; // 0x318(0x10)
	struct FMulticastInlineDelegate OnPingChangedCalled; // 0x328(0x10)
	struct FPingInfo CurrentPingInfo; // 0x338(0x50)
	struct UKSPingManager* PingManager; // 0x388(0x08)
	struct UDataTable* ContextualPingTypesDT; // 0x390(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x398(0x08)

	void SetupPingOnReady(); // Function KillstreakUINew.KSContextualPingMarkerWidget.SetupPingOnReady // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetPingInfo(struct FPingInfo PingInfoVal); // Function KillstreakUINew.KSContextualPingMarkerWidget.SetPingInfo // (Final|Native|Public) // @ game+0x2130050
	void OnPingUnhovered(int32_t PingId, struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.OnPingUnhovered // (Final|Native|Public|BlueprintCallable) // @ game+0x212f910
	void OnPingHovered(int32_t PingId, struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.OnPingHovered // (Final|Native|Public|BlueprintCallable) // @ game+0x212f850
	void OnInitializePing(); // Function KillstreakUINew.KSContextualPingMarkerWidget.OnInitializePing // (Final|Native|Public|BlueprintCallable) // @ game+0x212f7a0
	bool IsInvisiblePingType(enum class EPingType PingType); // Function KillstreakUINew.KSContextualPingMarkerWidget.IsInvisiblePingType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x212f710
	void HandleOnContextualPingRemoved(int32_t PingId, struct AKSPlayerState* PingingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.HandleOnContextualPingRemoved // (Native|Public) // @ game+0x212f530
	void HandleOnContextualPingChanged(int32_t PingId, struct AKSPlayerState* PingingPlayer, struct AKSPlayerState* AcknowledgingPlayer); // Function KillstreakUINew.KSContextualPingMarkerWidget.HandleOnContextualPingChanged // (Native|Public) // @ game+0x212f430
	float GetPingLifeSpan(enum class EPingType PingType); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingLifeSpan // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x212f2b0
	bool GetPingIconByType(enum class EPingType PingType, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingIconByType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x212f1b0
	bool GetPingIconByMessage(enum class EPingMessage PingMessage, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingIconByMessage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x212f0b0
	bool GetPingColorByType(enum class EPingType PingType, struct FLinearColor& PingColor); // Function KillstreakUINew.KSContextualPingMarkerWidget.GetPingColorByType // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x212efd0
	bool FindRowByType(enum class EPingType PingType, struct FContextualPingTypesRow& ContextualPingTypesRow); // Function KillstreakUINew.KSContextualPingMarkerWidget.FindRowByType // (Final|Native|Protected|HasOutParms|Const) // @ game+0x212ed60
	bool FindRowByMessage(enum class EPingMessage PingMessage, struct FContextualPingMessagesRow& ContextualPingMessagesRow); // Function KillstreakUINew.KSContextualPingMarkerWidget.FindRowByMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x212ec40
};

// Class KillstreakUINew.KSCosmeticItemSelectorWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSCosmeticItemSelectorWidget : UKSWidget {
};

// Class KillstreakUINew.KSCosmeticSlotDetails
// Size: 0x50 (Inherited: 0x28)
struct UKSCosmeticSlotDetails : UObject {
	struct UPlatformInventoryItem* CosmeticItem; // 0x28(0x08)
	struct UPUMG_StoreItem* StoreItem; // 0x30(0x08)
	struct UKSJobItem* AssociatedJobItem; // 0x38(0x08)
	enum class EMercCosmeticSlot MercCosmeticSlot; // 0x40(0x01)
	enum class EWeaponSlot WeaponSlot; // 0x41(0x01)
	char pad_42[0x2]; // 0x42(0x02)
	int32_t SlotPosition; // 0x44(0x04)
	bool NavigatedFromNews; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class KillstreakUINew.KSCustomizationSelection
// Size: 0x548 (Inherited: 0x518)
struct UKSCustomizationSelection : UKSWidget {
	char pad_518[0x8]; // 0x518(0x08)
	struct TArray<struct FRogueCustomizationRelatedInfo> RogueCustomizationRelatedInfos; // 0x520(0x10)
	struct TArray<enum class EMercCosmeticSlot> ActiveCosmeticSlots; // 0x530(0x10)
	int32_t TabIndex; // 0x540(0x04)
	char pad_544[0x4]; // 0x544(0x04)

	void TabRight(); // Function KillstreakUINew.KSCustomizationSelection.TabRight // (Final|Native|Public|BlueprintCallable) // @ game+0x21351c0
	void TabLeft(); // Function KillstreakUINew.KSCustomizationSelection.TabLeft // (Final|Native|Public|BlueprintCallable) // @ game+0x21351a0
	void SetWingSuitAsset(struct UKSWeaponAsset* WingSuit); // Function KillstreakUINew.KSCustomizationSelection.SetWingSuitAsset // (Final|Native|Protected|BlueprintCallable) // @ game+0x2135120
	void PurchaseAndEquip(enum class EMercCosmeticSlot SlotType, int32_t SlotPosition, struct UKSJobItem* JobItem, struct UPUMG_StoreItem* StoreItem); // Function KillstreakUINew.KSCustomizationSelection.PurchaseAndEquip // (Final|Native|Protected|BlueprintCallable) // @ game+0x2134d60
	void PromptEquipAllForCosmetic(struct UKSItem* CosmeticItem, enum class EMercCosmeticSlot SlotType, int32_t SlotPosition); // Function KillstreakUINew.KSCustomizationSelection.PromptEquipAllForCosmetic // (Final|Native|Public|BlueprintCallable) // @ game+0x2134c60
	void OnEquipAllComplete(bool bSuccess); // Function KillstreakUINew.KSCustomizationSelection.OnEquipAllComplete // (Final|Native|Public) // @ game+0x21348a0
	bool IsItemOwned(struct UPlatformInventoryItem* Item); // Function KillstreakUINew.KSCustomizationSelection.IsItemOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21347a0
	void GetWingSuitItems(struct TArray<struct TSoftObjectPtr<UKSItem>>& OwnedItems, struct TArray<struct UPUMG_StoreItem*>& StoreItems); // Function KillstreakUINew.KSCustomizationSelection.GetWingSuitItems // (Final|Native|Protected|HasOutParms) // @ game+0x2134600
	struct UKSWeaponAsset* GetWingSuitAsset(); // Function KillstreakUINew.KSCustomizationSelection.GetWingSuitAsset // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21345e0
	void GetWeaponSlotItems(enum class EWeaponSlot WeaponSlotType, struct UKSJobItem* JobItem, struct TArray<struct TSoftObjectPtr<UKSItem>>& OwnedItems, struct TArray<struct UPUMG_StoreItem*>& StoreItems); // Function KillstreakUINew.KSCustomizationSelection.GetWeaponSlotItems // (Final|Native|Protected|HasOutParms) // @ game+0x2134430
	bool GetWeaponItem(enum class EWeaponSlot WeaponSlotType, struct UKSJobItem* JobItem, struct UKSWeaponAsset*& Weapon); // Function KillstreakUINew.KSCustomizationSelection.GetWeaponItem // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2134320
	void GetSkinItemsForJobItem(struct UKSJobItem* JobItem, struct TArray<struct TSoftObjectPtr<UKSItem>>& OwnedItems, struct TArray<struct UPUMG_StoreItem*>& StoreItems); // Function KillstreakUINew.KSCustomizationSelection.GetSkinItemsForJobItem // (Final|Native|Protected|HasOutParms) // @ game+0x2133f70
	struct UKSScrollBox* GetScrollBoxForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetScrollBoxForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133ee0
	struct FRogueCustomizationRelatedInfo GetRogueCustomizationRelatedInfoForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetRogueCustomizationRelatedInfoForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133e30
	void GetRadialMenuItems(struct TSoftObjectPtr<UKSJobItem> ForJobItem, struct TArray<struct TSoftObjectPtr<UKSItem>>& OwnedItems, struct TArray<struct UPUMG_StoreItem*>& StoreItems, struct FName Tag); // Function KillstreakUINew.KSCustomizationSelection.GetRadialMenuItems // (Final|Native|Protected|HasOutParms) // @ game+0x2133c10
	struct UKSNavTabWidget* GetNavTabForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetNavTabForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133a80
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSCustomizationSelection.GetItemHelper // (Final|Native|Protected|BlueprintCallable) // @ game+0x21339a0
	struct UKSSortableGridPanel* GetItemContainerForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetItemContainerForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133910
	void GetCosmeticItemsForSlot(enum class EMercCosmeticSlot SlotType, enum class EWeaponSlot WeaponSlotType, struct UKSJobItem* JobItem, struct TArray<struct TSoftObjectPtr<UKSItem>>& OwnedItems, struct TArray<struct UPUMG_StoreItem*>& StoreItems); // Function KillstreakUINew.KSCustomizationSelection.GetCosmeticItemsForSlot // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2133670
	struct TArray<struct UKSCosmeticItemSelectorWidget*> GetCosmeticItemSelectorsForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.GetCosmeticItemSelectorsForCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21335a0
	struct UKSSortableGridPanel* GetActiveSortableGridPanel(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveSortableGridPanel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133570
	struct UKSScrollBox* GetActiveScrollBox(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveScrollBox // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133540
	struct FRogueCustomizationRelatedInfo GetActiveRogueCustomizationRelatedInfo(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveRogueCustomizationRelatedInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21334f0
	struct UKSNavTabWidget* GetActiveNavTab(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveNavTab // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21334c0
	enum class EMercCosmeticSlot GetActiveCosmeticSlot(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveCosmeticSlot // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133490
	struct TArray<struct UKSCosmeticItemSelectorWidget*> GetActiveCosmeticItemSelectors(); // Function KillstreakUINew.KSCustomizationSelection.GetActiveCosmeticItemSelectors // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133410
	void ForceSetTabIndex(int32_t NewTabIndex); // Function KillstreakUINew.KSCustomizationSelection.ForceSetTabIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x2133390
	void ClearCosmeticItemsForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot); // Function KillstreakUINew.KSCustomizationSelection.ClearCosmeticItemsForCosmeticSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x2133310
	void ChangeToNewTab(); // Function KillstreakUINew.KSCustomizationSelection.ChangeToNewTab // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AddRogueCustomizationRelatedInfo(int32_t NewSwitcherIndex, enum class EMercCosmeticSlot NewCosmeticSlot, struct UKSNavTabWidget* NewNavTab, struct UKSScrollBox* NewScrollBox, struct UKSSortableGridPanel* NewSortableGridPanel); // Function KillstreakUINew.KSCustomizationSelection.AddRogueCustomizationRelatedInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x2133160
	void AddCosmeticItemsForCosmeticSlot(enum class EMercCosmeticSlot CheckCosmeticSlot, struct TArray<struct UKSCosmeticItemSelectorWidget*> NewCosmeticItems); // Function KillstreakUINew.KSCustomizationSelection.AddCosmeticItemsForCosmeticSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x2133040
};

// Class KillstreakUINew.KSDailyChallengeViewBase
// Size: 0x528 (Inherited: 0x518)
struct UKSDailyChallengeViewBase : UKSWidget {
	float ChallengeTimerRefreshRate; // 0x518(0x04)
	char pad_51C[0xc]; // 0x51c(0x0c)

	void UpdateChallenges(); // Function KillstreakUINew.KSDailyChallengeViewBase.UpdateChallenges // (Final|Native|Protected) // @ game+0x2135210
	void InitializeChallengeDisplays(); // Function KillstreakUINew.KSDailyChallengeViewBase.InitializeChallengeDisplays // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandlePlayerChallengesReady(); // Function KillstreakUINew.KSDailyChallengeViewBase.HandlePlayerChallengesReady // (Final|Native|Protected) // @ game+0x2134780
	void HandlePlayerChallengesChanged(); // Function KillstreakUINew.KSDailyChallengeViewBase.HandlePlayerChallengesChanged // (Final|Native|Protected) // @ game+0x2134760
	void HandleDailyChallengeTimerRefreshed(); // Function KillstreakUINew.KSDailyChallengeViewBase.HandleDailyChallengeTimerRefreshed // (Final|Native|Protected) // @ game+0x2134740
	struct TArray<struct UKSActivityInstance*> GetDisplayingChallenges(); // Function KillstreakUINew.KSDailyChallengeViewBase.GetDisplayingChallenges // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayChallengeTimeRemaining(int32_t TimeRemainingSeconds); // Function KillstreakUINew.KSDailyChallengeViewBase.DisplayChallengeTimeRemaining // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayChallenge(int32_t Index, struct UKSActivityInstance* ActivityInstance, bool PlayFlourish); // Function KillstreakUINew.KSDailyChallengeViewBase.DisplayChallenge // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSDataSocialCategory
// Size: 0xe0 (Inherited: 0x28)
struct UKSDataSocialCategory : UObject {
	struct FMulticastInlineDelegate OnPlayersUpdated; // 0x28(0x10)
	struct FMulticastInlineDelegate OnHeaderUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMessageUpdated; // 0x48(0x10)
	char pad_58[0x78]; // 0x58(0x78)
	struct TArray<struct UKSDataSocialPlayer*> SortedPlayerList; // 0xd0(0x10)

	bool TryConsumeOpenOnUpdate(); // Function KillstreakUINew.KSDataSocialCategory.TryConsumeOpenOnUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x21351e0
	void SetOpenOnUpdate(bool Value); // Function KillstreakUINew.KSDataSocialCategory.SetOpenOnUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x21350a0
	void SetMessageText(bool bProcessing, struct FText& MessageText); // Function KillstreakUINew.KSDataSocialCategory.SetMessageText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2134f80
	void SetHeaderText(struct FText& Header); // Function KillstreakUINew.KSDataSocialCategory.SetHeaderText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2134eb0
	int32_t Num(); // Function KillstreakUINew.KSDataSocialCategory.Num // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2134880
	bool IsProcessing(); // Function KillstreakUINew.KSDataSocialCategory.IsProcessing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2134830
	struct TArray<struct UKSDataSocialPlayer*> GetPlayerList(); // Function KillstreakUINew.KSDataSocialCategory.GetPlayerList // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2133be0
	struct FText GetMessageText(); // Function KillstreakUINew.KSDataSocialCategory.GetMessageText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21339d0
	struct FText GetHeaderText(); // Function KillstreakUINew.KSDataSocialCategory.GetHeaderText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2133860
	char BP_GetSectionValue(); // Function KillstreakUINew.KSDataSocialCategory.BP_GetSectionValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21332f0
};

// Class KillstreakUINew.KSDataSocialPlayer
// Size: 0x40 (Inherited: 0x28)
struct UKSDataSocialPlayer : UObject {
	struct FMulticastInlineDelegate OnDataUpdate; // 0x28(0x10)
	struct UKSPlayerInfo* Info; // 0x38(0x08)

	void KSSocialPlayerUpdate__DelegateSignature(struct UKSPlayerInfo* playerinfo); // DelegateFunction KillstreakUINew.KSDataSocialPlayer.KSSocialPlayerUpdate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24d5b40
	bool IsValid(); // Function KillstreakUINew.KSDataSocialPlayer.IsValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2134850
	struct UKSPlayerInfo* GetPlayerInfo(); // Function KillstreakUINew.KSDataSocialPlayer.GetPlayerInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2133bc0
};

// Class KillstreakUINew.KSDebugMenu
// Size: 0x528 (Inherited: 0x518)
struct UKSDebugMenu : UKSWidget {
	struct TArray<struct FDebugMenuCommandInfo> DebugCommands; // 0x518(0x10)

	bool GetSubmenu(struct FDebugMenuCommandInfo BaseCommand, struct TArray<struct FDebugMenuCommandInfo>& Submenu); // Function KillstreakUINew.KSDebugMenu.GetSubmenu // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21341c0
	void GetSortedBaseDebugCommands(struct TArray<struct FDebugMenuCommandInfo>& SortedCommands); // Function KillstreakUINew.KSDebugMenu.GetSortedBaseDebugCommands // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21340f0
	enum class EConsoleCommandParamType GetParamTypeForSubCommand(struct FString BaseCommandString); // Function KillstreakUINew.KSDebugMenu.GetParamTypeForSubCommand // (Native|Event|Protected|BlueprintEvent) // @ game+0x2133b10
};

// Class KillstreakUINew.KSDownloadProgressWidget
// Size: 0x248 (Inherited: 0x238)
struct UKSDownloadProgressWidget : UUserWidget {
	float UpdatePeriod; // 0x238(0x04)
	bool bMarkedFinished; // 0x23c(0x01)
	char pad_23D[0x3]; // 0x23d(0x03)
	float TimeUntilNextUpdate; // 0x240(0x04)
	char pad_244[0x4]; // 0x244(0x04)

	void UpdateFinished(); // Function KillstreakUINew.KSDownloadProgressWidget.UpdateFinished // (Native|Event|Protected|BlueprintEvent) // @ game+0x1856f90
	void UpdatedDownloadProgress(float Progress, float Total, float Eta, bool bSupportsEta); // Function KillstreakUINew.KSDownloadProgressWidget.UpdatedDownloadProgress // (Native|Event|Protected|BlueprintEvent) // @ game+0x2135230
};

// Class KillstreakUINew.KSEditableTextBox
// Size: 0xa40 (Inherited: 0xa30)
struct UKSEditableTextBox : UEditableTextBox {
	struct FDelegate OnKeyDown; // 0xa30(0x10)
};

// Class KillstreakUINew.KSViewedPawnWidget
// Size: 0x548 (Inherited: 0x538)
struct UKSViewedPawnWidget : UKSPawnWidget {
	char pad_538[0x10]; // 0x538(0x10)
};

// Class KillstreakUINew.KSEliminationMessageWidget
// Size: 0x548 (Inherited: 0x548)
struct UKSEliminationMessageWidget : UKSViewedPawnWidget {

	void ShowMessageForTakenDown(struct AKSPlayerState* Instigator, bool IsElimination); // Function KillstreakUINew.KSEliminationMessageWidget.ShowMessageForTakenDown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ShowMessageForTakedown(struct AKSPlayerState* Victim, bool IsElimination); // Function KillstreakUINew.KSEliminationMessageWidget.ShowMessageForTakedown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ShowMessageForAssist(struct AKSPlayerState* Victim, bool IsElimination); // Function KillstreakUINew.KSEliminationMessageWidget.ShowMessageForAssist // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnPlayerDownReceived(struct FCombatEventInfo EventInfo, int32_t ExpBonus); // Function KillstreakUINew.KSEliminationMessageWidget.OnPlayerDownReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x2134b20
	void OnPlayerDeathReceived(struct FCombatEventInfo EventInfo); // Function KillstreakUINew.KSEliminationMessageWidget.OnPlayerDeathReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x2134a10
	void OnPlayerAssistReceived(struct FAssistInfo EventInfo); // Function KillstreakUINew.KSEliminationMessageWidget.OnPlayerAssistReceived // (Final|Native|Public|BlueprintCallable) // @ game+0x2134930
	void ClearMessages(); // Function KillstreakUINew.KSEliminationMessageWidget.ClearMessages // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSEmailCollection_ViewRedirector
// Size: 0x60 (Inherited: 0x60)
struct UKSEmailCollection_ViewRedirector : UKSActivityProgress_ViewRedirector {
};

// Class KillstreakUINew.KSEmailCollectionWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSEmailCollectionWidget : UKSWidget {

	void SubmitEmailAddress(struct FString EmailAddress); // Function KillstreakUINew.KSEmailCollectionWidget.SubmitEmailAddress // (Final|Native|Public|BlueprintCallable) // @ game+0x213a5a0
	void OnSubmitEmailResponseNative(bool bSuccess); // Function KillstreakUINew.KSEmailCollectionWidget.OnSubmitEmailResponseNative // (Final|Native|Public) // @ game+0x21399d0
	void OnSubmitEmailResponse(bool Success); // Function KillstreakUINew.KSEmailCollectionWidget.OnSubmitEmailResponse // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool IsValidEmailAddress(struct FString EmailAddress); // Function KillstreakUINew.KSEmailCollectionWidget.IsValidEmailAddress // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2139580
	struct FText GetPrepopulatedEmail(); // Function KillstreakUINew.KSEmailCollectionWidget.GetPrepopulatedEmail // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x18b2e40
	struct FText GetEULAText(); // Function KillstreakUINew.KSEmailCollectionWidget.GetEULAText // (Final|Native|Public|BlueprintCallable) // @ game+0x2138a30
	void DismissPopup(); // Function KillstreakUINew.KSEmailCollectionWidget.DismissPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x2138630
};

// Class KillstreakUINew.KSEMODataFactory
// Size: 0x120 (Inherited: 0x38)
struct UKSEMODataFactory : UPUMG_DataFactory {
	char pad_38[0x14]; // 0x38(0x14)
	bool haveRecieveMatchReport; // 0x4c(0x01)
	char pad_4D[0xb3]; // 0x4d(0xb3)
	struct FMulticastInlineDelegate OnRewardsRecieved; // 0x100(0x10)
	struct FMulticastInlineDelegate OnProgressionRecieved; // 0x110(0x10)

	void SetupTestData(int32_t PlayerXp, int32_t RankedXp, int32_t RogueXp, int32_t ReputationEarned, int32_t PlacementMatchNum, int32_t BattlePassXp, int32_t WeaponMasteryCount, int32_t WeaponMasteryLevels, bool CategoryMasteryCanLevel, int32_t MilestonesPerWeapon, int32_t BonusPoints); // Function KillstreakUINew.KSEMODataFactory.SetupTestData // (Final|Native|Public) // @ game+0x213a2b0
	bool IsLocalPlayer(int64_t PlayerId); // Function KillstreakUINew.KSEMODataFactory.IsLocalPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x21393d0
	void HandlePlayerRewardsEventTokens(); // Function KillstreakUINew.KSEMODataFactory.HandlePlayerRewardsEventTokens // (Final|Native|Public|BlueprintCallable) // @ game+0x2139380
	void HandlePlayerRewards(struct FPlayerRewardsSummary PlayerRewardSummary, bool bFakeTestData); // Function KillstreakUINew.KSEMODataFactory.HandlePlayerRewards // (Final|Native|Public|BlueprintCallable) // @ game+0x2139200
	void HandleEOMDetail(); // Function KillstreakUINew.KSEMODataFactory.HandleEOMDetail // (Final|Native|Public) // @ game+0x21390e0
	struct FScoreboardStats GetScoreboardStats(); // Function KillstreakUINew.KSEMODataFactory.GetScoreboardStats // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2138fb0
	struct FPlayerRewardsSummary GetPlayerRewardsSummary(); // Function KillstreakUINew.KSEMODataFactory.GetPlayerRewardsSummary // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2138df0
	int32_t GetLastMatchQueueId(); // Function KillstreakUINew.KSEMODataFactory.GetLastMatchQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2138bf0
	bool FindReputationProgressionActivity(struct UKSActivityInstance*& ReputationProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindReputationProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21388f0
	bool FindRankedProgressionActivity(struct UKSActivityInstance*& RankedProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindRankedProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x2138850
	bool FindPlayerXpProgressionActivity(struct UKSActivityInstance*& PlayerXpProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindPlayerXpProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x21387b0
	bool FindMiniBattlePassProgressionActivity(struct UKSActivityInstance*& MiniBattlePassProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindMiniBattlePassProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x2138710
	bool FindBattlePassProgressionActivity(struct UKSActivityInstance*& BattlePassProgressionActivity); // Function KillstreakUINew.KSEMODataFactory.FindBattlePassProgressionActivity // (Final|Native|Protected|HasOutParms) // @ game+0x2138670
	void ComputeEOMResults(); // Function KillstreakUINew.KSEMODataFactory.ComputeEOMResults // (Final|Native|Public|BlueprintCallable) // @ game+0x2138610
};

// Class KillstreakUINew.KSEnemyDetectedWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSEnemyDetectedWidget : UKSWidget {
};

// Class KillstreakUINew.KSEquipAllData
// Size: 0x88 (Inherited: 0x28)
struct UKSEquipAllData : UObject {
	struct UKSItem* CosmeticItem; // 0x28(0x08)
	struct FText HeaderText; // 0x30(0x18)
	struct FText DescText; // 0x48(0x18)
	struct FMulticastInlineDelegate EquipAllCompletedCallback; // 0x60(0x10)
	enum class EEquipAllType EquipType; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t SlotType; // 0x74(0x04)
	int32_t SlotPosition; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct UKSWeaponAsset* WeaponToEquipTo; // 0x80(0x08)
};

// Class KillstreakUINew.KSEquipAllWidget
// Size: 0x520 (Inherited: 0x518)
struct UKSEquipAllWidget : UKSWidget {
	struct UKSEquipAllData* EquipAllData; // 0x518(0x08)

	void OnEquipAll(); // Function KillstreakUINew.KSEquipAllWidget.OnEquipAll // (Final|Native|Public|BlueprintCallable) // @ game+0x21399b0
	void CancelEquipAll(); // Function KillstreakUINew.KSEquipAllWidget.CancelEquipAll // (Final|Native|Public|BlueprintCallable) // @ game+0x21385d0
};

// Class KillstreakUINew.KSEventBuyThroughScreenBase
// Size: 0x518 (Inherited: 0x518)
struct UKSEventBuyThroughScreenBase : UKSWidget {
};

// Class KillstreakUINew.KSExpDisplayWidget
// Size: 0x560 (Inherited: 0x548)
struct UKSExpDisplayWidget : UKSViewedPawnWidget {
	bool bIsWaitingForNextQueue; // 0x548(0x01)
	char pad_549[0x17]; // 0x549(0x17)

	void QueueExpDisplays(struct FExpDisplayInfo ExpInfo); // Function KillstreakUINew.KSExpDisplayWidget.QueueExpDisplays // (Final|Native|Protected|BlueprintCallable) // @ game+0x2139e60
	void NativeHandleDisplayExpInfo(); // Function KillstreakUINew.KSExpDisplayWidget.NativeHandleDisplayExpInfo // (Native|Protected) // @ game+0x2139670
	bool GetNextExpDisplay(struct FExpDisplayInfo& ExpInfo); // Function KillstreakUINew.KSExpDisplayWidget.GetNextExpDisplay // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2138c10
	void DisplayExpInfo(); // Function KillstreakUINew.KSExpDisplayWidget.DisplayExpInfo // (Native|Event|Protected|BlueprintEvent) // @ game+0x2138650
};

// Class KillstreakUINew.KSFloatTickLerpWidgetBase
// Size: 0x260 (Inherited: 0x238)
struct UKSFloatTickLerpWidgetBase : UUserWidget {
	struct FMulticastInlineDelegate OnLerpComplete; // 0x238(0x10)
	float LerpTime; // 0x248(0x04)
	float LerpPower; // 0x24c(0x04)
	char pad_250[0x10]; // 0x250(0x10)

	void SetTargetValue(float Value); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.SetTargetValue // (Final|Native|Public|BlueprintCallable) // @ game+0x213a230
	void SetLerpTime(float Time); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.SetLerpTime // (Final|Native|Public|BlueprintCallable) // @ game+0x213a1b0
	void SetLerpPower(float Power); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.SetLerpPower // (Final|Native|Public|BlueprintCallable) // @ game+0x213a120
	bool IsLerping(); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.IsLerping // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21393a0
	float GetCurrentValue(); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.GetCurrentValue // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2138a10
	void ForceCurrentValue(float Value); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.ForceCurrentValue // (Final|Native|Public|BlueprintCallable) // @ game+0x2138990
	void DisplayForValue(float Value); // Function KillstreakUINew.KSFloatTickLerpWidgetBase.DisplayForValue // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSFriendDataFactory
// Size: 0x138 (Inherited: 0x128)
struct UKSFriendDataFactory : UPUMG_FriendDataFactory {
	struct FMulticastInlineDelegate OnUpdateRecentlyPlayedPlayers; // 0x128(0x10)

	void OnEOMRewardsReceived(struct FPlayerRewardsSummary PlayerRewardsSummary, struct FScoreboardStats ScoreboardStats); // Function KillstreakUINew.KSFriendDataFactory.OnEOMRewardsReceived // (Final|Native|Protected) // @ game+0x21397c0
	void KSUpdateRecentlyPlayedPlayers__DelegateSignature(struct UKSFriendDataFactory* Source); // DelegateFunction KillstreakUINew.KSFriendDataFactory.KSUpdateRecentlyPlayedPlayers__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24d5b40
	struct TArray<struct UPUMG_PlayerInfo*> GetSuggestedFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetSuggestedFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x2139060
	struct TArray<struct UKSPlayerInfo*> GetPlayersPlayedWithThisClientSession_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetPlayersPlayedWithThisClientSession_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x2138f30
	struct TArray<struct UPUMG_PlayerInfo*> GetPendingFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetPendingFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x2138d70
	struct TArray<struct UPUMG_PlayerInfo*> GetOnlineFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetOnlineFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x2138cf0
	struct TArray<struct UPUMG_PlayerInfo*> GetFriends_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetFriends_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x2138b50
	struct TArray<struct UPUMG_PlayerInfo*> GetFriendRequests_Info(); // Function KillstreakUINew.KSFriendDataFactory.GetFriendRequests_Info // (Final|Native|Public|BlueprintCallable) // @ game+0x2138ad0
};

// Class KillstreakUINew.KSFubarPopupWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSFubarPopupWidget : UKSWidget {

	void ReceiveFubar(enum class EFubarDisplayReason Reason); // Function KillstreakUINew.KSFubarPopupWidget.ReceiveFubar // (Final|Native|Protected) // @ game+0x2139f50
	int32_t GetSecondsToShutdown(); // Function KillstreakUINew.KSFubarPopupWidget.GetSecondsToShutdown // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2139030
	void DisplayFubar(enum class EFubarDisplayReason Reason); // Function KillstreakUINew.KSFubarPopupWidget.DisplayFubar // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSMapWidgetBase
// Size: 0x640 (Inherited: 0x518)
struct UKSMapWidgetBase : UKSWidget {
	enum class EDisplayType MapDisplayType; // 0x518(0x01)
	bool bWasVisible; // 0x519(0x01)
	char pad_51A[0x6]; // 0x51a(0x06)
	uint64_t LastUpdateFrame; // 0x520(0x08)
	struct TArray<struct FMapIconWidgetConfig> MapIconWidgetsToPool; // 0x528(0x10)
	struct TArray<struct UKSMapIconWidgetPool*> MapIconWidgetPool; // 0x538(0x10)
	struct TArray<struct UKSMapIconWidgetBase*> MapIconWidgetPoolShown; // 0x548(0x10)
	char pad_558[0x50]; // 0x558(0x50)
	struct TMap<struct AKSPlayerState*, struct UKSMapIconWidgetBase*> PlayerIconMap; // 0x5a8(0x50)
	char pad_5F8[0x38]; // 0x5f8(0x38)
	bool AbsoluteRotation; // 0x630(0x01)
	bool CanBeScrambled; // 0x631(0x01)
	bool IsScrambled; // 0x632(0x01)
	bool bAffectedByScramble; // 0x633(0x01)
	char pad_634[0xc]; // 0x634(0x0c)

	void UpdateIcon(struct UKSMapIconWidgetBase* Icon); // Function KillstreakUINew.KSMapWidgetBase.UpdateIcon // (Final|Native|Protected) // @ game+0x2148310
	struct FVector2D ToIconRenderCoords(struct FVector2D MapCoords); // Function KillstreakUINew.KSMapWidgetBase.ToIconRenderCoords // (Native|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x2148230
	float ToIconRenderAngle(float PlayerAngle); // Function KillstreakUINew.KSMapWidgetBase.ToIconRenderAngle // (Native|Event|Protected|BlueprintEvent) // @ game+0x21481a0
	void TickCachedTransform(); // Function KillstreakUINew.KSMapWidgetBase.TickCachedTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x2148180
	void SetScrambleState(bool Scrambled); // Function KillstreakUINew.KSMapWidgetBase.SetScrambleState // (Final|Native|Protected) // @ game+0x2148040
	void RemoveWidgetFromLoaderById(int32_t InId); // Function KillstreakUINew.KSMapWidgetBase.RemoveWidgetFromLoaderById // (Final|Native|Public) // @ game+0x2147cb0
	void OnScrambleStateChanged(bool Scrambled); // Function KillstreakUINew.KSMapWidgetBase.OnScrambleStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnReceiveDisplayWidgetInfo(struct FDisplayInfo DisplayInfo); // Function KillstreakUINew.KSMapWidgetBase.OnReceiveDisplayWidgetInfo // (Native|Public) // @ game+0x2147af0
	void OnGameStateSet(struct AGameStateBase* GameStateBase); // Function KillstreakUINew.KSMapWidgetBase.OnGameStateSet // (Final|Native|Public) // @ game+0x2147a50
	bool IsOnMap(struct FVector2D MapCoords); // Function KillstreakUINew.KSMapWidgetBase.IsOnMap // (Native|Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x21477a0
	void HandleMoveToWidgetPool(struct UKSMapIconWidgetBase* MapIconWidget); // Function KillstreakUINew.KSMapWidgetBase.HandleMoveToWidgetPool // (Final|Native|Protected) // @ game+0x21475b0
	void HandleDisplayFromWidgetPool(struct UKSMapIconWidgetBase* MapIconWidget, struct FDisplayInfo DisplayInfo); // Function KillstreakUINew.KSMapWidgetBase.HandleDisplayFromWidgetPool // (Final|Native|Protected) // @ game+0x21473d0
	struct UKSMapIconWidgetBase* GrabMapIconWidget(struct FString WidgetPoolName); // Function KillstreakUINew.KSMapWidgetBase.GrabMapIconWidget // (Final|Native|Protected) // @ game+0x21472e0
	float GetDistanceToIcon(struct UKSMapIconWidgetBase* Icon); // Function KillstreakUINew.KSMapWidgetBase.GetDistanceToIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2146ca0
	struct APawn* GetCachedViewedPawn(); // Function KillstreakUINew.KSMapWidgetBase.GetCachedViewedPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2146c30
	struct FTransform GetCachedTransform(); // Function KillstreakUINew.KSMapWidgetBase.GetCachedTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2146bf0
	void DisplayToMapWidget(struct UKSMapIconWidgetBase* MapIcon); // Function KillstreakUINew.KSMapWidgetBase.DisplayToMapWidget // (Native|Event|Protected|BlueprintEvent) // @ game+0x2146a30
	struct UKSMapIconWidgetBase* CreateNewIconWidget(struct UKSMapIconWidgetBase* WidgetClass, int32_t UniqueId, struct AKSPlayerState* CreatingPlayer, enum class EDisplayType ParentMapDisplayType, struct AActor* AssociatedActor, struct UObject* AssociatedObject, struct FVector DefaultLocation, float Lifespan); // Function KillstreakUINew.KSMapWidgetBase.CreateNewIconWidget // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	void CreateMapIconWidgetPool(struct FMapIconWidgetConfig MapIconWidgetConfig); // Function KillstreakUINew.KSMapWidgetBase.CreateMapIconWidgetPool // (Final|Native|Protected) // @ game+0x2146930
};

// Class KillstreakUINew.KSFullMapWidget
// Size: 0x650 (Inherited: 0x640)
struct UKSFullMapWidget : UKSMapWidgetBase {
	struct AActor* MinimapRendererActor; // 0x638(0x08)
	float MinimapWidth; // 0x640(0x04)
	char pad_64C[0x4]; // 0x64c(0x04)
};

// Class KillstreakUINew.KSHUDCommon
// Size: 0x618 (Inherited: 0x5a0)
struct AKSHUDCommon : APUMG_HUD {
	struct FMulticastInlineDelegate OnPreferredSiteUpdated; // 0x5a0(0x10)
	struct UPUMG_LoginDataFactory* LoginDataFactory; // 0x5b0(0x08)
	struct UKSSettingsDataFactory* SettingsFactory; // 0x5b8(0x08)
	struct UKSChatDataFactory* ChatDataFactory; // 0x5c0(0x08)
	struct UKSPartyDataFactory* PartyDataFactory; // 0x5c8(0x08)
	struct UKSNPEDataFactory* NPEDataFactory; // 0x5d0(0x08)
	struct UKSPlayerDataFactory* PlayerDataFactory; // 0x5d8(0x08)
	bool bDisplayWatermark; // 0x5e0(0x01)
	char pad_5E1[0x3]; // 0x5e1(0x03)
	float WatermarkAlpha; // 0x5e4(0x04)
	float WatermarkOffsetLeft; // 0x5e8(0x04)
	float WatermarkOffsetTop; // 0x5ec(0x04)
	float WatermarkOffsetRight; // 0x5f0(0x04)
	float WatermarkOffsetBottom; // 0x5f4(0x04)
	float WatermarkChangePositionTime; // 0x5f8(0x04)
	char pad_5FC[0x4]; // 0x5fc(0x04)
	struct UDataTable* ColorPaletteDT; // 0x600(0x08)
	struct UDataTable* FontPaletteDT; // 0x608(0x08)
	struct UKSSettingsColorOptionsAsset* CrosshairColorOptions; // 0x610(0x08)

	void UIX_ReportServer(); // Function KillstreakUINew.KSHUDCommon.UIX_ReportServer // (Final|Native|Public|BlueprintCallable) // @ game+0x213f1d0
	void TestChallengeNotification(); // Function KillstreakUINew.KSHUDCommon.TestChallengeNotification // (Final|Exec|Native|Protected) // @ game+0xa6a770
	void ShowErrorPopup(struct FText ErrorMsg); // Function KillstreakUINew.KSHUDCommon.ShowErrorPopup // (Final|Native|Public|BlueprintCallable) // @ game+0x213eff0
	bool ShouldShowCrossplayIconForPlayerState(struct AKSPlayerState* PlayerState); // Function KillstreakUINew.KSHUDCommon.ShouldShowCrossplayIconForPlayerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213ef60
	bool ShouldShowCrossplayIconForPlayer(int64_t PlayerId); // Function KillstreakUINew.KSHUDCommon.ShouldShowCrossplayIconForPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213eed0
	void SetPreferredSiteId(int32_t SiteId); // Function KillstreakUINew.KSHUDCommon.SetPreferredSiteId // (Final|Native|Public|BlueprintCallable) // @ game+0x213ec50
	void PrintToLog(struct FText InText); // Function KillstreakUINew.KSHUDCommon.PrintToLog // (Final|Native|Public|BlueprintCallable) // @ game+0x213e850
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function KillstreakUINew.KSHUDCommon.OpenTextChatToPlayer // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x213e6d0
	void OnInvalidVoucherAcquisition(struct UPUMG_StoreItem* StoreItem); // Function KillstreakUINew.KSHUDCommon.OnInvalidVoucherAcquisition // (Final|Native|Public) // @ game+0x213e550
	bool MutePlayer(int64_t PlayerId, bool Mute); // Function KillstreakUINew.KSHUDCommon.MutePlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x213e220
	void LogErrorMessage(struct FText ErrorMsg); // Function KillstreakUINew.KSHUDCommon.LogErrorMessage // (Final|Native|Public|BlueprintCallable) // @ game+0x213e140
	bool IsSamePortalAsLocalPlayer(int64_t PlayerId); // Function KillstreakUINew.KSHUDCommon.IsSamePortalAsLocalPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213e0b0
	bool IsMuted(int64_t PlayerId); // Function KillstreakUINew.KSHUDCommon.IsMuted // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x213e020
	void HandleOpenTextChat(bool BeginChatCommand); // Function KillstreakUINew.KSHUDCommon.HandleOpenTextChat // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x213dcd0
	void HandleControllerDisconnect(); // Function KillstreakUINew.KSHUDCommon.HandleControllerDisconnect // (Final|Native|Protected) // @ game+0x213dc10
	struct UKSUISessionManager* GetUISessionManager(); // Function KillstreakUINew.KSHUDCommon.GetUISessionManager // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213dbe0
	void GetSiteList(struct TMap<int32_t, struct FText>& OutSiteIdToNameMap); // Function KillstreakUINew.KSHUDCommon.GetSiteList // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x213dab0
	struct UKSSettingsDataFactory* GetSettingsDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetSettingsDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213da80
	bool GetPreferredSiteId(int32_t& OutSiteId); // Function KillstreakUINew.KSHUDCommon.GetPreferredSiteId // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d9e0
	struct UKSPlayerDataFactory* GetPlayerDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetPlayerDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1f4c790
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetPartyDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d9b0
	struct UKSNPEDataFactory* GetNPEDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetNPEDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d980
	struct UKSMercManager* GetMercManager(); // Function KillstreakUINew.KSHUDCommon.GetMercManager // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d950
	struct UPUMG_LoginDataFactory* GetLoginDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetLoginDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d920
	struct UKSLoadoutDataFactory* GetLoadoutDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetLoadoutDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d8f0
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSHUDCommon.GetItemHelper // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d8c0
	bool GetFont(struct FName FontName, struct FSlateFontInfo& ReturnFont); // Function KillstreakUINew.KSHUDCommon.GetFont // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d7a0
	struct TArray<struct UPanelWidget*> GetFocusableWidgetContainers(); // Function KillstreakUINew.KSHUDCommon.GetFocusableWidgetContainers // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	struct UKSContextBarWidget* GetContextBarWidget(); // Function KillstreakUINew.KSHUDCommon.GetContextBarWidget // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	bool GetColor(struct FName ColorName, struct FLinearColor& ReturnColor); // Function KillstreakUINew.KSHUDCommon.GetColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d6c0
	struct UKSChatDataFactory* GetChatDataFactory(); // Function KillstreakUINew.KSHUDCommon.GetChatDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d690
	struct UKSAcquisitionManager* GetAcquisitionManager(); // Function KillstreakUINew.KSHUDCommon.GetAcquisitionManager // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x213d660
	void EvaluateFocus(); // Function KillstreakUINew.KSHUDCommon.EvaluateFocus // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWatermark(); // Function KillstreakUINew.KSHUDCommon.DisplayWatermark // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ConfirmReportServer(); // Function KillstreakUINew.KSHUDCommon.ConfirmReportServer // (Final|Native|Protected) // @ game+0x213d2f0
	void ApplySafeFrameScale(float SafeFrameScale); // Function KillstreakUINew.KSHUDCommon.ApplySafeFrameScale // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSGameHUDNew
// Size: 0x6c0 (Inherited: 0x618)
struct AKSGameHUDNew : AKSHUDCommon {
	char pad_618[0x8]; // 0x618(0x08)
	struct UUserWidget* AimAssistDebugWidgetClass; // 0x620(0x08)
	struct TWeakObjectPtr<struct UUserWidget> AimAssistDebugWidget; // 0x628(0x08)
	struct TArray<struct FDataTableInfo> BaseAssetDataTables; // 0x630(0x10)
	struct UDynamicSkinTable* AssetDataTableManager; // 0x640(0x08)
	struct UMultiSkinObject* SkinObject; // 0x648(0x08)
	struct UKSHUDStateTracker* HUDStateTracker; // 0x650(0x08)
	char pad_658[0x50]; // 0x658(0x50)
	struct FMulticastInlineDelegate OnHudFubarDel; // 0x6a8(0x10)
	char pad_6B8[0x8]; // 0x6b8(0x08)

	void UIX_ReturnLobby(); // Function KillstreakUINew.KSGameHUDNew.UIX_ReturnLobby // (Final|Native|Public|BlueprintCallable) // @ game+0x213a680
	void ToggleAimAssistDebug(); // Function KillstreakUINew.KSGameHUDNew.ToggleAimAssistDebug // (Final|Exec|Native|Public) // @ game+0xa6a770
	void SetHUDVisible(bool bVisible); // Function KillstreakUINew.KSGameHUDNew.SetHUDVisible // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x213a090
	void ReturnToHome(); // Function KillstreakUINew.KSGameHUDNew.ReturnToHome // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x2139fd0
	void OnViewedPlayerStateModRemoved(struct UKSPlayerMod* PlayerMod, struct UKSPlayerModInstance* ModInstance); // Function KillstreakUINew.KSGameHUDNew.OnViewedPlayerStateModRemoved // (Final|Native|Private) // @ game+0x2139c50
	void OnViewedPlayerStateModAdded(struct UKSPlayerMod* PlayerMod, struct UKSPlayerModInstance* ModInstance); // Function KillstreakUINew.KSGameHUDNew.OnViewedPlayerStateModAdded // (Final|Native|Private) // @ game+0x2139b90
	void OnViewedPawnChanged(struct AKSPlayerController* Controller, struct AActor* OldViewTarget, struct AActor* NewViewTarget); // Function KillstreakUINew.KSGameHUDNew.OnViewedPawnChanged // (Final|Native|Private) // @ game+0x2139a90
	void OnToggleHUD(); // Function KillstreakUINew.KSGameHUDNew.OnToggleHUD // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2139a60
	void OnAssetDataTableManagerChanged(struct TSet<struct FName>& UpdatedKeywords); // Function KillstreakUINew.KSGameHUDNew.OnAssetDataTableManagerChanged // (Final|Native|Private|HasOutParms) // @ game+0x2139690
	void NetworkLagStateChanged(struct UWorld* World, struct UNetDriver* NetDriver, enum class ENetworkLagState LagType); // Function KillstreakUINew.KSGameHUDNew.NetworkLagStateChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool IsPlayerMuted(struct AKSPlayerState* KSPlayerState); // Function KillstreakUINew.KSGameHUDNew.IsPlayerMuted // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21394f0
	bool IsPlayerInVoiceChannel(struct AKSPlayerState* KSPlayerState); // Function KillstreakUINew.KSGameHUDNew.IsPlayerInVoiceChannel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2139460
	void HandleLoginStateChange(enum class EPUMG_LoginState LoginState); // Function KillstreakUINew.KSGameHUDNew.HandleLoginStateChange // (Final|Native|Protected) // @ game+0x2139180
	void HandleFubar(enum class EFubarDisplayReason Reason); // Function KillstreakUINew.KSGameHUDNew.HandleFubar // (Final|Native|Private) // @ game+0x2139100
	struct UKSHUDStateTracker* GetHUDStateTracker(); // Function KillstreakUINew.KSGameHUDNew.GetHUDStateTracker // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2138bd0
};

// Class KillstreakUINew.KSGameInfoOverlayBase
// Size: 0x540 (Inherited: 0x518)
struct UKSGameInfoOverlayBase : UKSWidget {
	char pad_518[0x28]; // 0x518(0x28)

	void ToggleTopHUDBar(bool bShow); // Function KillstreakUINew.KSGameInfoOverlayBase.ToggleTopHUDBar // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnHeaderChanged(struct FText& Header); // Function KillstreakUINew.KSGameInfoOverlayBase.OnHeaderChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandlePlayerStateReady(struct AKSPlayerState* PlayerState); // Function KillstreakUINew.KSGameInfoOverlayBase.HandlePlayerStateReady // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSGamepadPromptWidget
// Size: 0x528 (Inherited: 0x518)
struct UKSGamepadPromptWidget : UKSWidget {
	char pad_518[0x10]; // 0x518(0x10)

	void SetContext(struct FButtonPromptContext PromptContext); // Function KillstreakUINew.KSGamepadPromptWidget.SetContext // (Final|Native|Public|BlueprintCallable) // @ game+0x2139ff0
	void PushContext(struct FButtonPromptContext PromptContext); // Function KillstreakUINew.KSGamepadPromptWidget.PushContext // (Final|Native|Public|BlueprintCallable) // @ game+0x2139dc0
	bool PopContext(struct FButtonPromptContext& OutContext); // Function KillstreakUINew.KSGamepadPromptWidget.PopContext // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2139d10
	void ClearAllContext(); // Function KillstreakUINew.KSGamepadPromptWidget.ClearAllContext // (Final|Native|Public|BlueprintCallable) // @ game+0x21385f0
	void ApplyContext(struct FButtonPromptContext Context); // Function KillstreakUINew.KSGamepadPromptWidget.ApplyContext // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSHealthWidget
// Size: 0x558 (Inherited: 0x538)
struct UKSHealthWidget : UKSPawnWidget {
	float CachedHealth; // 0x538(0x04)
	float CachedArmor; // 0x53c(0x04)
	float CachedMaxHealth; // 0x540(0x04)
	float CachedOverheal; // 0x544(0x04)
	char pad_548[0x10]; // 0x548(0x10)

	void OverhealChangeFromChar(struct AKSCharacterBase* Character, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.OverhealChangeFromChar // (Final|Native|Private) // @ game+0x213e760
	void OnOverhealChanged(float OldOverheal, float NewOverheal, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.OnOverhealChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x213e5d0
	void OnHealthChanged(float OldHealth, float OldMaxHealth, float NewHealth, float NewMaxHealth, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.OnHealthChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x213e3b0
	void OnArmorChanged(float OldArmor, float NewArmor); // Function KillstreakUINew.KSHealthWidget.OnArmorChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x213e2e0
	void HealthChangeFromChar(struct AKSCharacterBase* Character, bool bAnimatedChange); // Function KillstreakUINew.KSHealthWidget.HealthChangeFromChar // (Final|Native|Private) // @ game+0x213df50
	void HandlePawnOverhealChange(struct AKSCharacterBase* Character); // Function KillstreakUINew.KSHealthWidget.HandlePawnOverhealChange // (Final|Native|Private) // @ game+0x213dde0
	void HandlePawnHealthChange(struct AKSCharacterBase* Character); // Function KillstreakUINew.KSHealthWidget.HandlePawnHealthChange // (Final|Native|Private) // @ game+0x213dd60
};

// Class KillstreakUINew.KSHudEditableWidget
// Size: 0x290 (Inherited: 0x278)
struct UKSHudEditableWidget : UBorder {
	struct FName WidgetName; // 0x278(0x08)
	bool bCanScale; // 0x280(0x01)
	bool bCanSetOpacity; // 0x281(0x01)
	bool bCanBeInvisible; // 0x282(0x01)
	char pad_283[0x5]; // 0x283(0x05)
	struct UKSHudEditor* HudEditor; // 0x288(0x08)

	void HandleLayoutSaved(); // Function KillstreakUINew.KSHudEditableWidget.HandleLayoutSaved // (Final|Native|Public) // @ game+0x213dcb0
};

// Class KillstreakUINew.KSSettingsInfoBase
// Size: 0x108 (Inherited: 0x28)
struct UKSSettingsInfoBase : UObject {
	struct FMulticastInlineDelegate OnSettingValueChanged; // 0x28(0x10)
	struct FMulticastInlineDelegate OnSettingPreviewChanged; // 0x38(0x10)
	bool bIsAutoApplied; // 0x48(0x01)
	bool bIsAutoSaved; // 0x49(0x01)
	char pad_4A[0x86]; // 0x4a(0x86)
	struct TArray<struct FText> TextOptions; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnTextOptionsChanged; // 0xe0(0x10)
	float MinValue; // 0xf0(0x04)
	float MaxValue; // 0xf4(0x04)
	float StepValue; // 0xf8(0x04)
	bool bRoundValue; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	float RoundToNearest; // 0x100(0x04)
	bool bIsPercent; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)

	void UpdateTextOptions(struct TArray<struct FText>& NewOptions); // Function KillstreakUINew.KSSettingsInfoBase.UpdateTextOptions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x216f420
	bool SetPreviewValueInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.SetPreviewValueInt // (Final|Native|Public|BlueprintCallable) // @ game+0x216f390
	bool SetPreviewValueFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.SetPreviewValueFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x216f300
	bool SetPreviewValueBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.SetPreviewValueBool // (Final|Native|Public|BlueprintCallable) // @ game+0x216f270
	bool SetDesiredValueKeyBind(struct FKSKeyBind InKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueKeyBind // (Final|Native|Public|BlueprintCallable) // @ game+0x216f120
	bool SetDesiredValueInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueInt // (Final|Native|Public|BlueprintCallable) // @ game+0x216f090
	bool SetDesiredValueFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x216f000
	bool SetDesiredValueBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.SetDesiredValueBool // (Final|Native|Public|BlueprintCallable) // @ game+0x216ef70
	bool SaveKeyBindValue(struct FKSKeyBind InKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.SaveKeyBindValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x216ee20
	bool SaveIntValue(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.SaveIntValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x216ed80
	bool SaveFloatValue(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.SaveFloatValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x216ecf0
	bool SaveBoolValue(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.SaveBoolValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x216ec50
	void Save(); // Function KillstreakUINew.KSSettingsInfoBase.Save // (Final|Native|Public|BlueprintCallable) // @ game+0x216ec30
	float RoundToNearestValueFloat(float ValueToRound); // Function KillstreakUINew.KSSettingsInfoBase.RoundToNearestValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216eba0
	void RevertSettingToDefault(); // Function KillstreakUINew.KSSettingsInfoBase.RevertSettingToDefault // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f83a90
	void Revert(); // Function KillstreakUINew.KSSettingsInfoBase.Revert // (Final|Native|Public|BlueprintCallable) // @ game+0x216eb80
	void ResetPreview(); // Function KillstreakUINew.KSSettingsInfoBase.ResetPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x216eb60
	void OnValueKeyBindSaved(struct FKSKeyBind SavedKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.OnValueKeyBindSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e9e0
	void OnValueKeyBindApplied(struct FKSKeyBind AppliedKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.OnValueKeyBindApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e860
	void OnValueIntSaved(int32_t SavedInt); // Function KillstreakUINew.KSSettingsInfoBase.OnValueIntSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e7d0
	void OnValueIntApplied(int32_t AppliedInt); // Function KillstreakUINew.KSSettingsInfoBase.OnValueIntApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e740
	void OnValueFloatSaved(float SavedFloat); // Function KillstreakUINew.KSSettingsInfoBase.OnValueFloatSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e6b0
	void OnValueFloatApplied(float AppliedFloat); // Function KillstreakUINew.KSSettingsInfoBase.OnValueFloatApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e620
	void OnValueBoolSaved(bool SavedBool); // Function KillstreakUINew.KSSettingsInfoBase.OnValueBoolSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e590
	void OnValueBoolApplied(bool AppliedBool); // Function KillstreakUINew.KSSettingsInfoBase.OnValueBoolApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e500
	bool IsValidValueKeyBind(struct FKSKeyBind InKey); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueKeyBind // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x216e0b0
	bool IsValidValueInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueInt // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x216e010
	bool IsValidValueFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueFloat // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x216df80
	bool IsValidValueBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.IsValidValueBool // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x216dee0
	bool IsDirty(); // Function KillstreakUINew.KSSettingsInfoBase.IsDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216dea0
	void InitializeValue(); // Function KillstreakUINew.KSSettingsInfoBase.InitializeValue // (Native|Event|Protected|BlueprintEvent) // @ game+0x1eabb20
	struct FKSKeyBind GetValueKeyBind(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueKeyBind // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216dd10
	int32_t GetValueInt(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216dce0
	float GetValueFloat(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216dcb0
	bool GetValueBool(); // Function KillstreakUINew.KSSettingsInfoBase.GetValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216dc80
	struct TArray<struct FText> GetTextOptions(); // Function KillstreakUINew.KSSettingsInfoBase.GetTextOptions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216db70
	struct FText GetTextOption(int32_t Index); // Function KillstreakUINew.KSSettingsInfoBase.GetTextOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d980
	float GetStep(); // Function KillstreakUINew.KSSettingsInfoBase.GetStep // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d960
	enum class EKSSettingType GetSettingType(); // Function KillstreakUINew.KSSettingsInfoBase.GetSettingType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d930
	float GetRoundToNearest(); // Function KillstreakUINew.KSSettingsInfoBase.GetRoundToNearest // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d910
	bool GetRound(); // Function KillstreakUINew.KSSettingsInfoBase.GetRound // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d8f0
	int32_t GetPreviewValueInt(); // Function KillstreakUINew.KSSettingsInfoBase.GetPreviewValueInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d8c0
	float GetPreviewValueFloat(); // Function KillstreakUINew.KSSettingsInfoBase.GetPreviewValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d880
	bool GetPreviewValueBool(); // Function KillstreakUINew.KSSettingsInfoBase.GetPreviewValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d850
	int32_t GetNumTextOptions(); // Function KillstreakUINew.KSSettingsInfoBase.GetNumTextOptions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2134880
	float GetMin(); // Function KillstreakUINew.KSSettingsInfoBase.GetMin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d830
	float GetMax(); // Function KillstreakUINew.KSSettingsInfoBase.GetMax // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d810
	struct AKSHUDCommon* GetKSHUD(); // Function KillstreakUINew.KSSettingsInfoBase.GetKSHUD // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d7b0
	bool GetIsPercent(); // Function KillstreakUINew.KSSettingsInfoBase.GetIsPercent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d790
	struct FKSKeyBind GetDirtyValueKeyBind(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueKeyBind // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d5f0
	int32_t GetDirtyValueInt(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d5c0
	float GetDirtyValueFloat(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d580
	bool GetDirtyValueBool(); // Function KillstreakUINew.KSSettingsInfoBase.GetDirtyValueBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x216d550
	struct FKSKeyBind FixupInvalidKeyBind(struct FKSKeyBind InKey); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidKeyBind // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x216d3a0
	int32_t FixupInvalidInt(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidInt // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x216d300
	float FixupInvalidFloat(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidFloat // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x216d270
	bool FixupInvalidBool(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.FixupInvalidBool // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x216d1d0
	bool CanRevert(); // Function KillstreakUINew.KSSettingsInfoBase.CanRevert // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d190
	bool ApplyPreviewIntValue(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreviewIntValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x216d0f0
	bool ApplyPreviewFloatValue(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreviewFloatValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x216d060
	bool ApplyPreviewBoolValue(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreviewBoolValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x216cfc0
	void ApplyPreview(); // Function KillstreakUINew.KSSettingsInfoBase.ApplyPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x216cfa0
	bool ApplyKeyBindValue(struct FKSKeyBind InKeyBind); // Function KillstreakUINew.KSSettingsInfoBase.ApplyKeyBindValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x216ce50
	bool ApplyIntValue(int32_t inInt); // Function KillstreakUINew.KSSettingsInfoBase.ApplyIntValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xb4f680
	bool ApplyFloatValue(float InFloat); // Function KillstreakUINew.KSSettingsInfoBase.ApplyFloatValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x216cdc0
	bool ApplyBoolValue(bool InBool); // Function KillstreakUINew.KSSettingsInfoBase.ApplyBoolValue // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x216cd20
	void Apply(); // Function KillstreakUINew.KSSettingsInfoBase.Apply // (Final|Native|Public|BlueprintCallable) // @ game+0x216cd00
};

// Class KillstreakUINew.KSHudEditorSettingsInfo
// Size: 0x128 (Inherited: 0x108)
struct UKSHudEditorSettingsInfo : UKSSettingsInfoBase {
	struct FVector2D InRange; // 0x108(0x08)
	struct FVector2D OutRange; // 0x110(0x08)
	struct FName PropertyName; // 0x118(0x08)
	struct UKSHudEditableWidget* ActiveWidget; // 0x120(0x08)

	void SetStepValue(float InStepValue); // Function KillstreakUINew.KSHudEditorSettingsInfo.SetStepValue // (Final|Native|Public) // @ game+0x213ee50
	void SetRoundToNearest(float InRoundToNearest); // Function KillstreakUINew.KSHudEditorSettingsInfo.SetRoundToNearest // (Final|Native|Public) // @ game+0x213ed50
	void SetRound(bool bInRoundValue); // Function KillstreakUINew.KSHudEditorSettingsInfo.SetRound // (Final|Native|Public|BlueprintCallable) // @ game+0x213ecd0
	void SetMinValue(float InMinValue); // Function KillstreakUINew.KSHudEditorSettingsInfo.SetMinValue // (Final|Native|Public|BlueprintCallable) // @ game+0x213ebd0
	void SetMaxValue(float InMaxValue); // Function KillstreakUINew.KSHudEditorSettingsInfo.SetMaxValue // (Final|Native|Public|BlueprintCallable) // @ game+0x213eb50
	void SetIsPercent(bool bInIsPercent); // Function KillstreakUINew.KSHudEditorSettingsInfo.SetIsPercent // (Final|Native|Public|BlueprintCallable) // @ game+0x213ead0
	void AddTextOption(struct FText InTextOption); // Function KillstreakUINew.KSHudEditorSettingsInfo.AddTextOption // (Final|Native|Public|BlueprintCallable) // @ game+0x213d190
};

// Class KillstreakUINew.KSEditorPropertiesPanel
// Size: 0x530 (Inherited: 0x518)
struct UKSEditorPropertiesPanel : UKSWidget {
	struct TArray<struct UKSHudEditorSettingsInfo*> SettingsInfoList; // 0x518(0x10)
	struct UKSHudEditableWidget* SelectedHudEditableWidget; // 0x528(0x08)

	void SetSelectedHudEditableWidget(struct UKSHudEditableWidget* NewWidget); // Function KillstreakUINew.KSEditorPropertiesPanel.SetSelectedHudEditableWidget // (Final|Native|Public) // @ game+0x213edd0
	void SetOpacityEditable(struct UKSHudEditableWidget* HudEditableWidget, bool bIsEditable, float NewOpacity); // Function KillstreakUINew.KSEditorPropertiesPanel.SetOpacityEditable // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetButtonVisibilityEditable(struct UKSHudEditableWidget* HudEditableWidget, bool bIsEditable, bool bNewVisibility); // Function KillstreakUINew.KSEditorPropertiesPanel.SetButtonVisibilityEditable // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetButtonScaleEditable(struct UKSHudEditableWidget* HudEditableWidget, bool bIsEditable, float NewScale); // Function KillstreakUINew.KSEditorPropertiesPanel.SetButtonScaleEditable // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void CreateWidgetSettingsInfoForSettingsWidget(struct UKSSettingsWidget* InSettingsWidget, struct FName InPropertyName, struct FVector2D NewInRange, struct FVector2D NewOutRange, bool bInIsPercent, float InMinValue, float InMaxValue, float InStepValue, float InRoundToNearest, struct TArray<struct FText>& InTextOptions); // Function KillstreakUINew.KSEditorPropertiesPanel.CreateWidgetSettingsInfoForSettingsWidget // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x213d310
};

// Class KillstreakUINew.KSHudEditor
// Size: 0x530 (Inherited: 0x518)
struct UKSHudEditor : UKSWidget {
	struct UKSHudEditableWidget* CurrentHighlightedWidget; // 0x518(0x08)
	struct UKSEditorPropertiesPanel* EditorPropertiesPanel; // 0x520(0x08)
	struct FName DefaultHighlightedWidgetName; // 0x528(0x08)

	bool TryToExit(); // Function KillstreakUINew.KSHudEditor.TryToExit // (Final|Native|Public|BlueprintCallable) // @ game+0x213f1a0
	void SaveLayout(); // Function KillstreakUINew.KSHudEditor.SaveLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x213e970
	void RevertToSavedLayout(); // Function KillstreakUINew.KSHudEditor.RevertToSavedLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x213e950
	void RevertToDefaultLayout(); // Function KillstreakUINew.KSHudEditor.RevertToDefaultLayout // (Final|Native|Private|BlueprintCallable) // @ game+0x213e930
};

// Class KillstreakUINew.KSHudEditorSettings
// Size: 0x50 (Inherited: 0x28)
struct UKSHudEditorSettings : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	bool bIsLayoutDirty; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FHudEditableData> HudEditableData; // 0x40(0x10)

	void UpdateHudEditablePosition(struct UKSHudEditableWidget* InWidget, struct FVector2D InAbsolutePosition); // Function KillstreakUINew.KSHudEditorSettings.UpdateHudEditablePosition // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x213f1f0
	void SaveLayout(); // Function KillstreakUINew.KSHudEditorSettings.SaveLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x213e990
	void OnSettingsSaved__DelegateSignature(); // DelegateFunction KillstreakUINew.KSHudEditorSettings.OnSettingsSaved__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24d5b40
	struct UKSHudEditorSettings* Get(); // Function KillstreakUINew.KSHudEditorSettings.Get // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x213d600
};

// Class KillstreakUINew.KSHUDStateTracker
// Size: 0x50 (Inherited: 0x28)
struct UKSHUDStateTracker : UObject {
	struct FMulticastInlineDelegate OnHUDMatchPhaseChanged; // 0x28(0x10)
	float PhaseTime; // 0x38(0x04)
	struct FMatchPhase TrackedCurrentMatchPhase; // 0x3c(0x0c)
	char pad_48[0x8]; // 0x48(0x08)

	void PollMatchPhase(); // Function KillstreakUINew.KSHUDStateTracker.PollMatchPhase // (Final|Native|Protected) // @ game+0x213e830
	void HandleUpdatedMatchPhase(struct FMatchPhase NewPhase, struct FMatchPhase PreviousPhase); // Function KillstreakUINew.KSHUDStateTracker.HandleUpdatedMatchPhase // (Final|Native|Protected) // @ game+0x213de60
	void HandleGameStateBeginPlay(struct AKSGameState* GameState); // Function KillstreakUINew.KSHUDStateTracker.HandleGameStateBeginPlay // (Final|Native|Protected) // @ game+0x213dc30
};

// Class KillstreakUINew.KSInfoActorWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSInfoActorWidgetInterface : UInterface {

	bool SetInfoActor(struct AKSWidgetInfoActor* InfoActor); // Function KillstreakUINew.KSInfoActorWidgetInterface.SetInfoActor // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x213ea30
};

// Class KillstreakUINew.KSInputManager
// Size: 0xd8 (Inherited: 0xd8)
struct UKSInputManager : UPUMG_InputManager {
};

// Class KillstreakUINew.KSInspectPlayerInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSInspectPlayerInterface : UInterface {

	void UnbindEventFromInspectPlayerChanged(struct FDelegate& Callback); // Function KillstreakUINew.KSInspectPlayerInterface.UnbindEventFromInspectPlayerChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct AKSPlayerState* GetInspectPlayerState(); // Function KillstreakUINew.KSInspectPlayerInterface.GetInspectPlayerState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BindEventToInspectPlayerChanged(struct FDelegate& Callback); // Function KillstreakUINew.KSInspectPlayerInterface.BindEventToInspectPlayerChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSJobSelectorWidget
// Size: 0x540 (Inherited: 0x518)
struct UKSJobSelectorWidget : UKSWidget {
	bool bAutoBindJobSelector; // 0x518(0x01)
	bool bWaitForPlayerToBecomeRelevant; // 0x519(0x01)
	bool bBindToTasksChangedEvent; // 0x51a(0x01)
	bool bBindToPendingTasksChangedEvent; // 0x51b(0x01)
	bool bBindToPersonalTaskChangedEvent; // 0x51c(0x01)
	bool bBindToChoicesChangedEvent; // 0x51d(0x01)
	bool bBindToTaskCompletedEvent; // 0x51e(0x01)
	bool bBindToAllPersonalTasksCompletedEvent; // 0x51f(0x01)
	bool bBindToEndJobSelectionEvent; // 0x520(0x01)
	char pad_521[0x3]; // 0x521(0x03)
	struct TWeakObjectPtr<struct AKSJobSelector> JobSelector; // 0x524(0x08)
	char pad_52C[0x14]; // 0x52c(0x14)

	void TasksChanged(); // Function KillstreakUINew.KSJobSelectorWidget.TasksChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x2138650
	void TaskCompleted(struct FJobSelectionTask& CompletedTask); // Function KillstreakUINew.KSJobSelectorWidget.TaskCompleted // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2143470
	void SetJobSelector(struct AKSJobSelector* InNewSelector); // Function KillstreakUINew.KSJobSelectorWidget.SetJobSelector // (Final|Native|Public|BlueprintCallable) // @ game+0x2143110
	void SetBindToTasksChanged(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToTasksChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0x2143000
	void SetBindToTaskCompleted(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToTaskCompleted // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142f70
	void SetBindToPersonalTaskChanged(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToPersonalTaskChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142ee0
	void SetBindToPendingTasksChanged(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToPendingTasksChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142e50
	void SetBindToEndJobSelection(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToEndJobSelection // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142dc0
	void SetBindToChoicesChanged(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToChoicesChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142d30
	void SetBindToAllPersonalTasksCompleted(bool bEnable); // Function KillstreakUINew.KSJobSelectorWidget.SetBindToAllPersonalTasksCompleted // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142ca0
	void PreClearJobSelector(); // Function KillstreakUINew.KSJobSelectorWidget.PreClearJobSelector // (Native|Event|Protected|BlueprintEvent) // @ game+0x2142ab0
	void PostSetJobSelector(); // Function KillstreakUINew.KSJobSelectorWidget.PostSetJobSelector // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851ec0
	void PersonalTaskChanged(); // Function KillstreakUINew.KSJobSelectorWidget.PersonalTaskChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c010
	void PendingTasksChanged(); // Function KillstreakUINew.KSJobSelectorWidget.PendingTasksChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x2139670
	void OnBoundJobSelectorDestroyed(struct AActor* DestroyedActor); // Function KillstreakUINew.KSJobSelectorWidget.OnBoundJobSelectorDestroyed // (Final|Native|Protected) // @ game+0x21428d0
	void JobSelectorAddedToOwner(struct AKSJobSelector* NewSelector); // Function KillstreakUINew.KSJobSelectorWidget.JobSelectorAddedToOwner // (Final|Native|Private) // @ game+0x2142770
	struct AKSJobSelector* GetJobSelector(); // Function KillstreakUINew.KSJobSelectorWidget.GetJobSelector // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141e20
	void EndJobSelection(); // Function KillstreakUINew.KSJobSelectorWidget.EndJobSelection // (Native|Event|Protected|BlueprintEvent) // @ game+0x212a310
	void ChoicesChanged(struct TArray<struct UKSJobItem*>& RemovedChoices, struct TArray<struct UKSJobItem*>& AddedOrUpdatedChoices); // Function KillstreakUINew.KSJobSelectorWidget.ChoicesChanged // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2141740
	void AllPersonalTasksCompleted(); // Function KillstreakUINew.KSJobSelectorWidget.AllPersonalTasksCompleted // (Native|Event|Protected|BlueprintEvent) // @ game+0x21416e0
};

// Class KillstreakUINew.KSJobSelectBanWidget
// Size: 0x550 (Inherited: 0x540)
struct UKSJobSelectBanWidget : UKSJobSelectorWidget {
	struct TArray<struct FJobSelectionTask> CachedBanTasks; // 0x540(0x10)

	void BansChanged(); // Function KillstreakUINew.KSJobSelectBanWidget.BansChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b40
};

// Class KillstreakUINew.KSJobSelectCaptainStatusWidget
// Size: 0x5b0 (Inherited: 0x540)
struct UKSJobSelectCaptainStatusWidget : UKSJobSelectorWidget {
	struct FJobSelectionTask CachedCaptainTask; // 0x540(0x48)
	struct UKSPersistentPlayerData* CachedCaptainPlayerData; // 0x588(0x08)
	struct FKSPersistentPlayerId CachedCaptainId; // 0x590(0x10)
	char pad_5A0[0x10]; // 0x5a0(0x10)

	void CaptainTaskChanged(); // Function KillstreakUINew.KSJobSelectCaptainStatusWidget.CaptainTaskChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b40
};

// Class KillstreakUINew.KSJobSelectChoiceGridWidget
// Size: 0x5b0 (Inherited: 0x540)
struct UKSJobSelectChoiceGridWidget : UKSJobSelectorWidget {
	struct UGridPanel* GridPanel; // 0x540(0x08)
	struct UKSJobSelectionChoiceWidget* ChoiceWidgetClass; // 0x548(0x08)
	struct UUserWidget* PaddingWidgetClass; // 0x550(0x08)
	int32_t GridWidth; // 0x558(0x04)
	char pad_55C[0x4]; // 0x55c(0x04)
	struct TArray<struct UKSJobSelectionChoiceWidget*> ActiveChoiceWidgets; // 0x560(0x10)
	struct TArray<struct UUserWidget*> ActivePaddingWidgets; // 0x570(0x10)
	struct FMulticastInlineDelegate OnChoiceWidgetHovered; // 0x580(0x10)
	struct FMulticastInlineDelegate OnChoiceWidgetUnhovered; // 0x590(0x10)
	struct FMulticastInlineDelegate OnChoiceGridRebuilt; // 0x5a0(0x10)

	bool SortActiveChoiceWidgets(struct UKSJobSelectionChoiceWidget* LHS, struct UKSJobSelectionChoiceWidget* RHS); // Function KillstreakUINew.KSJobSelectChoiceGridWidget.SortActiveChoiceWidgets // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x213f0d0
	void SetGridPanel(struct UGridPanel* InGridPanel); // Function KillstreakUINew.KSJobSelectChoiceGridWidget.SetGridPanel // (Final|Native|Public|BlueprintCallable) // @ game+0x213e9b0
};

// Class KillstreakUINew.KSJobSelectionChoiceWidget
// Size: 0x580 (Inherited: 0x540)
struct UKSJobSelectionChoiceWidget : UKSJobSelectorWidget {
	char pad_540[0x20]; // 0x540(0x20)
	struct TArray<struct UButton*> HitTargets; // 0x560(0x10)
	struct UKSJobItem* LocalJob; // 0x570(0x08)
	char pad_578[0x8]; // 0x578(0x08)

	void SetJob(struct UKSJobItem* Job); // Function KillstreakUINew.KSJobSelectionChoiceWidget.SetJob // (Final|Native|Public|BlueprintCallable) // @ game+0x2143090
	enum class ECanCompleteTaskResult RequestSelect(); // Function KillstreakUINew.KSJobSelectionChoiceWidget.RequestSelect // (Final|Native|Public|BlueprintCallable) // @ game+0x2142b70
	void RemoveCombinedHitTarget(struct UButton* InButton); // Function KillstreakUINew.KSJobSelectionChoiceWidget.RemoveCombinedHitTarget // (Final|Native|Protected|BlueprintCallable) // @ game+0x2142af0
	struct UKSJobItem* GetJob(); // Function KillstreakUINew.KSJobSelectionChoiceWidget.GetJob // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141c40
	struct FJobSelectionChoice GetChoiceData(); // Function KillstreakUINew.KSJobSelectionChoiceWidget.GetChoiceData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21419d0
	void CombinedUnhover(); // Function KillstreakUINew.KSJobSelectionChoiceWidget.CombinedUnhover // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b60
	void CombinedHover(); // Function KillstreakUINew.KSJobSelectionChoiceWidget.CombinedHover // (Native|Event|Protected|BlueprintEvent) // @ game+0x1f80d40
	void ChoiceOrJobChanged(); // Function KillstreakUINew.KSJobSelectionChoiceWidget.ChoiceOrJobChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b40
	void AddCombinedHitTarget(struct UButton* InButton); // Function KillstreakUINew.KSJobSelectionChoiceWidget.AddCombinedHitTarget // (Final|Native|Protected|BlueprintCallable) // @ game+0x2141660
};

// Class KillstreakUINew.KSJobSelectionPlayerStatusWidget
// Size: 0x5b0 (Inherited: 0x540)
struct UKSJobSelectionPlayerStatusWidget : UKSJobSelectorWidget {
	struct TArray<struct FJobSelectionTask> CachedCompletedTasks; // 0x540(0x10)
	struct FJobSelectionTask CachedActiveTask; // 0x550(0x48)
	bool bCachedActiveTaskPendingComplete; // 0x598(0x01)
	char pad_599[0x7]; // 0x599(0x07)
	struct UKSPersistentPlayerData* PlayerData; // 0x5a0(0x08)
	char pad_5A8[0x8]; // 0x5a8(0x08)

	void SetPlayerByPlayerState(struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.SetPlayerByPlayerState // (Final|Native|Public|BlueprintCallable) // @ game+0x21432b0
	void SetPlayerByPersistentData(struct UKSPersistentPlayerData* InPlayerData); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.SetPlayerByPersistentData // (Final|Native|Public|BlueprintCallable) // @ game+0x2143230
	void SetPlayerById(struct FKSPersistentPlayerId& InPlayerId); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.SetPlayerById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2143190
	void PreClearPlayerData(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.PreClearPlayerData // (Native|Event|Protected|BlueprintEvent) // @ game+0x2142ad0
	void PostSetPlayerData(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.PostSetPlayerData // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851600
	void PlayerTasksChanged(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.PlayerTasksChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1f80d40
	bool HasLockedInAJob(struct UKSJobItem*& OutJob); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.HasLockedInAJob // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2142640
	bool HasActiveTask(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.HasActiveTask // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2142610
	struct FText GetSelectionStatusText(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.GetSelectionStatusText // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x21420a0
	struct UKSJobItem* GetSelectionStatusJob(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.GetSelectionStatusJob // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2142070
	struct FKSPersistentPlayerId GetPlayerId(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.GetPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141fd0
	struct UKSPersistentPlayerData* GetPersistentPlayerData(); // Function KillstreakUINew.KSJobSelectionPlayerStatusWidget.GetPersistentPlayerData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141fa0
};

// Class KillstreakUINew.KSJobSelectionWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSJobSelectionWidget : UKSWidget {

	struct TArray<struct TSoftObjectPtr<UKSJobItem>> GetJobItems(); // Function KillstreakUINew.KSJobSelectionWidget.GetJobItems // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2141c60
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSJobSelectionWidget.GetItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21339a0
	struct UPUMG_StoreItem* GetAdOffer(); // Function KillstreakUINew.KSJobSelectionWidget.GetAdOffer // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21418d0
};

// Class KillstreakUINew.KSJobSelectOverallStatusWidget
// Size: 0x5b8 (Inherited: 0x540)
struct UKSJobSelectOverallStatusWidget : UKSJobSelectorWidget {
	struct FText CachedDisplayText; // 0x540(0x18)
	struct FPGame_ReplicatedTimerId CachedDisplayTimerId; // 0x558(0x01)
	enum class EPGame_ReplicateTimerState CachedTimerState; // 0x559(0x01)
	char pad_55A[0x6]; // 0x55a(0x06)
	struct FJobSelectionTask CachedPrimaryTask; // 0x560(0x48)
	float TimerUpdatePeriod; // 0x5a8(0x04)
	char pad_5AC[0xc]; // 0x5ac(0x0c)

	struct FText GetCountdownFormattedText(float SecondsRemaining, bool bShowHours, bool bShowTenthsOfSecond, bool bAllowNegative); // Function KillstreakUINew.KSJobSelectOverallStatusWidget.GetCountdownFormattedText // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2141a10
	void DisplayTimerChanged(); // Function KillstreakUINew.KSJobSelectOverallStatusWidget.DisplayTimerChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b40
	void DisplayTextChanged(); // Function KillstreakUINew.KSJobSelectOverallStatusWidget.DisplayTextChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1851b60
};

// Class KillstreakUINew.KSKillCardWidget
// Size: 0x520 (Inherited: 0x518)
struct UKSKillCardWidget : UKSWidget {
	float DisplayDuration; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)

	void ShowPlayerAndMessage(struct AKSPlayerState* PlayerState, struct FText& Message); // Function KillstreakUINew.KSKillCardWidget.ShowPlayerAndMessage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ClearMessage(bool UseAnimations); // Function KillstreakUINew.KSKillCardWidget.ClearMessage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSLobbyHUDNew
// Size: 0x6b0 (Inherited: 0x618)
struct AKSLobbyHUDNew : AKSHUDCommon {
	char pad_618[0x10]; // 0x618(0x10)
	struct FMulticastInlineDelegate OnMinuteTimerUpdate; // 0x628(0x10)
	char pad_638[0x10]; // 0x638(0x10)
	struct UKSQueueDataFactory* QueueDataFactory; // 0x648(0x08)
	struct UKSFriendDataFactory* FriendDataFactory; // 0x650(0x08)
	struct UKSPlayerQueryDataFactory* PlayerQueryDataFactory; // 0x658(0x08)
	struct UKSEMODataFactory* EMODataFactory; // 0x660(0x08)
	struct UKSPlayerWhoDataFactory* PlayerWhoDataFactory; // 0x668(0x08)
	struct TWeakObjectPtr<struct UKSMediaPlayerWidget> CurrentMediaPlayerWidget; // 0x670(0x08)
	char pad_678[0x8]; // 0x678(0x08)
	struct FMulticastInlineDelegate OnTriggerBlockerChange; // 0x680(0x10)
	struct FMulticastInlineDelegate LobbyWidgetReady; // 0x690(0x10)
	char pad_6A0[0x4]; // 0x6a0(0x04)
	float LoadingScreenFadeInDelay; // 0x6a4(0x04)
	float LoadingScreenFadeInDuration; // 0x6a8(0x04)
	char pad_6AC[0x4]; // 0x6ac(0x04)

	void TransitionCamera(struct FName CameraTag, float BlendTime); // Function KillstreakUINew.KSLobbyHUDNew.TransitionCamera // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x2143a10
	void ToggleDisablePartyLobbyCharacters(bool Disable); // Function KillstreakUINew.KSLobbyHUDNew.ToggleDisablePartyLobbyCharacters // (Final|Native|Private|BlueprintCallable) // @ game+0x2143980
	void TestSetStoreRotationOverride(struct FString DateTime); // Function KillstreakUINew.KSLobbyHUDNew.TestSetStoreRotationOverride // (Final|Exec|Native|Protected) // @ game+0x21438a0
	void TestPostMatchLobby(int32_t PlayerXp, int32_t RankedXp, int32_t RogueXp, int32_t ReputationEarned, int32_t PlacementMatchNum, int32_t BattlePassXp, int32_t WeaponMasteryCount, int32_t WeaponMasteryLevels, bool CategoryMasteryCanLevel, int32_t MilestonesPerWeapon); // Function KillstreakUINew.KSLobbyHUDNew.TestPostMatchLobby // (Final|Exec|Native|Protected) // @ game+0x21435f0
	void TestEventGrandPrizeAcquisition(); // Function KillstreakUINew.KSLobbyHUDNew.TestEventGrandPrizeAcquisition // (Final|Exec|Native|Protected) // @ game+0x21435d0
	void TestBattlePassAcquisition(int32_t StartTier, int32_t EndTier); // Function KillstreakUINew.KSLobbyHUDNew.TestBattlePassAcquisition // (Final|Exec|Native|Protected) // @ game+0x2143510
	void ShowPopupConfirmation(struct FText Message, enum class ESocialMessageType MessageType); // Function KillstreakUINew.KSLobbyHUDNew.ShowPopupConfirmation // (Final|Native|Public|BlueprintCallable) // @ game+0x2143350
	void ResetLobbyCharactersByIndex(struct TArray<enum class ELobbyCharacterIndex> IndicesToReset); // Function KillstreakUINew.KSLobbyHUDNew.ResetLobbyCharactersByIndex // (Final|Native|Protected) // @ game+0x2142bc0
	void ResetLobbyCharacters(); // Function KillstreakUINew.KSLobbyHUDNew.ResetLobbyCharacters // (Final|Native|Protected) // @ game+0x2142ba0
	void OnStoreVendorsLoaded(int32_t GroupId, struct TArray<int32_t>& VendorIds); // Function KillstreakUINew.KSLobbyHUDNew.OnStoreVendorsLoaded // (Final|Native|Protected|HasOutParms) // @ game+0x21429d0
	void OnNotEnoughCurrency(struct UPUMG_StorePurchaseRequest* PurchaseRequest); // Function KillstreakUINew.KSLobbyHUDNew.OnNotEnoughCurrency // (Final|Native|Protected) // @ game+0x2142950
	void NotifyViewStateChange(struct FName& NewRoute, struct FName& PreviousRoute); // Function KillstreakUINew.KSLobbyHUDNew.NotifyViewStateChange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x21427f0
	bool IsPlayerMuted(struct UPUMG_PlayerInfo* PlayerData); // Function KillstreakUINew.KSLobbyHUDNew.IsPlayerMuted // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21426e0
	void HandleSpecificPartyIdDataUpdated(int64_t PlayerId); // Function KillstreakUINew.KSLobbyHUDNew.HandleSpecificPartyIdDataUpdated // (Final|Native|Protected) // @ game+0x2142590
	void HandleSpecificPartyDataUpdated(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSLobbyHUDNew.HandleSpecificPartyDataUpdated // (Final|Native|Protected) // @ game+0x2142460
	void HandleSpecificPartyDataAdded(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSLobbyHUDNew.HandleSpecificPartyDataAdded // (Final|Native|Protected) // @ game+0x2142460
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData& PartyMember, int32_t MemberIndex); // Function KillstreakUINew.KSLobbyHUDNew.HandlePartyMemberDataUpdated // (Final|Native|Protected|HasOutParms) // @ game+0x2142330
	void HandlePartyEmoteMessageReceived(struct UPUMG_PlayerInfo* Sender, struct TSoftObjectPtr<UKSEmote> SoftEmotePtr); // Function KillstreakUINew.KSLobbyHUDNew.HandlePartyEmoteMessageReceived // (Final|Native|Protected) // @ game+0x2142220
	void HandlePartyDataUpdated(); // Function KillstreakUINew.KSLobbyHUDNew.HandlePartyDataUpdated // (Final|Native|Protected) // @ game+0x2142200
	void HandleMatchStatusUpdated(enum class EPUMG_MatchStatus MatchStatus); // Function KillstreakUINew.KSLobbyHUDNew.HandleMatchStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleLoginUserChange(); // Function KillstreakUINew.KSLobbyHUDNew.HandleLoginUserChange // (Final|Native|Protected) // @ game+0xa6a770
	void HandleLoginStateChange(enum class EPUMG_LoginState LoginState); // Function KillstreakUINew.KSLobbyHUDNew.HandleLoginStateChange // (Final|Native|Protected) // @ game+0x2142180
	void HandleDenyPartyInvitation(); // Function KillstreakUINew.KSLobbyHUDNew.HandleDenyPartyInvitation // (Final|Native|Public) // @ game+0x2142160
	void HandleAcceptPartyInvitation(); // Function KillstreakUINew.KSLobbyHUDNew.HandleAcceptPartyInvitation // (Final|Native|Public) // @ game+0x2142140
	struct UKSPlayerWhoDataFactory* GetPlayerWhoDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetPlayerWhoDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2142030
	struct UKSPlayerQueryDataFactory* GetPlayerQueryDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetPlayerQueryDataFactory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2142010
	struct UKSLobbyWidget* GetLobbyWidget(); // Function KillstreakUINew.KSLobbyHUDNew.GetLobbyWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2141f70
	bool GetLobbyCharacterByPosition(enum class ELobbyCharacterIndex CharacterIndex, struct AKSLobbyCharacter*& LobbyCharacter); // Function KillstreakUINew.KSLobbyHUDNew.GetLobbyCharacterByPosition // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2141ea0
	struct UKSQueueDataFactory* GetKSQueueDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetKSQueueDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1fdca10
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetJsonDataFactory // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141e60
	bool GetJobSelectPreviewActorByPosition(enum class ELobbyCharacterIndex CharacterIndex, struct AKSJobSelectPreviewActor_Lobby*& PreviewActor); // Function KillstreakUINew.KSLobbyHUDNew.GetJobSelectPreviewActorByPosition // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2141d50
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetFriendDataFactory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141c00
	struct UKSEMODataFactory* GetEMODataFactory(); // Function KillstreakUINew.KSLobbyHUDNew.GetEMODataFactory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2141be0
	struct UKSItem* GetDefaultPlayerAccountItem(enum class EPlayerAccountSlot ItemSlot); // Function KillstreakUINew.KSLobbyHUDNew.GetDefaultPlayerAccountItem // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	bool GetCharacterIndexFromPartyIndex(int32_t PartyMemberIndex, enum class ELobbyCharacterIndex& OutCharIndex); // Function KillstreakUINew.KSLobbyHUDNew.GetCharacterIndexFromPartyIndex // (Final|Native|Protected|HasOutParms) // @ game+0x2141900
	void ForceMinuteTimerUpdate(); // Function KillstreakUINew.KSLobbyHUDNew.ForceMinuteTimerUpdate // (Final|Native|Protected|BlueprintCallable) // @ game+0x21418a0
	void ForceEulaAccept(); // Function KillstreakUINew.KSLobbyHUDNew.ForceEulaAccept // (Final|Native|Public|BlueprintCallable) // @ game+0x2141880
	void CreateInitialPlayerLoadout(); // Function KillstreakUINew.KSLobbyHUDNew.CreateInitialPlayerLoadout // (Final|Native|Protected) // @ game+0x2141860
	void CheckForVoucherRedemption(); // Function KillstreakUINew.KSLobbyHUDNew.CheckForVoucherRedemption // (Final|Native|Protected|BlueprintCallable) // @ game+0x2141720
	void CheckForExistingPenaltyTime(); // Function KillstreakUINew.KSLobbyHUDNew.CheckForExistingPenaltyTime // (Final|Native|Protected|BlueprintCallable) // @ game+0x2141700
};

// Class KillstreakUINew.KSLobbyNameplateWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSLobbyNameplateWidget : UKSWidget {

	void SetupRankedManager(); // Function KillstreakUINew.KSLobbyNameplateWidget.SetupRankedManager // (Final|Native|Public|BlueprintCallable) // @ game+0x2143330
	void RefreshRankedData(); // Function KillstreakUINew.KSLobbyNameplateWidget.RefreshRankedData // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSLobbyWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSLobbyWidget : UKSWidget {
};

// Class KillstreakUINew.KSLoginExistingBase
// Size: 0x518 (Inherited: 0x518)
struct UKSLoginExistingBase : UKSWidget {
};

// Class KillstreakUINew.KSLoginInventoryCheckViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSLoginInventoryCheckViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSLoginInventoryCheck
// Size: 0x528 (Inherited: 0x518)
struct UKSLoginInventoryCheck : UKSWidget {
	char pad_518[0x10]; // 0x518(0x10)

	void CancelLogin(); // Function KillstreakUINew.KSLoginInventoryCheck.CancelLogin // (Final|Native|Public|BlueprintCallable) // @ game+0x2146910
};

// Class KillstreakUINew.KSLoginProcessRewardsViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSLoginProcessRewardsViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSLoginProcessRewards
// Size: 0x518 (Inherited: 0x518)
struct UKSLoginProcessRewards : UKSWidget {

	void ProcessAccountRewards(); // Function KillstreakUINew.KSLoginProcessRewards.ProcessAccountRewards // (Final|Native|Protected|BlueprintCallable) // @ game+0x2147c90
};

// Class KillstreakUINew.KSTabValidator
// Size: 0x28 (Inherited: 0x28)
struct UKSTabValidator : UObject {

	bool IsValidTab(); // Function KillstreakUINew.KSTabValidator.IsValidTab // (Native|Public) // @ game+0x195e830
};

// Class KillstreakUINew.KSLoginRewardsTabValidator
// Size: 0x28 (Inherited: 0x28)
struct UKSLoginRewardsTabValidator : UKSTabValidator {
};

// Class KillstreakUINew.KSLoginRewardsModalViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSLoginRewardsModalViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSLoginRewardsModal
// Size: 0x540 (Inherited: 0x518)
struct UKSLoginRewardsModal : UKSWidget {
	struct FMulticastInlineDelegate OnLoginRewardsReady; // 0x518(0x10)
	struct TArray<struct FLoginRewardItem> LoginRewardItems; // 0x528(0x10)
	int32_t nDefaultItemsPerRow; // 0x538(0x04)
	char pad_53C[0x4]; // 0x53c(0x04)

	void UIX_AttemptClaimReward(); // Function KillstreakUINew.KSLoginRewardsModal.UIX_AttemptClaimReward // (Final|Native|Public|BlueprintCallable) // @ game+0x21482c0
	void HandlePlayerChallengesReady(); // Function KillstreakUINew.KSLoginRewardsModal.HandlePlayerChallengesReady // (Final|Native|Protected) // @ game+0x2147630
	struct TArray<struct FLoginRewardItem> GrabLoginRewardsFromActivityInstance(struct UKSActivityInstance* ActivityInstance); // Function KillstreakUINew.KSLoginRewardsModal.GrabLoginRewardsFromActivityInstance // (Final|Native|Public|BlueprintCallable) // @ game+0x2147200
	int32_t GetNumberOfItemsToDisplay(); // Function KillstreakUINew.KSLoginRewardsModal.GetNumberOfItemsToDisplay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2146fb0
	int32_t GetLoginRewardProgressCount(); // Function KillstreakUINew.KSLoginRewardsModal.GetLoginRewardProgressCount // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2146f50
	struct TArray<struct FLoginRewardItem> GetLoginRewardItems(); // Function KillstreakUINew.KSLoginRewardsModal.GetLoginRewardItems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2146e90
	struct FText GetLoginEventTimeRemaining(); // Function KillstreakUINew.KSLoginRewardsModal.GetLoginEventTimeRemaining // (Final|Native|Public|BlueprintCallable) // @ game+0x2146df0
};

// Class KillstreakUINew.KSLootSiteIconWidget
// Size: 0x320 (Inherited: 0x318)
struct UKSLootSiteIconWidget : UKSMapIconWidgetBase {
	struct AKSLootSiteBase* MarkedLootSite; // 0x318(0x08)
};

// Class KillstreakUINew.KSLootSiteMarkerWidget
// Size: 0x338 (Inherited: 0x318)
struct UKSLootSiteMarkerWidget : UKSMapIconWidgetBase {
	struct AKSLootSiteBase* MarkedLootSite; // 0x318(0x08)
	float MaxDisplayDistance; // 0x320(0x04)
	bool bViewedPawnHasEndedFreeFall; // 0x324(0x01)
	char pad_325[0x3]; // 0x325(0x03)
	struct TArray<enum class ELootSiteRarity> TagsToHide; // 0x328(0x10)
};

// Class KillstreakUINew.KSLowAmmoAlertWidget
// Size: 0x600 (Inherited: 0x5e0)
struct UKSLowAmmoAlertWidget : UKSActiveWeaponComponentWidget {
	float LowAmmoThreshold; // 0x5e0(0x04)
	enum class ELowAmmoState CachedLowAmmoState; // 0x5e4(0x01)
	char pad_5E5[0x3]; // 0x5e5(0x03)
	struct FMulticastInlineDelegate OnAmmoStateChangedDel; // 0x5e8(0x10)
	char pad_5F8[0x8]; // 0x5f8(0x08)

	enum class ELowAmmoState GetAmmoState(); // Function KillstreakUINew.KSLowAmmoAlertWidget.GetAmmoState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2146ac0
	enum class ELowAmmoState CalcAmmoState(); // Function KillstreakUINew.KSLowAmmoAlertWidget.CalcAmmoState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21468e0
	void AmmoStateChanged(); // Function KillstreakUINew.KSLowAmmoAlertWidget.AmmoStateChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x1f80d40
};

// Class KillstreakUINew.KSMapIconWidgetPool
// Size: 0x48 (Inherited: 0x28)
struct UKSMapIconWidgetPool : UObject {
	struct FString PoolType; // 0x28(0x10)
	struct TArray<struct UKSMapIconWidgetBase*> MapIconWidgets; // 0x38(0x10)

	struct UKSMapIconWidgetBase* GetMapIconWidget(); // Function KillstreakUINew.KSMapIconWidgetPool.GetMapIconWidget // (Final|Native|Public) // @ game+0x2146f80
	void AddMapIconWidget(struct UKSMapIconWidgetBase* MapIconWidget); // Function KillstreakUINew.KSMapIconWidgetPool.AddMapIconWidget // (Final|Native|Public) // @ game+0x2146860
};

// Class KillstreakUINew.KSMarkerDisplayBase
// Size: 0x6c0 (Inherited: 0x640)
struct UKSMarkerDisplayBase : UKSMapWidgetBase {
	char pad_640[0x80]; // 0x640(0x80)

	bool GetScreenPositionForMarker(struct FVector TargetLocation, float AnchorHeight, float MarginX, float MarginY, struct FVector2D& ScreenLocation); // Function KillstreakUINew.KSMarkerDisplayBase.GetScreenPositionForMarker // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2146fe0
};

// Class KillstreakUINew.KSDataMassInviteBase
// Size: 0x78 (Inherited: 0x28)
struct UKSDataMassInviteBase : UObject {
	struct FText Title; // 0x28(0x18)
	struct FText ButtonLabel; // 0x40(0x18)
	struct FDelegate OnShouldShow; // 0x58(0x10)
	struct FDelegate OnClose; // 0x68(0x10)
};

// Class KillstreakUINew.KSDataIndividualInviteSetup
// Size: 0x98 (Inherited: 0x78)
struct UKSDataIndividualInviteSetup : UKSDataMassInviteBase {
	struct FDelegate OnGetIsSelected; // 0x78(0x10)
	struct FDelegate OnSelect; // 0x88(0x10)

	struct UKSDataIndividualInviteSetup* SetCallbacks(struct FDelegate GetIsSelected, struct FDelegate Select, struct FDelegate ShouldShowPlayer, struct FDelegate Close); // Function KillstreakUINew.KSDataIndividualInviteSetup.SetCallbacks // (Final|Native|Public|BlueprintCallable) // @ game+0x214c9d0
	enum class EKSInviteSelectResult KSInviteSelect__DelegateSignature(struct UKSPlayerInfo* playerinfo); // DelegateFunction KillstreakUINew.KSDataIndividualInviteSetup.KSInviteSelect__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	bool KSInviteGetIsSelected__DelegateSignature(struct UKSPlayerInfo* playerinfo); // DelegateFunction KillstreakUINew.KSDataIndividualInviteSetup.KSInviteGetIsSelected__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSDataBatchInviteSetup
// Size: 0x88 (Inherited: 0x78)
struct UKSDataBatchInviteSetup : UKSDataMassInviteBase {
	struct FDelegate OnSelect; // 0x78(0x10)

	struct UKSDataBatchInviteSetup* SetCallbacks(struct FDelegate Select, struct FDelegate ShouldShowPlayer, struct FDelegate Cancel); // Function KillstreakUINew.KSDataBatchInviteSetup.SetCallbacks // (Final|Native|Public|BlueprintCallable) // @ game+0x214c870
	void KSBatchSelect__DelegateSignature(struct TArray<struct UKSPlayerInfo*> playerinfo); // DelegateFunction KillstreakUINew.KSDataBatchInviteSetup.KSBatchSelect__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSMassInviteModal
// Size: 0x530 (Inherited: 0x518)
struct UKSMassInviteModal : UKSWidget {
	struct TArray<struct UKSPlayerInfo*> SelectedPlayers; // 0x518(0x10)
	struct UKSDataMassInviteBase* RouteData; // 0x528(0x08)

	bool UpdateRouteData(); // Function KillstreakUINew.KSMassInviteModal.UpdateRouteData // (Final|Native|Protected|BlueprintCallable) // @ game+0x214d0b0
	enum class EKSInviteSelectResult SelectPlayer(struct UKSPlayerInfo* Player); // Function KillstreakUINew.KSMassInviteModal.SelectPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x214c6b0
	void RequestFriends(struct FDelegate OnReceivePlayers); // Function KillstreakUINew.KSMassInviteModal.RequestFriends // (Final|Native|Protected|BlueprintCallable) // @ game+0x214c610
	void KSInviteReceivePlayers__DelegateSignature(struct TArray<struct UKSPlayerInfo*>& Players); // DelegateFunction KillstreakUINew.KSMassInviteModal.KSInviteReceivePlayers__DelegateSignature // (Public|Delegate|HasOutParms) // @ game+0x24d5b40
	bool GetShouldSelect(struct UKSPlayerInfo* Player); // Function KillstreakUINew.KSMassInviteModal.GetShouldSelect // (Final|Native|Protected|BlueprintCallable) // @ game+0x214bbd0
	void CloseScreen(enum class EKSInviteCloseAction CloseAction); // Function KillstreakUINew.KSMassInviteModal.CloseScreen // (Final|Native|Protected|BlueprintCallable) // @ game+0x214b600
};

// Class KillstreakUINew.KSMatchInvitationModal
// Size: 0x550 (Inherited: 0x518)
struct UKSMatchInvitationModal : UKSWidget {
	struct FName RouteName; // 0x518(0x08)
	char pad_520[0x8]; // 0x520(0x08)
	struct FTimerHandle InvitationExpireTimeout; // 0x528(0x08)
	char pad_530[0x20]; // 0x530(0x20)

	void OnInvitationExpired(); // Function KillstreakUINew.KSMatchInvitationModal.OnInvitationExpired // (Final|Native|Private) // @ game+0x214c3f0
	void HandleReceivePlayerName(struct UPUMG_PlayerInfo* playerinfo); // Function KillstreakUINew.KSMatchInvitationModal.HandleReceivePlayerName // (Final|Native|Private) // @ game+0x214bee0
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSMatchInvitationModal.GetQueueDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x214ba80
	float GetInvitationTotalTimeToExpire(); // Function KillstreakUINew.KSMatchInvitationModal.GetInvitationTotalTimeToExpire // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x214b6f0
	float GetInvitationTimeRemaining(); // Function KillstreakUINew.KSMatchInvitationModal.GetInvitationTimeRemaining // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x214b6c0
	void DeclineInvite(); // Function KillstreakUINew.KSMatchInvitationModal.DeclineInvite // (Final|Native|Protected|BlueprintCallable) // @ game+0x214b6a0
	void CloseScreen(); // Function KillstreakUINew.KSMatchInvitationModal.CloseScreen // (Final|Native|Protected|BlueprintCallable) // @ game+0x214b680
	void AcceptInviteDefault(); // Function KillstreakUINew.KSMatchInvitationModal.AcceptInviteDefault // (Final|Native|Protected|BlueprintCallable) // @ game+0x214b200
	void AcceptInvite(int32_t MapId); // Function KillstreakUINew.KSMatchInvitationModal.AcceptInvite // (Final|Native|Protected|BlueprintCallable) // @ game+0x214b180
};

// Class KillstreakUINew.KSMatchResult
// Size: 0x560 (Inherited: 0x518)
struct UKSMatchResult : UKSWidget {
	char pad_518[0xc]; // 0x518(0x0c)
	float FinalResultEndTime; // 0x524(0x04)
	struct FRoundResultAnnoucement RoundResultAnnoucement; // 0x528(0x20)
	int32_t pTeamNum; // 0x548(0x04)
	int32_t pOpposeTeamNum; // 0x54c(0x04)
	int32_t pTeamScore; // 0x550(0x04)
	int32_t pOpposeTeamScore; // 0x554(0x04)
	bool bIsEndOfMatch; // 0x558(0x01)
	bool bMatchEndedInSurrender; // 0x559(0x01)
	char pad_55A[0x6]; // 0x55a(0x06)

	void UpdateRoundBaseScore(struct AKSGameState_RoundGame* pGameState); // Function KillstreakUINew.KSMatchResult.UpdateRoundBaseScore // (Final|Native|Protected|BlueprintCallable) // @ game+0x214d030
	void UpdateResultStatus(enum class EGameResult Result, struct FText& Status); // Function KillstreakUINew.KSMatchResult.UpdateResultStatus // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x214cf20
	void ProcessResultAnnoucement(enum class EGameResult Result); // Function KillstreakUINew.KSMatchResult.ProcessResultAnnoucement // (Final|Native|Protected|BlueprintCallable) // @ game+0x214c590
	void HandleResultReceived(struct FRoundResultAnnoucement ResultAnnoucement); // Function KillstreakUINew.KSMatchResult.HandleResultReceived // (Native|Event|Public|BlueprintEvent) // @ game+0x214bf60
	void HandleEndOfMatch(); // Function KillstreakUINew.KSMatchResult.HandleEndOfMatch // (Final|Native|Protected|BlueprintCallable) // @ game+0x214bec0
	void GetTeamNames(struct FText& pTeamName, struct FText& pOpposingTeamName); // Function KillstreakUINew.KSMatchResult.GetTeamNames // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x214bd30
	void GetSurrenderText(struct FText& pSurrenderText); // Function KillstreakUINew.KSMatchResult.GetSurrenderText // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x214bc60
};

// Class KillstreakUINew.KSMediaPlayerWidget
// Size: 0x550 (Inherited: 0x518)
struct UKSMediaPlayerWidget : UKSWidget {
	struct UDataTable* MediaPlayerPlaylistEntries; // 0x518(0x08)
	char pad_520[0x10]; // 0x520(0x10)
	bool bOnlyWatchFirstEntry; // 0x530(0x01)
	char pad_531[0x1f]; // 0x531(0x1f)

	void UIX_SkipEntry(); // Function KillstreakUINew.KSMediaPlayerWidget.UIX_SkipEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x214cc50
	void OnShouldShowPromptChanged(bool bCanSkipEntry); // Function KillstreakUINew.KSMediaPlayerWidget.OnShouldShowPromptChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnReadyForPlayback(struct UPlatformMediaSource* PlatformMediaSource, struct UAkAudioEvent* PlayEvent, struct UAkAudioEvent* StopEvent); // Function KillstreakUINew.KSMediaPlayerWidget.OnReadyForPlayback // (Native|Event|Public|BlueprintEvent) // @ game+0x214c410
	void OnEndLoadingMedia(); // Function KillstreakUINew.KSMediaPlayerWidget.OnEndLoadingMedia // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnBeginLoadingMedia(); // Function KillstreakUINew.KSMediaPlayerWidget.OnBeginLoadingMedia // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool IsCurrentEntrySkippable(); // Function KillstreakUINew.KSMediaPlayerWidget.IsCurrentEntrySkippable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x214c300
};

// Class KillstreakUINew.KSMilestoneCompletedSummary
// Size: 0x98 (Inherited: 0x28)
struct UKSMilestoneCompletedSummary : UObject {
	struct TArray<struct FKSMilestoneCompletedSummaryEntry> MilestoneEntries; // 0x28(0x10)
	struct TArray<struct UKSWeaponAsset*> WeaponKeys; // 0x38(0x10)
	struct TMap<struct UKSWeaponAsset*, int32_t> WeaponXpCounts; // 0x48(0x50)

	bool GetMilestoneEntriesForWeapon(struct UKSWeaponAsset* Weapon, struct TArray<struct FKSMilestoneCompletedSummaryEntry>& OutMilestoneEntries); // Function KillstreakUINew.KSMilestoneCompletedSummary.GetMilestoneEntriesForWeapon // (Final|Native|Public|HasOutParms) // @ game+0x214b720
};

// Class KillstreakUINew.KSMilestoneCompletedScreen
// Size: 0x550 (Inherited: 0x518)
struct UKSMilestoneCompletedScreen : UKSWidget {
	struct UKSWeaponProgressMeter* WeaponMasteryMeter; // 0x518(0x08)
	struct UKSWeaponAsset* PopulatedWeapon; // 0x520(0x08)
	struct UKSMilestoneCompletedSummary* CurrentMilestoneData; // 0x528(0x08)
	char pad_530[0x20]; // 0x530(0x20)

	void StartAnimSequence(); // Function KillstreakUINew.KSMilestoneCompletedScreen.StartAnimSequence // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ShowNextWeapon(); // Function KillstreakUINew.KSMilestoneCompletedScreen.ShowNextWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x214cb80
	void PopulateMilestoneData(struct TArray<struct FKSMilestoneCompletedSummaryEntry>& MilestonesForWeapon); // Function KillstreakUINew.KSMilestoneCompletedScreen.PopulateMilestoneData // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void PopulateFromWeaponAsset(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSMilestoneCompletedScreen.PopulateFromWeaponAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x214c510
	void HandleViewStateChanged(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function KillstreakUINew.KSMilestoneCompletedScreen.HandleViewStateChanged // (Final|Native|Public) // @ game+0x214c050
	void HandleSkipContextAction(); // Function KillstreakUINew.KSMilestoneCompletedScreen.HandleSkipContextAction // (Final|Native|Public) // @ game+0xa6a770
	void HandleCurrentWeaponDismissed(); // Function KillstreakUINew.KSMilestoneCompletedScreen.HandleCurrentWeaponDismissed // (Final|Native|Public|BlueprintCallable) // @ game+0x214bea0
	void DisplayWeaponAsset(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSMilestoneCompletedScreen.DisplayWeaponAsset // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ConfigureViewModel(struct UKSWeaponAsset* WeaponAsset, struct UKSWeaponAttachment* WeaponWrap); // Function KillstreakUINew.KSMilestoneCompletedScreen.ConfigureViewModel // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSMinimapWidgetBase
// Size: 0x650 (Inherited: 0x640)
struct UKSMinimapWidgetBase : UKSMapWidgetBase {
	float MinimapRepresentedWidth; // 0x638(0x04)
	float BackgroundWidth; // 0x63c(0x04)
	enum class EMinimapWidgetClampStyle ClampStyle; // 0x640(0x01)
	char pad_649[0x7]; // 0x649(0x07)

	void UpdateMapMaterialTransform(struct UMaterialInstanceDynamic* MapMaterial, float NormalizedX, float NormalizedY, float Rotation, float Scale); // Function KillstreakUINew.KSMinimapWidgetBase.UpdateMapMaterialTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x214cd90
};

// Class KillstreakUINew.KSModelViewer
// Size: 0x28 (Inherited: 0x28)
struct UKSModelViewer : UObject {

	void ViewModelByName(struct UObject* WorldContextObject, struct FName InTargetItem, struct UDataTable* InDataTable); // Function KillstreakUINew.KSModelViewer.ViewModelByName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214d410
	void ViewModelAttachment(struct UObject* WorldContextObject, struct UKSWeaponAttachment* InAttachment, struct FName InSpawnOnActorName, char Slot); // Function KillstreakUINew.KSModelViewer.ViewModelAttachment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214d2e0
	void ViewModel(struct UObject* WorldContextObject, struct UKSItem* InItem, struct FName InSpawnOnActorName, enum class EWeaponStateNew DefaultWeaponState, bool InScaleToFitTargetActor, struct FRotator InDefaultRotation, bool InBindControllerToSpawner); // Function KillstreakUINew.KSModelViewer.ViewModel // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x214d0e0
	void UnbindControllerFromSpawner(struct UObject* WorldContextObject, struct FName InSpawnActorName); // Function KillstreakUINew.KSModelViewer.UnbindControllerFromSpawner // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214cce0
	void UnbindAllControllersFromSpawners(struct UObject* WorldContextObject); // Function KillstreakUINew.KSModelViewer.UnbindAllControllersFromSpawners // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214cc70
	void TriggerReactiveAttachment(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.TriggerReactiveAttachment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214cba0
	void SetAnimation(struct UObject* WorldContextObject, struct UAnimSequence* InAnim, struct FName InSpawnOnActorName, bool bLooping); // Function KillstreakUINew.KSModelViewer.SetAnimation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214c740
	void HideModelAttachment(struct UObject* WorldContextObject, struct FName InSpawnOnActorName, char Slot); // Function KillstreakUINew.KSModelViewer.HideModelAttachment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214c210
	bool HasReactiveAttachment(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.HasReactiveAttachment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214c150
	struct FText GetReactiveAttachmentStateDescription(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.GetReactiveAttachmentStateDescription // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214bab0
	struct UAkAudioEvent* GetModelSoundFromDatatable(struct UObject* WorldContextObject, struct FName InSpawnOnActorName, struct FName& RowName); // Function KillstreakUINew.KSModelViewer.GetModelSoundFromDatatable // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x214b980
	void ClearModelAttachments(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.ClearModelAttachments // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214b550
	void ClearModel(struct UObject* WorldContextObject, struct FName InSpawnOnActorName); // Function KillstreakUINew.KSModelViewer.ClearModel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214b4a0
	bool BindDelForWeaponModelSet(struct UObject* WorldContextObject, struct FName InSpawnOnActorName, struct FDelegate& InEventCallback); // Function KillstreakUINew.KSModelViewer.BindDelForWeaponModelSet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x214b370
	void BindControllerToSpawner(struct UObject* WorldContextObject, struct FName InSpawnActorName); // Function KillstreakUINew.KSModelViewer.BindControllerToSpawner // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x214b2c0
};

// Class KillstreakUINew.KSModWidget_DetectEnemy
// Size: 0x530 (Inherited: 0x518)
struct UKSModWidget_DetectEnemy : UKSWidget {
	char pad_518[0x18]; // 0x518(0x18)

	void OnDetectChanged(struct UKSModInst_DetectEnemy* DetectEnemyModInst, bool bIsDetectingEnemy); // Function KillstreakUINew.KSModWidget_DetectEnemy.OnDetectChanged // (Final|Native|Private) // @ game+0x214c320
	struct UHorizontalBox* GetIconBox(); // Function KillstreakUINew.KSModWidget_DetectEnemy.GetIconBox // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSModWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSModWidgetInterface : UInterface {

	bool RemoveModInstance(struct UKSPlayerModInstance* InInstance); // Function KillstreakUINew.KSModWidgetInterface.RemoveModInstance // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x213ea30
	bool AddModInstance(struct UKSPlayerModInstance* InInstance); // Function KillstreakUINew.KSModWidgetInterface.AddModInstance // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x214b220
};

// Class KillstreakUINew.KSNavTabWidget
// Size: 0x558 (Inherited: 0x518)
struct UKSNavTabWidget : UKSWidget {
	struct FMulticastInlineDelegate OnNavTabSelected; // 0x518(0x10)
	struct FMulticastInlineDelegate OnNavTabUnselected; // 0x528(0x10)
	bool bSelected; // 0x538(0x01)
	bool bDisabled; // 0x539(0x01)
	char pad_53A[0x6]; // 0x53a(0x06)
	struct FText NavText; // 0x540(0x18)

	void UnselectNavTab(); // Function KillstreakUINew.KSNavTabWidget.UnselectNavTab // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x21518c0
	void SetSelected(bool bNewSelected); // Function KillstreakUINew.KSNavTabWidget.SetSelected // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x212f680
	void SetDisabled(bool bNewDisabled); // Function KillstreakUINew.KSNavTabWidget.SetDisabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x212f3a0
	void SelectNavTab(); // Function KillstreakUINew.KSNavTabWidget.SelectNavTab // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x212c030
	bool IsSelected(); // Function KillstreakUINew.KSNavTabWidget.IsSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1f90290
	bool IsDisabled(); // Function KillstreakUINew.KSNavTabWidget.IsDisabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x202cbd0
};

// Class KillstreakUINew.KSNewsRotatorData
// Size: 0xb0 (Inherited: 0x60)
struct UKSNewsRotatorData : UKSJsonData {
	struct UTexture2DDynamic* Image; // 0x60(0x08)
	struct FText Header; // 0x68(0x18)
	struct FText Body; // 0x80(0x18)
	enum class ENewsActions PanelAction; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FString ActionDetails; // 0xa0(0x10)
};

// Class KillstreakUINew.KSNewsRotatorWidget
// Size: 0x530 (Inherited: 0x518)
struct UKSNewsRotatorWidget : UKSWidget {
	struct FString JsonSection; // 0x518(0x10)
	float TimePerSection; // 0x528(0x04)
	char pad_52C[0x4]; // 0x52c(0x04)

	bool ShouldShowPanel(struct UKSNewsRotatorData* Panel); // Function KillstreakUINew.KSNewsRotatorWidget.ShouldShowPanel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2151dc0
	void OnNewsPanelClicked(struct UKSNewsRotatorData* Panel); // Function KillstreakUINew.KSNewsRotatorWidget.OnNewsPanelClicked // (Final|Native|Public|BlueprintCallable) // @ game+0x21517c0
	void OnJsonChanged(); // Function KillstreakUINew.KSNewsRotatorWidget.OnJsonChanged // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UKSNewsRotatorData*> GetPanelData(); // Function KillstreakUINew.KSNewsRotatorWidget.GetPanelData // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2150ec0
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSNewsRotatorWidget.GetJsonDataFactory // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x2150e50
};

// Class KillstreakUINew.KSNewStartMenuData
// Size: 0x68 (Inherited: 0x60)
struct UKSNewStartMenuData : UKSJsonData {
	struct UTexture2DDynamic* Image; // 0x60(0x08)
};

// Class KillstreakUINew.KSNewStartMenuWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSNewStartMenuWidget : UKSWidget {

	bool IsNewsAvailable(); // Function KillstreakUINew.KSNewStartMenuWidget.IsNewsAvailable // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2151690
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSNewStartMenuWidget.GetJsonDataFactory // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x2150e20
};

// Class KillstreakUINew.KSNPEDataFactory
// Size: 0x38 (Inherited: 0x38)
struct UKSNPEDataFactory : UPUMG_DataFactory {

	void UIX_ClaimTutorialActivity(); // Function KillstreakUINew.KSNPEDataFactory.UIX_ClaimTutorialActivity // (Final|Native|Public|BlueprintCallable) // @ game+0x2151e90
	void UIX_ClaimRegionSelectedActivity(); // Function KillstreakUINew.KSNPEDataFactory.UIX_ClaimRegionSelectedActivity // (Final|Native|Public|BlueprintCallable) // @ game+0x2151e70
	void SkipTutorial(); // Function KillstreakUINew.KSNPEDataFactory.SkipTutorial // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151e50
	bool ShouldForceTutorial(); // Function KillstreakUINew.KSNPEDataFactory.ShouldForceTutorial // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151d90
	void QueueTutorial(); // Function KillstreakUINew.KSNPEDataFactory.QueueTutorial // (Final|Native|Protected|BlueprintCallable) // @ game+0x21518e0
	bool HasClaimedActivity(struct FGameplayTag& ActivityTag); // Function KillstreakUINew.KSNPEDataFactory.HasClaimedActivity // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x21515f0
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSNPEDataFactory.GetQueueDataFactory // (Final|Native|Protected) // @ game+0x2151050
	void ClaimActivity(struct FGameplayTag& ActivityTag); // Function KillstreakUINew.KSNPEDataFactory.ClaimActivity // (Final|Native|Protected|HasOutParms) // @ game+0x2150820
};

// Class KillstreakUINew.KSOverlayTabHubRouteData
// Size: 0x30 (Inherited: 0x28)
struct UKSOverlayTabHubRouteData : UObject {
	struct FName RedirectViewName; // 0x28(0x08)
};

// Class KillstreakUINew.KSOverlayTabHubBase
// Size: 0x598 (Inherited: 0x518)
struct UKSOverlayTabHubBase : UKSWidget {
	struct UDataTable* ViewsTable; // 0x518(0x08)
	struct TArray<struct FName> ViewNames; // 0x520(0x10)
	struct FName CurrentViewName; // 0x530(0x08)
	char pad_538[0x50]; // 0x538(0x50)
	struct FName MyViewRouteName; // 0x588(0x08)
	char pad_590[0x8]; // 0x590(0x08)

	void SetFocusToView(); // Function KillstreakUINew.KSOverlayTabHubBase.SetFocusToView // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151c70
	void SetFocusToTabs(); // Function KillstreakUINew.KSOverlayTabHubBase.SetFocusToTabs // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151c50
	void SelectViewAndShow(struct FName ViewName); // Function KillstreakUINew.KSOverlayTabHubBase.SelectViewAndShow // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnViewFocused(); // Function KillstreakUINew.KSOverlayTabHubBase.OnViewFocused // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnTabsFocused(); // Function KillstreakUINew.KSOverlayTabHubBase.OnTabsFocused // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct FName GetLandingView(); // Function KillstreakUINew.KSOverlayTabHubBase.GetLandingView // (Final|Native|Protected|BlueprintCallable) // @ game+0x2150e80
	struct UPUMG_Widget* GetCurrentViewWidget(); // Function KillstreakUINew.KSOverlayTabHubBase.GetCurrentViewWidget // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	struct TArray<struct UPUMG_Widget*> GetAllViews(); // Function KillstreakUINew.KSOverlayTabHubBase.GetAllViews // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void CreateAllViews(); // Function KillstreakUINew.KSOverlayTabHubBase.CreateAllViews // (Final|Native|Protected|BlueprintCallable) // @ game+0x21508b0
	void ClearAllViews(); // Function KillstreakUINew.KSOverlayTabHubBase.ClearAllViews // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ChangeView(struct FName ViewName); // Function KillstreakUINew.KSOverlayTabHubBase.ChangeView // (Final|Native|Protected|BlueprintCallable) // @ game+0x21507a0
	void AddView(struct FName ViewName, struct FOverlayTabViewRow ViewInfo); // Function KillstreakUINew.KSOverlayTabHubBase.AddView // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSPartyDataFactory
// Size: 0x1d0 (Inherited: 0x1a8)
struct UKSPartyDataFactory : UPUMG_PartyDataFactory {
	struct FMulticastInlineDelegate OnEmoteMessageReceived; // 0x1a8(0x10)
	char pad_1B8[0x18]; // 0x1b8(0x18)

	void SetSelectedQueueId(int32_t QueueId); // Function KillstreakUINew.KSPartyDataFactory.SetSelectedQueueId // (Final|Native|Public|BlueprintCallable) // @ game+0x2151d10
	void PlayEmoteInParty(struct UKSEmote* Emote); // Function KillstreakUINew.KSPartyDataFactory.PlayEmoteInParty // (Final|Native|Public|BlueprintCallable) // @ game+0x2151840
	int32_t GetSelectedQueueId(); // Function KillstreakUINew.KSPartyDataFactory.GetSelectedQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2151080
	int32_t GetPartyMinimumLevel(); // Function KillstreakUINew.KSPartyDataFactory.GetPartyMinimumLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2150f70
	int32_t GetHighestDeserterPenaltySeconds(); // Function KillstreakUINew.KSPartyDataFactory.GetHighestDeserterPenaltySeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2150df0
	bool CanPartyQueueForRanked(struct FString RankedSeasonKey); // Function KillstreakUINew.KSPartyDataFactory.CanPartyQueueForRanked // (Final|Native|Public|BlueprintCallable) // @ game+0x21506f0
	void BroadcastPartyInvitationError(struct FText InvitationError); // Function KillstreakUINew.KSPartyDataFactory.BroadcastPartyInvitationError // (Final|Native|Public|BlueprintCallable) // @ game+0x2150610
};

// Class KillstreakUINew.KSPartyManagerWidgetBase
// Size: 0x528 (Inherited: 0x518)
struct UKSPartyManagerWidgetBase : UKSWidget {
	struct TArray<struct FPUMG_PartyMemberData> CachedDisplayedPartyMembers; // 0x518(0x10)

	void RefreshFromPartyData(); // Function KillstreakUINew.KSPartyManagerWidgetBase.RefreshFromPartyData // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151b10
	void HandlePartyMemberUpdateByName(struct FText PlayerName); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberUpdateByName // (Final|Native|Protected) // @ game+0x21512f0
	void HandlePartyMemberUpdateByInfo(struct UPUMG_PlayerInfo* playerinfo); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberUpdateByInfo // (Final|Native|Protected) // @ game+0x2151270
	void HandlePartyMemberUpdateById(int64_t PlayerId); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberUpdateById // (Final|Native|Protected) // @ game+0x2151270
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData MemberData); // Function KillstreakUINew.KSPartyManagerWidgetBase.HandlePartyMemberDataUpdated // (Final|Native|Protected) // @ game+0x2151140
	struct UPUMG_PlayerInfo* GetSuggestedInvite(); // Function KillstreakUINew.KSPartyManagerWidgetBase.GetSuggestedInvite // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x195ee20
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSPartyManagerWidgetBase.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2150f40
	struct TArray<struct FPUMG_PartyMemberData> GetCachedDisplayedPartyMembers(); // Function KillstreakUINew.KSPartyManagerWidgetBase.GetCachedDisplayedPartyMembers // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2150c60
	void ApplyPartyData(struct TArray<struct FPUMG_PartyMemberData>& PartyMembers); // Function KillstreakUINew.KSPartyManagerWidgetBase.ApplyPartyData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void ApplyEmptyPartyData(); // Function KillstreakUINew.KSPartyManagerWidgetBase.ApplyEmptyPartyData // (Final|Native|Protected|BlueprintCallable) // @ game+0x2150570
};

// Class KillstreakUINew.KSPerkTreeBase
// Size: 0x558 (Inherited: 0x518)
struct UKSPerkTreeBase : UKSWidget {
	struct FMulticastInlineDelegate OnPerkHovered; // 0x518(0x10)
	struct FMulticastInlineDelegate OnPerkSelected; // 0x528(0x10)
	struct FMulticastInlineDelegate OnPerkUnlockRequest; // 0x538(0x10)
	struct UWidget* HoverTarget; // 0x548(0x08)
	char pad_550[0x8]; // 0x550(0x08)

	void SetCursorLerping(bool bLerping); // Function KillstreakUINew.KSPerkTreeBase.SetCursorLerping // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151bc0
	void RefreshEdge(struct UKSPerkTreeEdgeBase* Edge, int32_t column, int32_t Row, struct TMap<struct FIntPoint, struct UKSPerkTreeNodeBase*> NodesMap); // Function KillstreakUINew.KSPerkTreeBase.RefreshEdge // (Final|Native|Protected|BlueprintCallable) // @ game+0x2151900
	struct TMap<struct FIntPoint, struct UKSPerkTreeNodeBase*> InitializeNodes(); // Function KillstreakUINew.KSPerkTreeBase.InitializeNodes // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleTreeNodeSelected(struct UKSPerkTreeNodeBase* SelectedNode, struct FCustomLoadoutItem SelectedPerk, bool bAlreadyEquipped); // Function KillstreakUINew.KSPerkTreeBase.HandleTreeNodeSelected // (Final|Native|Public) // @ game+0x21514c0
	void HandleTreeNodeHovered(struct UKSPerkTreeNodeBase* HoveredNode, struct FCustomLoadoutItem HoveredPerk); // Function KillstreakUINew.KSPerkTreeBase.HandleTreeNodeHovered // (Final|Native|Public) // @ game+0x21513d0
	struct UWidget* GetHoverCursor(); // Function KillstreakUINew.KSPerkTreeBase.GetHoverCursor // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	struct UKSPerkTreeNodeBase* GetDefaultFocusNode(); // Function KillstreakUINew.KSPerkTreeBase.GetDefaultFocusNode // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void BindNode(struct UKSPerkTreeNodeBase* TreeNode); // Function KillstreakUINew.KSPerkTreeBase.BindNode // (Final|Native|Public|BlueprintCallable) // @ game+0x2150590
};

// Class KillstreakUINew.KSPerkTreeEdgeBase
// Size: 0x530 (Inherited: 0x518)
struct UKSPerkTreeEdgeBase : UKSWidget {
	bool bTopEnabled; // 0x518(0x01)
	bool bLeftEnabled; // 0x519(0x01)
	bool bDiagonalEnabled; // 0x51a(0x01)
	bool bBackDiagonalEnabled; // 0x51b(0x01)
	struct FLinearColor AccentColor; // 0x51c(0x10)
	char pad_52C[0x4]; // 0x52c(0x04)

	void SetViewByState(struct FKSPerkTreeEdgeInfo EdgeInfo); // Function KillstreakUINew.KSPerkTreeEdgeBase.SetViewByState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSPerkTreeNodeBase
// Size: 0x578 (Inherited: 0x518)
struct UKSPerkTreeNodeBase : UKSWidget {
	struct TSoftObjectPtr<UKSPlayerMod> AssignedPerk; // 0x518(0x28)
	struct FMulticastInlineDelegate OnTreeNodeHovered; // 0x540(0x10)
	struct FMulticastInlineDelegate OnTreeNodeSelected; // 0x550(0x10)
	struct FMulticastInlineDelegate OnRequestPerkPurchase; // 0x560(0x10)
	bool bIsPlaceholder; // 0x570(0x01)
	enum class EPerkTreeNodeState NodeState; // 0x571(0x01)
	char pad_572[0x6]; // 0x572(0x06)

	void SetNodeState(enum class EPerkTreeNodeState NewNodeState); // Function KillstreakUINew.KSPerkTreeNodeBase.SetNodeState // (Final|Native|Public|BlueprintCallable) // @ game+0x2155fe0
	void RefreshView(); // Function KillstreakUINew.KSPerkTreeNodeBase.RefreshView // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	enum class EPerkTreeNodeState GetNodeState(); // Function KillstreakUINew.KSPerkTreeNodeBase.GetNodeState // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2154db0
};

// Class KillstreakUINew.KSPersistentDataTeamBarWidget
// Size: 0x568 (Inherited: 0x550)
struct UKSPersistentDataTeamBarWidget : UKSAutoTeamWidget {
	int32_t HoldReapply; // 0x550(0x04)
	bool bWantsRepply; // 0x554(0x01)
	char pad_555[0x3]; // 0x555(0x03)
	struct TArray<struct UKSPersistentPlayerData*> TeamPlayerData; // 0x558(0x10)

	bool SortPlayerData(struct UKSPersistentPlayerData* LHS, struct UKSPersistentPlayerData* RHS); // Function KillstreakUINew.KSPersistentDataTeamBarWidget.SortPlayerData // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x2156090
	void ApplyPlayerDataChildWidgets(struct TArray<struct UKSPersistentPlayerData*>& OrderedData); // Function KillstreakUINew.KSPersistentDataTeamBarWidget.ApplyPlayerDataChildWidgets // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x21547f0
};

// Class KillstreakUINew.KSViewedActiveWeaponWidget
// Size: 0x530 (Inherited: 0x520)
struct UKSViewedActiveWeaponWidget : UKSWeaponWidget {
	char pad_520[0x10]; // 0x520(0x10)
};

// Class KillstreakUINew.KSPlayerAmmoLoaderWidget
// Size: 0x648 (Inherited: 0x530)
struct UKSPlayerAmmoLoaderWidget : UKSViewedActiveWeaponWidget {
	struct TSoftClassPtr<UObject> PendingAmmoWidgetClass; // 0x530(0x28)
	struct UKSAmmoWidget* LoadedAmmoWidgetClass; // 0x558(0x08)
	char pad_560[0xe8]; // 0x560(0xe8)

	void SetActiveAmmoWidget(struct UKSAmmoWidget* NewWidgetClass, struct AKSWeapon* NewWeapon); // Function KillstreakUINew.KSPlayerAmmoLoaderWidget.SetActiveAmmoWidget // (Native|Event|Protected|BlueprintEvent) // @ game+0x2155f10
	struct UKSAmmoWidget* GetActiveAmmoWidget(); // Function KillstreakUINew.KSPlayerAmmoLoaderWidget.GetActiveAmmoWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2154940
	void ClearActiveAmmoWidget(); // Function KillstreakUINew.KSPlayerAmmoLoaderWidget.ClearActiveAmmoWidget // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c010
};

// Class KillstreakUINew.KSPlayerAwardsPanelWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSPlayerAwardsPanelWidget : UKSWidget {

	void GetSortedRecentlyProgressedData(struct TArray<struct FPlayerAwardsPanelData> AwardData, struct TArray<struct FPlayerAwardsPanelData>& RecentlyProgressedData); // Function KillstreakUINew.KSPlayerAwardsPanelWidget.GetSortedRecentlyProgressedData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2155020
	void GetActivityAwardData(struct TArray<struct FPlayerAwardsPanelData>& AwardData); // Function KillstreakUINew.KSPlayerAwardsPanelWidget.GetActivityAwardData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154970
};

// Class KillstreakUINew.KSPlayerCardModuleBase
// Size: 0x528 (Inherited: 0x518)
struct UKSPlayerCardModuleBase : UKSWidget {
	struct UPUMG_PlayerInfo* AssignedPlayerInfo; // 0x518(0x08)
	char pad_520[0x8]; // 0x520(0x08)

	void View_SetPlayer(struct UPUMG_PlayerInfo* playerinfo, enum class EKSPlayerOnlineStatus PlayerStatus, bool IsPortalFriend, bool IsPending); // Function KillstreakUINew.KSPlayerCardModuleBase.View_SetPlayer // (Native|Public|BlueprintCallable) // @ game+0x2156220
	void OnPlayerUpdate(struct UPUMG_PlayerInfo* playerinfo, enum class EKSPlayerOnlineStatus PlayerStatus, bool IsPortalFriend, bool IsPending); // Function KillstreakUINew.KSPlayerCardModuleBase.OnPlayerUpdate // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandlePlayerDataUpdated(struct UPUMG_PlayerInfo* playerinfo); // Function KillstreakUINew.KSPlayerCardModuleBase.HandlePlayerDataUpdated // (Final|Native|Protected) // @ game+0x2155650
};

// Class KillstreakUINew.KSPlayerCosmeticWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSPlayerCosmeticWidget : UKSWidget {

	void GetItemsForSlot(enum class EPlayerAccountSlot SlotType, struct TArray<struct TSoftObjectPtr<UKSItem>>& CosmeticItems); // Function KillstreakUINew.KSPlayerCosmeticWidget.GetItemsForSlot // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2154b40
};

// Class KillstreakUINew.KSPlayerDataFactory
// Size: 0xc8 (Inherited: 0xb0)
struct UKSPlayerDataFactory : UPUMG_PlayerDataFactory {
	struct UKSPlayerStatsManager* PlayerStatsManager; // 0xb0(0x08)
	struct FMulticastInlineDelegate OnPlayerLevelChanged; // 0xb8(0x10)

	bool ShouldDisplayRankedLevel(); // Function KillstreakUINew.KSPlayerDataFactory.ShouldDisplayRankedLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2156060
	void HandlePlayerRankIncremented(struct UKSActivityInstance* ActivityInstance, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerRankIncremented // (Final|Native|Protected) // @ game+0x2155a10
	void HandlePlayerRankChanged(struct UKSActivityInstance* Activity, int32_t Tier, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerRankChanged // (Final|Native|Protected) // @ game+0x2155910
	void HandlePlayerLevelIncremented(struct UKSActivityInstance* ActivityInstance, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerLevelIncremented // (Final|Native|Protected) // @ game+0x2155850
	void HandlePlayerLevelChanged(struct UKSActivityInstance* Activity, int32_t Tier, int32_t Count); // Function KillstreakUINew.KSPlayerDataFactory.HandlePlayerLevelChanged // (Final|Native|Protected) // @ game+0x2155750
	int32_t GetRankedLevel(); // Function KillstreakUINew.KSPlayerDataFactory.GetRankedLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2154ff0
	float GetPlayerLevelPercent(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerLevelPercent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2154e30
	int32_t GetPlayerLevel(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2154e00
	int32_t GetPlayerId(); // Function KillstreakUINew.KSPlayerDataFactory.GetPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154de0
	struct UKSCurrency* GetCurrencyItemByItemId(int32_t CurrencyItemId); // Function KillstreakUINew.KSPlayerDataFactory.GetCurrencyItemByItemId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154ab0
	int32_t GetCurrencyCountByItemId(int32_t CurrencyItemId); // Function KillstreakUINew.KSPlayerDataFactory.GetCurrencyCountByItemId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154a20
};

// Class KillstreakUINew.KSPlayerHealthSegmentBase
// Size: 0x518 (Inherited: 0x518)
struct UKSPlayerHealthSegmentBase : UKSWidget {

	void View_SetResidualValue(float PercentValue); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetResidualValue // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void View_SetResidualColor(struct FLinearColor Color); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetResidualColor // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void View_SetMainValue(float PercentValue, bool bCanTriggerPulse); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetMainValue // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void View_SetMainColor(struct FLinearColor Color); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_SetMainColor // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void View_PlayEmptiedPulse(); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_PlayEmptiedPulse // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void View_PlayDamagePulse(struct FLinearColor PeakColor, struct FLinearColor BaseColor); // Function KillstreakUINew.KSPlayerHealthSegmentBase.View_PlayDamagePulse // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSViewedTargetHealthWidget
// Size: 0x568 (Inherited: 0x558)
struct UKSViewedTargetHealthWidget : UKSHealthWidget {
	char pad_558[0x10]; // 0x558(0x10)
};

// Class KillstreakUINew.KSPlayerHealthWidgetBase
// Size: 0x598 (Inherited: 0x568)
struct UKSPlayerHealthWidgetBase : UKSViewedTargetHealthWidget {
	struct FPlayerHealthMeterState CurrentHealthMeterState; // 0x568(0x18)
	char pad_580[0x18]; // 0x580(0x18)

	void View_SetResidualPercent(float ResidualPercent); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetResidualPercent // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetResidualMode(bool IsHealing); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetResidualMode // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetResidualAlpha(float ResidualAlpha); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetResidualAlpha // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetHealthTextValue(float HealthValue, float OverhealValue); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetHealthTextValue // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetHealthPercent(float HealthPercent); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetHealthPercent // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_SetHealthMode(bool IsDowned, bool IsOverhealed); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_SetHealthMode // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_PlayDamagePulse(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_PlayDamagePulse // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void View_OnDeathStateChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.View_OnDeathStateChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnJobChanged(struct UKSJobItem* Job); // Function KillstreakUINew.KSPlayerHealthWidgetBase.OnJobChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnHealthMeterStateChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.OnHealthMeterStateChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnHealthDecreased(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.OnHealthDecreased // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandlePlayerDownedChanged(struct AKSPlayerState* pKSPlayerState); // Function KillstreakUINew.KSPlayerHealthWidgetBase.HandlePlayerDownedChanged // (Final|Native|Protected) // @ game+0x21556d0
	void HandleJobChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.HandleJobChanged // (Final|Native|Protected) // @ game+0x2155190
	void HandleDeathStateChanged(); // Function KillstreakUINew.KSPlayerHealthWidgetBase.HandleDeathStateChanged // (Final|Native|Protected) // @ game+0x2155170
};

// Class KillstreakUINew.JobSelectionEntryDetails
// Size: 0x60 (Inherited: 0x28)
struct UJobSelectionEntryDetails : UObject {
	struct FJobSelectionEntry JobEntry; // 0x28(0x28)
	struct UPUMG_StoreItem* StoreItem; // 0x50(0x08)
	bool AllowIfUnowned; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)

	bool IsSelf(); // Function KillstreakUINew.JobSelectionEntryDetails.IsSelf // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2155b80
	bool IsOwned(); // Function KillstreakUINew.JobSelectionEntryDetails.IsOwned // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2155b50
	struct FText GetJobName(); // Function KillstreakUINew.JobSelectionEntryDetails.GetJobName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154d10
	struct UKSJobItem* GetJobItem(); // Function KillstreakUINew.JobSelectionEntryDetails.GetJobItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154c50
};

// Class KillstreakUINew.KSPlayerJobSelectWidgetBase
// Size: 0x568 (Inherited: 0x518)
struct UKSPlayerJobSelectWidgetBase : UKSWidget {
	struct UKSJobSelectionManager* JobSelectionManager; // 0x518(0x08)
	struct UKSJobSelectionComponent* JobSelectionComponent; // 0x520(0x08)
	struct TArray<struct UJobSelectionEntryDetails*> JobDetailEntries; // 0x528(0x10)
	enum class EPlayerSelectionState CurrentPlayerSelectionState; // 0x538(0x01)
	char pad_539[0x7]; // 0x539(0x07)
	struct TArray<struct UJobSelectionEntryDetails*> EnemyJobDetailsEntries; // 0x540(0x10)
	struct TWeakObjectPtr<struct UKSJobSelectionComponent> BoundEnemyJobSelectionComponent; // 0x550(0x08)
	struct TWeakObjectPtr<struct UKSJobSelectionComponent> BoundLocalJobSelectionComponent; // 0x558(0x08)
	char pad_560[0x8]; // 0x560(0x08)

	bool UIX_RequestJobSelect(struct UJobSelectionEntryDetails* JobEntry, enum class EJobSelectionState RequestedState); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.UIX_RequestJobSelect // (Final|Native|Public|BlueprintCallable) // @ game+0x2156160
	void OnResetSelection(); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnResetSelection // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnPlayerSelectionStateChanged(enum class EPlayerSelectionState NewState); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnPlayerSelectionStateChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnJobEntryChanged(struct UJobSelectionEntryDetails* JobEntry, bool EnemyTeam); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnJobEntryChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnJobEntriesReady(struct TArray<struct UJobSelectionEntryDetails*>& JobEntries, bool EnemyTeam); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.OnJobEntriesReady // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleTeamAddedToMatch(struct AKSTeamState* NewTeam); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleTeamAddedToMatch // (Final|Native|Protected) // @ game+0x2155ad0
	void HandleNewJobSelectionComponent(struct UKSJobSelectionComponent* NewJobSelectionComponent); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleNewJobSelectionComponent // (Final|Native|Protected) // @ game+0x21555d0
	void HandleJobSelectionManagerReady(struct UKSJobSelectionManager* JobSelectionManager); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobSelectionManagerReady // (Final|Native|Protected) // @ game+0x2155550
	void HandleJobSelectionInitialized(); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobSelectionInitialized // (Final|Native|Protected) // @ game+0x2155530
	void HandleJobEntryStateChangedForEnemies(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryStateChangedForEnemies // (Final|Native|Protected) // @ game+0x2155490
	void HandleJobEntryStateChanged(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryStateChanged // (Final|Native|Protected) // @ game+0x21553f0
	void HandleJobEntryAddedForEnemies(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryAddedForEnemies // (Final|Native|Protected) // @ game+0x2155350
	void HandleJobEntryAdded(struct FJobSelectionEntry JobEntry); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryAdded // (Final|Native|Protected) // @ game+0x21552b0
	void HandleJobEntryAcknowledge(int32_t ItemId, bool bSuccess, enum class EJobSelectionState RequestState); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.HandleJobEntryAcknowledge // (Final|Native|Protected) // @ game+0x21551b0
	struct UKSJobSelectionComponent* GetJobSelectionComponent(); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.GetJobSelectionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x201d950
	struct UKSJobItem* GetJobItemById(int32_t JobItemId); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.GetJobItemById // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154c80
	void BindListenersForTeam(struct AKSTeamState* Team); // Function KillstreakUINew.KSPlayerJobSelectWidgetBase.BindListenersForTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x1f90a20
};

// Class KillstreakUINew.KSPlayerQueryDataFactory
// Size: 0x150 (Inherited: 0x38)
struct UKSPlayerQueryDataFactory : UPUMG_DataFactory {
	char pad_38[0x100]; // 0x38(0x100)
	struct FTimerHandle CheckTimerHandle; // 0x138(0x08)
	char pad_140[0x10]; // 0x140(0x10)

	bool QueryPlayersByNameWithProfiles(struct FText& PlayerName, struct FDelegate OnReponse, struct FKSPlayerQueryHandle& OutHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.QueryPlayersByNameWithProfiles // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2155d70
	bool QueryPlayersByName(struct FText& PlayerName, struct FDelegate OnReponse, struct FKSPlayerQueryHandle& OutHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.QueryPlayersByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2155bd0
	void OnTimeoutCheck(); // Function KillstreakUINew.KSPlayerQueryDataFactory.OnTimeoutCheck // (Final|Native|Protected) // @ game+0x2155bb0
	struct FText GetQueriedName(struct FKSPlayerQueryHandle& InHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.GetQueriedName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2154f40
	struct FText GetPlayerQueryErrorMessage(enum class EKSPlayerQueryError Error); // Function KillstreakUINew.KSPlayerQueryDataFactory.GetPlayerQueryErrorMessage // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2154e60
	void CancelQuery(struct FKSPlayerQueryHandle& InHandle); // Function KillstreakUINew.KSPlayerQueryDataFactory.CancelQuery // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x21548a0
};

// Class KillstreakUINew.KSPlayerShopWidgetBase
// Size: 0x530 (Inherited: 0x518)
struct UKSPlayerShopWidgetBase : UKSWidget {
	char pad_518[0x8]; // 0x518(0x08)
	struct AKSPlayerShop* PlayerShop; // 0x520(0x08)
	char pad_528[0x8]; // 0x528(0x08)

	void TriggerDisplayUpdate(bool ForceUpdate); // Function KillstreakUINew.KSPlayerShopWidgetBase.TriggerDisplayUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x215d5f0
	void ShopItemChanged(struct FShopItem& ChangedItem); // Function KillstreakUINew.KSPlayerShopWidgetBase.ShopItemChanged // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x215d290
	void SetShopState(bool IsOpen); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetShopState // (Native|Event|Public|BlueprintEvent) // @ game+0x212f680
	void SetShopContent(); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetShopContent // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x212c010
	void SetPromptShow(bool ShouldShowPrompt); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetPromptShow // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetCashValue(int32_t CashValue); // Function KillstreakUINew.KSPlayerShopWidgetBase.SetCashValue // (Native|Event|Public|BlueprintEvent) // @ game+0x215cad0
	void PurchaseAcknowledge(enum class EShopItemType ShopItemType); // Function KillstreakUINew.KSPlayerShopWidgetBase.PurchaseAcknowledge // (Native|Event|Public|BlueprintEvent) // @ game+0x215c3d0
	bool IsShopOfferingMastered(struct UKSItem* KSItem); // Function KillstreakUINew.KSPlayerShopWidgetBase.IsShopOfferingMastered // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x215bed0
	void HandleTeamsFlipped(); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleTeamsFlipped // (Final|Native|Protected) // @ game+0x215bac0
	void HandleShopOpened(struct AKSPlayerShop* KSPlayerShop); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopOpened // (Final|Native|Protected) // @ game+0x215b8f0
	void HandleShopOfferingsChanged(enum class EShopItemType ShopItemType, struct TArray<struct FPrimaryOffering>& Offerings); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopOfferingsChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleShopItemChanged(struct FShopItem ChangedItem); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopItemChanged // (Final|Native|Protected) // @ game+0x215b6f0
	void HandleShopClosed(struct AKSPlayerShop* KSPlayerShop); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopClosed // (Final|Native|Protected) // @ game+0x215b670
	void HandleShopAvailabilityChanged(struct AKSPlayerShop* KSPlayerShop); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleShopAvailabilityChanged // (Final|Native|Protected) // @ game+0x215b5f0
	void HandlePurchaseAcknowledged(enum class EShopItemType ShopItemType, bool bSuccess); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandlePurchaseAcknowledged // (Final|Native|Protected) // @ game+0x215b350
	void HandleCashChanged(int32_t cash, int32_t Delta); // Function KillstreakUINew.KSPlayerShopWidgetBase.HandleCashChanged // (Final|Native|Protected) // @ game+0x215b040
	void CheckForValidPlayerState(); // Function KillstreakUINew.KSPlayerShopWidgetBase.CheckForValidPlayerState // (Final|Native|Protected) // @ game+0x2159f40
};

// Class KillstreakUINew.KSPlayerWhoDataFactory
// Size: 0x60 (Inherited: 0x60)
struct UKSPlayerWhoDataFactory : UPUMG_PlayerWhoDataFactory {

	void ClearSearchResults(); // Function KillstreakUINew.KSPlayerWhoDataFactory.ClearSearchResults // (Final|Native|Public|BlueprintCallable) // @ game+0x215a150
};

// Class KillstreakUINew.KSPointObjectiveMarkerWidget
// Size: 0x390 (Inherited: 0x318)
struct UKSPointObjectiveMarkerWidget : UKSMapIconWidgetBase {
	char pad_318[0x78]; // 0x318(0x78)

	void ViewShowTeamCelebration(struct AKSTeamState* TeamState); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewShowTeamCelebration // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ViewSetCaptureProgress(float ProgressPercent); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewSetCaptureProgress // (Native|Event|Protected|BlueprintEvent) // @ game+0x215d710
	void ViewApplyTimerValue(float TimerSeconds); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewApplyTimerValue // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ViewApplyTimerPrioritiesChanged(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewApplyTimerPrioritiesChanged // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ViewApplyObjectiveProgress(float TimerSeconds, float TotalTimerSeconds); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ViewApplyObjectiveProgress // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	bool ShouldHideObjectiveIcon(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.ShouldHideObjectiveIcon // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215d380
	void SetView(struct FKSPointObjectiveMarkerViewState ViewState); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetView // (Native|Event|Protected|BlueprintEvent) // @ game+0x215d170
	void SetTeamColorsForState(struct TMap<enum class EPointObjectiveMarkerTeamState, struct FLinearColor> StateColors); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetTeamColorsForState // (Final|Native|Protected|BlueprintCallable) // @ game+0x215d010
	bool SetTeamColorForState(enum class EPointObjectiveMarkerTeamState ObjectiveState, struct FLinearColor StateColor); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetTeamColorForState // (Final|Native|Protected|HasDefaults|BlueprintCallable) // @ game+0x215cf40
	void SetMarkerTimerType(enum class EGameTimerType NewMarkerTimerType); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.SetMarkerTimerType // (Final|Native|Protected|BlueprintCallable) // @ game+0x215cc70
	bool IsInTimerState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInTimerState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bc60
	bool IsInProgressState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInProgressState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bc20
	bool IsInMatchTimerState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInMatchTimerState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bbe0
	bool IsInLockedState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInLockedState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bba0
	bool IsInCountdownState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInCountdownState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bb60
	bool IsInContestedState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInContestedState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bb30
	bool IsInCapturedState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.IsInCapturedState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bae0
	void HandleTeamCelebration(struct AKSTeamState* TeamState); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleTeamCelebration // (Final|Native|Protected) // @ game+0x215ba40
	void HandlePhaseChanged(struct FMatchPhase NewPhase, struct FMatchPhase PreviousPhase); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandlePhaseChanged // (Final|Native|Protected) // @ game+0x215b260
	void HandleObjectiveUnregistered(struct TScriptInterface<IKSObjective> Objective); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleObjectiveUnregistered // (Final|Native|Protected) // @ game+0x215b1c0
	void HandleObjectiveStateChanged(struct TScriptInterface<IKSObjective> Objective); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleObjectiveStateChanged // (Final|Native|Protected) // @ game+0x215b120
	void HandleMarkerTimerPrioritiesChanged(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.HandleMarkerTimerPrioritiesChanged // (Final|Native|Protected) // @ game+0x215b100
	enum class EKSPriority GetMarkerTimerPriority(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetMarkerTimerPriority // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x215aa10
	struct FKSPointObjectiveMarkerViewState GetCurrentViewState(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetCurrentViewState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x1fbdf90
	struct TScriptInterface<IKSPointOfInterest> GetAssociatedPOI(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetAssociatedPOI // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a570
	struct TScriptInterface<IKSObjective> GetAssociatedObjective(); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.GetAssociatedObjective // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a530
	bool DoesAttackingTeamExist(bool& IsLocalPlayerOnAttackingTeam); // Function KillstreakUINew.KSPointObjectiveMarkerWidget.DoesAttackingTeamExist // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a180
};

// Class KillstreakUINew.KSPortalOffersWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSPortalOffersWidget : UKSWidget {

	struct TArray<struct UPUMG_StoreItem*> GetPortalOfferItems(); // Function KillstreakUINew.KSPortalOffersWidget.GetPortalOfferItems // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215ad60
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSPortalOffersWidget.GetItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21339a0
};

// Class KillstreakUINew.KSProfileRogueStatsWidget
// Size: 0x538 (Inherited: 0x518)
struct UKSProfileRogueStatsWidget : UKSWidget {
	struct TArray<struct UKSStatWrapper*> DisplayedPlayerStats; // 0x518(0x10)
	struct TArray<struct UKSStatWrapper*> DisplayedRogueStats; // 0x528(0x10)

	struct TArray<int64_t> GetActiveJobIds(); // Function KillstreakUINew.KSProfileRogueStatsWidget.GetActiveJobIds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a480
};

// Class KillstreakUINew.KSProgressionTallyWidget
// Size: 0x688 (Inherited: 0x518)
struct UKSProgressionTallyWidget : UKSWidget {
	struct FPlayerProgression PlayerProgressionData; // 0x518(0x170)

	void SetPlayerProgressionData(struct FPlayerProgression PlayerProgression); // Function KillstreakUINew.KSProgressionTallyWidget.SetPlayerProgressionData // (Final|Native|Public|BlueprintCallable) // @ game+0x215ccf0
	void GetPlayerProgressionBreakdown(int32_t& BaseXP, int32_t& EventBonusXP, int32_t& WinBonusXP, int32_t& BackfillBonusXP, int32_t& MiscGainedXP); // Function KillstreakUINew.KSProgressionTallyWidget.GetPlayerProgressionBreakdown // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x215ab60
	struct FProgressionTallyMiscXPInfo GetMiscXPInfo(); // Function KillstreakUINew.KSProgressionTallyWidget.GetMiscXPInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x215aa90
};

// Class KillstreakUINew.KSProgressMeterWidgetBase
// Size: 0x538 (Inherited: 0x518)
struct UKSProgressMeterWidgetBase : UKSWidget {
	char pad_518[0x20]; // 0x518(0x20)

	void SetDeltaAnimationParams(float BasePercent, float DeltaPercent, float AnimTime); // Function KillstreakUINew.KSProgressMeterWidgetBase.SetDeltaAnimationParams // (Final|Native|Protected|BlueprintCallable) // @ game+0x215cb60
	void PlayDeltaAnimation(float StartDelay); // Function KillstreakUINew.KSProgressMeterWidgetBase.PlayDeltaAnimation // (Final|Native|Protected|BlueprintCallable) // @ game+0x215c310
	void OnDeltaAnimationTicked(); // Function KillstreakUINew.KSProgressMeterWidgetBase.OnDeltaAnimationTicked // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnDeltaAnimationStarted(); // Function KillstreakUINew.KSProgressMeterWidgetBase.OnDeltaAnimationStarted // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnDeltaAnimationFinished(bool bLevelChange); // Function KillstreakUINew.KSProgressMeterWidgetBase.OnDeltaAnimationFinished // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	bool IsPlayingDeltaAnimation(); // Function KillstreakUINew.KSProgressMeterWidgetBase.IsPlayingDeltaAnimation // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x215bca0
	void EnableDeltaAnimation(); // Function KillstreakUINew.KSProgressMeterWidgetBase.EnableDeltaAnimation // (Final|Native|Protected) // @ game+0x215a220
	void ApplyMeterPercentages_Raw(float BasePercent, float DeltaPercent); // Function KillstreakUINew.KSProgressMeterWidgetBase.ApplyMeterPercentages_Raw // (Final|Native|Protected|BlueprintCallable) // @ game+0x2159df0
	void ApplyMeterPercentages(float BasePercent, float DeltaPercent); // Function KillstreakUINew.KSProgressMeterWidgetBase.ApplyMeterPercentages // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSPurchaseData
// Size: 0x48 (Inherited: 0x28)
struct UKSPurchaseData : UObject {
	struct UPUMG_StoreItem* StoreItem; // 0x28(0x08)
	int32_t PurchaseQuantity; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FMulticastInlineDelegate PurchaseCompletedCallback; // 0x38(0x10)
};

// Class KillstreakUINew.KSStoreItemWithPurchaseData
// Size: 0x50 (Inherited: 0x48)
struct UKSStoreItemWithPurchaseData : UKSPurchaseData {
	struct UKSEquipOnAcquisitionData* EquipOnPurchase; // 0x48(0x08)
};

// Class KillstreakUINew.KSStoreItemWithWeaponData
// Size: 0x50 (Inherited: 0x48)
struct UKSStoreItemWithWeaponData : UKSPurchaseData {
	struct UKSWeaponAsset* AssociatedWeaponAsset; // 0x48(0x08)
};

// Class KillstreakUINew.KSPurchaseConfirmationWidget
// Size: 0x530 (Inherited: 0x518)
struct UKSPurchaseConfirmationWidget : UKSWidget {
	struct UPUMG_StoreItem* PurchaseItem; // 0x518(0x08)
	int32_t PurchaseQuantity; // 0x520(0x04)
	char pad_524[0x4]; // 0x524(0x04)
	struct UKSPurchaseData* PurchaseRequestData; // 0x528(0x08)

	bool TryChangePurchaseQuantity(int32_t QuantityChangeAmount); // Function KillstreakUINew.KSPurchaseConfirmationWidget.TryChangePurchaseQuantity // (Final|Native|Protected|BlueprintCallable) // @ game+0x215d680
	bool SubmitPurchaseWithAdditionalCurrency(); // Function KillstreakUINew.KSPurchaseConfirmationWidget.SubmitPurchaseWithAdditionalCurrency // (Final|Native|Protected|BlueprintCallable) // @ game+0x215d5c0
	void SetupEquipOnPurchase(struct UKSEquipOnAcquisitionData* EquipOnPurchaseData); // Function KillstreakUINew.KSPurchaseConfirmationWidget.SetupEquipOnPurchase // (Final|Native|Protected|BlueprintCallable) // @ game+0x215d210
	void PromptAlreadyPurchasing(); // Function KillstreakUINew.KSPurchaseConfirmationWidget.PromptAlreadyPurchasing // (Final|Native|Public|BlueprintCallable) // @ game+0x215c3b0
	void OnPurchaseComplete(bool bCompletedPurchase); // Function KillstreakUINew.KSPurchaseConfirmationWidget.OnPurchaseComplete // (Final|Native|Protected|BlueprintCallable) // @ game+0x215c280
	struct UKSStoreItemHelper* GetStoreItemHelper(); // Function KillstreakUINew.KSPurchaseConfirmationWidget.GetStoreItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215afe0
	struct UKSStoreItemWithPurchaseData* GetAdditionalCurrencyPurchaseData(); // Function KillstreakUINew.KSPurchaseConfirmationWidget.GetAdditionalCurrencyPurchaseData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a500
	bool CanChangePurchaseQuantity(int32_t QuantityChangeAmount); // Function KillstreakUINew.KSPurchaseConfirmationWidget.CanChangePurchaseQuantity // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2159eb0
};

// Class KillstreakUINew.KSPurchaseModal
// Size: 0x518 (Inherited: 0x518)
struct UKSPurchaseModal : UKSWidget {

	void SetupBindings(); // Function KillstreakUINew.KSPurchaseModal.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x215d1f0
	void HandleShowPurchaseModal(struct UPUMG_StoreItem* Item, struct UPUMG_StoreItemPrice* Price); // Function KillstreakUINew.KSPurchaseModal.HandleShowPurchaseModal // (Native|Event|Public|BlueprintEvent) // @ game+0x215b970
	struct UPUMG_StoreItemHelper* GetStoreItemHelper(); // Function KillstreakUINew.KSPurchaseModal.GetStoreItemHelper // (Final|Native|Protected|BlueprintCallable) // @ game+0x215b010
};

// Class KillstreakUINew.KSQueueDataFactory
// Size: 0x2a8 (Inherited: 0x210)
struct UKSQueueDataFactory : UPUMG_QueueDataFactory {
	char pad_210[0x10]; // 0x210(0x10)
	struct FMulticastInlineDelegate OnSetQueueId; // 0x220(0x10)
	struct FMulticastInlineDelegate OnQueueErrorRelevantStateChanged; // 0x230(0x10)
	int32_t ChunksInstallingQueueId; // 0x240(0x04)
	int32_t DefaultQueueId; // 0x244(0x04)
	struct FMulticastInlineDelegate OnSetQueueInputState; // 0x248(0x10)
	struct TArray<int64_t> PreviousCustomMatchMemberIds; // 0x258(0x10)
	int32_t SelectedQueueId; // 0x268(0x04)
	float TimeoutForSwitchFromShelteredToMainQueue; // 0x26c(0x04)
	bool bWaitingOnLeaveForShelteredSwitch; // 0x270(0x01)
	bool bWaitingOnJoinForShelteredSwitch; // 0x271(0x01)
	char pad_272[0x2]; // 0x272(0x02)
	int32_t MaxRetriesForAlternateQueue; // 0x274(0x04)
	float TimeBetweenRetriesForAlternateQueue; // 0x278(0x04)
	char pad_27C[0x4]; // 0x27c(0x04)
	int32_t NumRetriesForAlternateQueue; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
	struct TArray<struct FMapDetail> MapInfos; // 0x288(0x10)
	struct UDataTable* QueueDetailDataTable; // 0x298(0x08)
	char pad_2A0[0x8]; // 0x2a0(0x08)

	struct TArray<struct FClientQueueInfo> SortQueues(struct TArray<struct FClientQueueInfo> ClientCachedQueueInfo, bool IsAlphanumerical); // Function KillstreakUINew.KSQueueDataFactory.SortQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x215d3b0
	bool SetSelectedQueueId(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.SetSelectedQueueId // (Native|Public|BlueprintCallable) // @ game+0x215cea0
	void SetPreviousCustomMatchMemberIds(struct TArray<int64_t> PreviousMembers); // Function KillstreakUINew.KSQueueDataFactory.SetPreviousCustomMatchMemberIds // (Final|Native|Public|BlueprintCallable) // @ game+0x215cdc0
	void RetryJoinAlternateQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.RetryJoinAlternateQueue // (Final|Native|Public) // @ game+0x215ca50
	bool QualifiesForShelteredMM(int32_t QueueId, struct FClientQueueInfo& QueueInfo, bool& RetryFlag); // Function KillstreakUINew.KSQueueDataFactory.QualifiesForShelteredMM // (Final|Native|Protected|HasOutParms|Const) // @ game+0x215c850
	bool QualifiesForMercyMatch(int32_t QueueId, struct FClientQueueInfo& QueueInfo, bool& RetryFlag); // Function KillstreakUINew.KSQueueDataFactory.QualifiesForMercyMatch // (Final|Native|Protected|HasOutParms|Const) // @ game+0x215c650
	bool QualifiesForForcedBots(int32_t QueueId, struct FClientQueueInfo& QueueInfo, bool& RetryFlag); // Function KillstreakUINew.KSQueueDataFactory.QualifiesForForcedBots // (Final|Native|Protected|HasOutParms|Const) // @ game+0x215c450
	void PopulateMapInfos(); // Function KillstreakUINew.KSQueueDataFactory.PopulateMapInfos // (Final|Native|Public|BlueprintCallable) // @ game+0x215c390
	void OnPartyMemberUpdate(struct FPUMG_PartyMemberData Member); // Function KillstreakUINew.KSQueueDataFactory.OnPartyMemberUpdate // (Final|Native|Protected) // @ game+0x215c150
	void OnPartyMemberEvent(int64_t PlayerId); // Function KillstreakUINew.KSQueueDataFactory.OnPartyMemberEvent // (Final|Native|Protected) // @ game+0x215c0d0
	void OnPartyEvent(); // Function KillstreakUINew.KSQueueDataFactory.OnPartyEvent // (Final|Native|Protected) // @ game+0x215c0b0
	void OnInputStateChanged(enum class PGAME_INPUT_STATE InputState); // Function KillstreakUINew.KSQueueDataFactory.OnInputStateChanged // (Final|Native|Private) // @ game+0x215c030
	bool JoinSelectedQueue(); // Function KillstreakUINew.KSQueueDataFactory.JoinSelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x215bff0
	bool IsTutorialQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.IsTutorialQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bf60
	bool IsRankedQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.IsRankedQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215be40
	bool IsQueueAvailableOnPlatform(struct FPUMG_ClientQueueInfo& QueueInfo); // Function KillstreakUINew.KSQueueDataFactory.IsQueueAvailableOnPlatform // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bcc0
	bool IsCustomSpectateEnabled(); // Function KillstreakUINew.KSQueueDataFactory.IsCustomSpectateEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb48850
	void HandleShelteredMMTimeout(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.HandleShelteredMMTimeout // (Final|Native|Public) // @ game+0x215b570
	void HandleShelteredMMSwitchFinish(bool bSendNotify, bool bClearTimer); // Function KillstreakUINew.KSQueueDataFactory.HandleShelteredMMSwitchFinish // (Final|Native|Public) // @ game+0x215b4a0
	void HandleShelteredMMQueueSwitch(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.HandleShelteredMMQueueSwitch // (Final|Native|Public) // @ game+0x215b420
	int32_t GetSelectedShelteredQueueId(); // Function KillstreakUINew.KSQueueDataFactory.GetSelectedShelteredQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215afb0
	int32_t GetSelectedQueueId(); // Function KillstreakUINew.KSQueueDataFactory.GetSelectedQueueId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215af80
	bool GetQueueInfoById(int32_t QueueId, struct FClientQueueInfo& InClientQueueInfo); // Function KillstreakUINew.KSQueueDataFactory.GetQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x215ade0
	int32_t GetPenaltyTime(); // Function KillstreakUINew.KSQueueDataFactory.GetPenaltyTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215ab30
	struct UKSActivity* GetMercyMatchConsecutiveLossesActivity(); // Function KillstreakUINew.KSQueueDataFactory.GetMercyMatchConsecutiveLossesActivity // (Final|Native|Protected|Const) // @ game+0x215aa60
	struct UKSActivity* GetMatchesPlayedActivity(); // Function KillstreakUINew.KSQueueDataFactory.GetMatchesPlayedActivity // (Final|Native|Protected|Const) // @ game+0x215aa30
	bool GetMapRotationsByQueueId(int32_t QueueId, struct TArray<int32_t>& MapIds); // Function KillstreakUINew.KSQueueDataFactory.GetMapRotationsByQueueId // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x215a920
	bool GetMapInfoById(int32_t MapId, struct FMapDetail& MapDetail); // Function KillstreakUINew.KSQueueDataFactory.GetMapInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x215a7d0
	struct TArray<struct FClientQueueInfo> GetCustomQueues(); // Function KillstreakUINew.KSQueueDataFactory.GetCustomQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x215a710
	bool GetCurrentCustomMatchInfo(struct FClientQueueInfo& InClientQueueInfo); // Function KillstreakUINew.KSQueueDataFactory.GetCurrentCustomMatchInfo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a5b0
	bool FormatQueueJoinErrorMessage(struct FClientQueueInfo& Queue, enum class EKSQueueJoinError Error, struct FText& OutErrorMessage); // Function KillstreakUINew.KSQueueDataFactory.FormatQueueJoinErrorMessage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x215a240
	enum class EKSQueueJoinError CheckQueueJoinableById(int32_t QueueId); // Function KillstreakUINew.KSQueueDataFactory.CheckQueueJoinableById // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215a0c0
	enum class EKSQueueJoinError CheckQueueJoinable(struct FClientQueueInfo& Queue); // Function KillstreakUINew.KSQueueDataFactory.CheckQueueJoinable // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2159f60
};

// Class KillstreakUINew.KSQueuedMessageWidget
// Size: 0x530 (Inherited: 0x518)
struct UKSQueuedMessageWidget : UKSWidget {
	char pad_518[0x18]; // 0x518(0x18)

	void QueueMessage(struct FText Message); // Function KillstreakUINew.KSQueuedMessageWidget.QueueMessage // (Final|Native|Protected|BlueprintCallable) // @ game+0x21627d0
	bool GetNextMessage(struct FText& Message); // Function KillstreakUINew.KSQueuedMessageWidget.GetNextMessage // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2160a00
};

// Class KillstreakUINew.KSQueueWidgetBase
// Size: 0x518 (Inherited: 0x518)
struct UKSQueueWidgetBase : UKSWidget {

	void UpdateQueueSelection(); // Function KillstreakUINew.KSQueueWidgetBase.UpdateQueueSelection // (Native|Protected) // @ game+0x212c010
	void UpdateQueuePermissions(); // Function KillstreakUINew.KSQueueWidgetBase.UpdateQueuePermissions // (Final|Native|Protected) // @ game+0x2163080
	bool UIX_AttemptRejoinMatch(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptRejoinMatch // (Final|Native|Public|BlueprintCallable) // @ game+0x2162f50
	bool UIX_AttemptLeaveMatch(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptLeaveMatch // (Final|Native|Public|BlueprintCallable) // @ game+0x2162f20
	bool UIX_AttemptJoinSelectedQueue(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptJoinSelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x2162ec0
	bool UIX_AttemptCancelQueue(); // Function KillstreakUINew.KSQueueWidgetBase.UIX_AttemptCancelQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x2162e60
	void SetupReadyForQueueing(); // Function KillstreakUINew.KSQueueWidgetBase.SetupReadyForQueueing // (Final|Native|Protected) // @ game+0x2162cf0
	void SetupBindings(); // Function KillstreakUINew.KSQueueWidgetBase.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x2162cb0
	bool SetCurrentlySelectedQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueWidgetBase.SetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x21629b0
	void ReceiveMatchStatusUpdate(enum class EPUMG_MatchStatus CurrentMatchStatus); // Function KillstreakUINew.KSQueueWidgetBase.ReceiveMatchStatusUpdate // (Final|Native|Protected) // @ game+0x21628b0
	void OnSelectedQueueUpdate(struct FClientQueueInfo CurrentSelectedQueue); // Function KillstreakUINew.KSQueueWidgetBase.OnSelectedQueueUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x2162600
	void OnQueueStateUpdate(enum class EPUMG_MatchStatus CurrentMatchStatus); // Function KillstreakUINew.KSQueueWidgetBase.OnQueueStateUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x2162360
	void OnQueuePermissionUpdate(bool CanQueue); // Function KillstreakUINew.KSQueueWidgetBase.OnQueuePermissionUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x21622d0
	void OnControlQueuePermissionUpdate(bool CanControl); // Function KillstreakUINew.KSQueueWidgetBase.OnControlQueuePermissionUpdate // (Native|Event|Protected|BlueprintEvent) // @ game+0x2162200
	bool IsValidQueue(int32_t QueueId); // Function KillstreakUINew.KSQueueWidgetBase.IsValidQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161fa0
	void HandleSelectedQueueIdSet(); // Function KillstreakUINew.KSQueueWidgetBase.HandleSelectedQueueIdSet // (Final|Native|Protected) // @ game+0x2161e50
	void HandlePartyMemberRemoved(int64_t PartyMemberId); // Function KillstreakUINew.KSQueueWidgetBase.HandlePartyMemberRemoved // (Final|Native|Protected) // @ game+0x2161dd0
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSQueueWidgetBase.HandlePartyMemberDataUpdated // (Final|Native|Protected) // @ game+0x2161b70
	void HandleMatchStatusUpdate(enum class EPUMG_MatchStatus MatchStatus); // Function KillstreakUINew.KSQueueWidgetBase.HandleMatchStatusUpdate // (Final|Native|Protected) // @ game+0x2161a30
	void HandleConfirmLeaveQueue(); // Function KillstreakUINew.KSQueueWidgetBase.HandleConfirmLeaveQueue // (Final|Native|Protected) // @ game+0x2161990
	struct TArray<struct FQueueSection> GetQueueSections(struct TArray<struct FClientQueueInfo> ClientCachedQueueInfo); // Function KillstreakUINew.KSQueueWidgetBase.GetQueueSections // (Final|Native|Public|BlueprintCallable) // @ game+0x21612d0
	struct TArray<struct FClientQueueInfo> GetQueues(); // Function KillstreakUINew.KSQueueWidgetBase.GetQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x21617c0
	void GetQueuePermissions(bool& CanControl, bool& CanQueue); // Function KillstreakUINew.KSQueueWidgetBase.GetQueuePermissions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x21611f0
	bool GetQueueInfoById(int32_t QueueId, struct FClientQueueInfo& QueueInfo); // Function KillstreakUINew.KSQueueWidgetBase.GetQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2160eb0
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSQueueWidgetBase.GetQueueDataFactory // (Final|Native|Protected|Const) // @ game+0x2160e50
	struct UKSPlayerDataFactory* GetPlayerDataFactory(); // Function KillstreakUINew.KSQueueWidgetBase.GetPlayerDataFactory // (Final|Native|Protected|Const) // @ game+0x2160e20
	struct UPUMG_PartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSQueueWidgetBase.GetPartyDataFactory // (Final|Native|Protected|Const) // @ game+0x2160ae0
	struct FClientQueueInfo GetCurrentlySelectedQueue(); // Function KillstreakUINew.KSQueueWidgetBase.GetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160520
};

// Class KillstreakUINew.KSQueueTimerWidgetBase
// Size: 0x528 (Inherited: 0x518)
struct UKSQueueTimerWidgetBase : UKSQueueWidgetBase {
	char pad_518[0x10]; // 0x518(0x10)

	void OnUpdateQueueTimerState(enum class EQueueTimerState State); // Function KillstreakUINew.KSQueueTimerWidgetBase.OnUpdateQueueTimerState // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnUpdateQueueTime(float TimeSecs); // Function KillstreakUINew.KSQueueTimerWidgetBase.OnUpdateQueueTime // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	float GetQueueTime_TotalSecs(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_TotalSecs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161710
	int32_t GetQueueTime_PartSecs(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_PartSecs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21616d0
	int32_t GetQueueTime_PartMins(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_PartMins // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161670
	int32_t GetQueueTime_PartHours(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetQueueTime_PartHours // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161630
	enum class EQueueTimerState GetCurrentTimerState(); // Function KillstreakUINew.KSQueueTimerWidgetBase.GetCurrentTimerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x215bca0
};

// Class KillstreakUINew.KSQuickPlay
// Size: 0x618 (Inherited: 0x518)
struct UKSQuickPlay : UKSWidget {
	struct FMulticastInlineDelegate OnSelectedQueueChanged; // 0x518(0x10)
	bool CanCurrentlyJoinQueue; // 0x528(0x01)
	bool CanControlQueue; // 0x529(0x01)
	char pad_52A[0x2]; // 0x52a(0x02)
	int32_t DefaultSelectedQueueId; // 0x52c(0x04)
	int32_t ChunksInstallingQueueId; // 0x530(0x04)
	char pad_534[0x14]; // 0x534(0x14)
	bool ReadyForQueueing; // 0x548(0x01)
	char pad_549[0x7]; // 0x549(0x07)
	struct FClientQueueInfo CurrentSelectedQueue; // 0x550(0xc8)

	void UpdateQueuePermissions(); // Function KillstreakUINew.KSQuickPlay.UpdateQueuePermissions // (Final|Native|Protected) // @ game+0x21630a0
	bool UIX_AttemptJoinSelectedQueue(); // Function KillstreakUINew.KSQuickPlay.UIX_AttemptJoinSelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x2162ef0
	bool UIX_AttemptCancelQueue(); // Function KillstreakUINew.KSQuickPlay.UIX_AttemptCancelQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x2162e90
	struct TArray<struct FQueueSection> SortQueueSections(struct TArray<struct FQueueSection> QueueSections); // Function KillstreakUINew.KSQuickPlay.SortQueueSections // (Final|Native|Protected) // @ game+0x2162d30
	void SetupReadyForQueueing(); // Function KillstreakUINew.KSQuickPlay.SetupReadyForQueueing // (Final|Native|Protected) // @ game+0x2162d10
	void SetupBindings(); // Function KillstreakUINew.KSQuickPlay.SetupBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x2162cd0
	bool SetDefaultSelectedQueue(struct FClientQueueInfo& NewSelectedQueue); // Function KillstreakUINew.KSQuickPlay.SetDefaultSelectedQueue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2162ad0
	bool SetCurrentlySelectedQueue(int32_t QueueId); // Function KillstreakUINew.KSQuickPlay.SetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable) // @ game+0x2162a40
	void ReceiveMatchStatusUpdate(enum class EPUMG_MatchStatus CurrentMatchStatus); // Function KillstreakUINew.KSQuickPlay.ReceiveMatchStatusUpdate // (Final|Native|Protected) // @ game+0x2162930
	void OnQueuePermissionChanged(bool CanQueue); // Function KillstreakUINew.KSQuickPlay.OnQueuePermissionChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnControlQueuePermissionChanged(bool CanControl); // Function KillstreakUINew.KSQuickPlay.OnControlQueuePermissionChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool IsValidQueue(int32_t QueueId); // Function KillstreakUINew.KSQuickPlay.IsValidQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2162030
	void HandlePartyMemberDataUpdated(struct FPUMG_PartyMemberData PartyMember); // Function KillstreakUINew.KSQuickPlay.HandlePartyMemberDataUpdated // (Final|Native|Protected) // @ game+0x2161ca0
	enum class EQueueType GetQueueTypeFromName(struct FName QueueType); // Function KillstreakUINew.KSQuickPlay.GetQueueTypeFromName // (Final|Native|Protected) // @ game+0x2161730
	struct TArray<struct FQueueSection> GetQueueSections(struct TArray<struct FClientQueueInfo> ClientCachedQueueInfo); // Function KillstreakUINew.KSQuickPlay.GetQueueSections // (Final|Native|Public|BlueprintCallable) // @ game+0x2161480
	struct TArray<struct FClientQueueInfo> GetQueues(); // Function KillstreakUINew.KSQuickPlay.GetQueues // (Final|Native|Public|BlueprintCallable) // @ game+0x2161880
	bool GetQueueInfoById(int32_t QueueId, struct FClientQueueInfo& QueueInfo); // Function KillstreakUINew.KSQuickPlay.GetQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2161050
	struct UKSQueueDataFactory* GetQueueDataFactory(); // Function KillstreakUINew.KSQuickPlay.GetQueueDataFactory // (Final|Native|Protected|Const) // @ game+0x2160e80
	struct UPUMG_PartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSQuickPlay.GetPartyDataFactory // (Final|Native|Protected|Const) // @ game+0x2160b10
	int32_t GetDefaultSelectedQueueId(); // Function KillstreakUINew.KSQuickPlay.GetDefaultSelectedQueueId // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160730
	struct FClientQueueInfo GetCurrentlySelectedQueue(); // Function KillstreakUINew.KSQuickPlay.GetCurrentlySelectedQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160620
	bool CheckForDirtyQueues(struct TArray<struct FClientQueueInfo>& NewClientCachedQueueInfo); // Function KillstreakUINew.KSQuickPlay.CheckForDirtyQueues // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2160110
	bool CheckForCustomQueues(struct TArray<struct FClientQueueInfo>& CustomMatchQueueInfo); // Function KillstreakUINew.KSQuickPlay.CheckForCustomQueues // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2160000
};

// Class KillstreakUINew.KSQuickPlayWidget
// Size: 0x530 (Inherited: 0x518)
struct UKSQuickPlayWidget : UKSQueueWidgetBase {
	char pad_518[0x18]; // 0x518(0x18)

	void UpdateState(); // Function KillstreakUINew.KSQuickPlayWidget.UpdateState // (Final|Native|Protected|BlueprintCallable) // @ game+0x21630c0
	void SetIsPendingQueueUpdate(bool IsPending); // Function KillstreakUINew.KSQuickPlayWidget.SetIsPendingQueueUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x2162c30
	void OnUpdateQuickPlayState(enum class EQuickPlayQueueState QueueState); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdateQuickPlayState // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnUpdateQuickPlayCanPlay(bool CanPlay); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdateQuickPlayCanPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnUpdateQueueTimeElapsed(float TimeElapsed); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdateQueueTimeElapsed // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnUpdatePenaltyTimeLeft(int32_t TimeLeft); // Function KillstreakUINew.KSQuickPlayWidget.OnUpdatePenaltyTimeLeft // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	bool IsPendingQueueUpdate(); // Function KillstreakUINew.KSQuickPlayWidget.IsPendingQueueUpdate // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2161f50
	void HandleOnPlayerProgressInitialized(struct UKSActivityInstance* ActivityInstance, int32_t Count); // Function KillstreakUINew.KSQuickPlayWidget.HandleOnPlayerProgressInitialized // (Final|Native|Protected) // @ game+0x2161ab0
	enum class EQuickPlayQueueState GetSelectedQueueState(); // Function KillstreakUINew.KSQuickPlayWidget.GetSelectedQueueState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161960
	bool GetGameModeDisplayName(struct FText& GameModeDisplayName); // Function KillstreakUINew.KSQuickPlayWidget.GetGameModeDisplayName // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2160760
	enum class EQuickPlayQueueState GetCurrentQuickPlayState(); // Function KillstreakUINew.KSQuickPlayWidget.GetCurrentQuickPlayState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x212ef10
};

// Class KillstreakUINew.KSRadialSelectionWidgetBase
// Size: 0x5c8 (Inherited: 0x518)
struct UKSRadialSelectionWidgetBase : UKSWidget {
	struct TArray<struct FGameplayTag> EmoteSlots; // 0x518(0x10)
	struct TArray<struct FGameplayTag> QuipSlots; // 0x528(0x10)
	struct TArray<struct FGameplayTag> CommunicationSlots; // 0x538(0x10)
	struct TArray<struct FGameplayTag> SpraySlots; // 0x548(0x10)
	struct TArray<struct FName> AdditionalInputsToDisableOnOpen; // 0x558(0x10)
	struct TArray<enum class EMercCosmeticSlot> RadialMenuCosmeticSlots; // 0x568(0x10)
	bool bCycleBetweenMenusEnabled; // 0x578(0x01)
	char pad_579[0x8]; // 0x579(0x08)
	enum class ERadialWheelActivationMode RadialWheelActivationMode; // 0x581(0x01)
	char pad_582[0x36]; // 0x582(0x36)
	struct UDataTable* ContextualPingTypesDT; // 0x5b8(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x5c0(0x08)

	void UpdateLastSelectedIndex(int32_t NewIndex); // Function KillstreakUINew.KSRadialSelectionWidgetBase.UpdateLastSelectedIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x2163000
	void UpdateLastHoveredIndex(int32_t NewHoveredIndex); // Function KillstreakUINew.KSRadialSelectionWidgetBase.UpdateLastHoveredIndex // (Final|Native|Protected) // @ game+0x2162f80
	void TraceSelectionCursor(float Radius, float Angle); // Function KillstreakUINew.KSRadialSelectionWidgetBase.TraceSelectionCursor // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ShowSelector(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ShowSelector // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void SetupForRadialWheelMode(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.SetupForRadialWheelMode // (Native|Event|Protected|BlueprintEvent) // @ game+0x21416e0
	void RadialOptionUnhover(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.RadialOptionUnhover // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void RadialOptionSelected(int32_t Index); // Function KillstreakUINew.KSRadialSelectionWidgetBase.RadialOptionSelected // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void RadialOptionHovered(int32_t Index); // Function KillstreakUINew.KSRadialSelectionWidgetBase.RadialOptionHovered // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OpenSpecifiedRadialMenu(enum class EMercCosmeticSlot CosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OpenSpecifiedRadialMenu // (Final|Native|Protected|BlueprintCallable) // @ game+0x2162750
	void OnRadialMenuUseLastSelection(enum class EMercCosmeticSlot ButtonCosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuUseLastSelection // (Final|Native|Protected) // @ game+0x2162580
	void OnRadialMenuReleased(enum class EMercCosmeticSlot ButtonCosmeticSlot, bool bIsContextualPingHold); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuReleased // (Final|Native|Protected|BlueprintCallable) // @ game+0x21624b0
	void OnRadialMenuPressed(enum class EMercCosmeticSlot ButtonCosmeticSlot, bool bIsContextualPingHold); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuPressed // (Final|Native|Protected|BlueprintCallable) // @ game+0x21623e0
	void OnRadialMenuForceClosed(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnRadialMenuForceClosed // (Final|Native|Protected|BlueprintCallable) // @ game+0x215ffc0
	void OnCycleMenusRight(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCycleMenusRight // (Final|Native|Protected|BlueprintCallable) // @ game+0x21622b0
	void OnCycleMenusLeft(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCycleMenusLeft // (Final|Native|Protected|BlueprintCallable) // @ game+0x2162290
	void OnCycledMenus(bool bCycledRight); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCycledMenus // (Native|Event|Protected|BlueprintEvent) // @ game+0x212f3a0
	void OnCinematicSubLevelEnabled(struct FString CinematicSubLevelName); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCinematicSubLevelEnabled // (Final|Native|Protected) // @ game+0x2162160
	void OnCinematicSubLevelDisabled(struct FString CinematicSubLevelName); // Function KillstreakUINew.KSRadialSelectionWidgetBase.OnCinematicSubLevelDisabled // (Final|Native|Protected) // @ game+0x21620c0
	bool IsSelectorVisible(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsSelectorVisible // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	bool IsSelectorActive(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsSelectorActive // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161f70
	bool IsLobbyHUD(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsLobbyHUD // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161f20
	bool IsInFullControlMode(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsInFullControlMode // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161ef0
	bool IsInEmoteOnlyMode(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsInEmoteOnlyMode // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161ec0
	bool IsCycleBetweenMenusEnabled(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.IsCycleBetweenMenusEnabled // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161e90
	void InitializeTracking(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.InitializeTracking // (Final|Native|Protected) // @ game+0x2161e70
	void HideSelector(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.HideSelector // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleOnShowPopup(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.HandleOnShowPopup // (Final|Native|Protected) // @ game+0x215ffc0
	void HandleInputStateChanged(enum class PGAME_INPUT_STATE NewInputState); // Function KillstreakUINew.KSRadialSelectionWidgetBase.HandleInputStateChanged // (Final|Native|Protected) // @ game+0x21619b0
	float GetWheelSize(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetWheelSize // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	enum class ERadialWheelActivationMode GetRadialWheelActivationMode(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetRadialWheelActivationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2161940
	bool GetPingIconByType(enum class EPingType PingType, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetPingIconByType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160d20
	bool GetPingIconByMessage(enum class EPingMessage PingMessage, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetPingIconByMessage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160c20
	bool GetPingColorByType(enum class EPingType PingType, struct FLinearColor& PingColor); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetPingColorByType // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160b40
	int32_t GetOptionsCount(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetOptionsCount // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	int32_t GetLastSelectedIndexForCosmeticSlot(enum class EMercCosmeticSlot CosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetLastSelectedIndexForCosmeticSlot // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160970
	int32_t GetLastHoveredIndex(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetLastHoveredIndex // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160940
	enum class EMercCosmeticSlot GetInitialRadialMenu(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetInitialRadialMenu // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160910
	struct TArray<struct FGameplayTag> GetGameplayTagsForCosmeticSlot(enum class EMercCosmeticSlot CosmeticSlot); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetGameplayTagsForCosmeticSlot // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160840
	float GetDeadZone(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetDeadZone // (Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	enum class EMercCosmeticSlot GetContiguousCosmeticSlotMenu(bool bRightSide); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetContiguousCosmeticSlotMenu // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160490
	enum class EMercCosmeticSlot GetActiveCosmeticSlotMenu(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.GetActiveCosmeticSlotMenu // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2160460
	bool FindRowByType(enum class EPingType PingType, struct FContextualPingTypesRow& ContextualPingTypesRow); // Function KillstreakUINew.KSRadialSelectionWidgetBase.FindRowByType // (Final|Native|Protected|HasOutParms|Const) // @ game+0x2160340
	bool FindRowByMessage(enum class EPingMessage PingMessage, struct FContextualPingMessagesRow& ContextualPingMessagesRow); // Function KillstreakUINew.KSRadialSelectionWidgetBase.FindRowByMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x2160220
	void DummyFunction(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.DummyFunction // (Final|Native|Protected) // @ game+0xa6a770
	void ChangeToNewRadialMenu(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ChangeToNewRadialMenu // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ButtonClicked(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ButtonClicked // (Final|Native|Protected) // @ game+0x215ffe0
	void BackPressed(); // Function KillstreakUINew.KSRadialSelectionWidgetBase.BackPressed // (Final|Native|Protected) // @ game+0x215ffc0
	bool ActivateRadialMenuItem(int32_t Index, struct AKSPlayerController* PlayerController); // Function KillstreakUINew.KSRadialSelectionWidgetBase.ActivateRadialMenuItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x215ff00
};

// Class KillstreakUINew.KSRankChangeWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSRankChangeWidget : UKSWidget {

	struct FPlayerProgression FormatProgressionData(struct FPlayerProgression ProgressionData); // Function KillstreakUINew.KSRankChangeWidget.FormatProgressionData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168040
};

// Class KillstreakUINew.KSRankedUnlockedViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSRankedUnlockedViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSRedeemCodeScreenBase
// Size: 0x530 (Inherited: 0x518)
struct UKSRedeemCodeScreenBase : UKSWidget {
	char pad_518[0x18]; // 0x518(0x18)

	void RedeemCode(struct FString Code); // Function KillstreakUINew.KSRedeemCodeScreenBase.RedeemCode // (Final|Native|Public|BlueprintCallable) // @ game+0x21698c0
	void OnRedeemCodeSubmit(); // Function KillstreakUINew.KSRedeemCodeScreenBase.OnRedeemCodeSubmit // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnRedeemCodeResult(bool Success, struct FText& Error); // Function KillstreakUINew.KSRedeemCodeScreenBase.OnRedeemCodeResult // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool IsPendingServerReply(); // Function KillstreakUINew.KSRedeemCodeScreenBase.IsPendingServerReply // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169640
};

// Class KillstreakUINew.KSRegionSelectModalViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSRegionSelectModalViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSRegionSelectModal
// Size: 0x518 (Inherited: 0x518)
struct UKSRegionSelectModal : UKSWidget {
};

// Class KillstreakUINew.KSRelatedRogueEntry
// Size: 0x518 (Inherited: 0x518)
struct UKSRelatedRogueEntry : UKSWidget {

	void DisplayLocked(bool bLocked); // Function KillstreakUINew.KSRelatedRogueEntry.DisplayLocked // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayJob(struct UKSJobItem* JobItem); // Function KillstreakUINew.KSRelatedRogueEntry.DisplayJob // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSRelatedRoguesGroup
// Size: 0x518 (Inherited: 0x518)
struct UKSRelatedRoguesGroup : UKSWidget {

	void PopulateForWeaponOwnership(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSRelatedRoguesGroup.PopulateForWeaponOwnership // (Final|Native|Public) // @ game+0x2169840
	void PopulateForWeaponCategoryByWeapon(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSRelatedRoguesGroup.PopulateForWeaponCategoryByWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x21697c0
	void PopulateForWeaponCategory(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSRelatedRoguesGroup.PopulateForWeaponCategory // (Final|Native|Public) // @ game+0x2169740
	void PopulateForWeaponAsset(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSRelatedRoguesGroup.PopulateForWeaponAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x21696c0
	struct TArray<struct UKSRelatedRogueEntry*> GetEntries(); // Function KillstreakUINew.KSRelatedRoguesGroup.GetEntries // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponCategoryLabel(); // Function KillstreakUINew.KSRelatedRoguesGroup.DisplayWeaponCategoryLabel // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayNone(); // Function KillstreakUINew.KSRelatedRoguesGroup.DisplayNone // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayIndividualWeaponLabel(); // Function KillstreakUINew.KSRelatedRoguesGroup.DisplayIndividualWeaponLabel // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	struct UKSRelatedRogueEntry* CreateAndAddEntry(); // Function KillstreakUINew.KSRelatedRoguesGroup.CreateAndAddEntry // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ClearEntries(); // Function KillstreakUINew.KSRelatedRoguesGroup.ClearEntries // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSReticleWidgetBase
// Size: 0x550 (Inherited: 0x530)
struct UKSReticleWidgetBase : UKSViewedActiveWeaponWidget {
	float ShrinkAnimationTime; // 0x530(0x04)
	float BlockedShotIconMaxScale; // 0x534(0x04)
	float BlockedShotIconMinScale; // 0x538(0x04)
	float BlockedShotMinScaleSqDist; // 0x53c(0x04)
	bool bGrenadeCooking; // 0x540(0x01)
	bool bInADS; // 0x541(0x01)
	bool bCachedBlockIconVisible; // 0x542(0x01)
	char pad_543[0x1]; // 0x543(0x01)
	float CachedWeaponAccuracy; // 0x544(0x04)
	float CachedReticleOffset; // 0x548(0x04)
	char pad_54C[0x4]; // 0x54c(0x04)

	void UpdateReticleOffset(float OffsetFromCenterScreen); // Function KillstreakUINew.KSReticleWidgetBase.UpdateReticleOffset // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void UpdateBlockedShotIcon(bool IconVisible, struct FVector2D Translation, struct FVector2D IconScale); // Function KillstreakUINew.KSReticleWidgetBase.UpdateBlockedShotIcon // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	void CalculateReticleOffset(float DeltaTime); // Function KillstreakUINew.KSReticleWidgetBase.CalculateReticleOffset // (Final|Native|Protected) // @ game+0x2167f30
	void CalculateBlockedShotIcon(); // Function KillstreakUINew.KSReticleWidgetBase.CalculateBlockedShotIcon // (Final|Native|Protected) // @ game+0x2167f10
};

// Class KillstreakUINew.KSRewardsTrackMeterSegmentBase
// Size: 0x538 (Inherited: 0x538)
struct UKSRewardsTrackMeterSegmentBase : UKSProgressMeterWidgetBase {

	void UpdateFromRewardTier(struct FActivityTier ActivityTier, int32_t ActivityCount); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.UpdateFromRewardTier // (Final|Native|Public|BlueprintCallable) // @ game+0x2169e00
	struct FLinearColor GetStandardBackgroundColor(); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.GetStandardBackgroundColor // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	struct FLinearColor GetPremiumBackgroundColor(); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.GetPremiumBackgroundColor // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	struct FLinearColor GetBattlePassPremiumColor(); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.GetBattlePassPremiumColor // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	struct FLinearColor GetBattlePassFreeColor(); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.GetBattlePassFreeColor // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	void ApplySegmentProgress(float ProgressPercent); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.ApplySegmentProgress // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ApplySegmentMeterColor(struct FLinearColor MeterColor); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.ApplySegmentMeterColor // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
	void ApplySegmentLabel(struct FText& LabelText); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.ApplySegmentLabel // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void ApplySegmentBackgroundColor(struct FLinearColor BackgroundColor); // Function KillstreakUINew.KSRewardsTrackMeterSegmentBase.ApplySegmentBackgroundColor // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSRewardsTrackWidgetBase
// Size: 0x540 (Inherited: 0x518)
struct UKSRewardsTrackWidgetBase : UKSWidget {
	int32_t MaxPageCount; // 0x518(0x04)
	int32_t CurrentPage; // 0x51c(0x04)
	struct TArray<struct UKSWidget*> ItemButtons; // 0x520(0x10)
	struct UKSActivityInstance* ActivityInstance; // 0x530(0x08)
	struct UKSAcquisition* Acquisition; // 0x538(0x08)

	void UpdateMaxPageCount(int32_t RewardCount); // Function KillstreakUINew.KSRewardsTrackWidgetBase.UpdateMaxPageCount // (Final|Native|Protected|BlueprintCallable) // @ game+0x2169f20
	void SetCurrentPageFromIndex(int32_t Index); // Function KillstreakUINew.KSRewardsTrackWidgetBase.SetCurrentPageFromIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x2169be0
};

// Class KillstreakUINew.KSRogueDetailsWidget
// Size: 0x5c8 (Inherited: 0x518)
struct UKSRogueDetailsWidget : UKSWidget {
	struct UKSWeaponHubHelper* WeaponHubHelper; // 0x518(0x08)
	char pad_520[0x40]; // 0x520(0x40)
	struct FName RogueDetailsScreen; // 0x560(0x08)
	struct TSoftObjectPtr<UKSJobItem> ViewedJobItem; // 0x568(0x28)
	struct TSoftObjectPtr<UKSContextBarWidget> ContextBar; // 0x590(0x28)
	struct UGuidedMenuCalloutsViewRedirector* GuidedMenuCalloutRedirectorClass; // 0x5b8(0x08)
	struct UGuidedMenuCalloutsViewRedirector* GuidedMenuCalloutRedirector; // 0x5c0(0x08)

	void ShowGuidedCallout(struct FName CalloutName); // Function KillstreakUINew.KSRogueDetailsWidget.ShowGuidedCallout // (Final|Native|Protected|BlueprintCallable) // @ game+0x2169d80
	void SetCurrentTabSelectable(bool bIsSelectable); // Function KillstreakUINew.KSRogueDetailsWidget.SetCurrentTabSelectable // (Final|Native|Protected|BlueprintCallable) // @ game+0x2169c60
	void OnCurrentJobChanged(struct UKSJobItem* JobItem, bool bFromShowEvent); // Function KillstreakUINew.KSRogueDetailsWidget.OnCurrentJobChanged // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnBackButtonPressed(); // Function KillstreakUINew.KSRogueDetailsWidget.OnBackButtonPressed // (Final|Native|Public) // @ game+0x21696a0
	struct UPUMG_StoreItem* GetStoreItemForJob(struct UKSJobItem* JobItem); // Function KillstreakUINew.KSRogueDetailsWidget.GetStoreItemForJob // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169400
	struct UKSStoreItemHelper* GetItemHelper(); // Function KillstreakUINew.KSRogueDetailsWidget.GetItemHelper // (Final|Native|Protected|Const) // @ game+0x21339a0
	void CycleJob(bool bForward); // Function KillstreakUINew.KSRogueDetailsWidget.CycleJob // (Final|Native|Public|BlueprintCallable) // @ game+0x2167fb0
};

// Class KillstreakUINew.KSRogueMasteryWidget
// Size: 0x518 (Inherited: 0x518)
struct UKSRogueMasteryWidget : UKSWidget {

	void GetSectionData(struct UKSActivityInstance* ActivityInstance, struct TArray<struct FMasterySectionData>& SectionData); // Function KillstreakUINew.KSRogueMasteryWidget.GetSectionData // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168f10
	void GetMasteryRewardsForTier(struct FActivityTier Tier, struct TArray<struct FMasteryRewardData>& Rewards); // Function KillstreakUINew.KSRogueMasteryWidget.GetMasteryRewardsForTier // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168d90
};

// Class KillstreakUINew.KSScreenLogWidget
// Size: 0x528 (Inherited: 0x518)
struct UKSScreenLogWidget : UKSWidget {
	struct UDataTable* ContextualPingTypesDT; // 0x518(0x08)
	struct UDataTable* ContextualPingMessagesDT; // 0x520(0x08)
};

// Class KillstreakUINew.KSScreenMarkerWidgetBase
// Size: 0x328 (Inherited: 0x318)
struct UKSScreenMarkerWidgetBase : UKSMapIconWidgetBase {
	bool bHideWhenOffscreen; // 0x318(0x01)
	char pad_319[0x3]; // 0x319(0x03)
	struct FVector2D OffscreenMargins; // 0x31c(0x08)
	char pad_324[0x4]; // 0x324(0x04)
};

// Class KillstreakUINew.KSScrollBox
// Size: 0x888 (Inherited: 0x888)
struct UKSScrollBox : UScrollBox {

	float GetViewFraction(); // Function KillstreakUINew.KSScrollBox.GetViewFraction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169490
};

// Class KillstreakUINew.KSSettingsContainer
// Size: 0x538 (Inherited: 0x518)
struct UKSSettingsContainer : UKSWidget {
	struct TArray<struct UKSSettingsWidget*> SettingsWidgets; // 0x518(0x10)
	struct UKSSettingsPreview* AssociatePreviewWidget; // 0x528(0x08)
	struct UKSSettingsContainerConfigAsset* ContainerConfigAsset; // 0x530(0x08)

	void OnShowSettingsWidget(struct UKSSettingsWidget* SettingsWidget); // Function KillstreakUINew.KSSettingsContainer.OnShowSettingsWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnHideSettingsWidget(struct UKSSettingsWidget* SettingsWidget); // Function KillstreakUINew.KSSettingsContainer.OnHideSettingsWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnContainerConfigSet(); // Function KillstreakUINew.KSSettingsContainer.OnContainerConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct FText GetWidgetContainerTitle(); // Function KillstreakUINew.KSSettingsContainer.GetWidgetContainerTitle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169580
	struct UKSSettingsPreview* GetWidgetContainerPreview(); // Function KillstreakUINew.KSSettingsContainer.GetWidgetContainerPreview // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x203dd60
	struct FText GetWidgetContainerDescription(); // Function KillstreakUINew.KSSettingsContainer.GetWidgetContainerDescription // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21694c0
	struct TArray<struct UKSSettingsWidget*> GetSettingsWidgets(); // Function KillstreakUINew.KSSettingsContainer.GetSettingsWidgets // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2169370
	void AddSettingsWidget(struct UKSSettingsWidget* SettingsWidget); // Function KillstreakUINew.KSSettingsContainer.AddSettingsWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void AddPreviewWidget(struct UKSSettingsPreview* PreviewWidget); // Function KillstreakUINew.KSSettingsContainer.AddPreviewWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSSettingsColorOptionsAsset
// Size: 0x40 (Inherited: 0x30)
struct UKSSettingsColorOptionsAsset : UDataAsset {
	struct TArray<struct FColorOptions> ColorOptions; // 0x30(0x10)
};

// Class KillstreakUINew.KSSettingsContainerConfigAsset
// Size: 0x140 (Inherited: 0x30)
struct UKSSettingsContainerConfigAsset : UDataAsset {
	bool bIsAvailableOffline; // 0x30(0x01)
	bool bRequires120HzDisplay; // 0x31(0x01)
	struct FKSAllowedPlatformTypes AllowedPlatformTypes; // 0x32(0x0a)
	struct FKSRequiredInputTypes RequiredInputTypes; // 0x3c(0x03)
	char pad_3F[0x1]; // 0x3f(0x01)
	struct FString RequiredExperiment; // 0x40(0x10)
	struct FKSSwitchDockedModeSetting SwitchDockedModeSetting; // 0x50(0x02)
	bool bUsePreview; // 0x52(0x01)
	char pad_53[0x5]; // 0x53(0x05)
	struct UKSSettingsPreview* PreviewWidget; // 0x58(0x08)
	struct TArray<struct FKSSettingsWidgetConfig> WidgetConfigs; // 0x60(0x10)
	struct FText SettingName; // 0x70(0x18)
	struct TMap<struct FString, struct FText> SettingNameByPlatform; // 0x88(0x50)
	struct FText SettingDescription; // 0xd8(0x18)
	struct TMap<struct FString, struct FText> SettingDescriptionByPlatform; // 0xf0(0x50)

	struct FText GetSettingName(); // Function KillstreakUINew.KSSettingsContainerConfigAsset.GetSettingName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169330
	struct FText GetSettingDescription(); // Function KillstreakUINew.KSSettingsContainerConfigAsset.GetSettingDescription // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21692f0
};

// Class KillstreakUINew.KSSettingsSectionConfigAsset
// Size: 0xa8 (Inherited: 0x30)
struct UKSSettingsSectionConfigAsset : UDataAsset {
	struct TArray<struct FKSSettingsGroupConfig> SettingsGroups; // 0x30(0x10)
	struct FText Heading; // 0x40(0x18)
	struct TMap<struct FString, struct FText> HeadingByPlatform; // 0x58(0x50)

	struct FText GetHeading(); // Function KillstreakUINew.KSSettingsSectionConfigAsset.GetHeading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168d20
};

// Class KillstreakUINew.KSSettingsPageConfigAsset
// Size: 0xa8 (Inherited: 0x30)
struct UKSSettingsPageConfigAsset : UDataAsset {
	struct TArray<struct UKSSettingsSectionConfigAsset*> SettingsSectionConfigs; // 0x30(0x10)
	struct FText PageName; // 0x40(0x18)
	struct TMap<struct FString, struct FText> HeadingByPlatform; // 0x58(0x50)

	struct FText GetPageName(); // Function KillstreakUINew.KSSettingsPageConfigAsset.GetPageName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168d20
};

// Class KillstreakUINew.KSSettingsMenuConfigAsset
// Size: 0x40 (Inherited: 0x30)
struct UKSSettingsMenuConfigAsset : UDataAsset {
	struct TArray<struct UKSSettingsPageConfigAsset*> SettingsPageConfigs; // 0x30(0x10)
};

// Class KillstreakUINew.KSSettingsDataFactory
// Size: 0x3b0 (Inherited: 0xd8)
struct UKSSettingsDataFactory : UPUMG_SettingsDataFactory {
	char pad_D8[0x8]; // 0xd8(0x08)
	struct FMulticastInlineDelegate OnSettingsReceivedFromPlayerAccount; // 0xe0(0x10)
	char pad_F0[0xa0]; // 0xf0(0xa0)
	struct FMulticastInlineDelegate OnKeyBindSettingsApplied; // 0x190(0x10)
	struct FMulticastInlineDelegate OnKeyBindSettingsSaved; // 0x1a0(0x10)
	struct TArray<struct FKSSettingPropertyId> BoolSettingPropertyIds; // 0x1b0(0x10)
	char pad_1C0[0x50]; // 0x1c0(0x50)
	struct TArray<struct FKSSettingPropertyId> IntSettingPropertyIds; // 0x210(0x10)
	char pad_220[0x50]; // 0x220(0x50)
	struct TArray<struct FKSSettingPropertyId> FloatSettingPropertyIds; // 0x270(0x10)
	char pad_280[0xb0]; // 0x280(0xb0)
	struct TSoftObjectPtr<UKSSettingsMenuConfigAsset> KSSettingsMenuConfigAssetSoftObjectPtr; // 0x330(0x28)
	struct UKSSettingsMenuConfigAsset* KSSettingsMenuConfigAsset; // 0x358(0x08)
	char pad_360[0x10]; // 0x360(0x10)
	struct FMulticastInlineDelegate OnDisplayLanguageApplied; // 0x370(0x10)
	struct FMulticastInlineDelegate OnDisplayLanguageSaved; // 0x380(0x10)
	struct FMulticastInlineDelegate OnScreenResolutionApplied; // 0x390(0x10)
	struct FMulticastInlineDelegate OnScreenResolutionSaved; // 0x3a0(0x10)

	bool SetSelectedRegion(int32_t SiteId); // Function KillstreakUINew.KSSettingsDataFactory.SetSelectedRegion // (Final|Native|Public|BlueprintCallable) // @ game+0x2169cf0
	void SaveSettings(); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x2169bc0
	void SaveSettingAsInt(struct FName Name); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettingAsInt // (Final|Native|Public|BlueprintCallable) // @ game+0x2169b40
	void SaveSettingAsFloat(struct FName Name); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettingAsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x2169ac0
	void SaveSettingAsBool(struct FName Name); // Function KillstreakUINew.KSSettingsDataFactory.SaveSettingAsBool // (Final|Native|Public|BlueprintCallable) // @ game+0x2169a40
	void SaveScreenResolution(); // Function KillstreakUINew.KSSettingsDataFactory.SaveScreenResolution // (Final|Native|Public|BlueprintCallable) // @ game+0x2169a20
	void SaveLanguage(); // Function KillstreakUINew.KSSettingsDataFactory.SaveLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x2169a00
	void SaveKeyBindings(); // Function KillstreakUINew.KSSettingsDataFactory.SaveKeyBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x21699e0
	void RevertScreenResolution(); // Function KillstreakUINew.KSSettingsDataFactory.RevertScreenResolution // (Final|Native|Public|BlueprintCallable) // @ game+0x21699c0
	void RevertPlayerPreferences(); // Function KillstreakUINew.KSSettingsDataFactory.RevertPlayerPreferences // (Final|Native|Public|BlueprintCallable) // @ game+0x21699a0
	void RevertLanguageToDefault(); // Function KillstreakUINew.KSSettingsDataFactory.RevertLanguageToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x2169980
	void RevertKeyBindings(); // Function KillstreakUINew.KSSettingsDataFactory.RevertKeyBindings // (Final|Native|Public|BlueprintCallable) // @ game+0x2169960
	bool IsUserLoggedIn(); // Function KillstreakUINew.KSSettingsDataFactory.IsUserLoggedIn // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2169670
	bool GetSettingAsInt_Legacy(struct FName Name, int32_t& OutInt); // Function KillstreakUINew.KSSettingsDataFactory.GetSettingAsInt_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169210
	bool GetSettingAsFloat_Legacy(struct FName Name, float& OutFloat); // Function KillstreakUINew.KSSettingsDataFactory.GetSettingAsFloat_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169130
	bool GetSettingAsBool_Legacy(struct FName Name, bool& OutBool); // Function KillstreakUINew.KSSettingsDataFactory.GetSettingAsBool_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169050
	int32_t GetSelectedRegion(); // Function KillstreakUINew.KSSettingsDataFactory.GetSelectedRegion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2169020
	struct FIntPoint GetScreenResolution(); // Function KillstreakUINew.KSSettingsDataFactory.GetScreenResolution // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168ed0
	struct UKSPlayerInput* GetKSPlayerInput(); // Function KillstreakUINew.KSSettingsDataFactory.GetKSPlayerInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168d60
	void GetDefaultKSInputActionKeys(struct FName& Name, enum class EKSInputType InputType, struct TArray<struct FKSInputActionKey>& OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetDefaultKSInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168ba0
	void GetDefaultInputAxisKeys(struct FName& Name, enum class EKSInputType InputType, float Scale, struct TArray<struct FKey>& OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetDefaultInputAxisKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21689d0
	void GetDefaultInputActionKeys(struct FName& Name, enum class EKSInputType InputType, struct TArray<struct FKey>& OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetDefaultInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168850
	void GetCustomKSInputActionKeys(struct FName Name, enum class EKSInputType InputType, struct TArray<struct FKSInputActionKey>& OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetCustomKSInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21686e0
	void GetCustomInputAxisKeys(struct FName Name, enum class EKSInputType InputType, float Scale, struct TArray<struct FKey>& OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetCustomInputAxisKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168520
	void GetCustomInputActionKeys(struct FName Name, enum class EKSInputType InputType, struct TArray<struct FKey>& OutKeys); // Function KillstreakUINew.KSSettingsDataFactory.GetCustomInputActionKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21683b0
	struct FString GetCurrentLanguage(); // Function KillstreakUINew.KSSettingsDataFactory.GetCurrentLanguage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168330
	struct TArray<struct FString> GetAvailableLanguages(); // Function KillstreakUINew.KSSettingsDataFactory.GetAvailableLanguages // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2168250
	void BindSettingCallbacks_Legacy(struct FName Name, struct FSettingDelegateStruct& SettingDelegateStruct); // Function KillstreakUINew.KSSettingsDataFactory.BindSettingCallbacks_Legacy // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2167e20
	void ApplySettingAsInt(struct FName Name, int32_t Value); // Function KillstreakUINew.KSSettingsDataFactory.ApplySettingAsInt // (Final|Native|Public|BlueprintCallable) // @ game+0x2167d60
	void ApplySettingAsFloat(struct FName Name, float Value); // Function KillstreakUINew.KSSettingsDataFactory.ApplySettingAsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x2167c90
	void ApplySettingAsBool(struct FName Name, bool Value); // Function KillstreakUINew.KSSettingsDataFactory.ApplySettingAsBool // (Final|Native|Public|BlueprintCallable) // @ game+0x2167bc0
	void ApplyScreenResolution(struct FIntPoint ScreenResolution); // Function KillstreakUINew.KSSettingsDataFactory.ApplyScreenResolution // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2167b40
	void ApplyLanguage(struct FString LanguageCulture); // Function KillstreakUINew.KSSettingsDataFactory.ApplyLanguage // (Final|Native|Public|BlueprintCallable) // @ game+0x2167a60
};

// Class KillstreakUINew.KSSettingsGroup
// Size: 0x548 (Inherited: 0x518)
struct UKSSettingsGroup : UKSWidget {
	struct TArray<struct UKSSettingsContainer*> SettingsContainers; // 0x518(0x10)
	struct UKSSettingsContainer* SettingsContainerClass; // 0x528(0x08)
	struct FKSSettingsGroupConfig GroupConfig; // 0x530(0x18)

	void OnShowContainer(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.OnShowContainer // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnHideContainer(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.OnHideContainer // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnGroupConfigSet(); // Function KillstreakUINew.KSSettingsGroup.OnGroupConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UKSSettingsContainer*> GetSettingsContainers(); // Function KillstreakUINew.KSSettingsGroup.GetSettingsContainers // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2169370
	void AddSubSettingsContainerWidget(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.AddSubSettingsContainerWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void AddMainSettingsContainerWidget(struct UKSSettingsContainer* SettingsContainer); // Function KillstreakUINew.KSSettingsGroup.AddMainSettingsContainerWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSSettingsInfo_Binding
// Size: 0x128 (Inherited: 0x108)
struct UKSSettingsInfo_Binding : UKSSettingsInfoBase {
	struct FKSKeyBindInfo PrimaryKeyBindInfo; // 0x108(0x10)
	struct FKSKeyBindInfo GamepadKeyBindInfo; // 0x118(0x10)

	void OnSettingsReceivedFromPlayerAccount(); // Function KillstreakUINew.KSSettingsInfo_Binding.OnSettingsReceivedFromPlayerAccount // (Final|Native|Private) // @ game+0x216e4e0
	void OnKeyBindingsSaved(struct FName Name); // Function KillstreakUINew.KSSettingsInfo_Binding.OnKeyBindingsSaved // (Final|Native|Private) // @ game+0x216e280
	void OnKeyBindingsApplied(struct FName Name); // Function KillstreakUINew.KSSettingsInfo_Binding.OnKeyBindingsApplied // (Final|Native|Private) // @ game+0x216e200
};

// Class KillstreakUINew.KSSettingsInfo_Brightness
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_Brightness : UKSSettingsInfoBase {

	void OnSettingSaved(); // Function KillstreakUINew.KSSettingsInfo_Brightness.OnSettingSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e480
	void OnSettingApplied(); // Function KillstreakUINew.KSSettingsInfo_Brightness.OnSettingApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e420
	struct UKSSettingsDataFactory* GetKSSettingsDataFactory(); // Function KillstreakUINew.KSSettingsInfo_Brightness.GetKSSettingsDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d7e0
};

// Class KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_ConsolePerformanceMode : UKSSettingsInfoBase {

	void OnSettingSaved(); // Function KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode.OnSettingSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e4a0
	void OnSettingApplied(); // Function KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode.OnSettingApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e440
	struct UKSSettingsDataFactory* GetKSSettingsDataFactory(); // Function KillstreakUINew.KSSettingsInfo_ConsolePerformanceMode.GetKSSettingsDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d7e0
};

// Class KillstreakUINew.KSSettingsInfo_Generic
// Size: 0x118 (Inherited: 0x108)
struct UKSSettingsInfo_Generic : UKSSettingsInfoBase {
	enum class EKSSettingType KSSettingType; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	struct FName Name; // 0x10c(0x08)
	char pad_114[0x4]; // 0x114(0x04)

	void OnSettingSaved(); // Function KillstreakUINew.KSSettingsInfo_Generic.OnSettingSaved // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e4c0
	void OnSettingApplied(); // Function KillstreakUINew.KSSettingsInfo_Generic.OnSettingApplied // (Final|Native|Protected|BlueprintCallable) // @ game+0x216e460
	struct UKSSettingsDataFactory* GetKSSettingsDataFactory(); // Function KillstreakUINew.KSSettingsInfo_Generic.GetKSSettingsDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x216d7e0
};

// Class KillstreakUINew.KSSettingsInfo_CrosshairColor
// Size: 0x120 (Inherited: 0x118)
struct UKSSettingsInfo_CrosshairColor : UKSSettingsInfo_Generic {
	struct UKSSettingsColorOptionsAsset* ColorOptions; // 0x118(0x08)
};

// Class KillstreakUINew.KSSettingsInfo_GamepadIconSet
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_GamepadIconSet : UKSSettingsInfoBase {
};

// Class KillstreakUINew.KSSettingsInfo_MuteAudio
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_MuteAudio : UKSSettingsInfoBase {
};

// Class KillstreakUINew.KSSettingsInfo_Region
// Size: 0x108 (Inherited: 0x108)
struct UKSSettingsInfo_Region : UKSSettingsInfoBase {

	void OnPreferredSiteUpdated(); // Function KillstreakUINew.KSSettingsInfo_Region.OnPreferredSiteUpdated // (Final|Native|Protected) // @ game+0x216e300
};

// Class KillstreakUINew.KSSettingsInfo_Resolution
// Size: 0x118 (Inherited: 0x108)
struct UKSSettingsInfo_Resolution : UKSSettingsInfoBase {
	char pad_108[0x10]; // 0x108(0x10)

	void OnScreenResolutionSaved(struct FIntPoint SavedScreenResolution); // Function KillstreakUINew.KSSettingsInfo_Resolution.OnScreenResolutionSaved // (Final|Native|Private|HasDefaults) // @ game+0x216e3a0
	void OnScreenResolutionApplied(struct FIntPoint AppliedScreenResolution); // Function KillstreakUINew.KSSettingsInfo_Resolution.OnScreenResolutionApplied // (Final|Native|Private|HasDefaults) // @ game+0x216e320
};

// Class KillstreakUINew.KSSettingsMenu
// Size: 0x540 (Inherited: 0x518)
struct UKSSettingsMenu : UKSWidget {
	struct FKSSettingsState SettingsState; // 0x518(0x05)
	char pad_51D[0x3]; // 0x51d(0x03)
	struct TArray<struct UKSSettingsPage*> SettingsPages; // 0x520(0x10)
	struct UKSSettingsPage* SettingsPageClass; // 0x530(0x08)
	struct UKSSettingsMenuConfigAsset* MenuConfigAsset; // 0x538(0x08)

	void RevertSettings(); // Function KillstreakUINew.KSSettingsMenu.RevertSettings // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void RebuildNavigation(); // Function KillstreakUINew.KSSettingsMenu.RebuildNavigation // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnShowPage(struct UKSSettingsPage* SettingsPage); // Function KillstreakUINew.KSSettingsMenu.OnShowPage // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnSaveSettings(); // Function KillstreakUINew.KSSettingsMenu.OnSaveSettings // (Final|Native|Protected) // @ game+0x2173310
	void OnRevertSettings(); // Function KillstreakUINew.KSSettingsMenu.OnRevertSettings // (Final|Native|Protected) // @ game+0x21732f0
	void OnMenuConfigSet(); // Function KillstreakUINew.KSSettingsMenu.OnMenuConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnHidePage(struct UKSSettingsPage* SettingsPage); // Function KillstreakUINew.KSSettingsMenu.OnHidePage // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnConfirmExit(bool ShouldSaveSettings); // Function KillstreakUINew.KSSettingsMenu.OnConfirmExit // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UKSSettingsPage*> GetSettingsPages(); // Function KillstreakUINew.KSSettingsMenu.GetSettingsPages // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2172ce0
	void ConfirmRevertSettings(); // Function KillstreakUINew.KSSettingsMenu.ConfirmRevertSettings // (Final|Native|Protected|BlueprintCallable) // @ game+0x2172810
	void CheckSavePendingChanges(); // Function KillstreakUINew.KSSettingsMenu.CheckSavePendingChanges // (Final|Native|Protected|BlueprintCallable) // @ game+0x21727d0
	void AddSettingsPageWidget(struct UKSSettingsPage* SettingsPage); // Function KillstreakUINew.KSSettingsMenu.AddSettingsPageWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSSettingsPage
// Size: 0x538 (Inherited: 0x518)
struct UKSSettingsPage : UKSWidget {
	struct TArray<struct UKSSettingsSection*> SettingsSections; // 0x518(0x10)
	struct UKSSettingsSection* SettingsSectionClass; // 0x528(0x08)
	struct UKSSettingsPageConfigAsset* PageConfigAsset; // 0x530(0x08)

	void OnShowSection(struct UKSSettingsSection* SettingsSection); // Function KillstreakUINew.KSSettingsPage.OnShowSection // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnPageConfigSet(); // Function KillstreakUINew.KSSettingsPage.OnPageConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnHideSection(struct UKSSettingsSection* SettingsSection); // Function KillstreakUINew.KSSettingsPage.OnHideSection // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UKSSettingsSection*> GetSettingsSections(); // Function KillstreakUINew.KSSettingsPage.GetSettingsSections // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2169370
	struct UScrollBox* GetScrollBox(); // Function KillstreakUINew.KSSettingsPage.GetScrollBox // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void AddSettingsSectionWidget(struct UKSSettingsSection* SettingsSection); // Function KillstreakUINew.KSSettingsPage.AddSettingsSectionWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSSettingsPreview
// Size: 0x530 (Inherited: 0x518)
struct UKSSettingsPreview : UKSWidget {
	struct FMulticastInlineDelegate OnPreviewValueChanged; // 0x518(0x10)
	struct UKSSettingsInfoBase* SettingsInfo; // 0x528(0x08)

	void HandleOnValueChanged(bool ChangedExternally); // Function KillstreakUINew.KSSettingsPreview.HandleOnValueChanged // (Final|Native|Private) // @ game+0x2173040
	void HandleOnPreviewValueChanged(); // Function KillstreakUINew.KSSettingsPreview.HandleOnPreviewValueChanged // (Final|Native|Private) // @ game+0x2173020
};

// Class KillstreakUINew.KSSettingsSection
// Size: 0x538 (Inherited: 0x518)
struct UKSSettingsSection : UKSWidget {
	struct TArray<struct UKSSettingsGroup*> SettingsGroups; // 0x518(0x10)
	struct UKSSettingsGroup* SettingsGroupClass; // 0x528(0x08)
	struct UKSSettingsSectionConfigAsset* SectionConfigAsset; // 0x530(0x08)

	void OnShowGroup(struct UKSSettingsGroup* SettingsGroup); // Function KillstreakUINew.KSSettingsSection.OnShowGroup // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnSectionConfigSet(); // Function KillstreakUINew.KSSettingsSection.OnSectionConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnHideGroup(struct UKSSettingsGroup* SettingsGroup); // Function KillstreakUINew.KSSettingsSection.OnHideGroup // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UKSSettingsGroup*> GetSettingsGroups(); // Function KillstreakUINew.KSSettingsSection.GetSettingsGroups // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2169370
	void AddSettingsGroupWidget(struct UKSSettingsGroup* SettingsGroup); // Function KillstreakUINew.KSSettingsSection.AddSettingsGroupWidget // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSSettingsWidget
// Size: 0x570 (Inherited: 0x518)
struct UKSSettingsWidget : UKSWidget {
	struct FKSSettingsWidgetConfig WidgetConfig; // 0x518(0x10)
	struct FText WidgetContainerTitle; // 0x528(0x18)
	struct FText WidgetContainerDescription; // 0x540(0x18)
	bool bHasPreview; // 0x558(0x01)
	char pad_559[0x7]; // 0x559(0x07)
	struct UKSSettingsPreview* WidgetContainerPreviewWidget; // 0x560(0x08)
	struct UKSSettingsInfoBase* SettingsInfo; // 0x568(0x08)

	void SaveSetting(); // Function KillstreakUINew.KSSettingsWidget.SaveSetting // (Final|Native|Public|BlueprintCallable) // @ game+0x2173460
	void RevertSetting(); // Function KillstreakUINew.KSSettingsWidget.RevertSetting // (Final|Native|Public|BlueprintCallable) // @ game+0x2173440
	void OnWidgetSettingsInfoSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetSettingsInfoSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnWidgetContainerTitleSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetContainerTitleSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnWidgetContainerPreviewSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetContainerPreviewSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnWidgetContainerDescriptionSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetContainerDescriptionSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnWidgetConfigSet(); // Function KillstreakUINew.KSSettingsWidget.OnWidgetConfigSet // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnSettingsInfoValueChanged(bool bChangedExternally); // Function KillstreakUINew.KSSettingsWidget.OnSettingsInfoValueChanged // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnInputAttached(bool bGamepadAttached, bool bMouseAttached); // Function KillstreakUINew.KSSettingsWidget.OnInputAttached // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool IsSaved(); // Function KillstreakUINew.KSSettingsWidget.IsSaved // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2173140
	bool IsApplied(); // Function KillstreakUINew.KSSettingsWidget.IsApplied // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2173110
	bool HasPreview(); // Function KillstreakUINew.KSSettingsWidget.HasPreview // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21730f0
	bool CanGamepadNavigate(); // Function KillstreakUINew.KSSettingsWidget.CanGamepadNavigate // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x21727a0
	void ApplySetting(); // Function KillstreakUINew.KSSettingsWidget.ApplySetting // (Final|Native|Public|BlueprintCallable) // @ game+0x21726d0
};

// Class KillstreakUINew.KSShopItemButtonBase
// Size: 0x560 (Inherited: 0x518)
struct UKSShopItemButtonBase : UKSWidget {
	struct FMulticastInlineDelegate OnShopSelection; // 0x518(0x10)
	struct FMulticastInlineDelegate OnShopViewItemDetails; // 0x528(0x10)
	struct FMulticastInlineDelegate OnItemSelected; // 0x538(0x10)
	struct FMulticastInlineDelegate OnItemViewDetails; // 0x548(0x10)
	enum class EShopItemType ActiveShopSlot; // 0x558(0x01)
	char pad_559[0x7]; // 0x559(0x07)

	struct UButton* GetHitTarget(); // Function KillstreakUINew.KSShopItemButtonBase.GetHitTarget // (Event|Protected|BlueprintEvent|Const) // @ game+0x24d5b40
	void DisplayShopItem(struct FShopItem ShopItem, bool IsAffordable, bool IsToggleSlot, bool IsSwapDisplay); // Function KillstreakUINew.KSShopItemButtonBase.DisplayShopItem // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ButtonUnhovered(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ButtonReleased(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonReleased // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ButtonPressed(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonPressed // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ButtonHovered(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonHovered // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ButtonClicked(); // Function KillstreakUINew.KSShopItemButtonBase.ButtonClicked // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSSideNavigationOverlay
// Size: 0x528 (Inherited: 0x518)
struct UKSSideNavigationOverlay : UKSWidget {
	char pad_518[0x10]; // 0x518(0x10)

	void HandleNavigateRight(); // Function KillstreakUINew.KSSideNavigationOverlay.HandleNavigateRight // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleNavigateLeft(); // Function KillstreakUINew.KSSideNavigationOverlay.HandleNavigateLeft // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void DisplayRightPreviewText(struct FText& PreviewText); // Function KillstreakUINew.KSSideNavigationOverlay.DisplayRightPreviewText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void DisplayLeftPreviewText(struct FText& PreviewText); // Function KillstreakUINew.KSSideNavigationOverlay.DisplayLeftPreviewText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void BroadcastNavigationAction(int32_t SideDirection); // Function KillstreakUINew.KSSideNavigationOverlay.BroadcastNavigationAction // (Final|Native|Public|BlueprintCallable) // @ game+0x21726f0
};

// Class KillstreakUINew.KSSocialPanelBase
// Size: 0x578 (Inherited: 0x518)
struct UKSSocialPanelBase : UKSWidget {
	struct FMulticastInlineDelegate OnDataReady; // 0x518(0x10)
	struct FMulticastInlineDelegate OnPlayerCardClicked; // 0x528(0x10)
	struct FMulticastInlineDelegate OnSocialHeaderClicked; // 0x538(0x10)
	struct UTreeView* TreeView; // 0x548(0x08)
	struct UKSSocialOverlay* DataSource; // 0x550(0x08)
	char pad_558[0x10]; // 0x558(0x10)
	struct TArray<struct UKSDataSocialCategory*> CategoriesList; // 0x568(0x10)

	void UpdateListData(); // Function KillstreakUINew.KSSocialPanelBase.UpdateListData // (Native|Protected) // @ game+0x21416e0
	void SetupTreeView(struct UTreeView* List); // Function KillstreakUINew.KSSocialPanelBase.SetupTreeView // (Final|Native|Public|BlueprintCallable) // @ game+0x21735a0
	void SetDataSource(struct UKSSocialOverlay* Source); // Function KillstreakUINew.KSSocialPanelBase.SetDataSource // (Final|Native|Public|BlueprintCallable) // @ game+0x2173520
	void OnDataChange(struct TArray<enum class EKSSocialOverlaySection>& Sections); // Function KillstreakUINew.KSSocialPanelBase.OnDataChange // (Native|Protected|HasOutParms) // @ game+0x21731a0
	struct UTreeView* GetTreeView(); // Function KillstreakUINew.KSSocialPanelBase.GetTreeView // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172ee0
	void GetSubListFromData(struct UObject* Source, struct TArray<struct UObject*>& Out_List); // Function KillstreakUINew.KSSocialPanelBase.GetSubListFromData // (Final|Native|Protected|HasOutParms) // @ game+0x2172df0
	struct UKSSocialOverlay* GetDataSource(); // Function KillstreakUINew.KSSocialPanelBase.GetDataSource // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172bb0
};

// Class KillstreakUINew.KSSocialFriendsPanel
// Size: 0x590 (Inherited: 0x578)
struct UKSSocialFriendsPanel : UKSSocialPanelBase {
	struct TArray<struct UKSDataSocialCategory*> CategoryData; // 0x578(0x10)
	struct UKSSocialOverlay* Parent; // 0x588(0x08)
};

// Class KillstreakUINew.KSSocialOverlay
// Size: 0x5b8 (Inherited: 0x518)
struct UKSSocialOverlay : UKSWidget {
	struct FMulticastInlineDelegate OnDataChanged; // 0x518(0x10)
	struct TArray<struct UKSDataSocialCategory*> CategoriesList; // 0x528(0x10)
	char pad_538[0x8]; // 0x538(0x08)
	struct TMap<struct TWeakObjectPtr<struct UKSPlayerInfo>, enum class EKSSocialOverlaySection> PlayerCategoryMap; // 0x540(0x50)
	struct TArray<struct TWeakObjectPtr<struct UKSPlayerInfo>> PlayersToUpdate; // 0x590(0x10)
	char pad_5A0[0x8]; // 0x5a0(0x08)
	struct TArray<struct UKSDataSocialPlayer*> UnusedEntries; // 0x5a8(0x10)

	void RepopulateAll(); // Function KillstreakUINew.KSSocialOverlay.RepopulateAll // (Final|Native|Private|BlueprintCallable) // @ game+0x2173420
	void PlayTransition(struct UWidgetAnimation* Animation, bool TransitionOut); // Function KillstreakUINew.KSSocialOverlay.PlayTransition // (Final|Native|Public|BlueprintCallable) // @ game+0x2173350
	void OnRecentlyPlayedChange(struct UKSFriendDataFactory* Source); // Function KillstreakUINew.KSSocialOverlay.OnRecentlyPlayedChange // (Final|Native|Public) // @ game+0x2173270
	void HandleUpdatePlayers(); // Function KillstreakUINew.KSSocialOverlay.HandleUpdatePlayers // (Final|Native|Public) // @ game+0x21730d0
	struct TArray<struct UKSDataSocialCategory*> GetData(); // Function KillstreakUINew.KSSocialOverlay.GetData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172b80
	struct UKSDataSocialCategory* GetCategory(enum class EKSSocialOverlaySection Category); // Function KillstreakUINew.KSSocialOverlay.GetCategory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172af0
	struct TArray<struct UKSDataSocialCategory*> GetCategories(struct TArray<enum class EKSSocialOverlaySection> Categories); // Function KillstreakUINew.KSSocialOverlay.GetCategories // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21729c0
};

// Class KillstreakUINew.KSSocialSearchPanel
// Size: 0x5c0 (Inherited: 0x578)
struct UKSSocialSearchPanel : UKSSocialPanelBase {
	struct FMulticastInlineDelegate OnOpen; // 0x578(0x10)
	struct FMulticastInlineDelegate OnClose; // 0x588(0x10)
	char pad_598[0x28]; // 0x598(0x28)

	void OnSearchTimeout(); // Function KillstreakUINew.KSSocialSearchPanel.OnSearchTimeout // (Final|Native|Private) // @ game+0x2173330
	void OnSearchStart(struct FText& SearchTerm); // Function KillstreakUINew.KSSocialSearchPanel.OnSearchStart // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void OnSearchComplete(struct FText& SearchTerm, struct FText& Error, struct TArray<struct UKSDataSocialPlayer*>& Results); // Function KillstreakUINew.KSSocialSearchPanel.OnSearchComplete // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void OnOverlayClosed(); // Function KillstreakUINew.KSSocialSearchPanel.OnOverlayClosed // (Final|Native|Public|BlueprintCallable) // @ game+0x2173250
	bool IsSearching(); // Function KillstreakUINew.KSSocialSearchPanel.IsSearching // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2173170
	struct FText GetActiveSearchTerm(); // Function KillstreakUINew.KSSocialSearchPanel.GetActiveSearchTerm // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172910
	void DoSearch(struct FText SearchTerm); // Function KillstreakUINew.KSSocialSearchPanel.DoSearch // (Final|Native|Public|BlueprintCallable) // @ game+0x2172830
};

// Class KillstreakUINew.KSSocialWidgetBase
// Size: 0x520 (Inherited: 0x518)
struct UKSSocialWidgetBase : UKSWidget {
	struct UKSPartyDataFactory* CachedPartyDataFactory; // 0x518(0x08)

	void SortFriendData(struct TArray<struct UPUMG_PlayerInfo*>& Friends); // Function KillstreakUINew.KSSocialWidgetBase.SortFriendData // (Final|Native|Protected|HasOutParms) // @ game+0x2173620
	void SearchPlayerName(struct FString PlayerName); // Function KillstreakUINew.KSSocialWidgetBase.SearchPlayerName // (Final|Native|Protected|BlueprintCallable) // @ game+0x2173480
	void OnFriendRequestsUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.OnFriendRequestsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleSearchByNameResultsUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.HandleSearchByNameResultsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandlePartyDataUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.HandlePartyDataUpdated // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleFriendInviteReceived(struct FPUMG_FriendData PlayerData); // Function KillstreakUINew.KSSocialWidgetBase.HandleFriendInviteReceived // (Final|Native|Protected) // @ game+0x2172f00
	void HandleFriendDataUpdated(); // Function KillstreakUINew.KSSocialWidgetBase.HandleFriendDataUpdated // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UPUMG_PlayerInfo*> GetSortedFriends(); // Function KillstreakUINew.KSSocialWidgetBase.GetSortedFriends // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2172d70
	struct TArray<struct UPUMG_PlayerInfo*> GetSearchResults(); // Function KillstreakUINew.KSSocialWidgetBase.GetSearchResults // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2172c60
	struct UKSPlayerWhoDataFactory* GetPlayerWhoDataFactory(); // Function KillstreakUINew.KSSocialWidgetBase.GetPlayerWhoDataFactory // (Final|Native|Protected) // @ game+0x2172c30
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSSocialWidgetBase.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2172c00
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSSocialWidgetBase.GetFriendDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2172bd0
	void ClearSearchResults(); // Function KillstreakUINew.KSSocialWidgetBase.ClearSearchResults // (Final|Native|Protected|BlueprintCallable) // @ game+0x21727f0
};

// Class KillstreakUINew.KSSortableGridPanel
// Size: 0x170 (Inherited: 0x158)
struct UKSSortableGridPanel : UGridPanel {
	enum class EOrientation Orientation; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	struct FDelegate OnSortCompareChildrenEvent; // 0x15c(0x10)
	char pad_16C[0x4]; // 0x16c(0x04)

	bool SortChildrenComparator__DelegateSignature(struct UWidget* LHS, struct UWidget* RHS); // DelegateFunction KillstreakUINew.KSSortableGridPanel.SortChildrenComparator__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void SortChildren(); // Function KillstreakUINew.KSSortableGridPanel.SortChildren // (Final|Native|Public|BlueprintCallable) // @ game+0x21794b0
	struct UGridSlot* AddChildAutoLayout(struct UWidget* Content); // Function KillstreakUINew.KSSortableGridPanel.AddChildAutoLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x2176fc0
};

// Class KillstreakUINew.KSSortableVerticalBox
// Size: 0x148 (Inherited: 0x138)
struct UKSSortableVerticalBox : UVerticalBox {
	struct FDelegate OnSortCompareChildrenEvent; // 0x138(0x10)

	bool SortChildrenComparator__DelegateSignature(struct UWidget* LHS, struct UWidget* RHS); // DelegateFunction KillstreakUINew.KSSortableVerticalBox.SortChildrenComparator__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void SortChildren(); // Function KillstreakUINew.KSSortableVerticalBox.SortChildren // (Final|Native|Public|BlueprintCallable) // @ game+0x21794d0
};

// Class KillstreakUINew.KSStorePanelItem
// Size: 0x50 (Inherited: 0x28)
struct UKSStorePanelItem : UObject {
	struct UPUMG_StoreItem* StoreItem; // 0x28(0x08)
	bool IsNew; // 0x30(0x01)
	bool DisplaySaleTag; // 0x31(0x01)
	bool HasBeenSeen; // 0x32(0x01)
	char pad_33[0x5]; // 0x33(0x05)
	struct FText CustomBannerText; // 0x38(0x18)

	bool IsOnSale(); // Function KillstreakUINew.KSStorePanelItem.IsOnSale // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2178b10
};

// Class KillstreakUINew.KSStoreSectionItem
// Size: 0x50 (Inherited: 0x28)
struct UKSStoreSectionItem : UObject {
	struct TArray<struct UKSStorePanelItem*> StorePanelItems; // 0x28(0x10)
	int32_t column; // 0x38(0x04)
	int32_t Row; // 0x3c(0x04)
	enum class EStoreItemWidgetType WidgetType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct UKSStorePanelItem* CurrentlyViewedItem; // 0x48(0x08)

	bool HasUnseenItems(); // Function KillstreakUINew.KSStoreSectionItem.HasUnseenItems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2178a50
};

// Class KillstreakUINew.KSStoreSection
// Size: 0x60 (Inherited: 0x28)
struct UKSStoreSection : UObject {
	struct TArray<struct UKSStoreSectionItem*> SectionItems; // 0x28(0x10)
	enum class EStoreSectionTypes SectionType; // 0x38(0x01)
	char pad_39[0x27]; // 0x39(0x27)

	bool HasUnseenItems(); // Function KillstreakUINew.KSStoreSection.HasUnseenItems // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2178a20
	struct FText GetSectionHeader(); // Function KillstreakUINew.KSStoreSection.GetSectionHeader // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2177bd0
	int32_t GetSecondsRemaining(); // Function KillstreakUINew.KSStoreSection.GetSecondsRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2177ba0
};

// Class KillstreakUINew.KSStoreWidget
// Size: 0x520 (Inherited: 0x518)
struct UKSStoreWidget : UKSWidget {
	char pad_518[0x8]; // 0x518(0x08)

	void OnVendorsReceived(int32_t GroupId, struct TArray<int32_t>& VendorIds); // Function KillstreakUINew.KSStoreWidget.OnVendorsReceived // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void OnPricePointsReveived(); // Function KillstreakUINew.KSStoreWidget.OnPricePointsReveived // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnPortalOffersReceived(); // Function KillstreakUINew.KSStoreWidget.OnPortalOffersReceived // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool HasAllRequiredStoreInformation(); // Function KillstreakUINew.KSStoreWidget.HasAllRequiredStoreInformation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21789f0
	int32_t GetStoreRotationSecondsRemaining(); // Function KillstreakUINew.KSStoreWidget.GetStoreRotationSecondsRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2177cf0
	struct TArray<struct UKSStoreSection*> GetStoreLayout(); // Function KillstreakUINew.KSStoreWidget.GetStoreLayout // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2177c70
	struct UKSStoreItemHelper* GetStoreItemHelper(); // Function KillstreakUINew.KSStoreWidget.GetStoreItemHelper // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x215afe0
};

// Class KillstreakUINew.KSTargetMarkerWidget
// Size: 0x370 (Inherited: 0x328)
struct UKSTargetMarkerWidget : UKSScreenMarkerWidgetBase {
	struct FMulticastInlineDelegate OnTargetChanged; // 0x328(0x10)
	struct FMulticastInlineDelegate OnModUsed; // 0x338(0x10)
	struct AActor* CurrentTarget; // 0x348(0x08)
	struct UKSModInst_Activated* TargetModInst; // 0x350(0x08)
	struct TScriptInterface<IKSTargeter> Targeter; // 0x358(0x10)
	char pad_368[0x8]; // 0x368(0x08)

	void UpdateCharge(struct UKSModInst_Activated* ModInst); // Function KillstreakUINew.KSTargetMarkerWidget.UpdateCharge // (Final|Native|Public) // @ game+0x2179af0
	void TryApplyViewState(enum class ETargetMarkerViewState ViewState, bool bForce); // Function KillstreakUINew.KSTargetMarkerWidget.TryApplyViewState // (Final|Native|Protected|BlueprintCallable) // @ game+0x21796a0
	void ReceiveNewTarget(struct TScriptInterface<IKSTargeter> InTargeter, struct AActor* NewTarget); // Function KillstreakUINew.KSTargetMarkerWidget.ReceiveNewTarget // (Final|Native|Public) // @ game+0x21791c0
	void OnGamepadSelectedChanged(int32_t NewSelectionIndex); // Function KillstreakUINew.KSTargetMarkerWidget.OnGamepadSelectedChanged // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	enum class ETargetMarkerViewState GetCurrentViewState(); // Function KillstreakUINew.KSTargetMarkerWidget.GetCurrentViewState // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21777c0
	void BindTargetModInst(); // Function KillstreakUINew.KSTargetMarkerWidget.BindTargetModInst // (Native|Event|Protected|BlueprintEvent) // @ game+0xb59fe0
	void ApplyViewState(enum class ETargetMarkerViewState ViewState); // Function KillstreakUINew.KSTargetMarkerWidget.ApplyViewState // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSTextChatWidget
// Size: 0x558 (Inherited: 0x518)
struct UKSTextChatWidget : UKSWidget {
	struct TArray<enum class EMercCosmeticSlot> RadialMenuItemsToShowInChat; // 0x518(0x10)
	bool ActiveChatChannelsDirty; // 0x528(0x01)
	char pad_529[0x7]; // 0x529(0x07)
	struct TArray<struct FPUMG_ActiveChatChannelData> ActiveChatChannels; // 0x530(0x10)
	int32_t CurrentChatChannelIndex; // 0x540(0x04)
	char pad_544[0x4]; // 0x544(0x04)
	struct FMulticastInlineDelegate OnCurrentChatChannelChanged; // 0x548(0x10)

	void Whisper(struct FString PlayerName, struct FString Message); // Function KillstreakUINew.KSTextChatWidget.Whisper // (Final|Native|Protected) // @ game+0x2179b70
	void Unblock(struct FString PlayerName); // Function KillstreakUINew.KSTextChatWidget.Unblock // (Final|Native|Protected) // @ game+0x2177050
	void UIX_SubmitTextInput(struct FString Message); // Function KillstreakUINew.KSTextChatWidget.UIX_SubmitTextInput // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179a50
	void UIX_SendMessageToPlayer(struct FString Message, int64_t PlayerId); // Function KillstreakUINew.KSTextChatWidget.UIX_SendMessageToPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179970
	void UIX_SendMessageToChannel(struct FString Message, enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.UIX_SendMessageToChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179890
	void UIX_MarkMessageAsRead(int32_t MessageIndex); // Function KillstreakUINew.KSTextChatWidget.UIX_MarkMessageAsRead // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179810
	void UIX_ExecuteChatCommandLine(struct FString CommandLine); // Function KillstreakUINew.KSTextChatWidget.UIX_ExecuteChatCommandLine // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179770
	void ToggleDND(); // Function KillstreakUINew.KSTextChatWidget.ToggleDND // (Final|Native|Protected) // @ game+0x2179680
	void ShowTextChat(); // Function KillstreakUINew.KSTextChatWidget.ShowTextChat // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2139670
	bool SetChatChannelToPlayer(int64_t PlayerId); // Function KillstreakUINew.KSTextChatWidget.SetChatChannelToPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179400
	bool SetChatChannel(enum class EPUMG_ChatChannel Channel, int64_t PersonalChannelPlayerId); // Function KillstreakUINew.KSTextChatWidget.SetChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179340
	void Reply(struct FString Message); // Function KillstreakUINew.KSTextChatWidget.Reply // (Final|Native|Protected) // @ game+0x21792a0
	void ProcessMessageOnClient(struct FText& Message, enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.ProcessMessageOnClient // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x21790a0
	void PreviousChatChannel(); // Function KillstreakUINew.KSTextChatWidget.PreviousChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179080
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function KillstreakUINew.KSTextChatWidget.OpenTextChatToPlayer // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2150ab0
	void OpenTextChat(bool BeginChatCommand); // Function KillstreakUINew.KSTextChatWidget.OpenTextChat // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x2178e40
	void NextChatChannel(); // Function KillstreakUINew.KSTextChatWidget.NextChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2178b60
	bool IsActiveChatChannel(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.IsActiveChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2178a80
	void HandleChatMessageReceived(struct FPUMG_ChatData& ReceivedMessage); // Function KillstreakUINew.KSTextChatWidget.HandleChatMessageReceived // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2177f00
	void HandleChatMessageRead(struct FPUMG_ChatData& ReadMessage); // Function KillstreakUINew.KSTextChatWidget.HandleChatMessageRead // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2177e10
	void HandleChatChannelLeft(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.HandleChatChannelLeft // (Native|Event|Protected|BlueprintEvent) // @ game+0x2162360
	void HandleChatChannelJoined(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.HandleChatChannelJoined // (Native|Event|Protected|BlueprintEvent) // @ game+0x2177d90
	struct FPUMG_ActiveChatChannelData GetCurrentChatChannel(); // Function KillstreakUINew.KSTextChatWidget.GetCurrentChatChannel // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177790
	struct UKSChatDataFactory* GetChatDataFactory(); // Function KillstreakUINew.KSTextChatWidget.GetChatDataFactory // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177760
	struct TArray<struct FPUMG_ActiveChatChannelData> GetActiveChatChannels(); // Function KillstreakUINew.KSTextChatWidget.GetActiveChatChannels // (Final|Native|Protected|BlueprintCallable) // @ game+0x21776a0
	bool CanChatInChannel(enum class EPUMG_ChatChannel Channel); // Function KillstreakUINew.KSTextChatWidget.CanChatInChannel // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x21770f0
	void Block(struct FString PlayerName); // Function KillstreakUINew.KSTextChatWidget.Block // (Final|Native|Protected) // @ game+0x2177050
};

// Class KillstreakUINew.KSToastNotificationWidgetBase
// Size: 0x558 (Inherited: 0x518)
struct UKSToastNotificationWidgetBase : UKSWidget {
	struct FMulticastInlineDelegate OnToastReceived; // 0x518(0x10)
	int32_t MaxToastNotification; // 0x528(0x04)
	int32_t CurrentToastCount; // 0x52c(0x04)
	bool IsBusy; // 0x530(0x01)
	char pad_531[0x7]; // 0x531(0x07)
	struct TArray<struct FToastData> ToastQueue; // 0x538(0x10)
	struct TArray<struct FToastData> PostMatchToasts; // 0x548(0x10)

	void TestDisplayChallengeNotification(); // Function KillstreakUINew.KSToastNotificationWidgetBase.TestDisplayChallengeNotification // (Final|Native|Protected) // @ game+0xa6a770
	void StoreToastQueue(struct FToastData ToastNotification); // Function KillstreakUINew.KSToastNotificationWidgetBase.StoreToastQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x21794f0
	void ShowToastNotification(); // Function KillstreakUINew.KSToastNotificationWidgetBase.ShowToastNotification // (Final|Native|Protected|BlueprintCallable) // @ game+0x2179490
	void OnWeaponMilestoneCompleted(struct UKSActivityInstance* Activity, int32_t Tier, int32_t Count); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnWeaponMilestoneCompleted // (Final|Native|Protected) // @ game+0x2178d40
	void OnToastNotificationReceived(struct FToastData ToastData); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnToastNotificationReceived // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnChallengeCompleted(struct UKSActivityInstance* Activity); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnChallengeCompleted // (Final|Native|Protected) // @ game+0x2178cc0
	void OnAwardsCompleted(struct UKSActivityInstance* Activity); // Function KillstreakUINew.KSToastNotificationWidgetBase.OnAwardsCompleted // (Final|Native|Protected) // @ game+0x2178bc0
	void NotifyToastShown(); // Function KillstreakUINew.KSToastNotificationWidgetBase.NotifyToastShown // (Final|Native|Protected|BlueprintCallable) // @ game+0x2178ba0
	void NotifyToastHidden(); // Function KillstreakUINew.KSToastNotificationWidgetBase.NotifyToastHidden // (Final|Native|Protected|BlueprintCallable) // @ game+0x2178b80
	void HandlePartyMemberPromoted(int64_t PlayerId); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberPromoted // (Final|Native|Protected) // @ game+0x2178970
	void HandlePartyMemberLeftGeneric(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberLeftGeneric // (Final|Native|Protected) // @ game+0x2178950
	void HandlePartyMemberLeft(struct FPUMG_PartyMemberData PartyMemberData); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberLeft // (Final|Native|Protected) // @ game+0x2178820
	void HandlePartyMemberKick(int64_t PlayerId); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberKick // (Final|Native|Protected) // @ game+0x21787a0
	void HandlePartyMemberAdded(struct FPUMG_PartyMemberData PartyMemberData); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyMemberAdded // (Final|Native|Protected) // @ game+0x2178670
	void HandlePartyLocalPlayerLeft(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyLocalPlayerLeft // (Final|Native|Protected) // @ game+0x2178650
	void HandlePartyInviteSent(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteSent // (Final|Native|Protected) // @ game+0x2178570
	void HandlePartyInviteRejected(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteRejected // (Final|Native|Protected) // @ game+0x2178550
	void HandlePartyInviteReceived(struct UPUMG_PlayerInfo* PartyInviter); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteReceived // (Final|Native|Protected) // @ game+0x21784d0
	void HandlePartyInviteError(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteError // (Final|Native|Protected) // @ game+0x21783f0
	void HandlePartyInviteAccepted(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyInviteAccepted // (Final|Native|Protected) // @ game+0x21783d0
	void HandlePartyDisbanded(); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandlePartyDisbanded // (Final|Native|Protected) // @ game+0x21783b0
	void HandleFriendRejected(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendRejected // (Final|Native|Protected) // @ game+0x21782d0
	void HandleFriendInviteReceived(struct FPUMG_FriendData PlayerData); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendInviteReceived // (Final|Native|Protected) // @ game+0x21781b0
	void HandleFriendAddSuccess(struct FString PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendAddSuccess // (Final|Native|Protected) // @ game+0x2177ff0
	void HandleFriendAdded(struct FText PlayerName); // Function KillstreakUINew.KSToastNotificationWidgetBase.HandleFriendAdded // (Final|Native|Protected) // @ game+0x21780d0
	struct UKSWeaponMasteryManager* GetWeaponMasteryManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetWeaponMasteryManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2177d60
	struct TArray<struct FToastData> GetPostMatchToasts(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPostMatchToasts // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x21779b0
	struct UKSPlayerChallengesManager* GetPlayerChallengesManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPlayerChallengesManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2177980
	struct UKSAwardsManager* GetPlayerAwardsManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPlayerAwardsManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2177950
	struct UKSPartyDataFactory* GetPartyDataFactory(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetPartyDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2150f40
	bool GetNext(struct FToastData& NextToastNotification); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetNext // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x2177810
	struct UKSFriendDataFactory* GetFriendDataFactory(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetFriendDataFactory // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2172bd0
	struct UKSEventChallengesManager* GetEventChallengesManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetEventChallengesManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x21777e0
	struct UKSBattlePassProgressionManager* GetBattlePassProgressionManager(); // Function KillstreakUINew.KSToastNotificationWidgetBase.GetBattlePassProgressionManager // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0x2177730
	void CreatePlayerLevelUpToasts(struct UKSActivityInstance* PlayerLevelActivityInstance, struct FActivityTier TierObtained); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreatePlayerLevelUpToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177580
	void CreateMiniBattlePassTierUnlockToasts(struct UKSActivityInstance* MiniBattlePassActivityInstance, struct FActivityTier TierObtained); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateMiniBattlePassTierUnlockToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177460
	void CreateMercMasteryLevelUpToasts(struct UKSActivityInstance* MercMasteryActivityInstance, struct FActivityTier TierObtained); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateMercMasteryLevelUpToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177340
	void CreateEventChallengeCompleteToasts(struct UKSActivityInstance* EventChallengeActivityInstance); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateEventChallengeCompleteToasts // (Final|Native|Protected|BlueprintCallable) // @ game+0x21772c0
	void CreateBoostActivationToastBySpentItem(struct UPlatformInventoryItem* SpentItem); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateBoostActivationToastBySpentItem // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177240
	void CreateBoostActivationToastByAcquisition(struct UPUMG_StoreItem* AcquisitionItem); // Function KillstreakUINew.KSToastNotificationWidgetBase.CreateBoostActivationToastByAcquisition // (Final|Native|Protected|BlueprintCallable) // @ game+0x21771c0
	void ClearPostMatchQueue(); // Function KillstreakUINew.KSToastNotificationWidgetBase.ClearPostMatchQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x21771a0
	void ClearNotificationQueue(); // Function KillstreakUINew.KSToastNotificationWidgetBase.ClearNotificationQueue // (Final|Native|Protected|BlueprintCallable) // @ game+0x2177180
};

// Class KillstreakUINew.KSTopBarStatusIconInterface
// Size: 0x28 (Inherited: 0x28)
struct UKSTopBarStatusIconInterface : UInterface {

	void UnbindEventFromTopBarStatusIconShowingChanged(struct FDelegate& Callback); // Function KillstreakUINew.KSTopBarStatusIconInterface.UnbindEventFromTopBarStatusIconShowingChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool IsInTopBarStatusIconShowingState(); // Function KillstreakUINew.KSTopBarStatusIconInterface.IsInTopBarStatusIconShowingState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct UTexture2D* GetTopBarStatusIconTexture(); // Function KillstreakUINew.KSTopBarStatusIconInterface.GetTopBarStatusIconTexture // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BindEventToTopBarStatusIconShowingChanged(struct FDelegate& Callback); // Function KillstreakUINew.KSTopBarStatusIconInterface.BindEventToTopBarStatusIconShowingChanged // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSTouchHudWidget
// Size: 0x568 (Inherited: 0x518)
struct UKSTouchHudWidget : UKSWidget {
	bool bAlwaysShowQuickMelee; // 0x518(0x01)
	bool bIsInEditMode; // 0x519(0x01)
	char pad_51A[0x6]; // 0x51a(0x06)
	struct UKSWeaponAsset_Melee* QuickMeleeWeaponAsset; // 0x520(0x08)
	struct UWidget* MyFireWidget; // 0x528(0x08)
	struct UWidget* MyMeleeWidget; // 0x530(0x08)
	struct UWidget* MyGrenadeWidget; // 0x538(0x08)
	struct UWidget* MyQuickMeleeWidget; // 0x540(0x08)
	struct UImage* MyAimDownSightsWidget; // 0x548(0x08)
	struct UTexture2D* AimDownSightsEnableIcon; // 0x550(0x08)
	struct UTexture2D* AimDownSightsCancelIcon; // 0x558(0x08)
	struct UWidget* MyPingWidget; // 0x560(0x08)

	void UpdateQuickMeleeRadius(); // Function KillstreakUINew.KSTouchHudWidget.UpdateQuickMeleeRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x217eb30
	void UpdatePrimaryWeaponButton(); // Function KillstreakUINew.KSTouchHudWidget.UpdatePrimaryWeaponButton // (Final|Native|Public|BlueprintCallable) // @ game+0x217eb10
	void SetWidgetIconTexture(struct UWidget* Widget, struct FSoftObjectPath& Texture); // Function KillstreakUINew.KSTouchHudWidget.SetWidgetIconTexture // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x217e620
};

// Class KillstreakUINew.KSTreeView
// Size: 0x3e0 (Inherited: 0x3d8)
struct UKSTreeView : UTreeView {
	struct TWeakObjectPtr<struct APUMG_HUD> MyHud; // 0x3d8(0x08)

	void UninitializeWidget(); // Function KillstreakUINew.KSTreeView.UninitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x217eaf0
	void NavigateSelectItem(struct UObject* Item); // Function KillstreakUINew.KSTreeView.NavigateSelectItem // (Final|Native|Public|BlueprintCallable) // @ game+0x217e1f0
	bool IsItemExpanded(struct UObject* Item); // Function KillstreakUINew.KSTreeView.IsItemExpanded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x217dc60
	void InitializeWidget(); // Function KillstreakUINew.KSTreeView.InitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x217d980
	int32_t GetNumItemsInLayout(); // Function KillstreakUINew.KSTreeView.GetNumItemsInLayout // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x217ce70
	bool BP_GetEntryWidgetFromItem(struct UObject* Item, struct UUserWidget*& OutWidget); // Function KillstreakUINew.KSTreeView.BP_GetEntryWidgetFromItem // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x217bd30
};

// Class KillstreakUINew.KSUIBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKSUIBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	bool UIX_ReportPlayer(struct UObject* WorldContextObject, struct FReportPlayerParams& Params); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.UIX_ReportPlayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217e9d0
	struct FReportPlayerParams SetupReportPlayerFromScoreboardStats(int64_t PlayerId, struct FScoreboardStats& State, struct APUMG_HUD* InHud); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.SetupReportPlayerFromScoreboardStats // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217e820
	struct FReportPlayerParams SetupReportPlayerFromGameState(int64_t PlayerId, struct AKSGameState* State); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.SetupReportPlayerFromGameState // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217e710
	void SetHiddenCursorMode(struct UObject* WorldContextObject, struct APlayerController* PlayerController, bool ShouldHide); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.SetHiddenCursorMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217e520
	void ResetHiddenCursorMode(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.ResetHiddenCursorMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217e470
	void RegisterGridNavigation(struct UPUMG_Widget* ParentWidget, int32_t FocusGroup, struct TArray<struct UWidget*> NavWidgets, int32_t GridWidth, bool NavToLastElementOnDown); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.RegisterGridNavigation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217e2a0
	bool MapCountToActivityTier(float InCount, struct FActivityTier ActivityTier, float& CountWithinTier, float& PercentWithinTier); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.MapCountToActivityTier // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x217dfe0
	struct FText Key_GetShortDisplayName(struct FKey& Key); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.Key_GetShortDisplayName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x217dec0
	bool IsPlayerRelevant(struct FJobSelectionEntry& Entry, struct AKSPlayerState* InPlayerState, bool bLockedInOnly); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsPlayerRelevant // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217dd90
	bool IsNewJob(int32_t RogueID); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsNewJob // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217dd10
	bool IsInsideMargins(struct UObject* WorldContextObject, struct FVector2D Translation, struct FVector2D Margins); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsInsideMargins // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x217db70
	bool IsInCenteredScreenRect(float PositionX, float PositionY, float MarginX, float MarginY); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsInCenteredScreenRect // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217da20
	bool IsExperimentActive(enum class EExperimentalFeatureName Feature); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.IsExperimentActive // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217d9a0
	struct FText GetTextByPlatform(struct FText& DefaultText, struct TMap<struct FString, struct FText>& PlatformTexts); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetTextByPlatform // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x217d7d0
	struct UKSStoreItemHelper* GetStoreItemHelper(struct UObject* WorldContextObject); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetStoreItemHelper // (Final|Native|Static|Public) // @ game+0x217d750
	enum class EJobSelectionState GetSelectionStateForPlayer(struct FJobSelectionEntry& Entry, struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetSelectionStateForPlayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217d650
	bool GetQueueName(struct FText& DisplayNameText); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetQueueName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217d580
	bool GetQueueDisplayName(struct FText& DisplayNameText, struct UObject* WorldContextObject); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetQueueDisplayName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217d460
	bool GetPlayerSelectInfo(struct FJobSelectionEntry& Entry, struct AKSPlayerState* InPlayerState, struct FPlayerJobSelectInfo& PlayerSelectInfo); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPlayerSelectInfo // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217d300
	struct UPUMG_PlayerInfo* GetPlayerInfoById(struct APUMG_HUD* HUD, int64_t PlayerId); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPlayerInfoById // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217d240
	bool GetPingIconByType(struct UDataTable* ContextualPingTypesDT, enum class EPingType PingType, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPingIconByType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x217d100
	bool GetPingIconByMessage(struct UDataTable* ContextualPingMessagesDT, enum class EPingMessage PingMessage, struct TSoftObjectPtr<UTexture2D>& PingIcon); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPingIconByMessage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x217cfc0
	bool GetPingColorByType(struct UDataTable* ContextualPingTypesDT, enum class EPingType PingType, struct FLinearColor& PingColor); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetPingColorByType // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x217ceb0
	int32_t GetNewJobId(); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetNewJobId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217ce40
	struct UPUMG_PlayerInfo* GetLocalPlayerInfo(struct APUMG_HUD* HUD); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetLocalPlayerInfo // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217cdc0
	struct FKey GetKeyForBinding(struct APlayerController* PlayerController, struct FName Binding, bool SecondaryKey, bool FallbackToDefault, bool IsGamepadDoubleTap); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetKeyForBinding // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217cbd0
	struct UKSItem* GetItemById(int32_t ItemId); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetItemById // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217cb50
	struct UKSWeaponAsset* GetHeroPrimaryWeapon(); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetHeroPrimaryWeapon // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217cb20
	struct TArray<int32_t> GetDigitsFromInt(int32_t Value); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetDigitsFromInt // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217ca60
	void GetCurrentRogueMasteryLevel(struct UKSActivityInstance* ActivityInstance, int32_t& MasteryLevel, int32_t& CurrentXPProgress, int32_t& XPRequiredForLevel); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetCurrentRogueMasteryLevel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x217c8f0
	struct UKSContextBarWidget* GetContextBar(struct APUMG_HUD* HUD); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.GetContextBar // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217c870
	struct UKSWeaponAsset* FindWeaponForAttachment(struct UObject* WorldContextObject, struct UKSWeaponAttachment* WeaponAttachment); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.FindWeaponForAttachment // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217c7b0
	bool FindContextualPingTypesRowByType(struct UDataTable* ContextualPingTypesDT, enum class EPingType PingType, struct FContextualPingTypesRow& ContextualPingTypesRow); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.FindContextualPingTypesRowByType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217c670
	bool FindContextualPingMessagesRowByMessage(struct UDataTable* ContextualPingMessagesDT, enum class EPingMessage PingMessage, struct FContextualPingMessagesRow& ContextualPingMessagesRow); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.FindContextualPingMessagesRowByMessage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217c530
	bool DistanceToClosestScreenEdge(struct UObject* WorldContextObject, struct FVector2D Location, float& OutDistX, float& OutDistY); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.DistanceToClosestScreenEdge // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x217c3d0
	enum class EJobSelectionState DetermineEntryLocalSelectionState(struct FJobSelectionEntry& Entry); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.DetermineEntryLocalSelectionState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217c320
	struct UKSSettingsWidget* CreateSettingsWidgetWithConfig(struct APUMG_HUD* HUD, struct FKSSettingsWidgetConfig SettingsWidgetConfig); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CreateSettingsWidgetWithConfig // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217c250
	struct UKSSettingsWidget* CreateSettingsWidget(struct APUMG_HUD* HUD, struct UKSSettingsWidget*& SettingsWidgetClass); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CreateSettingsWidget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217c180
	struct UKSSettingsPreview* CreateSettingsPreview(struct APUMG_HUD* HUD, struct UKSSettingsPreview*& SettingsPreviewClass); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CreateSettingsPreview // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217c0b0
	int32_t CompareStrings(struct FString LeftString, struct FString RightString); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CompareStrings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x217bfc0
	void ClearKeyboardFocus(); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.ClearKeyboardFocus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217bfa0
	bool CanReportServer(struct UObject* WorldContextObject); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CanReportServer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x217bf20
	bool CanPlayerSelectEntry(struct FJobSelectionEntry& Entry, struct AKSPlayerState* InPlayerState); // Function KillstreakUINew.KSUIBlueprintFunctionLibrary.CanPlayerSelectEntry // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x217be20
};

// Class KillstreakUINew.KSUISoundLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKSUISoundLibrary : UObject {
};

// Class KillstreakUINew.KSGenericSoundLibrary
// Size: 0x40 (Inherited: 0x28)
struct UKSGenericSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* BackToScreenSound; // 0x28(0x08)
	struct UAkAudioEvent* ErrorSound; // 0x30(0x08)
	struct UAkAudioEvent* ScreenTransitionSound; // 0x38(0x08)
};

// Class KillstreakUINew.KSButtonSoundLibrary
// Size: 0x40 (Inherited: 0x28)
struct UKSButtonSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* ButtonClicked; // 0x28(0x08)
	struct UAkAudioEvent* ButtonHovered; // 0x30(0x08)
	struct UAkAudioEvent* ButtonUnhovered; // 0x38(0x08)
};

// Class KillstreakUINew.KSScrollButtonSoundLibrary
// Size: 0x48 (Inherited: 0x28)
struct UKSScrollButtonSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* ScrollClicked; // 0x28(0x08)
	struct UAkAudioEvent* ScrollHovered; // 0x30(0x08)
	struct UAkAudioEvent* ScrollUnhovered; // 0x38(0x08)
	struct UAkAudioEvent* ScrollingSound; // 0x40(0x08)
};

// Class KillstreakUINew.KSShopSoundLibrary
// Size: 0x48 (Inherited: 0x28)
struct UKSShopSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* ShopOpen; // 0x28(0x08)
	struct UAkAudioEvent* ShopClose; // 0x30(0x08)
	struct UAkAudioEvent* PurchaseSucceeded; // 0x38(0x08)
	struct UAkAudioEvent* PurchaseFailed; // 0x40(0x08)
};

// Class KillstreakUINew.KSToastSoundLibrary
// Size: 0x48 (Inherited: 0x28)
struct UKSToastSoundLibrary : UKSUISoundLibrary {
	struct UAkAudioEvent* FriendToast; // 0x28(0x08)
	struct UAkAudioEvent* PartyToast; // 0x30(0x08)
	struct UAkAudioEvent* ErrorToast; // 0x38(0x08)
	struct UAkAudioEvent* InfoToast; // 0x40(0x08)
};

// Class KillstreakUINew.CommonVendorHelper
// Size: 0x28 (Inherited: 0x28)
struct UCommonVendorHelper : UObject {

	int32_t GetVendorIDFromEnum(enum class EKSVendorTypes VendorType); // Function KillstreakUINew.CommonVendorHelper.GetVendorIDFromEnum // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2182280
};

// Class KillstreakUINew.KSViewedActiveWeaponCompWidget
// Size: 0x5f0 (Inherited: 0x5e0)
struct UKSViewedActiveWeaponCompWidget : UKSActiveWeaponComponentWidget {
	char pad_5E0[0x10]; // 0x5e0(0x10)
};

// Class KillstreakUINew.KSViewedActiveGadgetWidget
// Size: 0x530 (Inherited: 0x520)
struct UKSViewedActiveGadgetWidget : UKSWeaponWidget {
	char pad_520[0x10]; // 0x520(0x10)
};

// Class KillstreakUINew.KSViewedActiveMedPackWidget
// Size: 0x530 (Inherited: 0x520)
struct UKSViewedActiveMedPackWidget : UKSWeaponWidget {
	char pad_520[0x10]; // 0x520(0x10)
};

// Class KillstreakUINew.KSViewedItemLabel
// Size: 0x560 (Inherited: 0x548)
struct UKSViewedItemLabel : UKSViewedPawnWidget {
	char pad_548[0x8]; // 0x548(0x08)
	bool UpdateViewLimitPosition; // 0x550(0x01)
	char pad_551[0x3]; // 0x551(0x03)
	struct FVector2D ViewLimitPosition; // 0x554(0x08)
	char pad_55C[0x4]; // 0x55c(0x04)

	void UpdateLabelPosition(); // Function KillstreakUINew.KSViewedItemLabel.UpdateLabelPosition // (Final|Native|Protected|BlueprintCallable) // @ game+0x2183310
	void UnbindToViewportResizeEvent(); // Function KillstreakUINew.KSViewedItemLabel.UnbindToViewportResizeEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x21832f0
	void TriggerLabelPositionUpdate(); // Function KillstreakUINew.KSViewedItemLabel.TriggerLabelPositionUpdate // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnLabelShow(); // Function KillstreakUINew.KSViewedItemLabel.OnLabelShow // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnLabelHide(); // Function KillstreakUINew.KSViewedItemLabel.OnLabelHide // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct UImage* GetViewLimitImage(); // Function KillstreakUINew.KSViewedItemLabel.GetViewLimitImage // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x21823d0
	struct AActor* GetTrackedActor(); // Function KillstreakUINew.KSViewedItemLabel.GetTrackedActor // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2154940
	struct UCanvasPanel* GetOutermostCanvasPanel(); // Function KillstreakUINew.KSViewedItemLabel.GetOutermostCanvasPanel // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2182060
	bool GetOnScreenPositionForLabel(struct APlayerController* Player, struct AActor* InActor, struct FBox2D& OutBounds); // Function KillstreakUINew.KSViewedItemLabel.GetOnScreenPositionForLabel // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2181f50
	struct UCanvasPanel* GetLabelCanvasPanel(); // Function KillstreakUINew.KSViewedItemLabel.GetLabelCanvasPanel // (Native|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2181f20
	void BindToViewportResizeEvent(); // Function KillstreakUINew.KSViewedItemLabel.BindToViewportResizeEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x2181de0
};

// Class KillstreakUINew.KSViewedPawnDamageDisplay
// Size: 0x5d8 (Inherited: 0x548)
struct UKSViewedPawnDamageDisplay : UKSViewedPawnWidget {
	float StackingWait; // 0x548(0x04)
	bool TetherToEventLocation; // 0x54c(0x01)
	char pad_54D[0x3]; // 0x54d(0x03)
	int32_t MaxNumDamageWidgetsOnScreen; // 0x550(0x04)
	char pad_554[0x4]; // 0x554(0x04)
	struct UCanvasPanel* DamageNumberContainer; // 0x558(0x08)
	struct TMap<struct UDamageType*, struct FSpecialDamageColors> SpecialDamageTypes; // 0x560(0x50)
	struct TArray<struct UDamageNumberDisplayWidget*> CurrentDamageNumbersOnScreen; // 0x5b0(0x10)
	struct TArray<struct UDamageNumberDisplayWidget*> DamageNumbersPool; // 0x5c0(0x10)
	char pad_5D0[0x8]; // 0x5d0(0x08)

	void PrimeDamageNumbersWidgetPool(); // Function KillstreakUINew.KSViewedPawnDamageDisplay.PrimeDamageNumbersWidgetPool // (Final|Native|Protected|BlueprintCallable) // @ game+0x2182e10
	void HandlePhaseChange(struct FMatchPhase NewPhase, struct FMatchPhase PreviousPhase); // Function KillstreakUINew.KSViewedPawnDamageDisplay.HandlePhaseChange // (Final|Native|Protected) // @ game+0x21827e0
	void HandleInstigateDamageNotify(struct FCombatEventInfo& DamageInfo); // Function KillstreakUINew.KSViewedPawnDamageDisplay.HandleInstigateDamageNotify // (Final|Native|Protected|HasOutParms) // @ game+0x21826d0
	void HandleAnimationCompleted(struct UDamageNumberDisplayWidget* DamageNumberWidget); // Function KillstreakUINew.KSViewedPawnDamageDisplay.HandleAnimationCompleted // (Final|Native|Protected) // @ game+0x2182630
	struct UDamageNumberDisplayWidget* GetDamageNumberWidgetInstance(); // Function KillstreakUINew.KSViewedPawnDamageDisplay.GetDamageNumberWidgetInstance // (Native|Event|Protected|BlueprintEvent) // @ game+0x2154940
	void ClearDamageNumbersOnScreen(); // Function KillstreakUINew.KSViewedPawnDamageDisplay.ClearDamageNumbersOnScreen // (Final|Native|Protected) // @ game+0x2181e20
};

// Class KillstreakUINew.DamageNumberDisplayWidget
// Size: 0x280 (Inherited: 0x238)
struct UDamageNumberDisplayWidget : UUserWidget {
	struct FMulticastInlineDelegate OnNumberAnimationComplete; // 0x238(0x10)
	struct AActor* DamageTarget; // 0x248(0x08)
	struct FVector InitialDamageLocation; // 0x250(0x0c)
	bool TetherToEventLocation; // 0x25c(0x01)
	char pad_25D[0x3]; // 0x25d(0x03)
	float DamageAmount; // 0x260(0x04)
	enum class EDamageBaseType DamageBaseType; // 0x264(0x01)
	enum class EDamageFlourishType DamageFlourishType; // 0x265(0x01)
	enum class EDamageModifier DamageModifier; // 0x266(0x01)
	enum class EDamageTargetType DamageTargetType; // 0x267(0x01)
	float DelayBeforeAnimation; // 0x268(0x04)
	float StackWaitTime; // 0x26c(0x04)
	bool PlayingNumberAnimation; // 0x270(0x01)
	char pad_271[0x3]; // 0x271(0x03)
	float VerticalWorldOffset; // 0x274(0x04)
	bool ChangePosition; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)

	void SetDisplayInformation(struct AActor* InTargetActor, bool InTetherToEventLocation, float InDamageAmount, bool InIsSpecialDamage, struct FSpecialDamageColors InDamageColors, bool InIsLethal, bool InIsHeadshot, float InDelayWindow, float InStackWait, bool InArmorHit, bool InDamageReduced, bool InDamageResisted, bool InDamageShielded); // Function KillstreakUINew.DamageNumberDisplayWidget.SetDisplayInformation // (Final|Native|Public) // @ game+0x2182f20
	void SetContentVisibility(bool IsVisible); // Function KillstreakUINew.DamageNumberDisplayWidget.SetContentVisibility // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void PlayNumberAnimation(); // Function KillstreakUINew.DamageNumberDisplayWidget.PlayNumberAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1856f90
	bool PlayerIsBlinded(); // Function KillstreakUINew.DamageNumberDisplayWidget.PlayerIsBlinded // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnDisplaySpecialDamageInfo(float CurrentDamageAmount, struct FSpecialDamageColors DamageColors, bool bChangePosition); // Function KillstreakUINew.DamageNumberDisplayWidget.OnDisplaySpecialDamageInfo // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnDisplayInformationReset(); // Function KillstreakUINew.DamageNumberDisplayWidget.OnDisplayInformationReset // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool IsDisplayStacking(); // Function KillstreakUINew.DamageNumberDisplayWidget.IsDisplayStacking // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2182ad0
};

// Class KillstreakUINew.KSViewedPawnInventoryWidget
// Size: 0x5e0 (Inherited: 0x5a8)
struct UKSViewedPawnInventoryWidget : UKSPawnInventoryWidget {
	struct FPlayerInventorySlot ActiveInventoryItem; // 0x5a8(0x18)
	char pad_5C0[0x20]; // 0x5c0(0x20)

	void OnUpdatedPawnInventorySlot(struct FPlayerInventorySlot InventorySlot); // Function KillstreakUINew.KSViewedPawnInventoryWidget.OnUpdatedPawnInventorySlot // (Native|Event|Public|BlueprintEvent) // @ game+0x2182c60
	void OnRemovedPawnInventorySlot(struct FPlayerInventorySlot InventorySlot); // Function KillstreakUINew.KSViewedPawnInventoryWidget.OnRemovedPawnInventorySlot // (Native|Event|Public|BlueprintEvent) // @ game+0x2182bb0
	void OnActivePawnInventorySlot(struct FPlayerInventorySlot InventorySlot); // Function KillstreakUINew.KSViewedPawnInventoryWidget.OnActivePawnInventorySlot // (Native|Event|Public|BlueprintEvent) // @ game+0x2182b00
	int32_t GetSlotIndex(struct FGameplayTag EquipPoint); // Function KillstreakUINew.KSViewedPawnInventoryWidget.GetSlotIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x21821f0
};

// Class KillstreakUINew.KSViewedPawnModsWidget
// Size: 0x560 (Inherited: 0x548)
struct UKSViewedPawnModsWidget : UKSViewedPawnWidget {
	char pad_548[0x18]; // 0x548(0x18)

	void OnViewedPawnModAdded(struct UKSPlayerMod* Mod, struct UKSPlayerModInstance* ModInstance); // Function KillstreakUINew.KSViewedPawnModsWidget.OnViewedPawnModAdded // (Final|Native|Private) // @ game+0x2182d10
	struct UOverlay* GetOverlay(); // Function KillstreakUINew.KSViewedPawnModsWidget.GetOverlay // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSViewRedirector_LocalSetting
// Size: 0x30 (Inherited: 0x28)
struct UKSViewRedirector_LocalSetting : UPUMG_ViewRedirecter {
	struct FName LocalActionName; // 0x28(0x08)

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function KillstreakUINew.KSViewRedirector_LocalSetting.DoesLocalSettingApply // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2181e80
};

// Class KillstreakUINew.KSViewRedirector_OpeningCinematic
// Size: 0x30 (Inherited: 0x28)
struct UKSViewRedirector_OpeningCinematic : UPUMG_ViewRedirecter {
	struct UDataTable* MediaPlayerDataTable; // 0x28(0x08)
};

// Class KillstreakUINew.KSVoiceActivityWidget
// Size: 0x588 (Inherited: 0x518)
struct UKSVoiceActivityWidget : UKSWidget {
	struct FMulticastInlineDelegate VoiceAccountNamePairsUpdated; // 0x518(0x10)
	struct FMulticastInlineDelegate VoiceParticipantAdded; // 0x528(0x10)
	struct FMulticastInlineDelegate VoiceParticipantRemoved; // 0x538(0x10)
	struct FMulticastInlineDelegate VoiceParticipantUpdated; // 0x548(0x10)
	struct FMulticastInlineDelegate VoiceAudioStateChange; // 0x558(0x10)
	char pad_568[0x20]; // 0x568(0x20)

	void OnVoiceParticipantUpdated(struct FString AccountId, bool bIsTalking, bool bIsMuted); // Function KillstreakUINew.KSVoiceActivityWidget.OnVoiceParticipantUpdated // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnVoiceParticipantRemoved(struct FString AccountId); // Function KillstreakUINew.KSVoiceActivityWidget.OnVoiceParticipantRemoved // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnVoiceParticipantAdded(struct FString AccountId); // Function KillstreakUINew.KSVoiceActivityWidget.OnVoiceParticipantAdded // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct FString GetVoiceIdByPlayerId(int64_t PlayerId); // Function KillstreakUINew.KSVoiceActivityWidget.GetVoiceIdByPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2182400
	struct AKSPlayerState* GetPlayerStateByVoiceId(struct FString VoiceId); // Function KillstreakUINew.KSVoiceActivityWidget.GetPlayerStateByVoiceId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2182140
	int64_t GetPlayerIdByVoiceId(struct FString VoiceId); // Function KillstreakUINew.KSVoiceActivityWidget.GetPlayerIdByVoiceId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2182090
};

// Class KillstreakUINew.KSVoucherAcquisition
// Size: 0x518 (Inherited: 0x518)
struct UKSVoucherAcquisition : UKSWidget {

	bool RedeemVouchers(struct TArray<struct UPUMG_StoreItem*> VoucherItems); // Function KillstreakUINew.KSVoucherAcquisition.RedeemVouchers // (Final|Native|Public|BlueprintCallable) // @ game+0x2182e30
	void GetVoucherAcquisitions(struct TArray<struct UPUMG_StoreItem*>& VoucherItems, struct TArray<struct UPUMG_StoreItem*>& PurchaseItems); // Function KillstreakUINew.KSVoucherAcquisition.GetVoucherAcquisitions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x21824e0
	void DisplayVoucherRedemptionFailed(); // Function KillstreakUINew.KSVoucherAcquisition.DisplayVoucherRedemptionFailed // (Final|Native|Public|BlueprintCallable) // @ game+0x2181e60
};

// Class KillstreakUINew.KSWeaponCategoryButton
// Size: 0x550 (Inherited: 0x518)
struct UKSWeaponCategoryButton : UKSWidget {
	struct TSoftObjectPtr<UKSWeaponCategoryAsset> WeaponCategory; // 0x518(0x28)
	char pad_540[0x10]; // 0x540(0x10)

	void OnWeaponCategorySelected(); // Function KillstreakUINew.KSWeaponCategoryButton.OnWeaponCategorySelected // (Final|Native|Public|BlueprintCallable) // @ game+0x2182dd0
	struct UKSWeaponCategoryAsset* GetWeaponCategory(); // Function KillstreakUINew.KSWeaponCategoryButton.GetWeaponCategory // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2182600
	void DisplayWeaponCategory(struct UKSWeaponCategoryAsset* DisplayedCategory); // Function KillstreakUINew.KSWeaponCategoryButton.DisplayWeaponCategory // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayMasteryProgress(int32_t ProgressCount, int32_t ProgressTotal); // Function KillstreakUINew.KSWeaponCategoryButton.DisplayMasteryProgress // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BroadcastWeaponCategoryPreview(); // Function KillstreakUINew.KSWeaponCategoryButton.BroadcastWeaponCategoryPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x2181e00
};

// Class KillstreakUINew.KSWeaponCategoryScreen
// Size: 0x580 (Inherited: 0x518)
struct UKSWeaponCategoryScreen : UKSWidget {
	struct UKSWeaponProgressMeter* CategoryMasteryMeter; // 0x518(0x08)
	struct UKSRelatedRoguesGroup* RelatedRogues; // 0x520(0x08)
	struct UWidget* WeaponUnlockTooltipDisplay; // 0x528(0x08)
	struct UTextBlock* WeaponCountText; // 0x530(0x08)
	char pad_538[0x30]; // 0x538(0x30)
	struct UKSWeaponCategoryAsset* PopulatedCategory; // 0x568(0x08)
	struct UKSWeaponAsset* HoveredWeapon; // 0x570(0x08)
	char pad_578[0x8]; // 0x578(0x08)

	void RefreshWidgetNavigation(); // Function KillstreakUINew.KSWeaponCategoryScreen.RefreshWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void PopulateFromViewRouteData(); // Function KillstreakUINew.KSWeaponCategoryScreen.PopulateFromViewRouteData // (Final|Native|Public|BlueprintCallable) // @ game+0x2182df0
	void OnWeaponPopulationFinished(); // Function KillstreakUINew.KSWeaponCategoryScreen.OnWeaponPopulationFinished // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleWeaponSelected(struct UKSWeaponAsset* SelectedWeapon); // Function KillstreakUINew.KSWeaponCategoryScreen.HandleWeaponSelected // (Final|Native|Public) // @ game+0x2182a50
	void HandleWeaponPreview(struct UKSWeaponAsset* PreviewWeapon); // Function KillstreakUINew.KSWeaponCategoryScreen.HandleWeaponPreview // (Final|Native|Public) // @ game+0x21829d0
	void HandleViewStateChanged(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function KillstreakUINew.KSWeaponCategoryScreen.HandleViewStateChanged // (Final|Native|Public) // @ game+0x21828d0
	void HandleCustomizeAction(); // Function KillstreakUINew.KSWeaponCategoryScreen.HandleCustomizeAction // (Final|Native|Public) // @ game+0x21826b0
	void HandleBackContextAction(); // Function KillstreakUINew.KSWeaponCategoryScreen.HandleBackContextAction // (Final|Native|Public) // @ game+0x21696a0
	struct TArray<struct UKSWeaponProgressButton*> GetWeaponProgressButtons(); // Function KillstreakUINew.KSWeaponCategoryScreen.GetWeaponProgressButtons // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	int32_t GetPopulatedWeaponCount(); // Function KillstreakUINew.KSWeaponCategoryScreen.GetPopulatedWeaponCount // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x202bfb0
	void FX_OnViewMasteryRewards(); // Function KillstreakUINew.KSWeaponCategoryScreen.FX_OnViewMasteryRewards // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void FX_OnCustomizeContextAction(); // Function KillstreakUINew.KSWeaponCategoryScreen.FX_OnCustomizeContextAction // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponCategory(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponCategoryScreen.DisplayWeaponCategory // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	struct UKSWeaponProgressButton* CreateAndAddWeaponEntry(); // Function KillstreakUINew.KSWeaponCategoryScreen.CreateAndAddWeaponEntry // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ClearWeaponPreview(); // Function KillstreakUINew.KSWeaponCategoryScreen.ClearWeaponPreview // (Final|Native|Public) // @ game+0x2181e40
	void ClearWeaponEntries(); // Function KillstreakUINew.KSWeaponCategoryScreen.ClearWeaponEntries // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void AddWrapCustomizationViewRoute(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponCategoryScreen.AddWrapCustomizationViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x2181d60
	void AddMasteryRewardsViewRoute(); // Function KillstreakUINew.KSWeaponCategoryScreen.AddMasteryRewardsViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x2181d40
};

// Class KillstreakUINew.KSWeaponComponentWidget
// Size: 0x538 (Inherited: 0x518)
struct UKSWeaponComponentWidget : UKSWidget {
	struct TWeakObjectPtr<struct UKSWeaponComponent> WeaponComponent; // 0x518(0x08)
	struct FKSEquipmentId EquipmentId; // 0x520(0x04)
	char pad_524[0x14]; // 0x524(0x14)

	void SetOwningWeaponComponent(struct UKSWeaponComponent* InWeaponComponent); // Function KillstreakUINew.KSWeaponComponentWidget.SetOwningWeaponComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x2187f80
	void PreClearWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.PreClearWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c030
	void PostSetWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.PostSetWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x21518c0
	void OnEndActiveWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.OnEndActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x212a310
	void OnBecomeActiveWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.OnBecomeActiveWeaponComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x21416e0
	bool IsWeaponComponentActive(); // Function KillstreakUINew.KSWeaponComponentWidget.IsWeaponComponentActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21876d0
	struct UKSWeaponComponent* GetWeaponComponent(); // Function KillstreakUINew.KSWeaponComponentWidget.GetWeaponComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2187000
};

// Class KillstreakUINew.KSWeaponComponentAmmoWidget
// Size: 0x558 (Inherited: 0x538)
struct UKSWeaponComponentAmmoWidget : UKSWeaponComponentWidget {
	int32_t CachedAmmoInClip; // 0x538(0x04)
	int32_t CachedClipSize; // 0x53c(0x04)
	int32_t CachedInReserve; // 0x540(0x04)
	bool CachedIsReloading; // 0x544(0x01)
	char pad_545[0x13]; // 0x545(0x13)

	void StopReloading(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.StopReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x212c010
	void StartReloading(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.StartReloading // (Native|Event|Protected|BlueprintEvent) // @ game+0x2139670
	void OnAmmoChanged(int32_t OldInClip, int32_t OldClipSize, int32_t OldReserve, int32_t NewInClip, int32_t NewClipSize, int32_t NewReserve); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.OnAmmoChanged // (Native|Event|Protected|BlueprintEvent) // @ game+0x21877b0
	bool IsReloading(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.IsReloading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21876b0
	int32_t GetClipSize(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.GetClipSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x202b9d0
	int32_t GetAmmoInReserve(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.GetAmmoInReserve // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x202b6d0
	int32_t GetAmmoInClip(); // Function KillstreakUINew.KSWeaponComponentAmmoWidget.GetAmmoInClip // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x21869b0
};

// Class KillstreakUINew.KSWeaponDetailScreen
// Size: 0x588 (Inherited: 0x518)
struct UKSWeaponDetailScreen : UKSWidget {
	struct UKSWeaponProgressMeter* WeaponMasteryMeter; // 0x518(0x08)
	struct UKSRelatedRoguesGroup* RelatedRogues; // 0x520(0x08)
	struct UKSSideNavigationOverlay* SideNavigationOverlay; // 0x528(0x08)
	struct UKSWeaponMilestoneDisplay* WeaponMilestones; // 0x530(0x08)
	struct UKSWeaponStatsPanel* WeaponStatsPanel; // 0x538(0x08)
	struct UKSWeaponAsset* PopulatedWeaponAsset; // 0x540(0x08)
	char pad_548[0x30]; // 0x548(0x30)
	struct FName DesiredEquipSound; // 0x578(0x08)
	bool bPlayedWeaponEquipSound; // 0x580(0x01)
	char pad_581[0x7]; // 0x581(0x07)

	void PopulateFromWeaponAsset(struct UKSWeaponAsset* WeaponAsset, bool FromSideNav); // Function KillstreakUINew.KSWeaponDetailScreen.PopulateFromWeaponAsset // (Final|Native|Public) // @ game+0x2187a40
	void PopulateFromViewRouteData(); // Function KillstreakUINew.KSWeaponDetailScreen.PopulateFromViewRouteData // (Final|Native|Public) // @ game+0x2187a00
	void InitiateLockedMilestonesPurchase(); // Function KillstreakUINew.KSWeaponDetailScreen.InitiateLockedMilestonesPurchase // (Final|Native|Public|BlueprintCallable) // @ game+0x2187690
	bool HasLockedMilestones(); // Function KillstreakUINew.KSWeaponDetailScreen.HasLockedMilestones // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2187660
	void HandleWeaponPreview(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponDetailScreen.HandleWeaponPreview // (Final|Native|Public) // @ game+0x21875c0
	void HandleViewStateChanged(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function KillstreakUINew.KSWeaponDetailScreen.HandleViewStateChanged // (Final|Native|Public) // @ game+0x2187220
	void HandleSideNavigation(int32_t SideDirection); // Function KillstreakUINew.KSWeaponDetailScreen.HandleSideNavigation // (Final|Native|Public) // @ game+0x2187180
	void HandleCustomizeContextAction(); // Function KillstreakUINew.KSWeaponDetailScreen.HandleCustomizeContextAction // (Final|Native|Public) // @ game+0x2187160
	void HandleBackContextAction(); // Function KillstreakUINew.KSWeaponDetailScreen.HandleBackContextAction // (Final|Native|Public) // @ game+0x21696a0
	void FX_OnViewMasteryRewards(); // Function KillstreakUINew.KSWeaponDetailScreen.FX_OnViewMasteryRewards // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void FX_OnCustomizeContextAction(); // Function KillstreakUINew.KSWeaponDetailScreen.FX_OnCustomizeContextAction // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeapon(struct UKSWeaponAsset* WeaponAsset, struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponDetailScreen.DisplayWeapon // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayEquippedWrap(struct UKSWeaponAttachment* EquippedWrap); // Function KillstreakUINew.KSWeaponDetailScreen.DisplayEquippedWrap // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ConfigureViewModel(struct UKSWeaponAsset* WeaponAsset, struct UKSWeaponAttachment* WeaponWrap); // Function KillstreakUINew.KSWeaponDetailScreen.ConfigureViewModel // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void AddWrapCustomizationViewRoute(); // Function KillstreakUINew.KSWeaponDetailScreen.AddWrapCustomizationViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x21867b0
	void AddMasteryRewardsViewRoute(); // Function KillstreakUINew.KSWeaponDetailScreen.AddMasteryRewardsViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x2186770
};

// Class KillstreakUINew.KSWeaponHubBase
// Size: 0x548 (Inherited: 0x518)
struct UKSWeaponHubBase : UKSWidget {
	struct UKSWeaponProgressMeter* TotalWeaponMasteryMeter; // 0x518(0x08)
	struct UKSRelatedRoguesGroup* RelatedRogues; // 0x520(0x08)
	char pad_528[0x20]; // 0x528(0x20)

	void HandleWeaponCategoryPreview(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponHubBase.HandleWeaponCategoryPreview // (Final|Native|Public) // @ game+0x2187520
	void HandleBackContextAction(); // Function KillstreakUINew.KSWeaponHubBase.HandleBackContextAction // (Final|Native|Public) // @ game+0x21696a0
	struct TArray<struct UKSWeaponCategoryButton*> GetWeaponCategoryButtons(); // Function KillstreakUINew.KSWeaponHubBase.GetWeaponCategoryButtons // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void FX_OnViewMasteryRewards(); // Function KillstreakUINew.KSWeaponHubBase.FX_OnViewMasteryRewards // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void AddMasteryRewardsViewRoute(); // Function KillstreakUINew.KSWeaponHubBase.AddMasteryRewardsViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0x2186790
};

// Class KillstreakUINew.KSWeaponHubHelper
// Size: 0x38 (Inherited: 0x28)
struct UKSWeaponHubHelper : UObject {
	struct UDataTable* WeaponCategoryDetailsTable; // 0x28(0x08)
	struct UKSWeaponMasteryManager* WeaponMasteryManager; // 0x30(0x08)

	struct TArray<struct UKSWeaponAsset*> GetWeaponsForCategory(struct FGameplayTag WeaponCategoryTag, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSWeaponHubHelper.GetWeaponsForCategory // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2187040
	bool GetWeaponCategoryDetailsByTag(struct FGameplayTag CategoryTag, struct FWeaponCategoryDetails& OutDetails); // Function KillstreakUINew.KSWeaponHubHelper.GetWeaponCategoryDetailsByTag // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2186e70
	bool GetWeaponCategoryDetails(struct FName WeaponCategoryName, struct FWeaponCategoryDetails& OutDetails); // Function KillstreakUINew.KSWeaponHubHelper.GetWeaponCategoryDetails // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2186d70
	struct TArray<struct UKSJobItem*> GetJobsForWeaponId(int32_t WeaponId); // Function KillstreakUINew.KSWeaponHubHelper.GetJobsForWeaponId // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2186b70
	struct TArray<struct UKSJobItem*> GetJobsForWeaponCategory(struct FName WeaponCategoryName); // Function KillstreakUINew.KSWeaponHubHelper.GetJobsForWeaponCategory // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2186a90
	int32_t GetAvailableWeaponCountInCategory(struct FGameplayTag CategoryTag, struct UKSJobItem* JobItem); // Function KillstreakUINew.KSWeaponHubHelper.GetAvailableWeaponCountInCategory // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x21869d0
};

// Class KillstreakUINew.KSWeaponMasteryLevelUpSummary
// Size: 0x38 (Inherited: 0x28)
struct UKSWeaponMasteryLevelUpSummary : UObject {
	struct TArray<struct FKSWeaponMasteryLevelUpSummaryEntry> MasteryEntries; // 0x28(0x10)

	void SwapEntryToTop(struct UPrimaryDataAsset* InMasteryAsset); // Function KillstreakUINew.KSWeaponMasteryLevelUpSummary.SwapEntryToTop // (Final|Native|Public|BlueprintCallable) // @ game+0x21880a0
	bool HasEntries(); // Function KillstreakUINew.KSWeaponMasteryLevelUpSummary.HasEntries // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2187640
	bool ContainsMasteryEntry(struct UPrimaryDataAsset* InMasteryAsset); // Function KillstreakUINew.KSWeaponMasteryLevelUpSummary.ContainsMasteryEntry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2186900
};

// Class KillstreakUINew.KSWeaponMasteryLevelUpScreen
// Size: 0x570 (Inherited: 0x518)
struct UKSWeaponMasteryLevelUpScreen : UKSWidget {
	struct FKSWeaponMasteryLevelUpSummaryEntry PopulatedEntry; // 0x518(0x48)
	struct FName ViewActorName; // 0x560(0x08)
	char pad_568[0x8]; // 0x568(0x08)

	void ShowNextEntry(); // Function KillstreakUINew.KSWeaponMasteryLevelUpScreen.ShowNextEntry // (Final|Native|Public) // @ game+0x2188080
	void PopulateForLevelUpEntry(struct FKSWeaponMasteryLevelUpSummaryEntry LevelUpEntry); // Function KillstreakUINew.KSWeaponMasteryLevelUpScreen.PopulateForLevelUpEntry // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleViewStateChanged(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function KillstreakUINew.KSWeaponMasteryLevelUpScreen.HandleViewStateChanged // (Final|Native|Public) // @ game+0x2187320
	void HandleCurrentWeaponDismissed(); // Function KillstreakUINew.KSWeaponMasteryLevelUpScreen.HandleCurrentWeaponDismissed // (Final|Native|Public|BlueprintCallable) // @ game+0x2187140
};

// Class KillstreakUINew.KSWeaponMasteryRewardsScreen
// Size: 0x570 (Inherited: 0x518)
struct UKSWeaponMasteryRewardsScreen : UKSRogueMasteryWidget {
	enum class EKSWeaponMasteryType CurrentDisplayedMasteryType; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)
	struct UKSActivityInstance* CurrentProgressActivityInstance; // 0x520(0x08)
	struct UKSWeaponAsset* PopulatedWeaponAsset; // 0x528(0x08)
	struct UKSWeaponCategoryAsset* PopulatedWeaponCategory; // 0x530(0x08)
	char pad_538[0x38]; // 0x538(0x38)

	void UpdateReactiveStateDescription(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.UpdateReactiveStateDescription // (Final|Native|Public) // @ game+0x21881b0
	void SelectTierForCurrentProgress(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.SelectTierForCurrentProgress // (Final|Native|Public|BlueprintCallable) // @ game+0x2187f60
	void SelectTierByNumber(int32_t TierNumber); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.SelectTierByNumber // (Final|Native|Public|BlueprintCallable) // @ game+0x2187ee0
	void SelectTierByIndex(int32_t TierIndex); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.SelectTierByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x2187e60
	void SelectTier(struct FActivityTier ActivityTier); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.SelectTier // (Final|Native|Public|BlueprintCallable) // @ game+0x2187d10
	void SelectPrevTier(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.SelectPrevTier // (Final|Native|Public|BlueprintCallable) // @ game+0x2187cf0
	void SelectNextTier(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.SelectNextTier // (Final|Native|Public|BlueprintCallable) // @ game+0x2187cd0
	void PostChangeRewardPreview(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.PostChangeRewardPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x2187cb0
	void PopulateRewardTiers(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.PopulateRewardTiers // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void PopulateFromWeaponsMaster(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.PopulateFromWeaponsMaster // (Final|Native|Public) // @ game+0x2187c90
	void PopulateFromWeaponCategory(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.PopulateFromWeaponCategory // (Final|Native|Public) // @ game+0x2187c10
	void PopulateFromWeaponAsset(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.PopulateFromWeaponAsset // (Final|Native|Public) // @ game+0x2187b10
	void PopulateFromViewRouteData(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.PopulateFromViewRouteData // (Final|Native|Public) // @ game+0x2187a20
	void OnCurrentProgressActivityInstanceUpdated(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.OnCurrentProgressActivityInstanceUpdated // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	struct FMasteryRewardData MakeMasteryRewardData(struct FTierRewardItemData RewardItem); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.MakeMasteryRewardData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2187700
	void HandleWeaponModelSet(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.HandleWeaponModelSet // (Final|Native|Public) // @ game+0x21875a0
	void HandleViewStateChanged(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.HandleViewStateChanged // (Final|Native|Public) // @ game+0x2187420
	void HandleTriggerReactiveContextAction(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.HandleTriggerReactiveContextAction // (Final|Native|Public) // @ game+0x2187200
	void HandleBackContextAction(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.HandleBackContextAction // (Final|Native|Public) // @ game+0x21696a0
	struct UKSWeaponCategoryAsset* GetWeaponCategoryFromXP(struct UKSActivity* CategoryActivity); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.GetWeaponCategoryFromXP // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2186f70
	void GetRewardTiers(struct TArray<struct FActivityTier>& OutRewardTiers); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.GetRewardTiers // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2186ca0
	float GetRegularTiersProgress(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.GetRegularTiersProgress // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2186c70
	float GetPrestigeTierProgress(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.GetPrestigeTierProgress // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2186c40
	struct FName GetModelViewerActorName(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.GetModelViewerActorName // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponsMaster(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.DisplayWeaponsMaster // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponCategory(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.DisplayWeaponCategory // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponAsset(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.DisplayWeaponAsset // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayRewardTier(struct FActivityTier SelectedTier); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.DisplayRewardTier // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayReactiveStateDescription(struct FText& DescText); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.DisplayReactiveStateDescription // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void DisplayActivityProgress(int32_t Level, int32_t LevelProgressCount, int32_t LevelProgressTotal); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.DisplayActivityProgress // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ConfigureLobbyCamera(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.ConfigureLobbyCamera // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ClearReactiveStateDescription(); // Function KillstreakUINew.KSWeaponMasteryRewardsScreen.ClearReactiveStateDescription // (Final|Native|Public) // @ game+0x2186880
};

// Class KillstreakUINew.KSWeaponMilestoneDisplay
// Size: 0x520 (Inherited: 0x518)
struct UKSWeaponMilestoneDisplay : UKSWidget {
	struct UKSWeaponAsset* PopulatedWeaponAsset; // 0x518(0x08)

	void PopulateFromWeaponAsset(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponMilestoneDisplay.PopulateFromWeaponAsset // (Final|Native|Public) // @ game+0x2187b90
	void GetMilestoneEntries(struct TArray<struct UKSWeaponMilestoneEntry*>& Entries); // Function KillstreakUINew.KSWeaponMilestoneDisplay.GetMilestoneEntries // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSWeaponMilestoneEntry
// Size: 0x520 (Inherited: 0x518)
struct UKSWeaponMilestoneEntry : UKSWidget {
	struct UKSActivityInstance* PopulatedMilestoneInstance; // 0x518(0x08)

	void PopulateFromMilestoneActivity(struct UKSActivityInstance* MilestoneInstance); // Function KillstreakUINew.KSWeaponMilestoneEntry.PopulateFromMilestoneActivity // (Final|Native|Public) // @ game+0x2187980
	void DisplayMilestoneActivity(struct UKSActivityInstance* MilestoneInstance); // Function KillstreakUINew.KSWeaponMilestoneEntry.DisplayMilestoneActivity // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayEmpty(); // Function KillstreakUINew.KSWeaponMilestoneEntry.DisplayEmpty // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSWeaponProgressButton
// Size: 0x558 (Inherited: 0x518)
struct UKSWeaponProgressButton : UKSWidget {
	struct FMulticastInlineDelegate OnWeaponPreview; // 0x518(0x10)
	struct FMulticastInlineDelegate OnWeaponSelected; // 0x528(0x10)
	struct FMulticastInlineDelegate OnWeaponUnhovered; // 0x538(0x10)
	bool bOnCosmeticNavToDetails; // 0x548(0x01)
	char pad_549[0x7]; // 0x549(0x07)
	struct UKSWeaponAsset* WeaponAsset; // 0x550(0x08)

	void SetWeaponAsset(struct UKSWeaponAsset* InWeaponAsset); // Function KillstreakUINew.KSWeaponProgressButton.SetWeaponAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x2188000
	void OnCosmeticClicked(); // Function KillstreakUINew.KSWeaponProgressButton.OnCosmeticClicked // (Final|Native|Public|BlueprintCallable) // @ game+0x2187960
	struct UKSWeaponAsset* GetWeaponAsset(); // Function KillstreakUINew.KSWeaponProgressButton.GetWeaponAsset // (Final|Native|Public|Const) // @ game+0x2172bb0
	void DisplayWeapon(struct UKSWeaponAsset* DisplayedWeapon); // Function KillstreakUINew.KSWeaponProgressButton.DisplayWeapon // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayMasteryProgress(int32_t MasteryLevel, int32_t LevelProgressCount, int32_t LevelProgressTotal); // Function KillstreakUINew.KSWeaponProgressButton.DisplayMasteryProgress // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayCosmetic(struct UKSWeaponAttachment* Cosmetic); // Function KillstreakUINew.KSWeaponProgressButton.DisplayCosmetic // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BroadcastWeaponUnhovered(); // Function KillstreakUINew.KSWeaponProgressButton.BroadcastWeaponUnhovered // (Final|Native|Public|BlueprintCallable) // @ game+0x2186850
	void BroadcastWeaponSelected(); // Function KillstreakUINew.KSWeaponProgressButton.BroadcastWeaponSelected // (Final|Native|Public|BlueprintCallable) // @ game+0x2186810
	void BroadcastWeaponPreview(); // Function KillstreakUINew.KSWeaponProgressButton.BroadcastWeaponPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x21867d0
};

// Class KillstreakUINew.KSWeaponProgressMeter
// Size: 0x540 (Inherited: 0x518)
struct UKSWeaponProgressMeter : UKSWidget {
	enum class EKSWeaponMasteryType CurrentMasteryType; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)
	struct UKSActivityInstance* CurrentMasteryInstance; // 0x520(0x08)
	char pad_528[0x10]; // 0x528(0x10)
	struct UKSWeaponAsset* PopulatedWeaponAsset; // 0x538(0x08)

	void PopulateProgressReward(struct UKSActivityInstance* ProgressInstance); // Function KillstreakUINew.KSWeaponProgressMeter.PopulateProgressReward // (Final|Native|Protected) // @ game+0x218cad0
	void PopulateFromWeaponsMaster(); // Function KillstreakUINew.KSWeaponProgressMeter.PopulateFromWeaponsMaster // (Final|Native|Public|BlueprintCallable) // @ game+0x218c9b0
	void PopulateFromWeaponCategory(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponProgressMeter.PopulateFromWeaponCategory // (Final|Native|Public|BlueprintCallable) // @ game+0x218c930
	void PopulateFromWeapon(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponProgressMeter.PopulateFromWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x218c8b0
	struct TArray<struct FText> GetItemTypeTexts(struct TArray<struct FTierRewardItemData>& RewardItems); // Function KillstreakUINew.KSWeaponProgressMeter.GetItemTypeTexts // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponsMaster(); // Function KillstreakUINew.KSWeaponProgressMeter.DisplayWeaponsMaster // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponCategory(struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWeaponProgressMeter.DisplayWeaponCategory // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeapon(struct UKSWeaponAsset* WeaponAsset); // Function KillstreakUINew.KSWeaponProgressMeter.DisplayWeapon // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayProgressReward(struct FWeaponMasteryRewardDisplayData RewardDisplayData); // Function KillstreakUINew.KSWeaponProgressMeter.DisplayProgressReward // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayProgress(int32_t MasteryLevel, int32_t LevelProgressCount, int32_t LevelProgressTotal); // Function KillstreakUINew.KSWeaponProgressMeter.DisplayProgress // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void DisplayAltDescription(struct FText& DescriptionText); // Function KillstreakUINew.KSWeaponProgressMeter.DisplayAltDescription // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void ClearProgressReward(); // Function KillstreakUINew.KSWeaponProgressMeter.ClearProgressReward // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void BroadcastGoToRewardDetails(); // Function KillstreakUINew.KSWeaponProgressMeter.BroadcastGoToRewardDetails // (Final|Native|Public|BlueprintCallable) // @ game+0x218bb50
};

// Class KillstreakUINew.KSWeaponStatsPanel
// Size: 0x538 (Inherited: 0x518)
struct UKSWeaponStatsPanel : UKSWidget {
	char pad_518[0x20]; // 0x518(0x20)

	void UpdateStatCount(int32_t NewStatCount); // Function KillstreakUINew.KSWeaponStatsPanel.UpdateStatCount // (Final|Native|Public) // @ game+0x218d220
	void UpdateStatAtIndex(int32_t WidgetIndex, struct FItemDisplayStat WeaponStat, struct FItemDisplayStat UpgradeStat); // Function KillstreakUINew.KSWeaponStatsPanel.UpdateStatAtIndex // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void UpdateSideNavigation(bool PrevLevelEnabled, bool NextLevelEnabled); // Function KillstreakUINew.KSWeaponStatsPanel.UpdateSideNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetOpenedState(bool IsOpen); // Function KillstreakUINew.KSWeaponStatsPanel.SetOpenedState // (Final|Native|Public|BlueprintCallable) // @ game+0x218cec0
	void SetBaseWeapon(struct UKSWeaponAsset* InWeaponAsset); // Function KillstreakUINew.KSWeaponStatsPanel.SetBaseWeapon // (Final|Native|Public) // @ game+0x218ce40
	void RemoveStatWidget(); // Function KillstreakUINew.KSWeaponStatsPanel.RemoveStatWidget // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool PopulateWeaponLevel(int32_t TierLevel); // Function KillstreakUINew.KSWeaponStatsPanel.PopulateWeaponLevel // (Final|Native|Public) // @ game+0x218cb50
	bool PopulatePrevWeaponLevel(); // Function KillstreakUINew.KSWeaponStatsPanel.PopulatePrevWeaponLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x218ca90
	bool PopulateNextWeaponLevel(); // Function KillstreakUINew.KSWeaponStatsPanel.PopulateNextWeaponLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x218ca50
	bool GetOpenedState(); // Function KillstreakUINew.KSWeaponStatsPanel.GetOpenedState // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x218bea0
	int32_t GetCurrentStatCount(); // Function KillstreakUINew.KSWeaponStatsPanel.GetCurrentStatCount // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponInfo(int32_t Level, struct UKSWeaponAsset* LevelWeapon); // Function KillstreakUINew.KSWeaponStatsPanel.DisplayWeaponInfo // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayOpenedState(bool IsOpen); // Function KillstreakUINew.KSWeaponStatsPanel.DisplayOpenedState // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void AddStatWidget(); // Function KillstreakUINew.KSWeaponStatsPanel.AddStatWidget // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSWhatsNewModalViewRedirector
// Size: 0x28 (Inherited: 0x28)
struct UKSWhatsNewModalViewRedirector : UPUMG_ViewRedirecter {
};

// Class KillstreakUINew.KSWhatsNewPanel
// Size: 0xa8 (Inherited: 0x60)
struct UKSWhatsNewPanel : UKSJsonData {
	struct FText Header; // 0x60(0x18)
	struct TArray<struct FSubPanel> SubPanels; // 0x78(0x10)
	enum class ESubPanelAlignment Alignment; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	int32_t BgBoxOpacity; // 0x8c(0x04)
	struct UTexture2DDynamic* Image; // 0x90(0x08)
	struct FString URL; // 0x98(0x10)
};

// Class KillstreakUINew.KSWhatsNewModal
// Size: 0x530 (Inherited: 0x518)
struct UKSWhatsNewModal : UKSWidget {
	int32_t maxPanelCount; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)
	struct TArray<struct UKSWhatsNewPanel*> StoredPanels; // 0x520(0x10)

	void UpdateWhatsNewPanels(); // Function KillstreakUINew.KSWhatsNewModal.UpdateWhatsNewPanels // (Final|Native|Protected) // @ game+0x218d2a0
	void OnJsonChanged(); // Function KillstreakUINew.KSWhatsNewModal.OnJsonChanged // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UKSWhatsNewPanel*> GetPanelData(); // Function KillstreakUINew.KSWhatsNewModal.GetPanelData // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x218bf50
	int32_t GetMaxPanelCount(); // Function KillstreakUINew.KSWhatsNewModal.GetMaxPanelCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x218be50
	struct UKSJsonDataFactory* GetJsonDataFactory(); // Function KillstreakUINew.KSWhatsNewModal.GetJsonDataFactory // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x218bdf0
};

// Class KillstreakUINew.KSWrapCustomizationContext
// Size: 0x40 (Inherited: 0x28)
struct UKSWrapCustomizationContext : UObject {
	struct UKSWeaponAsset* WeaponAsset; // 0x28(0x08)
	struct UKSWeaponAttachment* SelectedWrap; // 0x30(0x08)
	struct UPUMG_StoreItem* SelectedStoreItem; // 0x38(0x08)
};

// Class KillstreakUINew.KSWrapCustomizationScreen
// Size: 0x578 (Inherited: 0x518)
struct UKSWrapCustomizationScreen : UKSWidget {
	struct UKSWeaponAsset* PopulatedWeaponAsset; // 0x518(0x08)
	struct UKSWeaponAttachment* PreviewedWeaponWrap; // 0x520(0x08)
	struct UPUMG_StoreItem* PreviewedStoreItem; // 0x528(0x08)
	char pad_530[0x48]; // 0x530(0x48)

	void UpdateReactiveStateDescription(); // Function KillstreakUINew.KSWrapCustomizationScreen.UpdateReactiveStateDescription // (Final|Native|Public) // @ game+0x218d180
	void SetActionButtonText(struct FText& DescText); // Function KillstreakUINew.KSWrapCustomizationScreen.SetActionButtonText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void RemoveLastWrapEntry(); // Function KillstreakUINew.KSWrapCustomizationScreen.RemoveLastWrapEntry // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void RefreshWidgetNavigation(); // Function KillstreakUINew.KSWrapCustomizationScreen.RefreshWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void PromptEquipAllForCosmetic(); // Function KillstreakUINew.KSWrapCustomizationScreen.PromptEquipAllForCosmetic // (Final|Native|Public|BlueprintCallable) // @ game+0x218cca0
	void PreviewWeaponWrap(struct UKSWeaponAttachment* WeaponWrap, struct UPUMG_StoreItem* StoreItem); // Function KillstreakUINew.KSWrapCustomizationScreen.PreviewWeaponWrap // (Final|Native|Public) // @ game+0x218cbe0
	void PopulateFromWrapCustomizationContext(struct UKSWrapCustomizationContext* WrapContext); // Function KillstreakUINew.KSWrapCustomizationScreen.PopulateFromWrapCustomizationContext // (Final|Native|Public) // @ game+0x218c9d0
	void PopulateFromViewRouteData(); // Function KillstreakUINew.KSWrapCustomizationScreen.PopulateFromViewRouteData // (Final|Native|Public|BlueprintCallable) // @ game+0x218c890
	void OnWrapPopulationFinished(); // Function KillstreakUINew.KSWrapCustomizationScreen.OnWrapPopulationFinished // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnPurchaseAndEquipComplete(bool bSuccess); // Function KillstreakUINew.KSWrapCustomizationScreen.OnPurchaseAndEquipComplete // (Final|Native|Private) // @ game+0x218c550
	void OnEquipButtonClicked(); // Function KillstreakUINew.KSWrapCustomizationScreen.OnEquipButtonClicked // (Final|Native|Public|BlueprintCallable) // @ game+0x218c5e0
	void OnEquipAllComplete(bool bSuccess); // Function KillstreakUINew.KSWrapCustomizationScreen.OnEquipAllComplete // (Final|Native|Public) // @ game+0x218c550
	void HandleWrapEntryPurchaseFlow(struct UKSWeaponAttachment* WrapAttachment, struct UPUMG_StoreItem* StoreItem); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleWrapEntryPurchaseFlow // (Final|Native|Public) // @ game+0x218c460
	void HandleWrapEntryPreview(struct UKSWeaponAttachment* WrapAttachment, struct UPUMG_StoreItem* StoreItem); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleWrapEntryPreview // (Final|Native|Public) // @ game+0x218c3a0
	void HandleWrapEntryEquip(struct UKSWeaponAttachment* WrapAttachment); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleWrapEntryEquip // (Final|Native|Public) // @ game+0x218c320
	void HandleWeaponModelSet(); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleWeaponModelSet // (Final|Native|Public) // @ game+0x218c300
	void HandleViewStateChanged(struct FName CurrentRoute, struct FName PreviousRoute, enum class EViewManagerLayer Layer); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleViewStateChanged // (Final|Native|Public) // @ game+0x218c200
	void HandleTriggerReactiveContextAction(); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleTriggerReactiveContextAction // (Final|Native|Public) // @ game+0x218c1e0
	void HandleLoadoutChanged(struct UPUMG_Loadout* Loadout); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleLoadoutChanged // (Final|Native|Public) // @ game+0x218c160
	void HandleBackContextAction(); // Function KillstreakUINew.KSWrapCustomizationScreen.HandleBackContextAction // (Final|Native|Public) // @ game+0x21696a0
	int32_t GetWrapEntryCount(); // Function KillstreakUINew.KSWrapCustomizationScreen.GetWrapEntryCount // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool GetWrapEntryByWeaponAttachment(struct UKSWeaponAttachment* WeaponAttachment, struct UKSWrapSelectionEntry*& OutWrapEntry); // Function KillstreakUINew.KSWrapCustomizationScreen.GetWrapEntryByWeaponAttachment // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	bool GetWrapEntry(int32_t Index, struct UKSWrapSelectionEntry*& OutWrapEntry); // Function KillstreakUINew.KSWrapCustomizationScreen.GetWrapEntry // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	struct UKSWrapSelectionEntry* GetOrCreateWrapEntry(int32_t Index); // Function KillstreakUINew.KSWrapCustomizationScreen.GetOrCreateWrapEntry // (Final|Native|Public) // @ game+0x218bec0
	struct FName GetModelViewerActorName(); // Function KillstreakUINew.KSWrapCustomizationScreen.GetModelViewerActorName // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void EquipWeaponWrap(struct UKSWeaponAttachment* WeaponWrap); // Function KillstreakUINew.KSWrapCustomizationScreen.EquipWeaponWrap // (Final|Native|Public) // @ game+0x218bd40
	void DisplayWrapInfo(struct UKSWeaponAttachment* WeaponWrap); // Function KillstreakUINew.KSWrapCustomizationScreen.DisplayWrapInfo // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayWeaponInfo(struct UKSWeaponAsset* WeaponAsset, struct UKSWeaponCategoryAsset* WeaponCategory); // Function KillstreakUINew.KSWrapCustomizationScreen.DisplayWeaponInfo // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayReactiveStateDescription(struct FText& DescText); // Function KillstreakUINew.KSWrapCustomizationScreen.DisplayReactiveStateDescription // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	struct UKSWrapSelectionEntry* CreateAndAddWrapEntry(); // Function KillstreakUINew.KSWrapCustomizationScreen.CreateAndAddWrapEntry // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ConfigureViewModel(struct UKSWeaponAsset* WeaponAsset, struct UKSWeaponAttachment* WeaponWrap); // Function KillstreakUINew.KSWrapCustomizationScreen.ConfigureViewModel // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ClearReactiveStateDescription(); // Function KillstreakUINew.KSWrapCustomizationScreen.ClearReactiveStateDescription // (Final|Native|Public) // @ game+0x218bcc0
	void ClearEquippedWeaponWrap(); // Function KillstreakUINew.KSWrapCustomizationScreen.ClearEquippedWeaponWrap // (Final|Native|Public) // @ game+0x218bca0
	void ClearEntries(); // Function KillstreakUINew.KSWrapCustomizationScreen.ClearEntries // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class KillstreakUINew.KSWrapSelectionEntry
// Size: 0x558 (Inherited: 0x518)
struct UKSWrapSelectionEntry : UKSWidget {
	struct FMulticastInlineDelegate OnWrapEquip; // 0x518(0x10)
	struct FMulticastInlineDelegate OnWrapPreview; // 0x528(0x10)
	struct FMulticastInlineDelegate OnStoreWrapSelect; // 0x538(0x10)
	char pad_548[0x10]; // 0x548(0x10)

	void PopulateEntry(struct UKSWeaponAttachment* WeaponAttachment, struct UPUMG_StoreItem* StoreItem, bool IsEquipped); // Function KillstreakUINew.KSWrapSelectionEntry.PopulateEntry // (Final|Native|Public) // @ game+0x218c780
	struct UKSWeaponAttachment* GetPopulatedWeaponAttachment(); // Function KillstreakUINew.KSWrapSelectionEntry.GetPopulatedWeaponAttachment // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172ee0
	struct UPUMG_StoreItem* GetPopulatedStoreItem(); // Function KillstreakUINew.KSWrapSelectionEntry.GetPopulatedStoreItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2172bb0
	void DisplayWrap(struct UKSWeaponAttachment* WeaponAttachment); // Function KillstreakUINew.KSWrapSelectionEntry.DisplayWrap // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplaySelected(bool IsSelected); // Function KillstreakUINew.KSWrapSelectionEntry.DisplaySelected // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DisplayEquipped(bool IsEquipped); // Function KillstreakUINew.KSWrapSelectionEntry.DisplayEquipped // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BroadcastWrapPreview(); // Function KillstreakUINew.KSWrapSelectionEntry.BroadcastWrapPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x218bc50
	void BroadcastWrapEquip(); // Function KillstreakUINew.KSWrapSelectionEntry.BroadcastWrapEquip // (Final|Native|Private) // @ game+0x218bc10
	void BroadcastStoreWrapSelect(); // Function KillstreakUINew.KSWrapSelectionEntry.BroadcastStoreWrapSelect // (Final|Native|Private) // @ game+0x218bbc0
	void BroadcaseWrapClicked(); // Function KillstreakUINew.KSWrapSelectionEntry.BroadcaseWrapClicked // (Final|Native|Public|BlueprintCallable) // @ game+0x218bae0
};

// Class KillstreakUINew.TickAnimationManager
// Size: 0x78 (Inherited: 0x28)
struct UTickAnimationManager : UObject {
	struct TMap<struct FName, struct FTickAnimationParams> AnimsByName; // 0x28(0x50)

	void StopAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.StopAnimation // (Final|Native|Public) // @ game+0x218dd40
	void SkipToEndAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.SkipToEndAnimation // (Final|Native|Public) // @ game+0x218dcc0
	void ResumeAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.ResumeAnimation // (Final|Native|Public) // @ game+0x218dc40
	void RemoveAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.RemoveAnimation // (Final|Native|Public) // @ game+0x218dbc0
	void PlayAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.PlayAnimation // (Final|Native|Public) // @ game+0x218db40
	void PauseAnimation(struct FName AnimName); // Function KillstreakUINew.TickAnimationManager.PauseAnimation // (Final|Native|Public) // @ game+0x218dac0
	bool GetAnimationInfo(struct FName AnimName, struct FTickAnimationParams& OutAnimParams); // Function KillstreakUINew.TickAnimationManager.GetAnimationInfo // (Final|Native|Public|HasOutParms) // @ game+0x218d9b0
	void ApplyTick(float DeltaTime); // Function KillstreakUINew.TickAnimationManager.ApplyTick // (Final|Native|Public) // @ game+0x218d930
	void AddAnimation(struct FName AnimName, float Duration, struct FDelegate& UpdateEvent, struct FDelegate& FinishedEvent); // Function KillstreakUINew.TickAnimationManager.AddAnimation // (Final|Native|Public|HasOutParms) // @ game+0x218d7a0
};

