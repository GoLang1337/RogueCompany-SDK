// BlueprintGeneratedClass EventTracker_RankedXP.EventTracker_RankedXP_C
// Size: 0x224 (Inherited: 0x208)
struct UEventTracker_RankedXP_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	int32_t Progress; // 0x210(0x04)
	float RankedXpBonus; // 0x214(0x04)
	float RankedXpBase; // 0x218(0x04)
	float RankedXpFavoredMatchBonus; // 0x21c(0x04)
	float RankedXpAwarded; // 0x220(0x04)

	void LogExtraData(); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.LogExtraData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_RankedXP(int32_t EntryPoint); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.ExecuteUbergraph_EventTracker_RankedXP // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

