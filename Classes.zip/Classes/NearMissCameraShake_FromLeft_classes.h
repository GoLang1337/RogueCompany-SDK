// BlueprintGeneratedClass NearMissCameraShake_FromLeft.NearMissCameraShake_FromLeft_C
// Size: 0x160 (Inherited: 0x160)
struct UNearMissCameraShake_FromLeft_C : UCameraShake {
};

