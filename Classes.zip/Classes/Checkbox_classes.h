// WidgetBlueprintGeneratedClass Checkbox.Checkbox_C
// Size: 0x570 (Inherited: 0x518)
struct UCheckbox_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWidgetSwitcher* background; // 0x520(0x08)
	struct UImage* Check; // 0x528(0x08)
	struct UButton* HitTarget; // 0x530(0x08)
	struct UImage* Hovered; // 0x538(0x08)
	struct UImage* Unhovered; // 0x540(0x08)
	bool Checked; // 0x548(0x01)
	char pad_549[0x7]; // 0x549(0x07)
	struct FMulticastInlineDelegate OnCheckChanged; // 0x550(0x10)
	struct UAkAudioEvent* HoverCheckboxSFX; // 0x560(0x08)
	struct UAkAudioEvent* ClickCheckboxSFX; // 0x568(0x08)

	bool NavigateConfirm(); // Function Checkbox.Checkbox_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature(); // Function Checkbox.Checkbox_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_0_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function Checkbox.Checkbox_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function Checkbox.Checkbox_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void SetCheckedState(bool Checked); // Function Checkbox.Checkbox_C.SetCheckedState // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GamepadConfirm(); // Function Checkbox.Checkbox_C.GamepadConfirm // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GamepadHover(); // Function Checkbox.Checkbox_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadUnhover(); // Function Checkbox.Checkbox_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_Checkbox(int32_t EntryPoint); // Function Checkbox.Checkbox_C.ExecuteUbergraph_Checkbox // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void OnCheckChanged__DelegateSignature(bool Checked); // Function Checkbox.Checkbox_C.OnCheckChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

