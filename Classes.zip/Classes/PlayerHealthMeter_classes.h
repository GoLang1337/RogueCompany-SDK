// DynamicClass PlayerHealthMeter.PlayerHealthMeter_C
// Size: 0x340 (Inherited: 0x238)
struct UPlayerHealthMeter_C : UKSPlayerHealthMeterBase {
	struct UWidgetAnimation* Pulseborder; // 0x238(0x08)
	struct UWidgetAnimation* DisableImmune; // 0x240(0x08)
	struct UWidgetAnimation* EnableImmune; // 0x248(0x08)
	struct UImage* BorderShimmer; // 0x250(0x08)
	struct UOverlay* ImmuneOverlay; // 0x258(0x08)
	struct UImage* OutlineBorder; // 0x260(0x08)
	struct UUserWidget* PlayerHealthMeterPadding; // 0x268(0x08)
	struct UUserWidget* PlayerHealthMeterSegment; // 0x270(0x08)
	struct UHorizontalBox* SegmentContainer; // 0x278(0x08)
	int32_t HealthSegmentWidth; // 0x280(0x04)
	bool ShouldUseDots; // 0x284(0x01)
	char pad_285[0x3]; // 0x285(0x03)
	struct FPlayerHealthMeterState CurrentHealthMeterState; // 0x288(0x18)
	float SegmentPadding; // 0x2a0(0x04)
	struct FLinearColor ImmuneBorderColor; // 0x2a4(0x10)
	struct FLinearColor StandardBorderColor; // 0x2b4(0x10)
	bool bIsImmune; // 0x2c4(0x01)
	bool bIsEnemyHealth; // 0x2c5(0x01)
	bool bNameplateWidgetOptimizations; // 0x2c6(0x01)
	char pad_2C7[0x1]; // 0x2c7(0x01)
	int32_t OriginalHealthSegmentWidth; // 0x2c8(0x04)
	enum class EColorVisionDeficiency ColorCorrection; // 0x2cc(0x01)
	char pad_2CD[0x3]; // 0x2cd(0x03)
	struct UImage* K2Node_CustomEvent_OutlineBorder_2; // 0x2d0(0x08)
	struct UImage* K2Node_CustomEvent_OutlineBorder; // 0x2d8(0x08)
	int32_t Temp_int_Loop_Counter_Variable; // 0x2e0(0x04)
	int32_t Temp_int_Array_Index_Variable; // 0x2e4(0x04)
	bool K2Node_Event_IsDesignTime; // 0x2e8(0x01)
	char pad_2E9[0x3]; // 0x2e9(0x03)
	struct FPlayerHealthMeterState K2Node_Event_HealthMeterState; // 0x2ec(0x18)
	char pad_304[0x4]; // 0x304(0x04)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue; // 0x308(0x10)
	struct FMargin K2Node_MakeStruct_Margin; // 0x318(0x10)
	struct UWidget* CallFunc_Array_Get_Item; // 0x328(0x08)
	struct UUserWidget* K2Node_DynamicCast_AsPlayer_Health_Meter_Segment; // 0x330(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)

	void UpdateColorCorrectionValue(enum class EColorVisionDeficiency bpp__ColorCorrection__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.UpdateColorCorrectionValue // (Native|Public|BlueprintCallable) // @ game+0x186add0
	void SetImmune(bool bpp__bEnabled__pf, bool bpp__bImmediate__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.SetImmune // (Native|Public|BlueprintCallable) // @ game+0x186ad00
	void SetHealthMeterState(struct FPlayerHealthMeterState bpp__HealthMeterState__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.SetHealthMeterState // (Native|Event|Public|BlueprintCallable) // @ game+0x186ac50
	void SequenceEvent__ENTRYPOINTPlayerHealthMeter_2(struct UImage* bpp__OutlineBorder__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.SequenceEvent__ENTRYPOINTPlayerHealthMeter_2 // (Native|Public|BlueprintCallable) // @ game+0x1856a10
	void SequenceEvent__ENTRYPOINTPlayerHealthMeter_1(struct UImage* bpp__OutlineBorder__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.SequenceEvent__ENTRYPOINTPlayerHealthMeter_1 // (Native|Public|BlueprintCallable) // @ game+0x1856750
	void PreConstruct(bool bpp__IsDesignTime__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.PreConstruct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x186abc0
	void PlayDamagePulse(); // Function PlayerHealthMeter.PlayerHealthMeter_C.PlayDamagePulse // (Native|Public|BlueprintCallable) // @ game+0xb58e90
	void OnEnableImmuneParams(struct UImage* bpp__OutlineBorder__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.OnEnableImmuneParams // (Native|Public|BlueprintCallable) // @ game+0x186ab30
	void OnDisableImmuneParams(struct UImage* bpp__OutlineBorder__pf); // Function PlayerHealthMeter.PlayerHealthMeter_C.OnDisableImmuneParams // (Native|Public|BlueprintCallable) // @ game+0x186aaa0
	void InitNameplateWidgetOptimizations(); // Function PlayerHealthMeter.PlayerHealthMeter_C.InitNameplateWidgetOptimizations // (Native|Public|BlueprintCallable) // @ game+0x18566a0
	void Construct(); // Function PlayerHealthMeter.PlayerHealthMeter_C.Construct // (BlueprintCosmetic|Native|Event|Public) // @ game+0x1856110
	void Apply State To Segments(); // Function PlayerHealthMeter.PlayerHealthMeter_C.Apply State To Segments // (Native|Public|BlueprintCallable) // @ game+0x1856130
	void Add Segments if Needed(); // Function PlayerHealthMeter.PlayerHealthMeter_C.Add Segments if Needed // (Native|Public|BlueprintCallable) // @ game+0x186a9d0
};

