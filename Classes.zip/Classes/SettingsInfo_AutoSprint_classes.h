// BlueprintGeneratedClass SettingsInfo_AutoSprint.SettingsInfo_AutoSprint_C
// Size: 0x118 (Inherited: 0x118)
struct USettingsInfo_AutoSprint_C : UKSSettingsInfo_Generic {
};

