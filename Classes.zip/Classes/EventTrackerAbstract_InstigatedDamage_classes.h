// BlueprintGeneratedClass EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTrackerAbstract_InstigatedDamage_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void ProcessValidCombatEvent(struct FCombatEventInfo& ValidEventInfo, int32_t& TriggerCount); // Function EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C.ProcessValidCombatEvent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void IsValidCombatEvent(struct FCombatEventInfo& EventInfo, bool& IsValid); // Function EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C.IsValidCombatEvent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void EventHandleCombatEvent(struct FCombatEventInfo& DamageInfo); // Function EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C.EventHandleCombatEvent // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTrackerAbstract_InstigatedDamage(int32_t EntryPoint); // Function EventTrackerAbstract_InstigatedDamage.EventTrackerAbstract_InstigatedDamage_C.ExecuteUbergraph_EventTrackerAbstract_InstigatedDamage // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

