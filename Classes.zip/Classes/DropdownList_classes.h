// WidgetBlueprintGeneratedClass DropdownList.DropdownList_C
// Size: 0x598 (Inherited: 0x518)
struct UDropdownList_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UButton* ClickBlocker; // 0x520(0x08)
	struct UScrollBox* DropdownScroll; // 0x528(0x08)
	struct USizeBox* SizeBox_1; // 0x530(0x08)
	struct TArray<struct FText> Options; // 0x538(0x10)
	struct FMulticastInlineDelegate OnSelection; // 0x548(0x10)
	struct FMulticastInlineDelegate OnCancel; // 0x558(0x10)
	struct TArray<struct UDropdownEntry_C*> DropdownEntries; // 0x568(0x10)
	struct UDropdownEntry_C* SelectedEntry; // 0x578(0x08)
	float SizeBoxMaxHeight; // 0x580(0x04)
	char pad_584[0x4]; // 0x584(0x04)
	struct FMulticastInlineDelegate OnHoverPreview; // 0x588(0x10)

	bool NavigateBack(); // Function DropdownList.DropdownList_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function DropdownList.DropdownList_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Selection(int32_t Index, struct FText Text); // Function DropdownList.DropdownList_C.Selection // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function DropdownList.DropdownList_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleOnHover(struct UWidget* Widget, int32_t Index); // Function DropdownList.DropdownList_C.HandleOnHover // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetSelectedEntryByIndex(int32_t Index); // Function DropdownList.DropdownList_C.SetSelectedEntryByIndex // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__Button_123_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DropdownList.DropdownList_C.BndEvt__Button_123_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_DropdownList(int32_t EntryPoint); // Function DropdownList.DropdownList_C.ExecuteUbergraph_DropdownList // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void OnHoverPreview__DelegateSignature(int32_t Index); // Function DropdownList.DropdownList_C.OnHoverPreview__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnCancel__DelegateSignature(); // Function DropdownList.DropdownList_C.OnCancel__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnSelection__DelegateSignature(int32_t Index, struct FText Text); // Function DropdownList.DropdownList_C.OnSelection__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

