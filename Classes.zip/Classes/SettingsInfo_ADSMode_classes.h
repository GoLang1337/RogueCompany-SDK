// BlueprintGeneratedClass SettingsInfo_ADSMode.SettingsInfo_ADSMode_C
// Size: 0x118 (Inherited: 0x118)
struct USettingsInfo_ADSMode_C : UKSSettingsInfo_Generic {
};

