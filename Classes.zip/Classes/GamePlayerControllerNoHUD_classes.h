// BlueprintGeneratedClass GamePlayerControllerNoHUD.GamePlayerControllerNoHUD_C
// Size: 0xeb0 (Inherited: 0xe98)
struct AGamePlayerControllerNoHUD_C : AKSPlayerController {
	struct UPlayerControllerThreatComponent_C* PlayerControllerThreatComponent; // 0xe98(0x08)
	struct UAkComponent* ControllerAkComponent; // 0xea0(0x08)
	struct UDefaultEnvironmentListener_C* DefaultEnvironmentListener; // 0xea8(0x08)
};

