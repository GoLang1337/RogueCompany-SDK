// BlueprintGeneratedClass SettingsInfo_AntiAliasingQuality.SettingsInfo_AntiAliasingQuality_C
// Size: 0x120 (Inherited: 0x120)
struct USettingsInfo_AntiAliasingQuality_C : USettingsInfo_Quality_C {
};

