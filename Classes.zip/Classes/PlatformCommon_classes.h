// Class PlatformCommon.PComGameEngine
// Size: 0xee0 (Inherited: 0xea8)
struct UPComGameEngine : UGameEngine {
	char pad_EA8[0x10]; // 0xea8(0x10)
	bool bRedirectLogsToConsole; // 0xeb8(0x01)
	char pad_EB9[0x27]; // 0xeb9(0x27)
};

// Class PlatformCommon.PCom_IpConnection
// Size: 0x1b28 (Inherited: 0x1b20)
struct UPCom_IpConnection : UIpConnection {
	char pad_1B20[0x8]; // 0x1b20(0x08)
};

// Class PlatformCommon.PCom_LocalPlayer
// Size: 0x260 (Inherited: 0x260)
struct UPCom_LocalPlayer : ULocalPlayer {
};

// Class PlatformCommon.PCom_UDPEncryptionHandlerComponentFactory
// Size: 0x28 (Inherited: 0x28)
struct UPCom_UDPEncryptionHandlerComponentFactory : UHandlerComponentFactory {
};

// Class PlatformCommon.PCom_SimpleTimecodeProvider
// Size: 0x40 (Inherited: 0x30)
struct UPCom_SimpleTimecodeProvider : UTimecodeProvider {
	struct FFrameRate FrameRate; // 0x30(0x08)
	char pad_38[0x8]; // 0x38(0x08)

	void SetFrameRate(struct FFrameRate& InFrameRate); // Function PlatformCommon.PCom_SimpleTimecodeProvider.SetFrameRate // (Final|Native|Public|HasOutParms) // @ game+0x988c00
};

