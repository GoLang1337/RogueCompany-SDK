// BlueprintGeneratedClass FriendlyLobbyCharacter.FriendlyLobbyCharacter_C
// Size: 0x3ed8 (Inherited: 0x3eb3)
struct AFriendlyLobbyCharacter_C : ALobbyMainCharacter_C {
	char pad_3EB3[0x5]; // 0x3eb3(0x05)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3eb8(0x08)
	struct UWidgetComponent* WidgetNameplate; // 0x3ec0(0x08)
	bool NeedsToSetNameplate; // 0x3ec8(0x01)
	char pad_3EC9[0x7]; // 0x3ec9(0x07)
	struct UKSPlayerInfo* PendingPlayerInfo; // 0x3ed0(0x08)

	void ReceiveTick(float DeltaSeconds); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HideLobbyNameplate(); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.HideLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ShowLobbyNameplate(); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ShowLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetLobbyNameplate(struct UKSPlayerInfo* playerinfo); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.SetLobbyNameplate // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_FriendlyLobbyCharacter(int32_t EntryPoint); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ExecuteUbergraph_FriendlyLobbyCharacter // (Final|UbergraphFunction) // @ game+0x24d5b40
};

