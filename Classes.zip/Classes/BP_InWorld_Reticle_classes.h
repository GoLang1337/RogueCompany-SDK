// BlueprintGeneratedClass BP_InWorld_Reticle.BP_InWorld_Reticle_C
// Size: 0x248 (Inherited: 0x220)
struct ABP_InWorld_Reticle_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UWidgetComponent* Reticle; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	struct UWBP_InWorld_Reticle_C* ReticleWidget; // 0x238(0x08)
	struct UWBP_InWorld_ReticleComponents_C* ReticleComponentWidget; // 0x240(0x08)

	void SetWeaponComponent(struct UKSWeaponComponent* WeaponComponent); // Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.SetWeaponComponent // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetPossession(struct APlayerState* PlayerState); // Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.SetPossession // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_BP_InWorld_Reticle(int32_t EntryPoint); // Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.ExecuteUbergraph_BP_InWorld_Reticle // (Final|UbergraphFunction) // @ game+0x24d5b40
};

