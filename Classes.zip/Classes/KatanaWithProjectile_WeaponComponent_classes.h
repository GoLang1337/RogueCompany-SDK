// DynamicClass KatanaWithProjectile_WeaponComponent.KatanaWithProjectile_WeaponComponent_C
// Size: 0x1610 (Inherited: 0x15a0)
struct UKatanaWithProjectile_WeaponComponent_C : UMasterMelee_WeaponComponent_C {
	struct FFullFireRepData K2Node_Event_Data; // 0x15a0(0x68)
	bool K2Node_Event_PlayNoChainFireMontage; // 0x1608(0x01)
	char pad_1609[0x7]; // 0x1609(0x07)
};

