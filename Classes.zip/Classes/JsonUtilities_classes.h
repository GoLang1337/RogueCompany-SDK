// Class JsonUtilities.JsonUtilitiesDummyObject
// Size: 0x28 (Inherited: 0x28)
struct UJsonUtilitiesDummyObject : UObject {
};

