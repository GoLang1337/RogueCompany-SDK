// WidgetBlueprintGeneratedClass NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C
// Size: 0x599 (Inherited: 0x518)
struct UNewWBP_LobbyNameplate_C : UKSLobbyNameplateWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UKSAsyncImage* AvatarIcon; // 0x520(0x08)
	struct UImage* PartyLeader; // 0x528(0x08)
	struct USizeBox* PartyLeaderIcon; // 0x530(0x08)
	struct UHorizontalBox* PlayerDisplay; // 0x538(0x08)
	struct UTextBlock* PlayerName; // 0x540(0x08)
	struct UTextBlock* ProgressNum; // 0x548(0x08)
	struct UHorizontalBox* RankedDisplayWrapper; // 0x550(0x08)
	struct UWBP_RankedIcon_C* RankedIcon; // 0x558(0x08)
	struct UVerticalBox* RankedProgress; // 0x560(0x08)
	struct UWBP_ProgressEarnedBar_C* RankedProgressBar; // 0x568(0x08)
	struct UTextBlock* TotalNum; // 0x570(0x08)
	struct UKSPartyDataFactory* PartyDataFactory; // 0x578(0x08)
	int32_t MaxNameLength; // 0x580(0x04)
	char pad_584[0x4]; // 0x584(0x04)
	struct UKSPlayerInfo* StoredPlayerInfo; // 0x588(0x08)
	struct UKSQueueDataFactory* QueueDataFactory; // 0x590(0x08)
	bool ShouldShowRankedXp; // 0x598(0x01)

	void UpdateRankedTotal(bool Index, int32_t RequiredPlacementMatches); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdateRankedTotal // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdatePlayerName(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdatePlayerName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdateRankedData(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdateRankedData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnPartyUpdated(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnPartyUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdateSelectedQueue(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdateSelectedQueue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetPlayerDisplayVisible(bool IsVisible); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetPlayerDisplayVisible // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdatePartyLeaderIcon(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.UpdatePartyLeaderIcon // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetPlayerInfo(struct UKSPlayerInfo* playerinfo); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetPlayerInfo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnPossession(struct APlayerState* PlayerState, struct AKSCharacter* Character); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnPossession // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnHovered(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnHovered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnUnhovered(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnUnhovered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Construct(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetName(struct FText InName); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetName // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetAvatar(struct UKSItem* AvatarItem); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.SetAvatar // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnInitialized(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void RefreshRankedData(); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.RefreshRankedData // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleOnPartyMemberPromoted(int64_t PlayerId); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.HandleOnPartyMemberPromoted // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_NewWBP_LobbyNameplate(int32_t EntryPoint); // Function NewWBP_LobbyNameplate.NewWBP_LobbyNameplate_C.ExecuteUbergraph_NewWBP_LobbyNameplate // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

