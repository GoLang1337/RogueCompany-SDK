// BlueprintGeneratedClass ANotifyState_PropLock.ANotifyState_PropLock_C
// Size: 0x33 (Inherited: 0x30)
struct UANotifyState_PropLock_C : UAnimNotifyState {
	bool HolsterLock; // 0x30(0x01)
	bool Left Holster Lock; // 0x31(0x01)
	bool No Prop Lock While Sprinting; // 0x32(0x01)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_PropLock.ANotifyState_PropLock_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_PropLock.ANotifyState_PropLock_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

