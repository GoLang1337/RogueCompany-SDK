// BlueprintGeneratedClass ExplosiveStakeDamageType.ExplosiveStakeDamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UExplosiveStakeDamageType_C : UMasterExplosion_DamageType_C {
};

