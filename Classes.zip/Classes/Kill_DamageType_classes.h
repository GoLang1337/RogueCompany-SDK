// BlueprintGeneratedClass Kill_DamageType.Kill_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UKill_DamageType_C : UKSDamageTypeBase {
};

