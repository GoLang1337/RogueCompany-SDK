// BlueprintGeneratedClass EmoteSoundManager.EmoteSoundManager_C
// Size: 0x268 (Inherited: 0x260)
struct AEmoteSoundManager_C : AKSEmoteMusicManager {
	struct USceneComponent* DefaultSceneRoot; // 0x260(0x08)
};

