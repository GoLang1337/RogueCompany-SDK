// BlueprintGeneratedClass Jump_CameraShake.Jump_CameraShake_C
// Size: 0x180 (Inherited: 0x180)
struct UJump_CameraShake_C : UKSCharacterCameraShake {
};

