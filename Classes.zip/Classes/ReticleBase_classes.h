// WidgetBlueprintGeneratedClass ReticleBase.ReticleBase_C
// Size: 0x258 (Inherited: 0x238)
struct UReticleBase_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x238(0x08)
	struct UImage* LoneDot; // 0x240(0x08)
	float LowAmmoThreshold; // 0x248(0x04)
	float CriticallyLowAmmoThreshold; // 0x24c(0x04)
	struct UKSSettingsColorOptionsAsset* SettingsColorOptionAsset; // 0x250(0x08)

	void Set Reticle Color(struct FLinearColor Color); // Function ReticleBase.ReticleBase_C.Set Reticle Color // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void On Reticle Color Changed(); // Function ReticleBase.ReticleBase_C.On Reticle Color Changed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Set Reticle Width(int32_t Width); // Function ReticleBase.ReticleBase_C.Set Reticle Width // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Set Reticle Height(int32_t Height); // Function ReticleBase.ReticleBase_C.Set Reticle Height // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void On Reticle Width Changed(); // Function ReticleBase.ReticleBase_C.On Reticle Width Changed // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void On Reticle Height Changed(); // Function ReticleBase.ReticleBase_C.On Reticle Height Changed // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void On Reticle Dimension Changed(); // Function ReticleBase.ReticleBase_C.On Reticle Dimension Changed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ChangeReticleSize(); // Function ReticleBase.ReticleBase_C.ChangeReticleSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GetAmmoState(struct UKSWeaponComponent* NewParam, enum class EAmmoState& Return Value); // Function ReticleBase.ReticleBase_C.GetAmmoState // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void HitConfirm(); // Function ReticleBase.ReticleBase_C.HitConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ForceADS(bool Active); // Function ReticleBase.ReticleBase_C.ForceADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GrenadeCook(bool Active, float TickPeriod); // Function ReticleBase.ReticleBase_C.GrenadeCook // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ChangeADS(bool Active); // Function ReticleBase.ReticleBase_C.ChangeADS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void KillConfirm(); // Function ReticleBase.ReticleBase_C.KillConfirm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Headshot(); // Function ReticleBase.ReticleBase_C.Headshot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdateOffset(float Offset); // Function ReticleBase.ReticleBase_C.UpdateOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnInitialized(); // Function ReticleBase.ReticleBase_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ReticleBase(int32_t EntryPoint); // Function ReticleBase.ReticleBase_C.ExecuteUbergraph_ReticleBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

