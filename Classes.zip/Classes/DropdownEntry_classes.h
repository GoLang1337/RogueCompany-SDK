// WidgetBlueprintGeneratedClass DropdownEntry.DropdownEntry_C
// Size: 0x598 (Inherited: 0x518)
struct UDropdownEntry_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWidgetAnimation* Hover; // 0x520(0x08)
	struct UImage* Color_Swatch_Brush; // 0x528(0x08)
	struct UButton* HitTarget; // 0x530(0x08)
	struct UTextBlock* OptionText; // 0x538(0x08)
	struct UImage* Selected; // 0x540(0x08)
	struct FText Text; // 0x548(0x18)
	int32_t Index; // 0x560(0x04)
	char pad_564[0x4]; // 0x564(0x04)
	struct FMulticastInlineDelegate OnOptionSelected; // 0x568(0x10)
	struct FMulticastInlineDelegate OnOptionHovered; // 0x578(0x10)
	struct UAkAudioEvent* HoverDropdownEntrySFX; // 0x588(0x08)
	struct UAkAudioEvent* ClickDropdownEntrySFX; // 0x590(0x08)

	bool NavigateConfirm(); // Function DropdownEntry.DropdownEntry_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Construct(); // Function DropdownEntry.DropdownEntry_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function DropdownEntry.DropdownEntry_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature(); // Function DropdownEntry.DropdownEntry_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_7_OnButtonHoverEvent__DelegateSignature(); // Function DropdownEntry.DropdownEntry_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_7_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void GamepadHover(); // Function DropdownEntry.DropdownEntry_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadUnhover(); // Function DropdownEntry.DropdownEntry_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadConfirm(); // Function DropdownEntry.DropdownEntry_C.GamepadConfirm // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ChangeSelectionState(bool Selected); // Function DropdownEntry.DropdownEntry_C.ChangeSelectionState // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_DropdownEntry(int32_t EntryPoint); // Function DropdownEntry.DropdownEntry_C.ExecuteUbergraph_DropdownEntry // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void OnOptionHovered__DelegateSignature(struct UWidget* Widget, int32_t Index); // Function DropdownEntry.DropdownEntry_C.OnOptionHovered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnOptionSelected__DelegateSignature(int32_t Index, struct FText Text); // Function DropdownEntry.DropdownEntry_C.OnOptionSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

