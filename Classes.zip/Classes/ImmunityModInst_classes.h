// BlueprintGeneratedClass ImmunityModInst.ImmunityModInst_C
// Size: 0x1c8 (Inherited: 0x1c0)
struct UImmunityModInst_C : UDamageResistModInst_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1c0(0x08)

	void ReceiveBeginPlay(); // Function ImmunityModInst.ImmunityModInst_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveTick(float DeltaSeconds); // Function ImmunityModInst.ImmunityModInst_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function ImmunityModInst.ImmunityModInst_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnNewCharacterFoundation(); // Function ImmunityModInst.ImmunityModInst_C.OnNewCharacterFoundation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ImmunityModInst(int32_t EntryPoint); // Function ImmunityModInst.ImmunityModInst_C.ExecuteUbergraph_ImmunityModInst // (Final|UbergraphFunction) // @ game+0x24d5b40
};

