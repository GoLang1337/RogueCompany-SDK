// BlueprintGeneratedClass CircleDeadZone_RightStick.CircleDeadZone_RightStick_C
// Size: 0x40 (Inherited: 0x40)
struct UCircleDeadZone_RightStick_C : UKSCircleDeadZoneFilter {
};

