// WidgetBlueprintGeneratedClass ScoreboardOverview.ScoreboardOverview_C
// Size: 0x590 (Inherited: 0x518)
struct UScoreboardOverview_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWBP_ScoreboardDisconnectedSection_Lobby_C* DisconnectedPlayers; // 0x520(0x08)
	struct UImage* Eliminated_Enemy; // 0x528(0x08)
	struct UImage* Objective_Enemy; // 0x530(0x08)
	struct UScoreboardTeamSection_Lobby_C* ScoreboardTeamSection_Lobby; // 0x538(0x08)
	struct UVerticalBox* TeamSections; // 0x540(0x08)
	struct UImage* TimeExpired_Enemy; // 0x548(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x550(0x08)
	struct UWBP_RoundRecap_C* WBP_RoundRecap; // 0x558(0x08)
	struct UPUMG_PlayerDataFactory* PlayerDataFactory; // 0x560(0x08)
	struct TArray<struct UScoreboardTeamSection_Lobby_C*> teams; // 0x568(0x10)
	bool DidWin; // 0x578(0x01)
	char pad_579[0x7]; // 0x579(0x07)
	struct FMulticastInlineDelegate OnTeamsChanged; // 0x580(0x10)

	void GetAllPlayerDisplays(struct TArray<struct UScoreboardPlayerStats_Lobby_C*>& Widgets); // Function ScoreboardOverview.ScoreboardOverview_C.GetAllPlayerDisplays // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void CreateTeamDisplay(struct FTeamStats& TeamStats, struct FScoreboardStats& ScoreboardStats, struct UScoreboardTeamSection_Lobby_C*& ScoreboardTeam); // Function ScoreboardOverview.ScoreboardOverview_C.CreateTeamDisplay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PopulateScoreboard(struct FScoreboardStats ScoreboardStatStruct); // Function ScoreboardOverview.ScoreboardOverview_C.PopulateScoreboard // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function ScoreboardOverview.ScoreboardOverview_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetMatchResult(bool DidWin); // Function ScoreboardOverview.ScoreboardOverview_C.SetMatchResult // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetTeamColor(); // Function ScoreboardOverview.ScoreboardOverview_C.SetTeamColor // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function ScoreboardOverview.ScoreboardOverview_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleTeamPlayersChanged(); // Function ScoreboardOverview.ScoreboardOverview_C.HandleTeamPlayersChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ScoreboardOverview(int32_t EntryPoint); // Function ScoreboardOverview.ScoreboardOverview_C.ExecuteUbergraph_ScoreboardOverview // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void OnTeamsChanged__DelegateSignature(); // Function ScoreboardOverview.ScoreboardOverview_C.OnTeamsChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

