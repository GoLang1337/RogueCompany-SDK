// Enum EKSMilestoneCompleteAnimState.EKSMilestoneCompleteAnimState
enum class EKSMilestoneCompleteAnimState : uint8 {
	NewEnumerator7 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator8 = 3,
	NewEnumerator2 = 4,
	NewEnumerator3 = 5,
	NewEnumerator4 = 6,
	NewEnumerator5 = 7,
	NewEnumerator6 = 8,
	NewEnumerator9 = 9,
	NewEnumerator11 = 10,
	EKSMilestoneCompleteAnimState_MAX = 11
};

