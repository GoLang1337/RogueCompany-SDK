// BlueprintGeneratedClass LaunchCinematicViewRedirector.LaunchCinematicViewRedirector_C
// Size: 0x30 (Inherited: 0x30)
struct ULaunchCinematicViewRedirector_C : UKSViewRedirector_OpeningCinematic {
};

