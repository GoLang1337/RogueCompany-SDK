// BlueprintGeneratedClass EventTracker_TheTwoTime.EventTracker_TheTwoTime_C
// Size: 0x228 (Inherited: 0x208)
struct UEventTracker_TheTwoTime_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	float CurrentProgress; // 0x210(0x04)
	char pad_214[0x4]; // 0x214(0x04)
	struct FString RequiredMap; // 0x218(0x10)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_TheTwoTime.EventTracker_TheTwoTime_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_TheTwoTime.EventTracker_TheTwoTime_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_TheTwoTime.EventTracker_TheTwoTime_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_TheTwoTime(int32_t EntryPoint); // Function EventTracker_TheTwoTime.EventTracker_TheTwoTime_C.ExecuteUbergraph_EventTracker_TheTwoTime // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

