// WidgetBlueprintGeneratedClass FirstTimeLanguageWidget.FirstTimeLanguageWidget_C
// Size: 0x510 (Inherited: 0x4b8)
struct UFirstTimeLanguageWidget_C : UPUMG_Widget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b8(0x08)
	struct UImage* Decro; // 0x4c0(0x08)
	struct UImage* Image_159; // 0x4c8(0x08)
	struct UOverlay* SettingsWidgetContainer; // 0x4d0(0x08)
	struct UTextBlock* Title; // 0x4d8(0x08)
	struct UWBP_StandardButtonMedium_C* WBP_StandardButtonMedium; // 0x4e0(0x08)
	struct FKSSettingsWidgetConfig SettingsWidgetConfig; // 0x4e8(0x10)
	struct UKSSettingsInfoBase* SettingsInfo; // 0x4f8(0x08)
	struct UKSSettingsWidget* SettingsWidget; // 0x500(0x08)
	struct UAkAudioEvent* ShowFirstTimeLanguageSFX; // 0x508(0x08)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnShown(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleInputState(enum class PGAME_INPUT_STATE InputState); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.HandleInputState // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SaveSetting(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.SaveSetting // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnHide(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.OnHide // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnSettingSelected(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.OnSettingSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_FirstTimeLanguageWidget(int32_t EntryPoint); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.ExecuteUbergraph_FirstTimeLanguageWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

