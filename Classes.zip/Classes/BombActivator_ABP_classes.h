// AnimBlueprintGeneratedClass BombActivator_ABP.BombActivator_ABP_C
// Size: 0x7d3 (Inherited: 0x270)
struct UBombActivator_ABP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x278(0x40)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x2b8(0x58)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x310(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x348(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x380(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x3b8(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x3f0(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x478(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x4b8(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x540(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x580(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x608(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x648(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x6d0(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x710(0xc0)
	bool BombDisarming; // 0x7d0(0x01)
	bool BombPlanted; // 0x7d1(0x01)
	bool NewVar_1; // 0x7d2(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BombActivator_ABP.BombActivator_ABP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BombActivator_ABP_AnimGraphNode_TransitionResult_BAB1EF554FE8E3E61CD2458A88DC7339(); // Function BombActivator_ABP.BombActivator_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BombActivator_ABP_AnimGraphNode_TransitionResult_BAB1EF554FE8E3E61CD2458A88DC7339 // (BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_PlayBombPlantedSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_PlayBombPlantedSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_PlayBombLoopSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_PlayBombLoopSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_PlayBombDisarmingSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_PlayBombDisarmingSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_StopBombPlantedSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_StopBombPlantedSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_StopBombLoopSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_StopBombLoopSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_StopBombDisarmingSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_StopBombDisarmingSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_BombActivator_ABP(int32_t EntryPoint); // Function BombActivator_ABP.BombActivator_ABP_C.ExecuteUbergraph_BombActivator_ABP // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

