// BlueprintGeneratedClass BulwarkShield_DamageType.BulwarkShield_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UBulwarkShield_DamageType_C : UMasterMelee_DamageType_C {
};

