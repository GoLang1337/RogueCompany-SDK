// DynamicClass AttackBomb_WeaponComponent.AttackBomb_WeaponComponent_C
// Size: 0x1250 (Inherited: 0x1230)
struct UAttackBomb_WeaponComponent_C : UMaster_WeaponComponent_C {
	struct AKSCharacter* K2Node_Event_SkyDiver_3; // 0x1228(0x08)
	bool CallFunc_DoesCharacterHaveHoverboard_Has_Hoverboard; // 0x1230(0x01)
	struct AKSCharacter* K2Node_Event_SkyDiver_2; // 0x1238(0x08)
	struct AKSCharacter* K2Node_Event_SkyDiver; // 0x1240(0x08)
	enum class EWeaponStateNew K2Node_Event_OldState; // 0x1248(0x01)
	enum class EWeaponStateNew K2Node_Event_NewState; // 0x1249(0x01)
	bool K2Node_SwitchEnum_CmpSuccess; // 0x124a(0x01)
	bool CallFunc_DoesCharacterHaveBackpack_HasBackpack; // 0x124b(0x01)
	bool CallFunc_DoesCharacterHaveBackpack_HasBackpack_2; // 0x124c(0x01)
	char pad_124E[0x2]; // 0x124e(0x02)

	void OnSkyDiveStarted(struct AKSCharacter* bpp__SkyDiver__pf); // Function AttackBomb_WeaponComponent.AttackBomb_WeaponComponent_C.OnSkyDiveStarted // (Native|Event|Public) // @ game+0x1822960
	void OnSkyDiveSkipped(struct AKSCharacter* bpp__SkyDiver__pf); // Function AttackBomb_WeaponComponent.AttackBomb_WeaponComponent_C.OnSkyDiveSkipped // (Native|Event|Public) // @ game+0x18228d0
	void OnSkyDiveEnded(struct AKSCharacter* bpp__SkyDiver__pf); // Function AttackBomb_WeaponComponent.AttackBomb_WeaponComponent_C.OnSkyDiveEnded // (Native|Event|Public) // @ game+0x1822840
	void DoesCharacterHaveHoverboard(struct AKSCharacter* bpp__Character__pf, bool& bpp__HasxHoverboard__pfT); // Function AttackBomb_WeaponComponent.AttackBomb_WeaponComponent_C.DoesCharacterHaveHoverboard // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1822580
	void DoesCharacterHaveBackpack(bool& bpp__HasBackpack__pf); // Function AttackBomb_WeaponComponent.AttackBomb_WeaponComponent_C.DoesCharacterHaveBackpack // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x18224e0
};

