// Enum ADSRollControlsEnum.ADSRollControlsEnum
enum class ADSRollControlsEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ADSRollControlsEnum_MAX = 3
};

