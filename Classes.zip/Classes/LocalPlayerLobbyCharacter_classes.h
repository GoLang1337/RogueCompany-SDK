// BlueprintGeneratedClass LocalPlayerLobbyCharacter.LocalPlayerLobbyCharacter_C
// Size: 0x3ed2 (Inherited: 0x3eb3)
struct ALocalPlayerLobbyCharacter_C : ALobbyMainCharacter_C {
	char pad_3EB3[0x5]; // 0x3eb3(0x05)
	struct FString PendingPlayerName; // 0x3eb8(0x10)
	struct UKSItem* PendingAvatar; // 0x3ec8(0x08)
	bool PendingIsLeader; // 0x3ed0(0x01)
	bool NeedsToSetNameplate; // 0x3ed1(0x01)
};

