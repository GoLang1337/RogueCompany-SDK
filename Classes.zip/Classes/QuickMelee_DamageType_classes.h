// BlueprintGeneratedClass QuickMelee_DamageType.QuickMelee_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UQuickMelee_DamageType_C : UMasterMelee_DamageType_C {
};

