// Enum Killstreak.EItemSourceType
enum class EItemSourceType : uint8 {
	Unknown = 0,
	AbilityUse = 1,
	Cheat = 2,
	InitialInventory = 3,
	LobbyAnimation = 4,
	PickupInteraction = 5,
	Refund = 6,
	RestoreInventory = 7,
	StorePurchase = 8,
	WeaponSwap = 9,
	ServerTravel = 10,
	EItemSourceType_MAX = 11
};

// Enum Killstreak.EDropPickupConfig
enum class EDropPickupConfig : uint8 {
	AllPlayers = 0,
	EnemiesOnly = 1,
	FriendliesOnly = 2,
	EDropPickupConfig_MAX = 3
};

// Enum Killstreak.EKSCharacterAimMode
enum class EKSCharacterAimMode : uint8 {
	Default = 0,
	TransitionToDefault = 1,
	Shoulder = 2,
	TransitionToShoulder = 3,
	AimDownSights = 4,
	TransitionToAimDownSights = 5,
	Alternate = 6,
	TransitionToAlternate = 7,
	EKSCharacterAimMode_MAX = 8
};

// Enum Killstreak.EKSEmotion
enum class EKSEmotion : uint8 {
	Neutral = 0,
	Focused = 1,
	Pain = 2,
	Wounded = 3,
	Dead = 4,
	MAX = 5
};

// Enum Killstreak.EAmmoType
enum class EAmmoType : uint8 {
	NINE_MM = 0,
	SEVEN_63 = 1,
	FIVE_57 = 2,
	TWELVE_G = 3,
	FORTY_FIVE = 4,
	THREE_HUND = 5,
	TWENTY_TWO = 6,
	FIFTY = 7,
	ABILITY = 8,
	NONE = 9,
	EAmmoType_MAX = 10
};

// Enum Killstreak.ECharacterBehaviorState
enum class ECharacterBehaviorState : uint8 {
	Combat = 0,
	Idle = 1,
	Skydive = 2,
	ECharacterBehaviorState_MAX = 3
};

// Enum Killstreak.EKSCamouflageLevel
enum class EKSCamouflageLevel : uint8 {
	Weak = 0,
	Medium = 1,
	Strong = 2,
	Full = 3,
	EKSCamouflageLevel_MAX = 4
};

// Enum Killstreak.EKSAbilityUsageFailureType
enum class EKSAbilityUsageFailureType : uint8 {
	Unknown = 0,
	Dead = 1,
	Downed = 2,
	EMP = 3,
	NoFireZone = 4,
	AlreadyActivating = 5,
	Driving = 6,
	Stunned = 7,
	BlockingMovement = 8,
	HardLanding = 9,
	OutOfBounds = 10,
	Locked = 11,
	AltLocked = 12,
	NotEnoughCharge = 13,
	NoBountyTarget = 14,
	NoLinkTarget = 15,
	AlreadyHasWeapon = 16,
	WeaponBusy = 17,
	RoundNotInProgress = 18,
	EKSAbilityUsageFailureType_MAX = 19
};

// Enum Killstreak.EKSItemUsageFailureType
enum class EKSItemUsageFailureType : uint8 {
	Unknown = 0,
	NotEnoughQuantity = 1,
	BlockingAction = 2,
	NoEffect = 3,
	EMP = 4,
	EKSItemUsageFailureType_MAX = 5
};

// Enum Killstreak.EShotgunHitResult
enum class EShotgunHitResult : uint8 {
	Miss = 0,
	Hit = 1,
	Headshot = 2,
	EShotgunHitResult_MAX = 3
};

// Enum Killstreak.EWeaponStateNew
enum class EWeaponStateNew : uint8 {
	Idle = 0,
	Buildup = 1,
	PreFire = 2,
	PostFire = 3,
	Cooldown = 4,
	PreReload = 5,
	PostReload = 6,
	ReloadCooldown = 7,
	Retrieve = 8,
	Holster = 9,
	Inactive = 10,
	NotValid = 11,
	EWeaponStateNew_MAX = 12
};

// Enum Killstreak.EShopItemType
enum class EShopItemType : uint8 {
	None = 0,
	PrimaryOne = 1,
	PrimaryTwo = 2,
	SecondaryOne = 3,
	SecondaryTwo = 4,
	GadgetOne = 5,
	GadgetTwo = 6,
	Melee = 7,
	PerkOne = 8,
	PerkTwo = 9,
	PerkThree = 10,
	PerkFour = 11,
	PerkFive = 12,
	PerkSix = 13,
	GambitOne = 14,
	GambitTwo = 15,
	GambitThree = 16,
	GambitFour = 17,
	GambitFive = 18,
	GambitSix = 19,
	GlobalPerk1 = 20,
	GlobalPerk2 = 21,
	GlobalPerk3 = 22,
	GlobalPerk4 = 23,
	GlobalPerk5 = 24,
	GlobalPerk6 = 25,
	GlobalPerk7 = 26,
	GlobalPerk8 = 27,
	GlobalPerk9 = 28,
	GlobalPerk10 = 29,
	GlobalPerk11 = 30,
	GlobalPerk12 = 31,
	GlobalPerk13 = 32,
	GlobalPerk14 = 33,
	GlobalPerk15 = 34,
	MAX = 35
};

// Enum Killstreak.EProjectileExplosionType
enum class EProjectileExplosionType : uint8 {
	Impact = 0,
	Fizzle = 1,
	FuseExpired = 2,
	EProjectileExplosionType_MAX = 3
};

// Enum Killstreak.EModViewModeStateChangeReason
enum class EModViewModeStateChangeReason : uint8 {
	Activated = 0,
	SpectatorChange = 1,
	Timeout = 2,
	Death = 3,
	EModViewModeStateChangeReason_MAX = 4
};

// Enum Killstreak.EModViewModeState
enum class EModViewModeState : uint8 {
	Off = 0,
	OnButUnviewed = 1,
	OnAndViewed = 2,
	EModViewModeState_MAX = 3
};

// Enum Killstreak.EHitLocationType
enum class EHitLocationType : uint8 {
	Body = 0,
	Head = 1,
	Limb = 2,
	None = 3,
	EHitLocationType_MAX = 4
};

// Enum Killstreak.ETrackedActorType
enum class ETrackedActorType : uint8 {
	Unknown = 0,
	ShieldWeapon = 1,
	MagGloveTarget = 2,
	CoopEscapePoint = 3,
	BountyTarget = 4,
	BombDrop = 5,
	CashDrop = 6,
	Projectile = 7,
	HackTablet = 8,
	ETrackedActorType_MAX = 9
};

// Enum Killstreak.ELootSiteRarity
enum class ELootSiteRarity : uint8 {
	Personal = 0,
	Normal = 1,
	Uncommon = 2,
	Epic = 3,
	Rare = 4,
	Legendary = 5,
	NonWeapons = 6,
	ChildSpawner = 7,
	CarePackage = 8,
	MedPack = 9,
	StartingDrop = 10,
	GameMode = 11,
	PowerUp = 12,
	ELootSiteRarity_MAX = 13
};

// Enum Killstreak.EKSVoiceOverPriority
enum class EKSVoiceOverPriority : uint8 {
	None = 0,
	Nonverbal = 1,
	Flavor = 2,
	GameTeamState = 3,
	CharacterInfo = 4,
	Callout = 5,
	Objective = 6,
	MatchStartEnd = 7,
	EKSVoiceOverPriority_MAX = 8
};

// Enum Killstreak.EKSVoicelineType
enum class EKSVoicelineType : uint8 {
	Standard = 0,
	Quip = 1,
	Communication = 2,
	EKSVoicelineType_MAX = 3
};

// Enum Killstreak.EKSVoicelineAudience
enum class EKSVoicelineAudience : uint8 {
	Self = 0,
	Nearby = 1,
	NearbyFriendlies = 2,
	AllFriendlies = 3,
	Enemies = 4,
	EKSVoicelineAudience_MAX = 5
};

// Enum Killstreak.EAccoladeEventType
enum class EAccoladeEventType : uint8 {
	AccoladeEvent_Unknown = 0,
	AccoladeEvent_Elim = 1,
	AccoladeEvent_Downed = 2,
	AccoladeEvent_Revived = 3,
	AccoladeEvent_DownAssist = 4,
	AccoladeEvent_CombatEvent = 5,
	AccoladeEvent_MAX = 6
};

// Enum Killstreak.EAccoladeCategory
enum class EAccoladeCategory : uint8 {
	AccoladeCategory_DownsElims = 0,
	AccoladeCategory_MultiKill = 1,
	AccoladeCategory_Support = 2,
	AccoladeCategory_MAX = 3
};

// Enum Killstreak.EDisplayType
enum class EDisplayType : uint8 {
	Mini = 0,
	Full = 1,
	Overlay = 2,
	EDisplayType_MAX = 3
};

// Enum Killstreak.EJobUniquenessRule
enum class EJobUniquenessRule : uint8 {
	DuplicatesAllowed = 0,
	UniqueToTeam = 1,
	UniversallyUnique = 2,
	EJobUniquenessRule_MAX = 3
};

// Enum Killstreak.EJobSelectionState
enum class EJobSelectionState : uint8 {
	Available = 0,
	Unavailable = 1,
	OtherSelected = 2,
	Selected = 3,
	OtherLockedIn = 4,
	LockedIn = 5,
	Banned = 6,
	EJobSelectionState_MAX = 7
};

// Enum Killstreak.EKSJobSelectPreviewLoadState
enum class EKSJobSelectPreviewLoadState : uint8 {
	NoPreview = 0,
	PreviewActive = 1,
	PreviewLoadingNoVisible = 2,
	PreviewLoadingActiveVisible = 3,
	EKSJobSelectPreviewLoadState_MAX = 4
};

// Enum Killstreak.EVariableFireRateState
enum class EVariableFireRateState : uint8 {
	Static = 0,
	Charging = 1,
	Decaying = 2,
	EVariableFireRateState_MAX = 3
};

// Enum Killstreak.ECombatState
enum class ECombatState : uint8 {
	Combat = 0,
	Engaged = 1,
	NonCombat = 2,
	BuildUp = 3,
	ECombatState_MAX = 4
};

// Enum Killstreak.EKSRevealPriority
enum class EKSRevealPriority : uint8 {
	None = 0,
	Lowest = 1,
	VeryLow = 2,
	Low = 3,
	Medium = 4,
	High = 5,
	VeryHigh = 6,
	Highest = 7,
	EKSRevealPriority_MAX = 8
};

// Enum Killstreak.EKSRevealSource
enum class EKSRevealSource : uint8 {
	None = 0,
	AimedAt = 1,
	ModStandard = 2,
	ModPerk = 3,
	ModAbility = 4,
	Gadget = 5,
	KilledBy = 6,
	Objective = 7,
	FriendlyVisibility = 8,
	EKSRevealSource_MAX = 9
};

// Enum Killstreak.ETargetAudience
enum class ETargetAudience : uint8 {
	None = 0,
	SelfOnly = 1,
	Friendlies = 2,
	FriendliesExcludingSelf = 3,
	Enemies = 4,
	All = 5,
	ETargetAudience_MAX = 6
};

// Enum Killstreak.ECombatEventFriendlyFireType
enum class ECombatEventFriendlyFireType : uint8 {
	Enemy = 0,
	Friendly = 1,
	ReverseFriendly = 2,
	Self = 3,
	ECombatEventFriendlyFireType_MAX = 4
};

// Enum Killstreak.EFubarDisplayReason
enum class EFubarDisplayReason : uint8 {
	NotFubar = 0,
	SystemFubar = 1,
	AbsentPlayers = 2,
	EFubarDisplayReason_MAX = 3
};

// Enum Killstreak.EMercCosmeticSlot
enum class EMercCosmeticSlot : uint8 {
	EMOTE_SLOT = 0,
	SKIN_BUNDLE_SLOT = 1,
	WINGSUIT_SLOT = 2,
	WEAPON_WRAP_SLOT = 3,
	QUIP_SLOT = 4,
	COMMUNICATION_SLOT = 5,
	SPRAY_SLOT = 6,
	WEAPON_CATEGORY_SLOT = 7,
	FAVORITE_WEAPON_SLOT = 8,
	EMercCosmeticSlot_MAX = 9
};

// Enum Killstreak.EPingFailedType
enum class EPingFailedType : uint8 {
	None = 0,
	Throttled = 1,
	NoTarget = 2,
	InvalidPingType = 3,
	EPingFailedType_MAX = 4
};

// Enum Killstreak.EPingMessage
enum class EPingMessage : uint8 {
	None = 0,
	GoHere = 1,
	EnemyHere = 2,
	DefendHere = 3,
	HoldPosition = 4,
	FallBack = 5,
	PushForward = 6,
	GroupUp = 7,
	HelpMe = 8,
	EnemiesMoving = 9,
	Understood = 10,
	AllClear = 11,
	CancelThat = 12,
	ReviveMe = 13,
	Task1 = 14,
	Task2 = 15,
	Task3 = 16,
	Task4 = 17,
	Task5 = 18,
	WatchOut = 19,
	EPingMessage_MAX = 20
};

// Enum Killstreak.EPingType
enum class EPingType : uint8 {
	None = 0,
	PointAlly = 1,
	PointEnemy = 2,
	Self = 3,
	SelfEmergency = 4,
	Target = 5,
	Cancel = 6,
	Task = 7,
	NoPing = 8,
	EPingType_MAX = 9
};

// Enum Killstreak.ESplineBehaviourType
enum class ESplineBehaviourType : uint8 {
	OneShot = 0,
	OneShot_Reverse = 1,
	Loop_Reset = 2,
	PingPong = 3,
	ESplineBehaviourType_MAX = 4
};

// Enum Killstreak.ETeamAlignment
enum class ETeamAlignment : uint8 {
	TMAL_Neutral = 0,
	TMAL_Enemy = 1,
	TMAL_Friendly = 2,
	TMAL_MAX = 3
};

// Enum Killstreak.EAnnouncementType
enum class EAnnouncementType : uint8 {
	ANMT_Uknown = 0,
	ANMT_ObjectiveMilestone = 1,
	ANMT_PlayersLeft = 2,
	ANMT_LastPlayerStanding = 3,
	ANMT_RoyalePhase = 4,
	ANMT_MAX = 5
};

// Enum Killstreak.EGameResult
enum class EGameResult : uint8 {
	Victory = 0,
	Defeat = 1,
	Draw = 2,
	EGameResult_MAX = 3
};

// Enum Killstreak.EJobSelectionTaskType
enum class EJobSelectionTaskType : uint8 {
	PickAndLock = 0,
	Pick = 1,
	Lock = 2,
	Ban = 3,
	Block = 4,
	EJobSelectionTaskType_MAX = 5
};

// Enum Killstreak.EKSInteractionResult
enum class EKSInteractionResult : uint8 {
	None = 0,
	Success = 1,
	Interrupted = 2,
	Failed = 3,
	EKSInteractionResult_MAX = 4
};

// Enum Killstreak.EKSReviveDroneAbilityState
enum class EKSReviveDroneAbilityState : uint8 {
	Unavailable = 0,
	Available = 1,
	Deployed = 2,
	Reviving = 3,
	Success = 4,
	Refunded = 5,
	Destroyed = 6,
	EKSReviveDroneAbilityState_MAX = 7
};

// Enum Killstreak.EKSPingType
enum class EKSPingType : uint8 {
	PING_DEFAULT = 0,
	PING_RADAR = 1,
	PING_INTEL = 2,
	PING_TRACKER = 3,
	PING_BOMB_HOLDER = 4,
	PING_MAX = 5
};

// Enum Killstreak.ESurfaceTargetErrorReason
enum class ESurfaceTargetErrorReason : uint8 {
	None = 0,
	TooFar = 1,
	TooHigh = 2,
	NoRoomAtOrigin = 3,
	InvalidSurface = 4,
	TooClose = 5,
	AimBlocked = 6,
	ESurfaceTargetErrorReason_MAX = 7
};

// Enum Killstreak.EAimDataMode
enum class EAimDataMode : uint8 {
	NoEndTrace = 0,
	EndTraceFromStartTrace = 1,
	EndTraceFromViewPoint = 2,
	Shotgun = 3,
	EAimDataMode_MAX = 4
};

// Enum Killstreak.EKSAcquisitionType
enum class EKSAcquisitionType : uint8 {
	None = 0,
	Voucher = 1,
	BattlePass = 2,
	ActiveBoost = 3,
	EventGrandPrize = 4,
	MAX = 5
};

// Enum Killstreak.EKSBattlePassProgressionActivityType
enum class EKSBattlePassProgressionActivityType : uint8 {
	None = 0,
	MiniBattlePass1 = 1,
	BattlePass1 = 2,
	BattlePass2 = 3,
	BattlePass3 = 4,
	MAX = 5
};

// Enum Killstreak.EKSActivityTimeQueryType
enum class EKSActivityTimeQueryType : uint8 {
	All = 0,
	OnlyFinished = 1,
	OnlyUnfinished = 2,
	EKSActivityTimeQueryType_MAX = 3
};

// Enum Killstreak.EKSActivityManagerSetupPhase
enum class EKSActivityManagerSetupPhase : uint8 {
	None = 0,
	InitialAssetScan = 1,
	RequestStoreVendors = 2,
	RequestXpTables = 3,
	LoadActivities = 4,
	WaitForSelectionPhaseFinished = 5,
	AttemptInitialActivityCreation = 6,
	Done = 7,
	EKSActivityManagerSetupPhase_MAX = 8
};

// Enum Killstreak.EKSActivityInstanceQueryType
enum class EKSActivityInstanceQueryType : uint8 {
	LowestProgress = 0,
	HighestProgress = 1,
	LowestTier = 2,
	HighestTier = 3,
	EKSActivityInstanceQueryType_MAX = 4
};

// Enum Killstreak.EKSActivityClientNotifyFrequency
enum class EKSActivityClientNotifyFrequency : uint8 {
	None = 0,
	OnProgressCompleted = 1,
	OnProgressTierReached = 2,
	OnProgressIncremented = 3,
	EKSActivityClientNotifyFrequency_MAX = 4
};

// Enum Killstreak.EKSActivityProgressDisplayType
enum class EKSActivityProgressDisplayType : uint8 {
	Default = 0,
	RawProgress = 1,
	PercentToNextTier = 2,
	PercentToMaxTier = 3,
	MinutesAsDuration = 4,
	CurrentTier = 5,
	None = 6,
	EKSActivityProgressDisplayType_MAX = 7
};

// Enum Killstreak.EReviveDroneFlightPath
enum class EReviveDroneFlightPath : uint8 {
	Drop = 0,
	Left = 1,
	Right = 2,
	EReviveDroneFlightPath_MAX = 3
};

// Enum Killstreak.EReviveDroneState
enum class EReviveDroneState : uint8 {
	Release = 0,
	Transit = 1,
	Arrival = 2,
	Hover = 3,
	Leave = 4,
	EReviveDroneState_MAX = 5
};

// Enum Killstreak.EAgentRefundMethod
enum class EAgentRefundMethod : uint8 {
	GiveWeaponAsset = 0,
	BroadcastDelegate = 1,
	EAgentRefundMethod_MAX = 2
};

// Enum Killstreak.EKSAimAssistInputFlag
enum class EKSAimAssistInputFlag : uint8 {
	GamepadOnly = 0,
	GamepadAndTouch = 1,
	AllInputModes = 2,
	EKSAimAssistInputFlag_MAX = 3
};

// Enum Killstreak.EKSAimAssistActivationType
enum class EKSAimAssistActivationType : uint8 {
	AIMASSIST_DEFAULT = 0,
	AIMASSIST_ALWAYSON = 1,
	AIMASSIST_ALWAYSOFF = 2,
	AIMASSIST_MAX = 3
};

// Enum Killstreak.EKSAnalogStickType
enum class EKSAnalogStickType : uint8 {
	Unknown = 0,
	Left = 1,
	Right = 2,
	EKSAnalogStickType_MAX = 3
};

// Enum Killstreak.EReactiveResetTrigger
enum class EReactiveResetTrigger : uint8 {
	IdleCooldown = 0,
	WeaponReload = 1,
	WeaponHolster = 2,
	WeaponInactive = 3,
	CharacterDamaged = 4,
	CharacterDowned = 5,
	CharacterKilled = 6,
	EReactiveResetTrigger_MAX = 7
};

// Enum Killstreak.EReactiveTrigger
enum class EReactiveTrigger : uint8 {
	WeaponFire = 0,
	TargetDamagedAnyWeapon = 1,
	TargetDownedAnyWeapon = 2,
	TargetKilledAnyWeapon = 3,
	TargetDamagedThisWeapon = 4,
	TargetDownedThisWeapon = 5,
	TargetKilledThisWeapon = 6,
	DamageWithinTimePeriodGoalMet = 7,
	MultiDownGoalMet = 8,
	DemoMode = 9,
	EReactiveTrigger_MAX = 10
};

// Enum Killstreak.ECosmeticPersistentDataCache
enum class ECosmeticPersistentDataCache : uint8 {
	DataCacheA = 0,
	DataCacheB = 1,
	DataCacheC = 2,
	ECosmeticPersistentDataCache_MAX = 3
};

// Enum Killstreak.EGameplayAudioEvent
enum class EGameplayAudioEvent : uint8 {
	Unknown = 0,
	GameStarted = 1,
	LoggedIn = 2,
	QueueingStarted = 3,
	QueueingCanceled = 4,
	MatchFound = 5,
	LoadingScreenStarted = 6,
	EndOfMatchLobbyStarted = 7,
	EndOfMatchLobbyEnded = 8,
	EndOfMatchLobbySkipped = 9,
	EnteredMatch = 10,
	BanStarted = 11,
	BanEndedEarly = 12,
	RogueSelectionStarted = 13,
	RogueSelectionEnded = 14,
	RogueSelectionFadeOut = 15,
	TeamCinematicStarted = 16,
	EstablishingShotStarted = 17,
	HoldingPenStarted = 18,
	DropshipDoorOpened = 19,
	SkydiveStarted = 20,
	SkydiveEnded = 21,
	ObjectiveArmed = 22,
	ObjectiveTime_30SecondsLeft = 23,
	ObjectiveCaptured = 24,
	LastManStanding = 25,
	SuddenDeath = 26,
	KillcamStarted = 27,
	RoundReset = 28,
	RoundWon = 29,
	RoundLost = 30,
	MatchWon = 31,
	MatchLost = 32,
	ReturnToLobby = 33,
	Max = 34
};

// Enum Killstreak.EKSItemBattlePassSource
enum class EKSItemBattlePassSource : uint8 {
	None = 0,
	InstantUnlock = 1,
	FreeTrackUnlock = 2,
	PremiumTrackUnlock = 3,
	MAX = 4
};

// Enum Killstreak.EPlayerBehaviorChangeReact
enum class EPlayerBehaviorChangeReact : uint8 {
	SkipReact = 0,
	SendNewOnly = 1,
	SendFullSetIfChanged = 2,
	SendFullSetRegardless = 3,
	EPlayerBehaviorChangeReact_MAX = 4
};

// Enum Killstreak.EBoostDurationCategory
enum class EBoostDurationCategory : uint8 {
	Minutes15 = 0,
	Minutes30 = 1,
	Minutes45 = 2,
	Hours1 = 3,
	Hours2 = 4,
	Hours4 = 5,
	Hours8 = 6,
	EBoostDurationCategory_MAX = 7
};

// Enum Killstreak.EBoostCategory
enum class EBoostCategory : uint8 {
	GlobalAccount = 0,
	EBoostCategory_MAX = 1
};

// Enum Killstreak.EAbilityExecutionType
enum class EAbilityExecutionType : uint8 {
	InstantActivate = 0,
	RandomActivate = 1,
	AimFireActivate = 2,
	IngressPointActivate = 3,
	ThrowLikeGrenade = 4,
	UniqueActivation = 5,
	EAbilityExecutionType_MAX = 6
};

// Enum Killstreak.EActorFocalPoint
enum class EActorFocalPoint : uint8 {
	ActorFocalPoint_None = 0,
	ActorFocalPoint_Head = 1,
	ActorFocalPoint_Body = 2,
	ActorFocalPoint_LeftShoulder = 3,
	ActorFocalPoint_RightShoulder = 4,
	ActorFocalPoint_MAX = 5
};

// Enum Killstreak.EKSBuildInteractionType
enum class EKSBuildInteractionType : uint8 {
	Reclaim = 0,
	Custom = 1,
	None = 2,
	EKSBuildInteractionType_MAX = 3
};

// Enum Killstreak.EKSArmVisibilityType
enum class EKSArmVisibilityType : uint8 {
	HideNothing = 0,
	ArmAndWeapon = 1,
	WeaponOnly = 2,
	EKSArmVisibilityType_MAX = 3
};

// Enum Killstreak.EKSPlayerHand
enum class EKSPlayerHand : uint8 {
	LeftHand = 0,
	RightHand = 1,
	EKSPlayerHand_MAX = 2
};

// Enum Killstreak.EKSMaterialHideType
enum class EKSMaterialHideType : uint8 {
	CastsShadowWhenHidden = 0,
	DoesNotCastShadowWhenHidden = 1,
	EKSMaterialHideType_MAX = 2
};

// Enum Killstreak.EKSVehicleState
enum class EKSVehicleState : uint8 {
	Outside = 0,
	Entering = 1,
	Driver = 2,
	Passenger = 3,
	Exiting = 4,
	EKSVehicleState_MAX = 5
};

// Enum Killstreak.EKSQualitySwitch
enum class EKSQualitySwitch : uint8 {
	LocomotionCached = 0,
	SecondLocomotionCached = 1,
	PreAimArray = 2,
	PostWingSuit = 3,
	Finalized3p = 4,
	PreFacialAnimation = 5,
	PostFacialAnimation = 6,
	PrePowSlide_SklController = 7,
	PreHitReactions = 8,
	PostFootIK = 9,
	PostZiplinePullyLocks = 10,
	PostZiplineSkeletalControllers = 11,
	PreRecoil = 12,
	PostRecoil = 13,
	PreCounterRotate = 14,
	SkeletalControllersPostIK = 15,
	PreVaulting_SKLController = 16,
	PostVaulting_SKLController = 17,
	EKSQualitySwitch_MAX = 18
};

// Enum Killstreak.EKSTurnInPlaceAnimationVariant
enum class EKSTurnInPlaceAnimationVariant : uint8 {
	Left90 = 0,
	Left180 = 1,
	Right90 = 2,
	Right180 = 3,
	EKSTurnInPlaceAnimationVariant_MAX = 4
};

// Enum Killstreak.EKSLocomotionState
enum class EKSLocomotionState : uint8 {
	Idle = 0,
	InMotion = 1,
	Stopping = 2,
	Pivoting = 3,
	EKSLocomotionState_MAX = 4
};

// Enum Killstreak.EKSQueuedMovement
enum class EKSQueuedMovement : uint8 {
	Jump = 0,
	DodgeRoll = 1,
	None = 2,
	EKSQueuedMovement_MAX = 3
};

// Enum Killstreak.EKSDeathState
enum class EKSDeathState : uint8 {
	NotDead = 0,
	NormalDeath = 1,
	EKSDeathState_MAX = 2
};

// Enum Killstreak.EKSCinematicCharacterType
enum class EKSCinematicCharacterType : uint8 {
	Cinematic = 0,
	JobSelection = 1,
	EKSCinematicCharacterType_MAX = 2
};

// Enum Killstreak.EFlashBangIntensity
enum class EFlashBangIntensity : uint8 {
	Min = 0,
	Half = 1,
	Max = 2
};

// Enum Killstreak.EKSEventChallengesDisplayState
enum class EKSEventChallengesDisplayState : uint8 {
	None = 0,
	HasSelectedChallenge = 1,
	AdditionalChallengesLocked = 2,
	AllChallengesFinished = 3,
	MAX = 4
};

// Enum Killstreak.EKSTeamAssignmentType
enum class EKSTeamAssignmentType : uint8 {
	AllOnOne = 0,
	EvenlyDistributed = 1,
	EKSTeamAssignmentType_MAX = 2
};

// Enum Killstreak.EKSBotNameGeneration
enum class EKSBotNameGeneration : uint8 {
	None = 0,
	RandomNames = 1,
	DefaultClassNames = 2,
	EKSBotNameGeneration_MAX = 3
};

// Enum Killstreak.EKSLootRespawnMode
enum class EKSLootRespawnMode : uint8 {
	RespawnActiveSites = 0,
	RespawnRandomSites = 1,
	EKSLootRespawnMode_MAX = 2
};

// Enum Killstreak.EKSRewardType
enum class EKSRewardType : uint8 {
	MatchInProgress = 0,
	Winner = 1,
	Loser = 2,
	Draw = 3,
	EKSRewardType_MAX = 4
};

// Enum Killstreak.EChangeAdditionalActionCondition
enum class EChangeAdditionalActionCondition : uint8 {
	NeverDo = 0,
	DoIfChanged = 1,
	AlwaysDo = 2,
	EChangeAdditionalActionCondition_MAX = 3
};

// Enum Killstreak.EPlayerInfoInventoryRestoreType
enum class EPlayerInfoInventoryRestoreType : uint8 {
	ResetToStartingInventory = 0,
	KeepInventory = 1,
	KeepInventoryIfNotDead = 2,
	KeepGunsOnly = 3,
	UseNewMethod = 4,
	EPlayerInfoInventoryRestoreType_MAX = 5
};

// Enum Killstreak.EJobSelectionType
enum class EJobSelectionType : uint8 {
	Unknown = 0,
	Legacy = 1,
	SelectionAuthority = 2,
	EJobSelectionType_MAX = 3
};

// Enum Killstreak.EKillCamStatus
enum class EKillCamStatus : uint8 {
	KillCamUninitialized = 0,
	KillCamEnabled = 1,
	KillCamDisabled = 2,
	EKillCamStatus_MAX = 3
};

// Enum Killstreak.ECrosshairSize
enum class ECrosshairSize : uint8 {
	Standard = 0,
	Medium = 1,
	Large = 2,
	ECrosshairSize_MAX = 3
};

// Enum Killstreak.EKSGamepadIcons
enum class EKSGamepadIcons : uint8 {
	XboxOne = 0,
	PlayStation4 = 1,
	NintendoSwitch = 2,
	EKSGamepadIcons_MAX = 3
};

// Enum Killstreak.ERadialWheelMode
enum class ERadialWheelMode : uint8 {
	Hold = 0,
	Toggle = 1,
	ERadialWheelMode_MAX = 2
};

// Enum Killstreak.EGyroMode
enum class EGyroMode : uint8 {
	None = 0,
	AimOnly = 1,
	Always = 2,
	EGyroMode_MAX = 3
};

// Enum Killstreak.EADSMode
enum class EADSMode : uint8 {
	Hold = 0,
	Toggle = 1,
	Both = 2,
	EADSMode_MAX = 3
};

// Enum Killstreak.EKSInteractableGroup
enum class EKSInteractableGroup : uint8 {
	Generic = 0,
	Bomb = 1,
	Objective = 2,
	DropOffZone = 3,
	Vehicle = 4,
	Projectile = 5,
	ZipLine = 6,
	Pawn = 7,
	EKSInteractableGroup_MAX = 8
};

// Enum Killstreak.EKSLabelAndHighlightState
enum class EKSLabelAndHighlightState : uint8 {
	NotTargeted = 0,
	Targeted = 1,
	EKSLabelAndHighlightState_MAX = 2
};

// Enum Killstreak.EJobLoadoutSlot
enum class EJobLoadoutSlot : uint8 {
	JobSlot_Unknown = 0,
	JobSlot_JobItem = 1,
	JobSlot_UniqueItem = 2,
	JobSlot_PrimaryWeapon = 3,
	JobSlot_PrimaryWeaponAttachment = 4,
	JobSlot_SecondaryWeapon = 5,
	JobSlot_SecondaryWeaponAttachment = 6,
	JobSlot_Gadget = 7,
	JobSlot_PerkOne = 8,
	JobSlot_PerkTwo = 9,
	JobSlot_PrimaryWeapon_Alt = 10,
	JobSlot_SecondaryWeapon_Alt = 11,
	JobSlot_Gadget_Alt = 12,
	JobSlot_Melee = 13,
	JobSlot_QuickMelee = 14,
	JobSlot_MAX = 15
};

// Enum Killstreak.EJobSelectProxyRules
enum class EJobSelectProxyRules : uint8 {
	DelayOrAbstain = 0,
	Random = 1,
	Captain = 2,
	EJobSelectProxyRules_MAX = 3
};

// Enum Killstreak.EJobBanEffects
enum class EJobBanEffects : uint8 {
	EffectsAll = 0,
	EffectsOpposingTeams = 1,
	EJobBanEffects_MAX = 2
};

// Enum Killstreak.EJobPickExclusivity
enum class EJobPickExclusivity : uint8 {
	NotExclusive = 0,
	ExclusiveToTeam = 1,
	ExclusiveToAll = 2,
	EJobPickExclusivity_MAX = 3
};

// Enum Killstreak.EJobSelectDraftingTaskType
enum class EJobSelectDraftingTaskType : uint8 {
	Ban = 0,
	Pick = 1,
	Wait = 2,
	EJobSelectDraftingTaskType_MAX = 3
};

// Enum Killstreak.EJobOwnershipState
enum class EJobOwnershipState : uint8 {
	Owned = 0,
	NotOwned = 1,
	WaitingToCheckInventory = 2,
	EJobOwnershipState_MAX = 3
};

// Enum Killstreak.ECanCompleteTaskResult
enum class ECanCompleteTaskResult : uint8 {
	Ok = 0,
	NotValidTask = 1,
	Unavailable = 2,
	UnavailableByOwnership = 3,
	Banned = 4,
	AlreadyPicked = 5,
	AlreadyLocked = 6,
	CannotAbstain = 7,
	CannotLock = 8,
	ECanCompleteTaskResult_MAX = 9
};

// Enum Killstreak.ESelectionActivityState
enum class ESelectionActivityState : uint8 {
	Inactive = 0,
	Waiting = 1,
	Selecting = 2,
	Banning = 3,
	ESelectionActivityState_MAX = 4
};

// Enum Killstreak.EAllowUnownedJobsState
enum class EAllowUnownedJobsState : uint8 {
	Unknown = 0,
	AllowUnowned = 1,
	DoNotAllowUnowned = 2,
	EAllowUnownedJobsState_MAX = 3
};

// Enum Killstreak.EPlayerAccountSlot
enum class EPlayerAccountSlot : uint8 {
	AVATAR_SLOT = 0,
	BANNER_SLOT = 1,
	PREFERRED_MERC_SLOT = 2,
	BORDER_SLOT = 3,
	TITLE_SLOT = 4,
	EPlayerAccountSlot_MAX = 5
};

// Enum Killstreak.EWeaponCosmeticSlot
enum class EWeaponCosmeticSlot : uint8 {
	WRAP_SLOT = 0,
	WRAP_MAX = 1
};

// Enum Killstreak.EKSLoadoutTypes
enum class EKSLoadoutTypes : uint8 {
	INVALID_LOADOUT = 0,
	JOB_COSMETICS = 1,
	PLAYER_ACCOUNT = 2,
	GLOBAL_COSMETIC_LOADOUT = 3,
	WEAPON_COSMETIC_LOADOUT = 4,
	EKSLoadoutTypes_MAX = 5
};

// Enum Killstreak.EKSLobbyCharacterAnimationPose
enum class EKSLobbyCharacterAnimationPose : uint8 {
	Lobby_Idle = 0,
	Lobby_Fidget_01 = 1,
	Lobby_Fidget_02 = 2,
	Lobby_Fidget_03 = 3,
	Lobby_Fidget_04 = 4,
	Lobby_Fidget_05 = 5,
	Lobby_MAX = 6
};

// Enum Killstreak.ELobbyCharacterIndex
enum class ELobbyCharacterIndex : uint8 {
	LobbyCharacter_Unknown = 0,
	LobbyCharacter_LocalPlayer = 1,
	LobbyCharacter_PartyMemberOne = 2,
	LobbyCharacter_PartyMemberTwo = 3,
	LobbyCharacter_PartyMemberThree = 4,
	LobbyCharacter_RogueScreen = 5,
	LobbyCharacter_PurchaseConfirmation = 6,
	LobbyCharacter_EventScreen = 7,
	LobbyCharacter_BattlePassScreen = 8,
	LobbyCharacter_RogueScreenPosed = 9,
	LobbyCharacter_MAX = 10
};

// Enum Killstreak.ELobbyCharacterAnimState
enum class ELobbyCharacterAnimState : uint8 {
	LobbyAnim_Unknown = 0,
	LobbyAnim_Login = 1,
	LobbyAnim_Default = 2,
	LobbyAnim_Hidden = 3,
	LobbyAnim_Idle = 4,
	LobbyAnim_IntroWalk = 5,
	LobbyAnim_EmoteOne = 6,
	LobbyAnim_EmoteTwo = 7,
	LobbyAnim_EmoteThree = 8,
	LobbyAnim_EmoteFour = 9,
	LobbyAnim_EmoteFive = 10,
	LobbyAnim_PreMatchWalk = 11,
	LobbyAnim_EOMBackground = 12,
	LobbyAnim_PostMatchWalk = 13,
	LobbyAnim_MidSequence = 14,
	LobbyAnim_MAX = 15
};

// Enum Killstreak.ELobbyPresenceState
enum class ELobbyPresenceState : uint8 {
	ELobbyPresence_Unknown = 0,
	ELobbyPresence_NotPresent = 1,
	ELobbyPresence_PendingInvite = 2,
	ELobbyPresence_Idle = 3,
	ELobbyPresence_MAX = 4
};

// Enum Killstreak.ELobbyLevelSequenceTag
enum class ELobbyLevelSequenceTag : uint8 {
	ELobbyLvlSeqTag_Login = 0,
	ELobbyLvlSeqTag_MAX = 1
};

// Enum Killstreak.ELobbyCameraActorTag
enum class ELobbyCameraActorTag : uint8 {
	ELobbyCamTag_Home = 0,
	ELobbyCamTag_CustomizeLoadout = 1,
	ELobbyCamTag_LobbyMain = 2,
	ELobbyCamTag_MAX = 3
};

// Enum Killstreak.ELootSiteAlignment
enum class ELootSiteAlignment : uint8 {
	Attack = 0,
	Defend = 1,
	Contested = 2,
	ELootSiteAlignment_MAX = 3
};

// Enum Killstreak.EKSMantleScaleType
enum class EKSMantleScaleType : uint8 {
	ScaleDistOnly = 0,
	ScaleDistAndTime = 1,
	ShaveIntro = 2,
	EKSMantleScaleType_MAX = 3
};

// Enum Killstreak.ETeamRole
enum class ETeamRole : uint8 {
	Roleless = 0,
	Attacker = 1,
	Defender = 2,
	ETeamRole_MAX = 3
};

// Enum Killstreak.EKSRelativeMinimapHeight
enum class EKSRelativeMinimapHeight : uint8 {
	Below = 0,
	SameLevel = 1,
	Above = 2,
	EKSRelativeMinimapHeight_MAX = 3
};

// Enum Killstreak.EThrowDirection
enum class EThrowDirection : uint8 {
	Back = 0,
	Front = 1,
	Left = 2,
	Right = 3,
	EThrowDirection_MAX = 4
};

// Enum Killstreak.EWillToSurviveTimerType
enum class EWillToSurviveTimerType : uint8 {
	ShotAtTimer = 0,
	ModActivatedTimer = 1,
	CooldownTimer = 2,
	EWillToSurviveTimerType_MAX = 3
};

// Enum Killstreak.EWillToSurviveModState
enum class EWillToSurviveModState : uint8 {
	Inactive = 0,
	WaitForShotAt = 1,
	WaitForDodgeRollEnd = 2,
	ModActivated = 3,
	Cooldown = 4,
	EWillToSurviveModState_MAX = 5
};

// Enum Killstreak.EKSReviveDroneEvent
enum class EKSReviveDroneEvent : uint8 {
	ReviveStarted = 0,
	ReviveFinished = 1,
	TargetRevived = 2,
	TargetDied = 3,
	DroneAborted = 4,
	DroneDestroyed = 5,
	EKSReviveDroneEvent_MAX = 6
};

// Enum Killstreak.EKSNeutralBombState
enum class EKSNeutralBombState : uint8 {
	Spawned = 0,
	Reset = 1,
	Held = 2,
	Dropped = 3,
	Arming = 4,
	Armed = 5,
	Disarming = 6,
	Disarmed = 7,
	Deactivated = 8,
	Exploded = 9,
	EKSNeutralBombState_MAX = 10
};

// Enum Killstreak.EKSObjectiveState
enum class EKSObjectiveState : uint8 {
	None = 0,
	Spawned = 1,
	Reset = 2,
	Held = 3,
	Dropped = 4,
	Contested = 5,
	Arming = 6,
	Armed = 7,
	Disarming = 8,
	Disarmed = 9,
	Deactivated = 10,
	Exploded = 11,
	EKSObjectiveState_MAX = 12
};

// Enum Killstreak.EObjectiveIconType
enum class EObjectiveIconType : uint8 {
	Hack = 0,
	Pickup = 1,
	EObjectiveIconType_MAX = 2
};

// Enum Killstreak.EObjectiveType
enum class EObjectiveType : uint8 {
	None = 0,
	ExtractionPC = 1,
	BombZone = 2,
	ControlPoint = 3,
	EObjectiveType_MAX = 4
};

// Enum Killstreak.EKSNavAreaType
enum class EKSNavAreaType : uint8 {
	UnusedDefault = 0,
	Jump = 1,
	Hazard = 2,
	StartZipline = 3,
	TravelZipline = 4,
	Swim = 5,
	InteractiveObstacle = 6,
	EKSNavAreaType_MAX = 7
};

// Enum Killstreak.EAccountJobStatType
enum class EAccountJobStatType : uint8 {
	MasteryXp = 0,
	EAccountJobStatType_MAX = 1
};

// Enum Killstreak.EKSPlatformType
enum class EKSPlatformType : uint8 {
	PC = 0,
	XboxOne = 1,
	Playstation4 = 2,
	Switch = 3,
	ConsoleGeneric = 4,
	Epic = 5,
	Steam = 6,
	IOS = 7,
	Android = 8,
	MobileGeneric = 9,
	EKSPlatformType_MAX = 10
};

// Enum Killstreak.EKSPlayerInputType
enum class EKSPlayerInputType : uint8 {
	PIT_Unknown = 0,
	PIT_KeyboardMouse = 1,
	PIT_Gamepad = 2,
	PIT_Touch = 3,
	PIT_MAX = 4
};

// Enum Killstreak.EKSPlayerOnlineStatus
enum class EKSPlayerOnlineStatus : uint8 {
	FGS_InParty = 0,
	FGS_PendingParty = 1,
	FGS_InGame = 2,
	FGS_InMatch = 3,
	FGS_InQueue = 4,
	FGS_Online = 5,
	FGS_DND = 6,
	FGS_Offline = 7,
	FGS_FriendRequest = 8,
	FGS_PendingInvite = 9,
	FGS_MAX = 10
};

// Enum Killstreak.EKSInputType
enum class EKSInputType : uint8 {
	KBM = 0,
	GP = 1,
	Touch = 2,
	EKSInputType_MAX = 3
};

// Enum Killstreak.EKSKeyBindType
enum class EKSKeyBindType : uint8 {
	ActionMapping = 0,
	AxisMapping = 1,
	EKSKeyBindType_MAX = 2
};

// Enum Killstreak.EModPriorityResolution
enum class EModPriorityResolution : uint8 {
	TakeValue1 = 0,
	TakeValue2 = 1,
	Stack = 2,
	EModPriorityResolution_MAX = 3
};

// Enum Killstreak.EPlayerModType
enum class EPlayerModType : uint8 {
	Perk = 0,
	GlobalPerk = 1,
	Activated = 2,
	Passive = 3,
	TemporaryBuff = 4,
	TemporaryDebuff = 5,
	Hidden = 6,
	Unknown = 7,
	EPlayerModType_MAX = 8
};

// Enum Killstreak.EModInterferenceType
enum class EModInterferenceType : uint8 {
	Defer = 0,
	Stack = 1,
	WeakestWins = 2,
	StrongestWins = 3,
	BonusWins = 4,
	PenaltyWins = 5,
	EModInterferenceType_MAX = 6
};

// Enum Killstreak.EEliminationState
enum class EEliminationState : uint8 {
	NotInPlay = 0,
	Playing = 1,
	Eliminated = 2,
	EEliminationState_MAX = 3
};

// Enum Killstreak.EIsPlayer
enum class EIsPlayer : uint8 {
	Unknown = 0,
	Player = 1,
	NotPlayer = 2,
	EIsPlayer_MAX = 3
};

// Enum Killstreak.EKSStimulateTarget
enum class EKSStimulateTarget : uint8 {
	OnlyEnemies = 0,
	OnlyAllies = 1,
	AllPlayers = 2,
	EKSStimulateTarget_MAX = 3
};

// Enum Killstreak.EKSPOIState
enum class EKSPOIState : uint8 {
	Disabled = 0,
	Staged = 1,
	Enabled = 2,
	EKSPOIState_MAX = 3
};

// Enum Killstreak.EPollAudience
enum class EPollAudience : uint8 {
	AllPlayerPoll = 0,
	TeamPoll = 1,
	EPollAudience_MAX = 2
};

// Enum Killstreak.EProjectileReclaimPermission
enum class EProjectileReclaimPermission : uint8 {
	OwnerOnly = 0,
	TeammatesOnly = 1,
	Anyone = 2,
	EProjectileReclaimPermission_MAX = 3
};

// Enum Killstreak.EProjectilePredictionType
enum class EProjectilePredictionType : uint8 {
	PassThrough = 0,
	Bounce = 1,
	Stop = 2,
	EProjectilePredictionType_MAX = 3
};

// Enum Killstreak.EProjectileVisibilityType
enum class EProjectileVisibilityType : uint8 {
	Owner = 0,
	Ally = 1,
	All = 2,
	EProjectileVisibilityType_MAX = 3
};

// Enum Killstreak.EProjectileWeaponComponentType
enum class EProjectileWeaponComponentType : uint8 {
	None = 0,
	Self = 1,
	Parent = 2,
	EProjectileWeaponComponentType_MAX = 3
};

// Enum Killstreak.EMarkerTeamVisibility
enum class EMarkerTeamVisibility : uint8 {
	None = 0,
	Self = 1,
	AllyTeam = 2,
	EnemyTeam = 3,
	AllButSelf = 4,
	Everyone = 5,
	EMarkerTeamVisibility_MAX = 6
};

// Enum Killstreak.EProjectileClusterSpreadType
enum class EProjectileClusterSpreadType : uint8 {
	AimRelative = 0,
	ImpactRelative = 1,
	EProjectileClusterSpreadType_MAX = 2
};

// Enum Killstreak.EKSProjectileTargetingHitComponentType
enum class EKSProjectileTargetingHitComponentType : uint8 {
	Decal = 0,
	Mesh = 1,
	EKSProjectileTargetingHitComponentType_MAX = 2
};

// Enum Killstreak.EBadBehaviorType
enum class EBadBehaviorType : uint8 {
	None = 0,
	QuitEarly = 1,
	Disconnected = 2,
	AFK = 3,
	EBadBehaviorType_MAX = 4
};

// Enum Killstreak.ERadialMenuItemInterruptNotifyBehaviorType
enum class ERadialMenuItemInterruptNotifyBehaviorType : uint8 {
	NoNotify = 0,
	OnlyIfMarkedPlaying = 1,
	ERadialMenuItemInterruptNotifyBehaviorType_MAX = 2
};

// Enum Killstreak.EKSRadialMenuItemInterruptReason
enum class EKSRadialMenuItemInterruptReason : uint8 {
	Unknown = 0,
	NoCharacter = 1,
	Walking = 2,
	Sprinting = 3,
	Crouching = 4,
	Downed = 5,
	Dead = 6,
	Interacting = 7,
	Zipline = 8,
	SkyDiving = 9,
	DodgeRolling = 10,
	Falling = 11,
	NonRadialMenuItemEquipment = 12,
	RadialMenuItemActivated = 13,
	RadialMenuItemCooldown = 14,
	InvalidTargeting = 15,
	DistFromOrigin = 16,
	Throttled = 17,
	Truncated = 18,
	BlockedByMod = 19,
	EKSRadialMenuItemInterruptReason_MAX = 20
};

// Enum Killstreak.ERecoilStart2
enum class ERecoilStart2 : uint8 {
	ERS_Zero2 = 0,
	ERS_Random2 = 1,
	ERS_MAX = 2
};

// Enum Killstreak.ERewardSource
enum class ERewardSource : uint8 {
	UNKNOWN = 0,
	Base = 1,
	MatchWin = 2,
	BoosterBonusProgression = 3,
	QueueBonusProgression = 4,
	EventBonusProgression = 5,
	Backfill = 6,
	ERewardSource_MAX = 7
};

// Enum Killstreak.EPlayerStatType
enum class EPlayerStatType : uint8 {
	UNKNOWN = 0,
	Kills = 1,
	Deaths = 2,
	Assists = 3,
	Downs = 4,
	Revives = 5,
	Eliminations = 6,
	RoundsPlayed = 7,
	Hacks = 8,
	Dehacks = 9,
	RawDamageDealt = 10,
	MitigatedDamageDealt = 11,
	RawDamageReceived = 12,
	MitigatedDamageReceived = 13,
	TimeAlive = 14,
	Rank = 15,
	TimePlayed = 16,
	Score = 17,
	Cash = 18,
	Headshots = 19,
	EPlayerStatType_MAX = 20
};

// Enum Killstreak.ELimitPerRound
enum class ELimitPerRound : uint8 {
	None = 0,
	OneActive = 1,
	OnePerRound = 2,
	ELimitPerRound_MAX = 3
};

// Enum Killstreak.ELocalRequirements
enum class ELocalRequirements : uint8 {
	None = 0,
	Controlled = 1,
	Viewed = 2,
	ControlledOrViewed = 3,
	ELocalRequirements_MAX = 4
};

// Enum Killstreak.EPlayerShopTransactionType
enum class EPlayerShopTransactionType : uint8 {
	Purchase = 0,
	SetActive = 1,
	Refund = 2,
	EPlayerShopTransactionType_MAX = 3
};

// Enum Killstreak.EStartingCashRoundBonus
enum class EStartingCashRoundBonus : uint8 {
	None = 0,
	Record = 1,
	Win = 2,
	Loss = 3,
	EStartingCashRoundBonus_MAX = 4
};

// Enum Killstreak.ESpecialtyRoleType
enum class ESpecialtyRoleType : uint8 {
	Unknown = 0,
	Attack = 1,
	Defense = 2,
	Support = 3,
	Movement = 4,
	ESpecialtyRoleType_MAX = 5
};

// Enum Killstreak.EStoreItemCollectionMode
enum class EStoreItemCollectionMode : uint8 {
	StoreItems = 0,
	BlockedItems = 1,
	RefundedItems = 2,
	EStoreItemCollectionMode_MAX = 3
};

// Enum Killstreak.EStoreSectionTypes
enum class EStoreSectionTypes : uint8 {
	NewSection = 1,
	DLCSection = 2,
	FeaturedSection = 3,
	RogueBucksSection = 4,
	DailySection = 5,
	BoostsSection = 6,
	LimitedTimeOfferSection = 7,
	SpecialPromotionsSection = 8,
	DLCSectionOnSale = 9,
	CustomMessage = 10,
	DisplayOnCustomizationScreenOnly = 11,
	DynamicallyGeneratedOffers = 12,
	EStoreSectionTypes_MAX = 13
};

// Enum Killstreak.EKSBlacklistOrWhitelist
enum class EKSBlacklistOrWhitelist : uint8 {
	Blacklist = 0,
	Whitelist = 1,
	EKSBlacklistOrWhitelist_MAX = 2
};

// Enum Killstreak.EWeaponMasteryRewardPreviewType
enum class EWeaponMasteryRewardPreviewType : uint8 {
	Item = 0,
	Image = 1,
	WeaponRelatedRogues = 2,
	WeaponKillFeed = 3,
	None = 4,
	EWeaponMasteryRewardPreviewType_MAX = 5
};

// Enum Killstreak.EKSWeaponMasteryType
enum class EKSWeaponMasteryType : uint8 {
	Weapon = 0,
	WeaponCategory = 1,
	WeaponsMaster = 2,
	EKSWeaponMasteryType_MAX = 3
};

// Enum Killstreak.EKSEquipmentType
enum class EKSEquipmentType : uint8 {
	Normal = 0,
	Prop = 1,
	EKSEquipmentType_MAX = 2
};

// Enum Killstreak.ETopbarTicketDisplaySide
enum class ETopbarTicketDisplaySide : uint8 {
	Both = 0,
	ShowAttacker = 1,
	ShowDefender = 2,
	ETopbarTicketDisplaySide_MAX = 3
};

// Enum Killstreak.ETopbarPointsBarType
enum class ETopbarPointsBarType : uint8 {
	Neither = 0,
	Score = 1,
	Ticket = 2,
	ETopbarPointsBarType_MAX = 3
};

// Enum Killstreak.EGameTimerType
enum class EGameTimerType : uint8 {
	None = 0,
	RoundTimer = 1,
	PhaseTimer = 2,
	ObjectiveTimer = 3,
	EGameTimerType_MAX = 4
};

// Enum Killstreak.EWeaponSlot
enum class EWeaponSlot : uint8 {
	NONE = 0,
	PRIMARY_ONE_SLOT = 1,
	PRIMARY_TWO_SLOT = 2,
	SECONDARY_SLOT = 3,
	MELEE_SLOT = 4,
	EWeaponSlot_MAX = 5
};

// Enum Killstreak.ECharacterRole
enum class ECharacterRole : uint8 {
	None = 0,
	Attacker = 1,
	Defender = 2,
	Max = 3
};

// Enum Killstreak.ERestoreInfoInitRestoreType
enum class ERestoreInfoInitRestoreType : uint8 {
	Normal = 0,
	RestoreSelfOnComplete = 1,
	RestoreSelfAndChildrenOnComplete = 2,
	ERestoreInfoInitRestoreType_MAX = 3
};

// Enum Killstreak.ERestoreInfoInitBindType
enum class ERestoreInfoInitBindType : uint8 {
	Normal = 0,
	BindSelfOnComplete = 1,
	BindSelfAndChildrenOnComplete = 2,
	ERestoreInfoInitBindType_MAX = 3
};

// Enum Killstreak.EKSSocketCrouchHandling
enum class EKSSocketCrouchHandling : uint8 {
	MaintainCapsuleBottomOffset = 0,
	MaintainCapsuleCenterOffset = 1,
	ApplyCustomOffset = 2,
	EKSSocketCrouchHandling_MAX = 3
};

// Enum Killstreak.EKSSocketOffsetType
enum class EKSSocketOffsetType : uint8 {
	KeepRelativeToParent = 0,
	KeepRelativeToMesh = 1,
	KeepRelativeToCylinder = 2,
	EKSSocketOffsetType_MAX = 3
};

// Enum Killstreak.ECameraShoulder
enum class ECameraShoulder : uint8 {
	Right = 0,
	Left = 1,
	ECameraShoulder_MAX = 2
};

// Enum Killstreak.EInputReleaseType
enum class EInputReleaseType : uint8 {
	All = 0,
	RadialMenu = 1,
	EscapeMenu = 2,
	Scoreboard = 3,
	Map = 4,
	RadialMenuClose = 5,
	EInputReleaseType_MAX = 6
};

// Enum Killstreak.EKSContextualActionButtonMode
enum class EKSContextualActionButtonMode : uint8 {
	HoldUse = 0,
	HoldReload = 1,
	HoldNone = 2,
	EKSContextualActionButtonMode_MAX = 3
};

// Enum Killstreak.EKSInputActionType
enum class EKSInputActionType : uint8 {
	Press = 0,
	Hold = 1,
	Repeat = 2,
	EKSInputActionType_MAX = 3
};

// Enum Killstreak.EControllerInputType
enum class EControllerInputType : uint8 {
	None = 0,
	ADSBit = 1,
	KeyboardMouse = 2,
	KeyboardMouseADS = 3,
	Gamepad = 4,
	GamepadADS = 5,
	JoyCon = 6,
	JoyConADS = 7,
	Touch = 8,
	TouchADS = 9,
	PCGamepad = 10,
	PCGamepadADS = 11,
	EControllerInputType_MAX = 12
};

// Enum Killstreak.EOcclusionType
enum class EOcclusionType : uint8 {
	None = 0,
	Simple = 1,
	Advanced = 2,
	EOcclusionType_MAX = 3
};

// Enum Killstreak.EKSVoiceOverState
enum class EKSVoiceOverState : uint8 {
	Mute = 0,
	Duck = 1,
	Play = 2,
	EKSVoiceOverState_MAX = 3
};

// Enum Killstreak.EKSResourceReplicationType
enum class EKSResourceReplicationType : uint8 {
	Standard = 0,
	Predictive = 1,
	EKSResourceReplicationType_MAX = 2
};

// Enum Killstreak.EMuteMode
enum class EMuteMode : uint8 {
	VoicechatOnly = 0,
	VoicechatAndQuips = 1,
	VoicechatAndCommunications = 2,
	VoicechatQuipsCommunications = 3,
	EMuteMode_MAX = 4
};

// Enum Killstreak.EKSPowerSlideEndReason
enum class EKSPowerSlideEndReason : uint8 {
	Expired = 0,
	Collide = 1,
	Fall = 2,
	Action = 3,
	Interrupted = 4,
	FaceAway = 5,
	Unknown = 6,
	EKSPowerSlideEndReason_MAX = 7
};

// Enum Killstreak.EKSGame_CustomMovement
enum class EKSGame_CustomMovement : uint8 {
	KSMOVE_Vaulting = 0,
	KSMOVE_DiveFreeFall = 1,
	KSMOVE_DiveParachute = 2,
	KSMOVE_DodgeRoll = 3,
	KSMOVE_ZipLine = 4,
	KSMOVE_FlightRecovery = 5,
	KSMOVE_Ability = 6,
	KSMOVE_PowerSlide = 7,
	KSMOVE_Kick = 8,
	KSMOVE_MAX = 9
};

// Enum Killstreak.EScreenLogType
enum class EScreenLogType : uint8 {
	CombatLog = 0,
	RadialMenuItemLog = 1,
	EScreenLogType_MAX = 2
};

// Enum Killstreak.EEmoteCameraPositionType
enum class EEmoteCameraPositionType : uint8 {
	None = 0,
	Stand = 1,
	Crouch = 2,
	Prone = 3,
	EEmoteCameraPositionType_MAX = 4
};

// Enum Killstreak.ERadialWheelActivationMode
enum class ERadialWheelActivationMode : uint8 {
	None = 0,
	Gameplay = 1,
	Cinematic = 2,
	Lobby = 3,
	ERadialWheelActivationMode_MAX = 4
};

// Enum Killstreak.EKSLevelStreamingMethod
enum class EKSLevelStreamingMethod : uint8 {
	LevelStream = 0,
	PreLoaded = 1,
	EKSLevelStreamingMethod_MAX = 2
};

// Enum Killstreak.EKSPriority
enum class EKSPriority : uint8 {
	None = 0,
	Lowest = 1,
	VeryLow = 2,
	Low = 3,
	Medium = 4,
	High = 5,
	VeryHigh = 6,
	Highest = 7,
	EKSPriority_MAX = 8
};

// Enum Killstreak.EKSRevealType
enum class EKSRevealType : uint8 {
	NotRevealed = 0,
	Normal = 1,
	Permanent = 2,
	EKSRevealType_MAX = 3
};

// Enum Killstreak.EKSModSource
enum class EKSModSource : uint8 {
	Standard = 0,
	Job = 1,
	GameMode = 2,
	EKSModSource_MAX = 3
};

// Enum Killstreak.EExtractionTeamType
enum class EExtractionTeamType : uint8 {
	NotSet = 0,
	Attacker = 1,
	Defender = 2,
	EExtractionTeamType_MAX = 3
};

// Enum Killstreak.EKSRespawnMode
enum class EKSRespawnMode : uint8 {
	NoRespawn = 0,
	QueueRespawn = 1,
	TicketRespawn = 2,
	AlwaysRespawn = 3,
	EKSRespawnMode_MAX = 4
};

// Enum Killstreak.EKSGameTicketDisplayType
enum class EKSGameTicketDisplayType : uint8 {
	Respawns = 0,
	BombPoints = 1,
	EKSGameTicketDisplayType_MAX = 2
};

// Enum Killstreak.EKSPerSecondChargeMode
enum class EKSPerSecondChargeMode : uint8 {
	OverrideNone = 0,
	OverrideChargeable = 1,
	OverrideUnchargeable = 2,
	OverrideAll = 3,
	EKSPerSecondChargeMode_MAX = 4
};

// Enum Killstreak.EKSMovementDirection
enum class EKSMovementDirection : uint8 {
	Forward = 0,
	Right = 1,
	Back = 2,
	Left = 3,
	EKSMovementDirection_MAX = 4
};

// Enum Killstreak.EKSApparelGender
enum class EKSApparelGender : uint8 {
	Unisex = 0,
	Male = 1,
	Female = 2,
	EKSApparelGender_MAX = 3
};

// Enum Killstreak.EKSCharacterGender
enum class EKSCharacterGender : uint8 {
	Unknown = 0,
	Male = 1,
	Female = 2,
	EKSCharacterGender_MAX = 3
};

// Enum Killstreak.EPerceivedAlignmentType
enum class EPerceivedAlignmentType : uint8 {
	Neutral = 0,
	Friendly = 1,
	Enemy = 2,
	EPerceivedAlignmentType_MAX = 3
};

// Enum Killstreak.EPlayerSilhouetteQualifier
enum class EPlayerSilhouetteQualifier : uint8 {
	NotSet = 0,
	Objective = 1,
	EPlayerSilhouetteQualifier_MAX = 2
};

// Enum Killstreak.EPlayerSilhouetteType
enum class EPlayerSilhouetteType : uint8 {
	None = 0,
	Neutral = 1,
	Selected = 2,
	Friendly = 3,
	Enemy = 4,
	EPlayerSilhouetteType_MAX = 5
};

// Enum Killstreak.EDamageCategory
enum class EDamageCategory : uint8 {
	Default = 0,
	NonDamage = 1,
	Firearm = 2,
	Impact = 3,
	Explosion = 4,
	Melee = 5,
	ThrownMelee = 6,
	InstantDeath = 7,
	Environmental = 8,
	Bleed = 9,
	Fire = 10,
	Poison = 11,
	EDamageCategory_MAX = 12
};

// Enum Killstreak.ELoadoutSlot
enum class ELoadoutSlot : uint8 {
	LoadoutSlot_None = 0,
	LoadoutSlot_SpecialtyOne = 1,
	LoadoutSlot_SpecialtyTwo = 2,
	LoadoutSlot_PerkOne = 3,
	LoadoutSlot_PerkTwo = 4,
	LoadoutSlot_PerkFour = 5,
	LoadoutSlot_KillstreakOne = 6,
	LoadoutSlot_KillstreakTwo = 7,
	LoadoutSlot_Pistol = 8,
	LoadoutSlot_PistolAttachOne = 9,
	LoadoutSlot_PistolAttachTwo = 10,
	LoadoutSlot_PistolAttachThree = 11,
	LoadoutSlot_PrimaryWeapon = 12,
	LoadoutSlot_PerkThree = 13,
	LoadoutSlot_GadgetOne = 14,
	LoadoutSlot_PassiveOne = 15,
	LoadoutSlot_PassiveTwo = 16,
	LoadoutSlot_SecondaryAbilityOne = 17,
	LoadoutSlot_SecondaryAbilityTwo = 18,
	LoadoutSlot_LoadoutBundleId = 19,
	LoadoutSlot_MAX = 20
};

// Enum Killstreak.TG_EQUIP_POINT
enum class TG_EQUIP_POINT : uint8 {
	EQP_NONE = 0,
	EQP_AUTO = 1,
	EQP_OFFHAND_2 = 2,
	EQP_OFFHAND_3 = 3,
	EQP_OFFHAND_4 = 4,
	EQP_OFFHAND_5 = 5,
	EQP_RECALL = 6,
	EQP_PASSIVE = 7,
	EQP_ACTIVE_2 = 8,
	EQP_ACTIVE_3 = 9,
	EQP_ACTIVE_4 = 10,
	EQP_CONSUMABLE_2 = 11,
	EQP_CONSUMABLE_3 = 12,
	EQP_UNUSED_4 = 13,
	EQP_UNUSED_5 = 14,
	EQP_UNUSED_6 = 15,
	EQP_UNUSED_7 = 16,
	EQP_UNUSED_8 = 17,
	EQP_UNUSED_9 = 18,
	EQP_ITEM_STORE_2 = 19,
	EQP_ITEM_STORE_3 = 20,
	EQP_ITEM_STORE_4 = 21,
	EQP_ITEM_STORE_5 = 22,
	EQP_ITEM_STORE_6 = 23,
	EQP_OVER_DRAW = 24,
	EQP_MAX = 25
};

// Enum Killstreak.EQueueDivertType
enum class EQueueDivertType : uint8 {
	None = 0,
	ShelteredMM = 1,
	ForcedBotMatch = 2,
	MercyMatch = 3,
	Other = 4,
	EQueueDivertType_MAX = 5
};

// Enum Killstreak.EKSVehicleDeathState
enum class EKSVehicleDeathState : uint8 {
	Alive = 0,
	DestroyedByDamage = 1,
	DestroyedBySuicide = 2,
	EKSVehicleDeathState_MAX = 3
};

// Enum Killstreak.EKSWeaponDestroyReason
enum class EKSWeaponDestroyReason : uint8 {
	None = 0,
	RemoveNoReplace = 1,
	RemoveWithReplace = 2,
	DropNoReplace = 3,
	DropWithReplace = 4,
	EKSWeaponDestroyReason_MAX = 5
};

// Enum Killstreak.EReloadReplicationFlags
enum class EReloadReplicationFlags : uint8 {
	MinimumReplication = 0,
	ReplicateAmmo = 1,
	EReloadReplicationFlags_MAX = 2
};

// Enum Killstreak.EFiredReplicationFlags
enum class EFiredReplicationFlags : uint8 {
	MinimumReplication = 0,
	ReplicateAmmo = 1,
	ReplicateAim = 2,
	ReplicateAimAndAmmo = 3,
	ReplicateAllFireParameters = 4,
	EFiredReplicationFlags_MAX = 5
};

// Enum Killstreak.EKSBuildState
enum class EKSBuildState : uint8 {
	BUILD_PENDING_VALID = 0,
	BUILD_PENDING_INVALID = 1,
	BUILD_SUCCEEDED = 2,
	BUILD_FAILED = 3,
	BUILD_MAX = 4
};

// Enum Killstreak.EKSWeaponCategoryType
enum class EKSWeaponCategoryType : uint8 {
	Invalid = 0,
	AssaultRifle = 1,
	DMR = 2,
	LightMachineGun = 3,
	Shotgun = 4,
	SniperRifle = 5,
	SubMachineGun = 6,
	Pistol = 7,
	Melee = 8,
	Gadget = 9,
	EKSWeaponCategoryType_MAX = 10
};

// Enum Killstreak.EThirdPersonAimOriginType
enum class EThirdPersonAimOriginType : uint8 {
	ActorEyes = 0,
	FixedRelativeLocation = 1,
	ComponentByTag = 2,
	SocketOnCharacterMesh = 3,
	EThirdPersonAimOriginType_MAX = 4
};

// Enum Killstreak.EReticleType
enum class EReticleType : uint8 {
	Pistol = 0,
	Rifle = 1,
	Shotgun = 2,
	DualAR = 3,
	Gatling = 4,
	ChaosLauncher = 5,
	None = 6,
	EReticleType_MAX = 7
};

// Enum Killstreak.EReloadType
enum class EReloadType : uint8 {
	Clip = 0,
	SingleShot = 1,
	EReloadType_MAX = 2
};

// Enum Killstreak.EWeaponCastType
enum class EWeaponCastType : uint8 {
	UseSettings = 0,
	AlwaysQuickCast = 1,
	AlwaysNormalCast = 2,
	EWeaponCastType_MAX = 3
};

// Enum Killstreak.EFireModeType
enum class EFireModeType : uint8 {
	Single = 0,
	Burst = 1,
	SemiAuto = 2,
	EFireModeType_MAX = 3
};

// Enum Killstreak.EKSWeaponEquipType
enum class EKSWeaponEquipType : uint8 {
	Normal = 0,
	Special = 1,
	GameMode = 2,
	Gambit = 3,
	EKSWeaponEquipType_MAX = 4
};

// Enum Killstreak.EExtendedMagazineRounding
enum class EExtendedMagazineRounding : uint8 {
	NearestInteger = 0,
	RoundUp = 1,
	RoundDown = 2,
	EExtendedMagazineRounding_MAX = 3
};

// Enum Killstreak.EKSVariableScopeType
enum class EKSVariableScopeType : uint8 {
	FixedFOV = 0,
	ScopeMultiplier = 1,
	EKSVariableScopeType_MAX = 2
};

// Enum Killstreak.EBundledAmmoType
enum class EBundledAmmoType : uint8 {
	FullClip = 0,
	DefaultAmmoFromAsset = 1,
	Override = 2,
	EBundledAmmoType_MAX = 3
};

// Enum Killstreak.EWeaponComponentAttachmentType
enum class EWeaponComponentAttachmentType : uint8 {
	AttachToCharacter = 0,
	AttachToMesh = 1,
	EWeaponComponentAttachmentType_MAX = 2
};

// Enum Killstreak.EGamepadTriggerType
enum class EGamepadTriggerType : uint8 {
	RightTrigger = 0,
	LeftTrigger = 1,
	EGamepadTriggerType_MAX = 2
};

// Enum Killstreak.ESkinObjectParentingType
enum class ESkinObjectParentingType : uint8 {
	Never = 0,
	ActiveAndMainHand = 1,
	Active = 2,
	InAction = 3,
	Always = 4,
	ESkinObjectParentingType_MAX = 5
};

// Enum Killstreak.EWeaponComponentTickType
enum class EWeaponComponentTickType : uint8 {
	NeverTick = 0,
	TickWhenPrimary = 1,
	TickWhenActive = 2,
	AlwaysTick = 3,
	EWeaponComponentTickType_MAX = 4
};

// Enum Killstreak.EWeaponMasteryRewardGroup
enum class EWeaponMasteryRewardGroup : uint8 {
	PriorityItems = 0,
	MiscRewards = 1,
	OtherItems = 2,
	Unknown = 3,
	EWeaponMasteryRewardGroup_MAX = 4
};

// ScriptStruct Killstreak.GiveItemParameters
// Size: 0x1c (Inherited: 0x00)
struct FGiveItemParameters {
	enum class EItemSourceType ItemSource; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag PreferredEquipPoint; // 0x04(0x08)
	int32_t OriginalOwnerId; // 0x0c(0x04)
	int32_t ObjectiveId; // 0x10(0x04)
	int32_t Price; // 0x14(0x04)
	bool bActivate; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
};

// ScriptStruct Killstreak.DropItemParameters
// Size: 0x28 (Inherited: 0x00)
struct FDropItemParameters {
	int32_t OriginalOwnerId; // 0x00(0x04)
	int32_t OriginalOwnerTeamNum; // 0x04(0x04)
	bool bIsPlayerDrop; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t ObjectiveId; // 0x0c(0x04)
	struct TArray<struct UKSWeaponAttachment*> Attachments; // 0x10(0x10)
	int32_t Price; // 0x20(0x04)
	enum class EDropPickupConfig DropPickupConfig; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct Killstreak.DamageEffect
// Size: 0x50 (Inherited: 0x00)
struct FDamageEffect {
	float Damage; // 0x00(0x04)
	float AttemptedDamage; // 0x04(0x04)
	struct UDamageType* DamageTypeClass; // 0x08(0x08)
	struct AActor* DamageCauser; // 0x10(0x08)
	struct FVector DamageOrigin; // 0x18(0x0c)
	bool bArmorBroke; // 0x24(0x01)
	bool bDamageResisted; // 0x25(0x01)
	bool bDamageReduced; // 0x26(0x01)
	bool bDamageShielded; // 0x27(0x01)
	struct FVector RelativeImpactLocation; // 0x28(0x0c)
	struct FVector_NetQuantizeNormal RelativeImpactNormal; // 0x34(0x0c)
	struct FName BoneName; // 0x40(0x08)
	bool IsHeadshot; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct Killstreak.ShotgunHitData
// Size: 0x18 (Inherited: 0x00)
struct FShotgunHitData {
	struct UKSWeaponAsset_Shotgun* ShotgunAsset; // 0x00(0x08)
	struct TArray<enum class EShotgunHitResult> HitResults; // 0x08(0x10)
};

// ScriptStruct Killstreak.ShopItem
// Size: 0x70 (Inherited: 0x0c)
struct FShopItem : FFastArraySerializerItem {
	enum class EShopItemType Type; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct TArray<struct FShopSubItem> CurrentSubItemList; // 0x10(0x10)
	struct TArray<struct FShopSubItem> AppliedSubItemList; // 0x20(0x10)
	bool bResetable; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t NextSubItemIndex; // 0x34(0x04)
	int32_t CurrentSubItemIndex; // 0x38(0x04)
	int32_t AppliedSubItemIndex; // 0x3c(0x04)
	bool bIsActive; // 0x40(0x01)
	bool bIsAppliedActive; // 0x41(0x01)
	bool bStartInactive; // 0x42(0x01)
	bool bOneTimePurchase; // 0x43(0x01)
	bool bResetOnExhausted; // 0x44(0x01)
	bool bAuthorityIsActive; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	int32_t AuthorityPurchaseIndex; // 0x48(0x04)
	int32_t AuthorityLatestTransactionId; // 0x4c(0x04)
	bool bSimulatedIsActive; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	int32_t SimulatedPurchaseIndex; // 0x54(0x04)
	int32_t SimulatedLatestTransactionId; // 0x58(0x04)
	char pad_5C[0x14]; // 0x5c(0x14)
};

// ScriptStruct Killstreak.ShopSubItem
// Size: 0x10 (Inherited: 0x00)
struct FShopSubItem {
	struct UKSItem* Item; // 0x00(0x08)
	int32_t Price; // 0x08(0x04)
	bool bPurchased; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct Killstreak.ProjectileExplosionInfo
// Size: 0x1c (Inherited: 0x00)
struct FProjectileExplosionInfo {
	enum class EProjectileExplosionType ExplosionType; // 0x00(0x01)
	enum class EPhysicalSurface SurfaceType; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	struct FVector_NetQuantize ImpactPoint; // 0x04(0x0c)
	struct FVector_NetQuantizeNormal ImpactNormal; // 0x10(0x0c)
};

// ScriptStruct Killstreak.KSPollResults
// Size: 0x28 (Inherited: 0x00)
struct FKSPollResults {
	struct FKSPollData PollFinalData; // 0x00(0x10)
	struct FString PollName; // 0x10(0x10)
	int32_t TeamNum; // 0x20(0x04)
	bool bPollPassed; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct Killstreak.KSPollData
// Size: 0x10 (Inherited: 0x00)
struct FKSPollData {
	int32_t VoterCount; // 0x00(0x04)
	int32_t VotesInFavor; // 0x04(0x04)
	int32_t VotesAgainst; // 0x08(0x04)
	float TimeElapsed; // 0x0c(0x04)
};

// ScriptStruct Killstreak.CombatEventInfo
// Size: 0x60 (Inherited: 0x00)
struct FCombatEventInfo {
	struct TWeakObjectPtr<struct APlayerState> EventVictim; // 0x00(0x08)
	struct TWeakObjectPtr<struct APlayerState> EventInstigator; // 0x08(0x08)
	struct TWeakObjectPtr<struct AController> InstigatorController; // 0x10(0x08)
	struct TArray<struct TWeakObjectPtr<struct APlayerState>> EventAssistants; // 0x18(0x10)
	struct TWeakObjectPtr<struct AActor> DamagedActor; // 0x28(0x08)
	struct TWeakObjectPtr<struct AActor> DamageCauser; // 0x30(0x08)
	struct UDamageType* DamageType; // 0x38(0x08)
	struct UKSWeaponAsset* WeaponAsset; // 0x40(0x08)
	bool DownEvent; // 0x48(0x01)
	bool KillEvent; // 0x49(0x01)
	enum class EHitLocationType HitLocationType; // 0x4a(0x01)
	char pad_4B[0x1]; // 0x4b(0x01)
	float DamageDealt; // 0x4c(0x04)
	float OverkillDamageDealt; // 0x50(0x04)
	float OriginalDamageDealt; // 0x54(0x04)
	bool IsArmorHit; // 0x58(0x01)
	bool bDamageResisted; // 0x59(0x01)
	bool bDamageReduced; // 0x5a(0x01)
	bool bDamageShielded; // 0x5b(0x01)
	bool IsRadialDamage; // 0x5c(0x01)
	bool WasCharacterAlreadyDown; // 0x5d(0x01)
	bool WasCharacterBeingRevived; // 0x5e(0x01)
	bool bDamageMastered; // 0x5f(0x01)
};

// ScriptStruct Killstreak.CombatEventInfoContainer
// Size: 0x10 (Inherited: 0x00)
struct FCombatEventInfoContainer {
	struct TArray<struct FCombatEventInfo> CombatEventInfoArray; // 0x00(0x10)
};

// ScriptStruct Killstreak.KSScoreChangeEvent
// Size: 0x30 (Inherited: 0x00)
struct FKSScoreChangeEvent {
	int32_t Delta; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FText Reason; // 0x08(0x18)
	bool bBonus; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	struct TWeakObjectPtr<struct AKSPlayerState> Instigator; // 0x24(0x08)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct Killstreak.PrimaryOffering
// Size: 0x10 (Inherited: 0x00)
struct FPrimaryOffering {
	struct UKSItem* Offering; // 0x00(0x08)
	bool Mastered; // 0x08(0x01)
	bool Favorited; // 0x09(0x01)
	bool Default; // 0x0a(0x01)
	char pad_B[0x5]; // 0x0b(0x05)
};

// ScriptStruct Killstreak.LootSiteState
// Size: 0x02 (Inherited: 0x00)
struct FLootSiteState {
	bool bActive; // 0x00(0x01)
	bool bLooted; // 0x01(0x01)
};

// ScriptStruct Killstreak.RadialMenuItemEventInfo
// Size: 0x10 (Inherited: 0x00)
struct FRadialMenuItemEventInfo {
	struct TWeakObjectPtr<struct APlayerState> EventInstigator; // 0x00(0x08)
	struct TWeakObjectPtr<struct UKSRadialMenuItem> RadialMenuItem; // 0x08(0x08)
};

// ScriptStruct Killstreak.AssistInfo
// Size: 0x28 (Inherited: 0x00)
struct FAssistInfo {
	struct TWeakObjectPtr<struct AKSPlayerState> Assistant; // 0x00(0x08)
	float DamageContributed; // 0x08(0x04)
	float ContributionPercent; // 0x0c(0x04)
	int32_t PointsAwarded; // 0x10(0x04)
	struct TWeakObjectPtr<struct AKSPlayerState> Victim; // 0x14(0x08)
	struct TWeakObjectPtr<struct AKSPlayerState> DownInstigator; // 0x1c(0x08)
	bool bLethal; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct Killstreak.MatchPhase
// Size: 0x0c (Inherited: 0x00)
struct FMatchPhase {
	struct FName Name; // 0x00(0x08)
	int32_t ID; // 0x08(0x04)
};

// ScriptStruct Killstreak.AccoladeEventEntry
// Size: 0x78 (Inherited: 0x00)
struct FAccoladeEventEntry {
	struct TWeakObjectPtr<struct AKSPlayerState> RelevantPlayer; // 0x00(0x08)
	struct FAccoladeDisplayInfo AccoladeDisplayInfo; // 0x08(0x68)
	bool IgnoreRelevantPlayerId; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct Killstreak.AccoladeDisplayInfo
// Size: 0x68 (Inherited: 0x00)
struct FAccoladeDisplayInfo {
	enum class EAccoladeCategory Category; // 0x00(0x01)
	enum class EAccoladeEventType Type; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct UTexture2D* DisplayIcon; // 0x08(0x08)
	struct FText DisplayTitle; // 0x10(0x18)
	float DisplayDuration; // 0x28(0x04)
	int32_t Multiplier; // 0x2c(0x04)
	struct FKSVoicelineEvent AccoladeVoiceLine; // 0x30(0x38)
};

// ScriptStruct Killstreak.KSVoicelineEvent
// Size: 0x38 (Inherited: 0x00)
struct FKSVoicelineEvent {
	struct FName EventName; // 0x00(0x08)
	struct FName SelfEventName; // 0x08(0x08)
	enum class EKSVoicelineAudience Audience; // 0x10(0x01)
	enum class EKSVoicelineType VoicelineType; // 0x11(0x01)
	char pad_12[0x2]; // 0x12(0x02)
	float ActivationChance; // 0x14(0x04)
	bool bAffectedByGlobalCooldown; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t CooldownGroup; // 0x1c(0x04)
	float CooldownDuration; // 0x20(0x04)
	float VoicelineChangeValue; // 0x24(0x04)
	enum class EKSVoiceOverPriority LinePriority; // 0x28(0x01)
	bool bPlayedByOwnerAlready; // 0x29(0x01)
	bool bPlaySpecificVoiceLine; // 0x2a(0x01)
	char pad_2B[0x5]; // 0x2b(0x05)
	struct UAkAudioEvent* SpecificAkAudioEvent; // 0x30(0x08)
};

// ScriptStruct Killstreak.DisplayInfo
// Size: 0xa0 (Inherited: 0x00)
struct FDisplayInfo {
	struct TMap<enum class EDisplayType, struct TSoftClassPtr<UObject>> DisplayWidgetMap; // 0x00(0x50)
	bool bUseWidgetPool; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct TArray<struct FString> WidgetPoolName; // 0x58(0x10)
	int32_t UniqueId; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct AKSPlayerState* CreatingPlayer; // 0x70(0x08)
	struct AActor* AssociatedActor; // 0x78(0x08)
	struct UObject* AssociatedObject; // 0x80(0x08)
	struct FVector DefaultLocation; // 0x88(0x0c)
	float Lifespan; // 0x94(0x04)
	struct FTimerHandle TimerHandle; // 0x98(0x08)
};

// ScriptStruct Killstreak.RoundInitState
// Size: 0x10 (Inherited: 0x00)
struct FRoundInitState {
	char RoundNumber; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t AttackingTeam; // 0x04(0x04)
	int32_t DefendingTeam; // 0x08(0x04)
	char LastPrepareTriggered; // 0x0c(0x01)
	char LastRoundStartTriggered; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct Killstreak.RoundResult
// Size: 0x20 (Inherited: 0x00)
struct FRoundResult {
	char RoundNumber; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct AKSTeamState* WinningTeam; // 0x08(0x08)
	int32_t WinnerScore; // 0x10(0x04)
	bool WinByElimination; // 0x14(0x01)
	char LastTriggeredRound; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	struct AKSObjectiveBase* ObjectiveChosen; // 0x18(0x08)
};

// ScriptStruct Killstreak.JobSelectionEntry
// Size: 0x28 (Inherited: 0x0c)
struct FJobSelectionEntry : FFastArraySerializerItem {
	int32_t JobId; // 0x0c(0x04)
	struct TArray<struct FPlayerJobSelectInfo> CurrentPlayerInfos; // 0x10(0x10)
	enum class EJobSelectionState LocalAvailability; // 0x20(0x01)
	enum class EJobUniquenessRule CachedJobUniquenessRule; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
};

// ScriptStruct Killstreak.PlayerJobSelectInfo
// Size: 0x20 (Inherited: 0x00)
struct FPlayerJobSelectInfo {
	struct TWeakObjectPtr<struct AKSPlayerState> PlayerState; // 0x00(0x08)
	struct FSerializedMctsNetId NetId; // 0x08(0x08)
	int32_t SkinId; // 0x10(0x04)
	int32_t JobMasteryXp; // 0x14(0x04)
	enum class EJobSelectionState SelectionState; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct Killstreak.ActivityTier
// Size: 0x40 (Inherited: 0x00)
struct FActivityTier {
	int32_t Tier; // 0x00(0x04)
	int32_t StartingCount; // 0x04(0x04)
	int32_t Count; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FTierRewardItemData> RewardItems; // 0x10(0x10)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct Killstreak.TierRewardItemData
// Size: 0x10 (Inherited: 0x00)
struct FTierRewardItemData {
	struct UPUMG_StoreItem* RewardItem; // 0x00(0x08)
	int32_t QuantityInTier; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct Killstreak.KSRevealInfo
// Size: 0x48 (Inherited: 0x00)
struct FKSRevealInfo {
	int32_t RevealID; // 0x00(0x04)
	struct TWeakObjectPtr<struct AKSPlayerState> Revealer; // 0x04(0x08)
	struct TWeakObjectPtr<struct AActor> RevealTarget; // 0x0c(0x08)
	struct TWeakObjectPtr<struct UObject> RevealInstigator; // 0x14(0x08)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct UObject* RevealClass; // 0x20(0x08)
	enum class ETargetAudience TargetAudience; // 0x28(0x01)
	enum class EKSRevealSource RevealSource; // 0x29(0x01)
	enum class EKSRevealPriority RevealPriority; // 0x2a(0x01)
	bool bUseRevealOverrideColor; // 0x2b(0x01)
	struct FLinearColor RevealOverrideColor; // 0x2c(0x10)
	bool bFilled; // 0x3c(0x01)
	bool bOutlineTargetOnClient; // 0x3d(0x01)
	bool bNotifyTargetRevealed; // 0x3e(0x01)
	bool bDisplayEnemyDetectedUI; // 0x3f(0x01)
	bool bForcedDisplay; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct Killstreak.AdvancedCombatSummary
// Size: 0x20 (Inherited: 0x00)
struct FAdvancedCombatSummary {
	struct APawn* DamageInstigatorPawn; // 0x00(0x08)
	struct AActor* DamageCauser; // 0x08(0x08)
	struct TArray<struct FAdvancedCombatEvent> CombatEvents; // 0x10(0x10)
};

// ScriptStruct Killstreak.AdvancedCombatEvent
// Size: 0xa8 (Inherited: 0x00)
struct FAdvancedCombatEvent {
	struct TWeakObjectPtr<struct APlayerState> DamageInstigator; // 0x00(0x08)
	struct TWeakObjectPtr<struct APawn> DamageInstigatorPawn; // 0x08(0x08)
	struct TWeakObjectPtr<struct AActor> DamageCauser; // 0x10(0x08)
	float Damage; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct UDamageType* DamageType; // 0x20(0x08)
	struct UKSWeaponAsset* WeaponAsset; // 0x28(0x08)
	int32_t VictimId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString Victim; // 0x38(0x10)
	struct FVector_NetQuantize VictimLocation; // 0x48(0x0c)
	int32_t VictimTeamNum; // 0x54(0x04)
	int32_t InstigatorId; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FString Instigator; // 0x60(0x10)
	enum class ECombatEventFriendlyFireType FriendlyFireType; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	float GameTimeStamp; // 0x74(0x04)
	struct FVector_NetQuantize HitLocation; // 0x78(0x0c)
	struct FName HitBone; // 0x84(0x08)
	bool Headshot; // 0x8c(0x01)
	bool DowningHit; // 0x8d(0x01)
	bool FatalHit; // 0x8e(0x01)
	bool bResisted; // 0x8f(0x01)
	bool bReduced; // 0x90(0x01)
	bool bShielded; // 0x91(0x01)
	char pad_92[0x16]; // 0x92(0x16)
};

// ScriptStruct Killstreak.TelemetrySettings
// Size: 0x04 (Inherited: 0x00)
struct FTelemetrySettings {
	bool bPingEnabled; // 0x00(0x01)
	bool bPacketLossEnabled; // 0x01(0x01)
	bool bFPSEnabled; // 0x02(0x01)
	bool bTelemetryFeatureActive; // 0x03(0x01)
};

// ScriptStruct Killstreak.PingInfo
// Size: 0x50 (Inherited: 0x00)
struct FPingInfo {
	enum class EPingType PingType; // 0x00(0x01)
	enum class EPingMessage PingMessage; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	struct FVector_NetQuantize Location; // 0x04(0x0c)
	struct FVector_NetQuantize PingIconOffset; // 0x10(0x0c)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct AActor* PingedActor; // 0x20(0x08)
	struct AKSPlayerState* PingingPlayer; // 0x28(0x08)
	struct TArray<struct AKSPlayerState*> AcknowledgedPlayers; // 0x30(0x10)
	struct FTimerHandle ExpirationHandle; // 0x40(0x08)
	int32_t PingId; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct Killstreak.KSActorProximityInfo
// Size: 0x18 (Inherited: 0x00)
struct FKSActorProximityInfo {
	bool bInLOS; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float LastTimeUpdated; // 0x04(0x04)
	struct TArray<struct UPrimitiveComponent*> OverlappedComponents; // 0x08(0x10)
};

// ScriptStruct Killstreak.AnnouncementData
// Size: 0x38 (Inherited: 0x00)
struct FAnnouncementData {
	enum class EAnnouncementType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText MessageText; // 0x08(0x18)
	enum class ETeamAlignment TeamAlignment; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t TeamAlignmentNum; // 0x24(0x04)
	int32_t FriendlyTeamAlive; // 0x28(0x04)
	int32_t EnemyTeamAlive; // 0x2c(0x04)
	float Seconds; // 0x30(0x04)
	float DisplayDuration; // 0x34(0x04)
};

// ScriptStruct Killstreak.JobSelectionTask
// Size: 0x48 (Inherited: 0x0c)
struct FJobSelectionTask : FFastArraySerializerItem {
	struct FJobSelectionTaskId TaskId; // 0x0c(0x02)
	enum class EJobSelectionTaskType TaskType; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
	struct UKSJobItem* SelectedJob; // 0x10(0x08)
	struct FKSPersistentPlayerId Player; // 0x18(0x10)
	struct FKSPersistentPlayerId SelectingProxy; // 0x28(0x10)
	int32_t TeamNum; // 0x38(0x04)
	bool bHaltingTask; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	float TimeForTask; // 0x40(0x04)
	struct FPGame_ReplicatedTimerId TimerId; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
};

// ScriptStruct Killstreak.KSPersistentPlayerId
// Size: 0x10 (Inherited: 0x00)
struct FKSPersistentPlayerId {
	struct FSerializedMctsNetId NetId; // 0x00(0x08)
	int32_t EngineId; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct Killstreak.JobSelectionTaskId
// Size: 0x02 (Inherited: 0x00)
struct FJobSelectionTaskId {
	uint16_t ID; // 0x00(0x02)
};

// ScriptStruct Killstreak.KSGlobalShotInfo
// Size: 0x18 (Inherited: 0x00)
struct FKSGlobalShotInfo {
	struct APlayerState* FiringPlayer; // 0x00(0x08)
	struct FVector FiringLocation; // 0x08(0x0c)
	float AudibleRange; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSClientShotInfo
// Size: 0x18 (Inherited: 0x00)
struct FKSClientShotInfo {
	struct FVector FiringLocation; // 0x00(0x0c)
	int32_t UniqueId; // 0x0c(0x04)
	float FadeTime; // 0x10(0x04)
	enum class EKSPingType PingType; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct Killstreak.CongregatedShotgunHit
// Size: 0xb0 (Inherited: 0x00)
struct FCongregatedShotgunHit {
	struct FHitResult FirstHit; // 0x00(0x88)
	struct AActor* HitActor; // 0x88(0x08)
	int32_t TimesHit; // 0x90(0x04)
	float AccumulatedDamage; // 0x94(0x04)
	int32_t TimesHitHead; // 0x98(0x04)
	bool HeadshotRegistered; // 0x9c(0x01)
	char pad_9D[0x3]; // 0x9d(0x03)
	struct FName BackupBodyBone; // 0xa0(0x08)
	struct FName BackupHeadBone; // 0xa8(0x08)
};

// ScriptStruct Killstreak.AimData
// Size: 0x50 (Inherited: 0x00)
struct FAimData {
	struct FVector_NetQuantize10 StartTrace; // 0x00(0x0c)
	struct FVector_NetQuantizeNormal Direction; // 0x0c(0x0c)
	struct FVector_NetQuantize10 ViewPoint; // 0x18(0x0c)
	enum class EAimDataMode AimDataMode; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	struct FVector_NetQuantize10 EndTrace; // 0x28(0x0c)
	struct FVector_NetQuantizeNormal ImpactNormal; // 0x34(0x0c)
	struct TArray<struct FVector_NetQuantizeNormal> SpreadDirections; // 0x40(0x10)
};

// ScriptStruct Killstreak.ScoreboardStats
// Size: 0x50 (Inherited: 0x00)
struct FScoreboardStats {
	int32_t userPlayerID; // 0x00(0x04)
	int32_t winTeamNum; // 0x04(0x04)
	struct FString mapName; // 0x08(0x10)
	struct FSerializedMatchId MatchID; // 0x18(0x10)
	int32_t GameMode; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FTeamStats> teams; // 0x30(0x10)
	struct TArray<struct FPlayerEntryStats> playerStats; // 0x40(0x10)
};

// ScriptStruct Killstreak.PlayerEntryStats
// Size: 0xc8 (Inherited: 0x00)
struct FPlayerEntryStats {
	int32_t PlayerId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	int64_t netPlayerID; // 0x08(0x08)
	struct FString PlayerName; // 0x10(0x10)
	int32_t TeamNum; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct UKSJobItem* PlayerJob; // 0x28(0x08)
	bool IsBot; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FPlayerMatchStatInfo elimCount; // 0x34(0x10)
	struct FPlayerMatchStatInfo DownCount; // 0x44(0x10)
	struct FPlayerMatchStatInfo deathCount; // 0x54(0x10)
	struct FPlayerMatchStatInfo reviveCount; // 0x64(0x10)
	struct FPlayerMatchStatInfo DamageDealt; // 0x74(0x10)
	struct FPlayerMatchStatInfo hackCount; // 0x84(0x10)
	struct FPlayerMatchStatInfo dehackCount; // 0x94(0x10)
	struct FPlayerMatchStatInfo pointCount; // 0xa4(0x10)
	struct FPlayerMatchStatInfo timePlayed; // 0xb4(0x10)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// ScriptStruct Killstreak.PlayerMatchStatInfo
// Size: 0x10 (Inherited: 0x00)
struct FPlayerMatchStatInfo {
	enum class EPlayerStatType StatType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float StatValue; // 0x04(0x04)
	int32_t StatPlaceTeam; // 0x08(0x04)
	int32_t StatPlaceAll; // 0x0c(0x04)
};

// ScriptStruct Killstreak.TeamStats
// Size: 0x20 (Inherited: 0x00)
struct FTeamStats {
	int32_t TeamNum; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString teamName; // 0x08(0x10)
	int32_t teamScore; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct Killstreak.PlayerRewardsSummary
// Size: 0x60 (Inherited: 0x00)
struct FPlayerRewardsSummary {
	struct TMap<int64_t, struct FRewardProgress> ActivityRewards; // 0x00(0x50)
	struct TArray<struct FPlayerMatchStatInfo> BestStats; // 0x50(0x10)
};

// ScriptStruct Killstreak.RewardProgress
// Size: 0x90 (Inherited: 0x00)
struct FRewardProgress {
	int32_t InitialQuantity; // 0x00(0x04)
	int32_t Quantity; // 0x04(0x04)
	struct TArray<enum class ERewardSource> SourceKeys; // 0x08(0x10)
	struct TArray<float> SourceValues; // 0x18(0x10)
	struct TArray<struct FString> EventKeys; // 0x28(0x10)
	struct TArray<float> EventValues; // 0x38(0x10)
	struct TArray<struct FString> BoosterKeys; // 0x48(0x10)
	struct TArray<float> BoosterValues; // 0x58(0x10)
	struct TArray<struct FString> ExtraDataKeys; // 0x68(0x10)
	struct TArray<float> ExtraDataValues; // 0x78(0x10)
	bool InitialUnlocked; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// ScriptStruct Killstreak.AttachmentData
// Size: 0x48 (Inherited: 0x00)
struct FAttachmentData {
	struct TSoftObjectPtr<UKSWeaponAttachment> SoftObjectPtr; // 0x00(0x28)
	struct FGameplayTagContainer CachedCompatibleWeaponTypes; // 0x28(0x20)
};

// ScriptStruct Killstreak.SizedArraySerializer
// Size: 0x70 (Inherited: 0x70)
struct FSizedArraySerializer : FReplicatedLog {
};

// ScriptStruct Killstreak.AccoladeEventList
// Size: 0x88 (Inherited: 0x70)
struct FAccoladeEventList : FSizedArraySerializer {
	struct TArray<struct FAccoladeEventItem> Items; // 0x70(0x10)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct Killstreak.AccoladeEventItem
// Size: 0x78 (Inherited: 0x01)
struct FAccoladeEventItem : FReplicatedLogItem {
	struct FAccoladeEventEntry AccoladeEventEntry; // 0x00(0x78)
};

// ScriptStruct Killstreak.AccoladeTrackerTableRow
// Size: 0x30 (Inherited: 0x08)
struct FAccoladeTrackerTableRow : FTableRowBase {
	struct TSoftClassPtr<UObject> AccoladeTrackerObject; // 0x08(0x28)
};

// ScriptStruct Killstreak.AccoladePlayerTrackers
// Size: 0x30 (Inherited: 0x00)
struct FAccoladePlayerTrackers {
	int32_t PlayerId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AKSPlayerState* PlayerState; // 0x08(0x08)
	int32_t DownCount; // 0x10(0x04)
	int32_t elimCount; // 0x14(0x04)
	float TimeLeft; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FCombatEventInfo> ContributingCombatEvents; // 0x20(0x10)
};

// ScriptStruct Killstreak.KSActivityDescriptor
// Size: 0x20 (Inherited: 0x00)
struct FKSActivityDescriptor {
	struct FGameplayTag ActivityTag; // 0x00(0x08)
	int64_t DescriptorId; // 0x08(0x08)
	struct FString DescriptorString; // 0x10(0x10)
};

// ScriptStruct Killstreak.ActivitySequenceRow
// Size: 0x30 (Inherited: 0x08)
struct FActivitySequenceRow : FTableRowBase {
	struct FText DisplayName; // 0x08(0x18)
	struct TArray<struct TSoftObjectPtr<UKSActivity>> ActivitySequence; // 0x20(0x10)
};

// ScriptStruct Killstreak.ActivityTierStructure
// Size: 0xb8 (Inherited: 0x00)
struct FActivityTierStructure {
	int32_t ProgressRequired; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FText Name; // 0x08(0x18)
	struct FText Description; // 0x20(0x18)
	struct TSoftObjectPtr<UTexture2D> Image; // 0x38(0x28)
	struct FActivityAchievementInfo PlatformAchievement; // 0x60(0x58)
};

// ScriptStruct Killstreak.ActivityAchievementInfo
// Size: 0x58 (Inherited: 0x00)
struct FActivityAchievementInfo {
	bool bIsAchievement; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<struct FName, struct FString> AchievementIdByOSSName; // 0x08(0x50)
};

// ScriptStruct Killstreak.AgentStateChangeList
// Size: 0x88 (Inherited: 0x70)
struct FAgentStateChangeList : FSizedArraySerializer {
	struct TWeakObjectPtr<struct AKSAgent_Aimed> Owner; // 0x70(0x08)
	struct TArray<struct FAgentStateChange> StateChanges; // 0x78(0x10)
};

// ScriptStruct Killstreak.AgentStateChange
// Size: 0x02 (Inherited: 0x01)
struct FAgentStateChange : FReplicatedLogItem {
	enum class EWeaponStateNew OldState; // 0x00(0x01)
	enum class EWeaponStateNew NewState; // 0x01(0x01)
};

// ScriptStruct Killstreak.BotNameTableRow
// Size: 0x08 (Inherited: 0x08)
struct FBotNameTableRow : FTableRowBase {
};

// ScriptStruct Killstreak.KSInitialLoadoutRow
// Size: 0x18 (Inherited: 0x08)
struct FKSInitialLoadoutRow : FTableRowBase {
	struct TArray<struct TSoftObjectPtr<UKSItem>> LoadoutItems; // 0x08(0x10)
};

// ScriptStruct Killstreak.AimAssistActorHealthInfo
// Size: 0x08 (Inherited: 0x00)
struct FAimAssistActorHealthInfo {
	float CurrentHealth; // 0x00(0x04)
	bool bKilled; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
};

// ScriptStruct Killstreak.RankedAimAssistTarget
// Size: 0x48 (Inherited: 0x00)
struct FRankedAimAssistTarget {
	struct UKSAimAssistAnchorComponent* Anchor; // 0x00(0x08)
	struct TScriptInterface<IKSAimAssistTargetInterface> Target; // 0x08(0x10)
	float HeadWeight; // 0x18(0x04)
	struct FVector2D BodyLocation; // 0x1c(0x08)
	struct FVector2D HeadLocation; // 0x24(0x08)
	struct FBox2D ScaledProjectionBounds; // 0x2c(0x14)
	float DistanceFromCamera; // 0x40(0x04)
	int32_t UpdateCount; // 0x44(0x04)
};

// ScriptStruct Killstreak.KSAimAssistPropertyCurveVector
// Size: 0x10 (Inherited: 0x00)
struct FKSAimAssistPropertyCurveVector {
	enum class EControllerInputType InputType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UCurveVector* Value; // 0x08(0x08)
};

// ScriptStruct Killstreak.KSAimAssistPropertyCurveFloat
// Size: 0x10 (Inherited: 0x00)
struct FKSAimAssistPropertyCurveFloat {
	enum class EControllerInputType InputType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UCurveFloat* Value; // 0x08(0x08)
};

// ScriptStruct Killstreak.KSAimAssistPropertyFloat
// Size: 0x08 (Inherited: 0x00)
struct FKSAimAssistPropertyFloat {
	enum class EControllerInputType InputType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Value; // 0x04(0x04)
};

// ScriptStruct Killstreak.KSAimAssistPropertyBool
// Size: 0x02 (Inherited: 0x00)
struct FKSAimAssistPropertyBool {
	enum class EControllerInputType InputType; // 0x00(0x01)
	bool Value; // 0x01(0x01)
};

// ScriptStruct Killstreak.KSPerceptionFilter
// Size: 0x170 (Inherited: 0x00)
struct FKSPerceptionFilter {
	struct FName PerceptionEvent; // 0x00(0x08)
	struct FKSAffiliationFilter AffiliationFilter; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FKSCharacterStateFilter CharacterStateFilter; // 0x10(0x98)
	struct FKSInteractableStateFilter InteractableStateFilter; // 0xa8(0x18)
	struct FKSDestructibleStateFilter DestructibleStateFilter; // 0xc0(0x02)
	char pad_C2[0x2]; // 0xc2(0x02)
	struct FKSItemDropStateFilter ItemDropStateFilter; // 0xc4(0x10)
	struct FKSLootSiteFilter LootSiteFilter; // 0xd4(0x02)
	struct FKSDestroyableHazardStateFilter DestroyableHazardStateFilter; // 0xd6(0x07)
	char pad_DD[0x3]; // 0xdd(0x03)
	struct FKSMapPointStateFilter MapPointStateFilter; // 0xe0(0x30)
	struct FKSObjectiveStateFilter ObjectiveStateFilter; // 0x110(0x18)
	bool bCheckDistance; // 0x128(0x01)
	enum class EArithmeticKeyOperation DistanceOperation; // 0x129(0x01)
	char pad_12A[0x2]; // 0x12a(0x02)
	float Distance; // 0x12c(0x04)
	bool bCheckDistanceRange; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	float MinDistance; // 0x134(0x04)
	float MaxDistance; // 0x138(0x04)
	bool bCheckActorClass; // 0x13c(0x01)
	char pad_13D[0x3]; // 0x13d(0x03)
	struct AActor* ActorClass; // 0x140(0x08)
	bool bCheckActorClassArray; // 0x148(0x01)
	char pad_149[0x7]; // 0x149(0x07)
	struct TArray<struct AActor*> ActorClassArray; // 0x150(0x10)
	bool bCheckLOS; // 0x160(0x01)
	bool bCheckForward; // 0x161(0x01)
	char pad_162[0x2]; // 0x162(0x02)
	float MaxForwardAngle; // 0x164(0x04)
	bool bCheckIntersectsNavMeshPath; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
};

// ScriptStruct Killstreak.KSObjectiveStateFilter
// Size: 0x18 (Inherited: 0x00)
struct FKSObjectiveStateFilter {
	bool bCheckObjectiveState; // 0x00(0x01)
	enum class EBasicKeyOperation MatchesObjectiveState; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<struct FName> StateNamesToCheck; // 0x08(0x10)
};

// ScriptStruct Killstreak.KSMapPointStateFilter
// Size: 0x30 (Inherited: 0x00)
struct FKSMapPointStateFilter {
	bool bCheckMapPointType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FGameplayTagContainer RequiredMapPointTypes; // 0x08(0x20)
	bool bCheckIsPointActive; // 0x28(0x01)
	enum class EBasicKeyOperation IsPointActive; // 0x29(0x01)
	bool bCheckIsPointAvailable; // 0x2a(0x01)
	enum class EBasicKeyOperation IsPointAvailable; // 0x2b(0x01)
	bool bCheckIsPointFriendly; // 0x2c(0x01)
	enum class EBasicKeyOperation IsPointFriendly; // 0x2d(0x01)
	char pad_2E[0x2]; // 0x2e(0x02)
};

// ScriptStruct Killstreak.KSDestroyableHazardStateFilter
// Size: 0x07 (Inherited: 0x00)
struct FKSDestroyableHazardStateFilter {
	bool bReturnTrueIfNotDestroyableHazard; // 0x00(0x01)
	bool bCheckCanBotDetect; // 0x01(0x01)
	enum class EBasicKeyOperation CanBotDetect; // 0x02(0x01)
	bool bCheckShouldDestroyWithGunfire; // 0x03(0x01)
	enum class EBasicKeyOperation ShouldDestroyWithGunfire; // 0x04(0x01)
	bool bCheckShouldDestroyWithEMP; // 0x05(0x01)
	enum class EBasicKeyOperation ShouldDestroyWithEMP; // 0x06(0x01)
};

// ScriptStruct Killstreak.KSLootSiteFilter
// Size: 0x02 (Inherited: 0x00)
struct FKSLootSiteFilter {
	bool bCheckHasBeenSeen; // 0x00(0x01)
	enum class EBasicKeyOperation HasBeenSeen; // 0x01(0x01)
};

// ScriptStruct Killstreak.KSItemDropStateFilter
// Size: 0x10 (Inherited: 0x00)
struct FKSItemDropStateFilter {
	bool bCheckEquipPoint; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag EquipPoint; // 0x04(0x08)
	bool bCheckHasBeenSeen; // 0x0c(0x01)
	enum class EBasicKeyOperation HasBeenSeen; // 0x0d(0x01)
	bool bCheckIsInActiveState; // 0x0e(0x01)
	enum class EBasicKeyOperation IsInActiveState; // 0x0f(0x01)
};

// ScriptStruct Killstreak.KSDestructibleStateFilter
// Size: 0x02 (Inherited: 0x00)
struct FKSDestructibleStateFilter {
	bool bCheckIsDestroyed; // 0x00(0x01)
	enum class EBasicKeyOperation Destroyed; // 0x01(0x01)
};

// ScriptStruct Killstreak.KSInteractableStateFilter
// Size: 0x18 (Inherited: 0x00)
struct FKSInteractableStateFilter {
	bool bCheckIsInteracting; // 0x00(0x01)
	enum class EBasicKeyOperation IsInteracting; // 0x01(0x01)
	bool bCheckInteractorAffiliation; // 0x02(0x01)
	struct FKSAffiliationFilter InteractorAffiliation; // 0x03(0x04)
	bool bCheckCanInteract; // 0x07(0x01)
	enum class EBasicKeyOperation CanInteract; // 0x08(0x01)
	bool bCheckInteractableClass; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct AActor* InteractableClass; // 0x10(0x08)
};

// ScriptStruct Killstreak.KSAffiliationFilter
// Size: 0x04 (Inherited: 0x00)
struct FKSAffiliationFilter {
	bool bCountEnemies; // 0x00(0x01)
	bool bCountAllies; // 0x01(0x01)
	bool bCountSelf; // 0x02(0x01)
	bool bCountUnaffiliated; // 0x03(0x01)
};

// ScriptStruct Killstreak.KSCharacterStateFilter
// Size: 0x98 (Inherited: 0x00)
struct FKSCharacterStateFilter {
	bool bCheckHealth; // 0x00(0x01)
	enum class EArithmeticKeyOperation HealthOperation; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	float HealthPercent; // 0x04(0x04)
	bool bCheckDowned; // 0x08(0x01)
	enum class EBasicKeyOperation Downed; // 0x09(0x01)
	bool bCheckDead; // 0x0a(0x01)
	enum class EBasicKeyOperation Dead; // 0x0b(0x01)
	bool bCheckCrouched; // 0x0c(0x01)
	enum class EBasicKeyOperation Crouched; // 0x0d(0x01)
	bool bCheckFalling; // 0x0e(0x01)
	enum class EBasicKeyOperation Falling; // 0x0f(0x01)
	bool bCheckSprinting; // 0x10(0x01)
	enum class EBasicKeyOperation Sprinting; // 0x11(0x01)
	bool bCheckSwimming; // 0x12(0x01)
	enum class EBasicKeyOperation Swimming; // 0x13(0x01)
	bool bCheckRidingZipline; // 0x14(0x01)
	enum class EBasicKeyOperation RidingZipline; // 0x15(0x01)
	bool bCheckIsBot; // 0x16(0x01)
	enum class EBasicKeyOperation IsBot; // 0x17(0x01)
	bool bCheckBehaviorState; // 0x18(0x01)
	enum class EBasicKeyOperation BehaviorOperation; // 0x19(0x01)
	enum class ECharacterBehaviorState BehaviorState; // 0x1a(0x01)
	bool bCheckInteracting; // 0x1b(0x01)
	enum class EBasicKeyOperation Interacting; // 0x1c(0x01)
	bool bCheckInteractableClass; // 0x1d(0x01)
	char pad_1E[0x2]; // 0x1e(0x02)
	struct AActor* InteractableClass; // 0x20(0x08)
	float MinInteractTimeRemaining; // 0x28(0x04)
	float MaxInteractTimeRemaining; // 0x2c(0x04)
	bool bCheckADS; // 0x30(0x01)
	enum class EBasicKeyOperation ADS; // 0x31(0x01)
	bool bCheckHasReviver; // 0x32(0x01)
	enum class EBasicKeyOperation HasReviver; // 0x33(0x01)
	bool bCheckReviverAffiliation; // 0x34(0x01)
	struct FKSAffiliationFilter ReviverAffiliation; // 0x35(0x04)
	bool bCheckIsOnFire; // 0x39(0x01)
	enum class EBasicKeyOperation IsOnFire; // 0x3a(0x01)
	bool bCheckIsWeaponEquipped; // 0x3b(0x01)
	enum class EBasicKeyOperation IsWeaponEquipped; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct AKSWeapon* EquippedWeaponClass; // 0x40(0x08)
	bool bCheckIsWeaponAssetEquipped; // 0x48(0x01)
	enum class EBasicKeyOperation IsWeaponAssetEquipped; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
	struct TSoftObjectPtr<UKSWeaponAsset> EquippedWeaponAsset; // 0x50(0x28)
	bool bCheckRoles; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TArray<enum class ECharacterRole> RolesToCheck; // 0x80(0x10)
	bool bRequireAllRoles; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// ScriptStruct Killstreak.KSStimulusEvent
// Size: 0x48 (Inherited: 0x00)
struct FKSStimulusEvent {
	struct AActor* Actor; // 0x00(0x08)
	struct FAIStimulus Stimulus; // 0x08(0x3c)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct Killstreak.KSAIMapPointStimulusEvent
// Size: 0x10 (Inherited: 0x00)
struct FKSAIMapPointStimulusEvent {
	struct AActor* Broadcaster; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct Killstreak.AIObjectiveEvent
// Size: 0x30 (Inherited: 0x00)
struct FAIObjectiveEvent {
	char pad_0[0x4]; // 0x00(0x04)
	struct FVector ObjectiveLocation; // 0x04(0x0c)
	float Loudness; // 0x10(0x04)
	float MaxRange; // 0x14(0x04)
	struct AActor* Instigator; // 0x18(0x08)
	struct FName Tag; // 0x20(0x08)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct Killstreak.KSAIPlayerStimulusEvent
// Size: 0x38 (Inherited: 0x00)
struct FKSAIPlayerStimulusEvent {
	char pad_0[0x28]; // 0x00(0x28)
	struct AActor* Broadcaster; // 0x28(0x08)
	struct AActor* Enemy; // 0x30(0x08)
};

// ScriptStruct Killstreak.KSAITeamStimulusEvent
// Size: 0x38 (Inherited: 0x00)
struct FKSAITeamStimulusEvent {
	char pad_0[0x28]; // 0x00(0x28)
	struct AActor* Broadcaster; // 0x28(0x08)
	struct AActor* Enemy; // 0x30(0x08)
};

// ScriptStruct Killstreak.KSAmmoManager
// Size: 0x130 (Inherited: 0x108)
struct FKSAmmoManager : FFastArraySerializer {
	struct TWeakObjectPtr<struct AActor> Owner; // 0x108(0x08)
	struct TArray<struct FKSAmmoManagerEntry> AmmoSupply; // 0x110(0x10)
	struct TArray<struct FKSAmmoTransactions> UnverifiedAmmoTransactions; // 0x120(0x10)
};

// ScriptStruct Killstreak.KSAmmoTransactions
// Size: 0x18 (Inherited: 0x00)
struct FKSAmmoTransactions {
	uint64_t TransactionId; // 0x00(0x08)
	uint32_t UpdateIdAtTimeOfTransaction; // 0x08(0x04)
	enum class EAmmoType AmmoType; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	int32_t AmmoDelta; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSAmmoManagerEntry
// Size: 0x1c (Inherited: 0x0c)
struct FKSAmmoManagerEntry : FFastArraySerializerItem {
	enum class EAmmoType AmmoType; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	uint32_t UpdateId; // 0x10(0x04)
	int32_t AmmoCount; // 0x14(0x04)
	char pad_18[0x4]; // 0x18(0x04)
};

// ScriptStruct Killstreak.KSAnimInstanceProxy
// Size: 0x790 (Inherited: 0x730)
struct FKSAnimInstanceProxy : FSkinnedAnimInstanceProxy {
	char pad_730[0x60]; // 0x730(0x60)
};

// ScriptStruct Killstreak.KSAnimStats
// Size: 0x08 (Inherited: 0x00)
struct FKSAnimStats {
	float PlayTime; // 0x00(0x04)
	float PlayTimeWeighted; // 0x04(0x04)
};

// ScriptStruct Killstreak.TimeAnnouncementList
// Size: 0x10 (Inherited: 0x00)
struct FTimeAnnouncementList {
	struct TArray<struct FTimeAnnouncement> TimeAnnouncements; // 0x00(0x10)
};

// ScriptStruct Killstreak.TimeAnnouncement
// Size: 0x60 (Inherited: 0x00)
struct FTimeAnnouncement {
	float Time; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FAnnouncement Announcement; // 0x08(0x40)
	struct TArray<struct FName> AnnouncementGroups; // 0x48(0x10)
	bool Block; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// ScriptStruct Killstreak.Announcement
// Size: 0x40 (Inherited: 0x00)
struct FAnnouncement {
	struct UAkAudioEvent* AkEvent; // 0x00(0x08)
	struct UAkAudioEvent* AltAkEvent; // 0x08(0x08)
	enum class EKSVoiceOverPriority Priority; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float Lifetime; // 0x14(0x04)
	float ValidUntil; // 0x18(0x04)
	float Delay; // 0x1c(0x04)
	float Lockout; // 0x20(0x04)
	float RTPC; // 0x24(0x04)
	int32_t TeamNum; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FSerializedMctsNetId PlayerId; // 0x30(0x08)
	struct UAkAudioEvent* TargetPlayerAkEvent; // 0x38(0x08)
};

// ScriptStruct Killstreak.AppliedApparelKey
// Size: 0x04 (Inherited: 0x00)
struct FAppliedApparelKey {
	int32_t ID; // 0x00(0x04)
};

// ScriptStruct Killstreak.ReactiveWrapSFXParam
// Size: 0x30 (Inherited: 0x00)
struct FReactiveWrapSFXParam {
	struct UAkAudioEvent* AKAudioEventToPlay; // 0x00(0x08)
	struct UAkAudioEvent* AKAudioStopEvent; // 0x08(0x08)
	struct FName RTPCNameToModify; // 0x10(0x08)
	bool UpdateValuesOnTrigger; // 0x18(0x01)
	bool UpdateValuesOnInterpolate; // 0x19(0x01)
	bool UpdateValuesOnMaximumReached; // 0x1a(0x01)
	bool UpdateValuesOnResetStarted; // 0x1b(0x01)
	float InitilizedRTPCFloatValue; // 0x1c(0x04)
	float InterpolateSpeedBuildUp; // 0x20(0x04)
	float InterpolateSpeedCoolDown; // 0x24(0x04)
	bool SFXLocalOnly; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct Killstreak.ReactiveWrapVFXFloatParam
// Size: 0x30 (Inherited: 0x00)
struct FReactiveWrapVFXFloatParam {
	struct UParticleSystem* VFXParticleSystemToSpawn; // 0x00(0x08)
	struct FName VFXAttachTargetName; // 0x08(0x08)
	struct FName VFXFloatParameterToModify; // 0x10(0x08)
	bool ActivateEmitterOnlyOnTrigger; // 0x18(0x01)
	bool UpdateValuesOnTrigger; // 0x19(0x01)
	bool UpdateValuesOnInterpolate; // 0x1a(0x01)
	bool UpdateValuesOnMaximumReached; // 0x1b(0x01)
	bool UpdateValuesOnResetStarted; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	float InitilizedFloatValue; // 0x20(0x04)
	float InterpolateSpeedBuildUp; // 0x24(0x04)
	float InterpolateSpeedCoolDown; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct Killstreak.ReactiveWrapMaterialVectorParam
// Size: 0x20 (Inherited: 0x00)
struct FReactiveWrapMaterialVectorParam {
	struct FName MaterialVectorParametersToModify; // 0x00(0x08)
	bool UpdateValuesOnTrigger; // 0x08(0x01)
	bool UpdateValuesOnInterpolate; // 0x09(0x01)
	bool UpdateValuesOnMaximumReached; // 0x0a(0x01)
	bool UpdateValuesOnResetStarted; // 0x0b(0x01)
	struct FVector InitilizedVectorValue; // 0x0c(0x0c)
	float InterpolateSpeedBuildUp; // 0x18(0x04)
	float InterpolateSpeedCoolDown; // 0x1c(0x04)
};

// ScriptStruct Killstreak.ReactiveWrapMaterialScalarParam
// Size: 0x18 (Inherited: 0x00)
struct FReactiveWrapMaterialScalarParam {
	struct FName MaterialScalarParametersToModify; // 0x00(0x08)
	bool UpdateValuesOnTrigger; // 0x08(0x01)
	bool UpdateValuesOnInterpolate; // 0x09(0x01)
	bool UpdateValuesOnMaximumReached; // 0x0a(0x01)
	bool UpdateValuesOnResetStarted; // 0x0b(0x01)
	float InitilizedScalarValue; // 0x0c(0x04)
	float InterpolateSpeedBuildUp; // 0x10(0x04)
	float InterpolateSpeedCoolDown; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSAudioEventTableRow
// Size: 0x10 (Inherited: 0x08)
struct FKSAudioEventTableRow : FTableRowBase {
	struct UAkAudioEvent* AkEvent; // 0x08(0x08)
};

// ScriptStruct Killstreak.ArrayAsMapValue
// Size: 0x10 (Inherited: 0x00)
struct FArrayAsMapValue {
	struct TArray<struct FString> StringArray; // 0x00(0x10)
};

// ScriptStruct Killstreak.PlayerCombatInfo
// Size: 0x20 (Inherited: 0x00)
struct FPlayerCombatInfo {
	int32_t PlayerId; // 0x00(0x04)
	int32_t PlayerTeamNum; // 0x04(0x04)
	struct AKSPlayerState* PlayerState; // 0x08(0x08)
	struct AKSPlayerState* PlayerVictim; // 0x10(0x08)
	float TimeLeft; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct Killstreak.KSBotAbilityTableRow
// Size: 0x40 (Inherited: 0x08)
struct FKSBotAbilityTableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSPlayerMod> Ability; // 0x08(0x28)
	struct TArray<struct UKSBTAction*> RequiredActions; // 0x30(0x10)
};

// ScriptStruct Killstreak.KSBotJobConfig
// Size: 0x58 (Inherited: 0x00)
struct FKSBotJobConfig {
	bool bAllowJob; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<struct TSoftObjectPtr<UKSSkinBundle>, int32_t> AllowedAlternateSkins; // 0x08(0x50)
};

// ScriptStruct Killstreak.KSBotEquipmentSkinTableRow
// Size: 0x18 (Inherited: 0x08)
struct FKSBotEquipmentSkinTableRow : FTableRowBase {
	struct FGameplayTag EquipPointTag; // 0x08(0x08)
	struct UDataTable* SkinTable; // 0x10(0x08)
};

// ScriptStruct Killstreak.KSBotCharacterSkinTableRow
// Size: 0x38 (Inherited: 0x08)
struct FKSBotCharacterSkinTableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSJobItem> JobItem; // 0x08(0x28)
	struct UDataTable* SkinTable; // 0x30(0x08)
};

// ScriptStruct Killstreak.KSBotSkinTableRow
// Size: 0x38 (Inherited: 0x08)
struct FKSBotSkinTableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSItem> Skin; // 0x08(0x28)
	int32_t Weight; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct Killstreak.BotSpawnTableRow
// Size: 0x198 (Inherited: 0x08)
struct FBotSpawnTableRow : FTableRowBase {
	struct TSoftClassPtr<UObject> Character; // 0x08(0x28)
	struct TSoftClassPtr<UObject> Controller; // 0x30(0x28)
	struct TSoftObjectPtr<UBehaviorTree> BehaviorTree1; // 0x58(0x28)
	struct UKSBTDifficulty* InitialDifficulty; // 0x80(0x08)
	struct UDataTable* DifficultyTable; // 0x88(0x08)
	bool AllowDynamicDifficulty; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FKSBTDifficultyConfig SpawnDifficultyConfig; // 0x98(0x78)
	struct TArray<struct TSoftObjectPtr<UDataTable>> ItemLoadoutTables; // 0x110(0x10)
	struct UDataTable* ObjectivePriorityTable; // 0x120(0x08)
	struct UDataTable* ItemPriorityTable; // 0x128(0x08)
	struct FGameplayTagQuery AllowedJobQuery; // 0x130(0x48)
	struct UDataTable* AbilityTable; // 0x178(0x08)
	struct UDataTable* RandomCharacterSkinTable; // 0x180(0x08)
	struct UDataTable* RandomEquipmentSkinTable; // 0x188(0x08)
	bool bIsPlayer; // 0x190(0x01)
	bool bUseGameModeInventory; // 0x191(0x01)
	bool bDelayPawnUntilLoadoutComplete; // 0x192(0x01)
	char pad_193[0x5]; // 0x193(0x05)
};

// ScriptStruct Killstreak.KSBTDifficultyConfig
// Size: 0x78 (Inherited: 0x00)
struct FKSBTDifficultyConfig {
	float AccuracyMultiplierStandard; // 0x00(0x04)
	float AccuracyMultiplierThrownMelee; // 0x04(0x04)
	float AccuracyMultiplierThrownGrenade; // 0x08(0x04)
	float AccuracyMultiplierWhenBlinded; // 0x0c(0x04)
	float AccuracyMultiplierWhenCrosshairHidden; // 0x10(0x04)
	float NewTargetAccuracyMultiplier; // 0x14(0x04)
	float NewTargetTime; // 0x18(0x04)
	float SpeedMultiplier; // 0x1c(0x04)
	float AttackDelayClipPercentMin; // 0x20(0x04)
	float AttackDelayClipPercentMax; // 0x24(0x04)
	float AttackDelay; // 0x28(0x04)
	float DamageDealtMultiplier; // 0x2c(0x04)
	float HeadshotDamageDealtMultiplier; // 0x30(0x04)
	float DamageTakenMultiplier; // 0x34(0x04)
	float HeadshotDamageTakenMultiplier; // 0x38(0x04)
	float AimForHeadshotProbability; // 0x3c(0x04)
	float DodgeRollProbability; // 0x40(0x04)
	float StrafeProbability; // 0x44(0x04)
	float ThrowGrenadeProbability; // 0x48(0x04)
	float ThrowMeleeProbability; // 0x4c(0x04)
	float PerceptionStrengthMin; // 0x50(0x04)
	float PerceptionStrengthMax; // 0x54(0x04)
	struct TArray<struct UKSBTAction*> AllowedActions; // 0x58(0x10)
	struct TArray<struct UKSBTAction*> DisallowedActions; // 0x68(0x10)
};

// ScriptStruct Killstreak.KSBTAbilityConditionTableRow
// Size: 0x40 (Inherited: 0x08)
struct FKSBTAbilityConditionTableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSPlayerMod> AbilityItem; // 0x08(0x28)
	struct UKSBTAbilityConditionValidator* AbilityConditionValidator; // 0x30(0x08)
	enum class EAbilityExecutionType AbilityExecutionType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct Killstreak.KSWeightedPerceptionEntry
// Size: 0x188 (Inherited: 0x00)
struct FKSWeightedPerceptionEntry {
	struct TArray<struct UAISense*> SensesToUse; // 0x00(0x10)
	struct FKSPerceptionFilter PerceptionFilter; // 0x10(0x170)
	int32_t WeightPerPerceivedStimuli; // 0x180(0x04)
	bool bWeightTowards; // 0x184(0x01)
	char pad_185[0x3]; // 0x185(0x03)
};

// ScriptStruct Killstreak.KSBTDifficultyTableRow
// Size: 0x98 (Inherited: 0x08)
struct FKSBTDifficultyTableRow : FTableRowBase {
	struct UKSBTDifficulty* Difficulty; // 0x08(0x08)
	struct FKSBTDifficultyConfig DifficultyModifierConfig; // 0x10(0x78)
	struct UDataTable* ObjectivePriorityTable; // 0x88(0x08)
	float BackfillMMRMin; // 0x90(0x04)
	float BackfillMMRMax; // 0x94(0x04)
};

// ScriptStruct Killstreak.KSBTItemPriorityTableRow
// Size: 0x40 (Inherited: 0x08)
struct FKSBTItemPriorityTableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSItem> ItemAsset; // 0x08(0x28)
	float Weight; // 0x30(0x04)
	float ShopPurchaseWeight; // 0x34(0x04)
	float ShopPriorityGroup; // 0x38(0x04)
	float Multiplier; // 0x3c(0x04)
};

// ScriptStruct Killstreak.KSBTObjectivePriorityTableRow
// Size: 0x60 (Inherited: 0x08)
struct FKSBTObjectivePriorityTableRow : FTableRowBase {
	struct UKSBTObjective* Objective; // 0x08(0x08)
	float MinDistance; // 0x10(0x04)
	float MaxDistance; // 0x14(0x04)
	float MaxSecondsElapsed; // 0x18(0x04)
	float MinSecondsElapsed; // 0x1c(0x04)
	float MaxSecondsRemaining; // 0x20(0x04)
	float MinSecondsRemaining; // 0x24(0x04)
	float Priority; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct TSoftObjectPtr<UKSPlayerMod>> RequiredAbilities; // 0x30(0x10)
	struct TArray<struct UKSBTTargetSelector*> ObjectiveValidationArray; // 0x40(0x10)
	struct UDataTable* TargetSelectionTable; // 0x50(0x08)
	struct UDataTable* OverrideDataTable; // 0x58(0x08)
};

// ScriptStruct Killstreak.KSBTTargetSelectionTableRow
// Size: 0x10 (Inherited: 0x08)
struct FKSBTTargetSelectionTableRow : FTableRowBase {
	struct UKSBTTargetSelector* TargetSelector; // 0x08(0x08)
};

// ScriptStruct Killstreak.KSBTWeaponRangeTableRow
// Size: 0x58 (Inherited: 0x08)
struct FKSBTWeaponRangeTableRow : FTableRowBase {
	struct FGameplayTagContainer WeaponTypes; // 0x08(0x20)
	struct TSoftClassPtr<UObject> WeaponClassOverride; // 0x28(0x28)
	float IdealAttackRange; // 0x50(0x04)
	float StartAttackRange; // 0x54(0x04)
};

// ScriptStruct Killstreak.KSDamageRecord
// Size: 0x18 (Inherited: 0x00)
struct FKSDamageRecord {
	struct TArray<struct UKSWeaponAsset*> WeaponsUsed; // 0x00(0x10)
	float TotalRecordedDamage; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSDamageHistory
// Size: 0x10 (Inherited: 0x00)
struct FKSDamageHistory {
	struct AController* DamageInstigator; // 0x00(0x08)
	struct UDamageType* DamageType; // 0x08(0x08)
};

// ScriptStruct Killstreak.KSInputAction
// Size: 0xc0 (Inherited: 0x00)
struct FKSInputAction {
	char pad_0[0xc0]; // 0x00(0xc0)
};

// ScriptStruct Killstreak.KSInputActionMapping
// Size: 0x30 (Inherited: 0x00)
struct FKSInputActionMapping {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct Killstreak.KSShotgunHitChangeList
// Size: 0x88 (Inherited: 0x70)
struct FKSShotgunHitChangeList : FReplicatedLog {
	struct TArray<struct FKSShotgunHitChangeItem> Items; // 0x70(0x10)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct Killstreak.KSShotgunHitChangeItem
// Size: 0x10 (Inherited: 0x01)
struct FKSShotgunHitChangeItem : FReplicatedLogItem {
	struct FCompressedShotgunHitData ShotgunHitData; // 0x00(0x10)
};

// ScriptStruct Killstreak.CompressedShotgunHitData
// Size: 0x10 (Inherited: 0x00)
struct FCompressedShotgunHitData {
	struct UKSWeaponAsset_Shotgun* ShotgunAsset; // 0x00(0x08)
	uint64_t CompressedHitResults; // 0x08(0x08)
};

// ScriptStruct Killstreak.AssistTag
// Size: 0x10 (Inherited: 0x00)
struct FAssistTag {
	float ExpirationTime; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AKSPlayerState* Assistant; // 0x08(0x08)
};

// ScriptStruct Killstreak.VOTableRow
// Size: 0x38 (Inherited: 0x08)
struct FVOTableRow : FTableRowBase {
	struct FGameplayTag VOEvent; // 0x08(0x08)
	struct TSoftObjectPtr<UAkAudioEvent> AudioEvent; // 0x10(0x28)
};

// ScriptStruct Killstreak.KSOutOfBoundsInfo
// Size: 0x08 (Inherited: 0x00)
struct FKSOutOfBoundsInfo {
	bool bOutOfBounds; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float WarningLength; // 0x04(0x04)
};

// ScriptStruct Killstreak.SmoothedComponentInfo
// Size: 0x30 (Inherited: 0x00)
struct FSmoothedComponentInfo {
	struct USceneComponent* Component; // 0x00(0x08)
	struct FVector InitialTranslationOffset; // 0x08(0x0c)
	char pad_14[0xc]; // 0x14(0x0c)
	struct FQuat InitialRotationOffset; // 0x20(0x10)
};

// ScriptStruct Killstreak.ReviveInfo
// Size: 0x30 (Inherited: 0x00)
struct FReviveInfo {
	bool bIsBeingRevived; // 0x00(0x01)
	bool bRemoteRevive; // 0x01(0x01)
	bool bSelectedToRevive; // 0x02(0x01)
	bool bReviveGuaranteed; // 0x03(0x01)
	char pad_4[0x4]; // 0x04(0x04)
	struct AKSPlayerState* Reviver; // 0x08(0x08)
	struct AKSCharacter* ReviverCharacter; // 0x10(0x08)
	struct FName ReviveeOverrideMontage; // 0x18(0x08)
	float ReviveProgress; // 0x20(0x04)
	float ReviveRate; // 0x24(0x04)
	float LocalReviveProgress; // 0x28(0x04)
	char RequestID; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct Killstreak.KSPendingWeaponStateUpdates
// Size: 0x0c (Inherited: 0x00)
struct FKSPendingWeaponStateUpdates {
	uint32_t BroadcastId; // 0x00(0x04)
	uint16_t nEquipmentId; // 0x04(0x02)
	struct FKSWeaponDataUpdateContainer UpdateData; // 0x06(0x04)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct Killstreak.KSWeaponDataUpdateContainer
// Size: 0x04 (Inherited: 0x00)
struct FKSWeaponDataUpdateContainer {
	bool bChangeWeaponState; // 0x00(0x01)
	enum class EWeaponStateNew WeaponState; // 0x01(0x01)
	bool bChangeAimMode; // 0x02(0x01)
	enum class EKSCharacterAimMode AimMode; // 0x03(0x01)
};

// ScriptStruct Killstreak.KSInitialAmmo
// Size: 0x08 (Inherited: 0x00)
struct FKSInitialAmmo {
	enum class EAmmoType AmmoType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t AmmoCount; // 0x04(0x04)
};

// ScriptStruct Killstreak.KSLootLockerItem
// Size: 0x20 (Inherited: 0x00)
struct FKSLootLockerItem {
	struct UKSWeaponAsset* WeaponAsset; // 0x00(0x08)
	struct UKSWeaponAttachment* Attachment1; // 0x08(0x08)
	struct UKSWeaponAttachment* Attachment2; // 0x10(0x08)
	struct UKSWeaponAttachment* Attachment3; // 0x18(0x08)
};

// ScriptStruct Killstreak.HitReaction
// Size: 0x14 (Inherited: 0x00)
struct FHitReaction {
	struct FVector WorldHitDirection; // 0x00(0x0c)
	float Damage; // 0x0c(0x04)
	float HitTime; // 0x10(0x04)
};

// ScriptStruct Killstreak.FloatHitSpringState
// Size: 0x08 (Inherited: 0x00)
struct FFloatHitSpringState {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Killstreak.KSCharacterSocketInfo
// Size: 0x70 (Inherited: 0x00)
struct FKSCharacterSocketInfo {
	struct FName SocketName; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform RelativeTM; // 0x10(0x30)
	struct UKSCharacterSocketComponent* SocketComponent; // 0x40(0x08)
	struct USceneComponent* ParentComponent; // 0x48(0x08)
	struct FName ParentSocketName; // 0x50(0x08)
	enum class EKSSocketCrouchHandling CrouchHandlingType; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FVector AdditiveCrouchOffset; // 0x5c(0x0c)
	char pad_68[0x8]; // 0x68(0x08)
};

// ScriptStruct Killstreak.KSPowerSlideInfo
// Size: 0x02 (Inherited: 0x00)
struct FKSPowerSlideInfo {
	bool bIsInPowerSlide; // 0x00(0x01)
	enum class EKSPowerSlideEndReason EndReason; // 0x01(0x01)
};

// ScriptStruct Killstreak.KSLungeInfo
// Size: 0x10 (Inherited: 0x00)
struct FKSLungeInfo {
	struct AActor* LungeTarget; // 0x00(0x08)
	float MaxLungeDistance; // 0x08(0x04)
	float MaxLungeDuration; // 0x0c(0x04)
};

// ScriptStruct Killstreak.KSZipLineInfo
// Size: 0x10 (Inherited: 0x00)
struct FKSZipLineInfo {
	struct AKSZipLine* Zipline; // 0x00(0x08)
	bool bZipLineReverse; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct Killstreak.KSMantleInfo
// Size: 0x44 (Inherited: 0x00)
struct FKSMantleInfo {
	bool bIsMantling; // 0x00(0x01)
	bool bVaultingOver; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	float ApproachDist; // 0x04(0x04)
	float MantleHeight; // 0x08(0x04)
	float ForwardDist; // 0x0c(0x04)
	float VaultDrop; // 0x10(0x04)
	float MantleUpDuration; // 0x14(0x04)
	float VaultAcrossDuration; // 0x18(0x04)
	float VaultDownDuration; // 0x1c(0x04)
	struct FName MantleName; // 0x20(0x08)
	struct FVector WorldSpaceGrabLocation; // 0x28(0x0c)
	struct FVector WorldTowardsWallDir; // 0x34(0x0c)
	bool bFromStanding; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
};

// ScriptStruct Killstreak.KSDeathInfo
// Size: 0x28 (Inherited: 0x00)
struct FKSDeathInfo {
	enum class EKSDeathState DeathState; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UDamageType* DamageType; // 0x08(0x08)
	struct FVector DamageDirection; // 0x10(0x0c)
	float FinalBlowDamage; // 0x1c(0x04)
	bool bImmediateRagdoll; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct Killstreak.ChildBodyCollisionProfileCache
// Size: 0x0c (Inherited: 0x00)
struct FChildBodyCollisionProfileCache {
	int32_t BodyIndex; // 0x00(0x04)
	struct FName CollisionProfileName; // 0x04(0x08)
};

// ScriptStruct Killstreak.KSChildPhysicsAssetKeywords
// Size: 0x18 (Inherited: 0x00)
struct FKSChildPhysicsAssetKeywords {
	struct FName AssetKeyword; // 0x00(0x08)
	struct FName CollisionProfileKeyword; // 0x08(0x08)
	struct FName SimulatePhysicsKeyword; // 0x10(0x08)
};

// ScriptStruct Killstreak.CharacterRestoreOptions
// Size: 0x08 (Inherited: 0x00)
struct FCharacterRestoreOptions {
	bool bReplaceAmmo; // 0x00(0x01)
	bool bReplaceInventory; // 0x01(0x01)
	bool bReplaceHealth; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	float MinimumStartingHealthPercentage; // 0x04(0x04)
};

// ScriptStruct Killstreak.ItemTableElement
// Size: 0x30 (Inherited: 0x08)
struct FItemTableElement : FTableRowBase {
	struct TSoftObjectPtr<UKSItem> Item; // 0x08(0x28)
};

// ScriptStruct Killstreak.CharacterArray
// Size: 0x50 (Inherited: 0x00)
struct FCharacterArray {
	struct TArray<struct FVector> Positions; // 0x00(0x10)
	struct TArray<struct FCombatEvent> CombatEvents; // 0x10(0x10)
	struct TArray<struct Frevive> Revives; // 0x20(0x10)
	struct TArray<struct Fassist> Assists; // 0x30(0x10)
	struct TArray<struct Fadvcombat> AdvCombats; // 0x40(0x10)
};

// ScriptStruct Killstreak.advcombat
// Size: 0x0c (Inherited: 0x00)
struct Fadvcombat {
	struct FVector Location; // 0x00(0x0c)
};

// ScriptStruct Killstreak.assist
// Size: 0x0c (Inherited: 0x00)
struct Fassist {
	struct FVector Location; // 0x00(0x0c)
};

// ScriptStruct Killstreak.revive
// Size: 0x0c (Inherited: 0x00)
struct Frevive {
	struct FVector Location; // 0x00(0x0c)
};

// ScriptStruct Killstreak.CombatEvent
// Size: 0x14 (Inherited: 0x00)
struct FCombatEvent {
	struct FVector Location; // 0x00(0x0c)
	bool Fatal; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float Damage; // 0x10(0x04)
};

// ScriptStruct Killstreak.KSControlPointSettings
// Size: 0x30 (Inherited: 0x00)
struct FKSControlPointSettings {
	float BaseControlPointCaptureTime; // 0x00(0x04)
	float BaseControlPointRecaptureTime; // 0x04(0x04)
	float CaptureRatePercentIncreasePerPlayer; // 0x08(0x04)
	float FullCaptureDecayTime; // 0x0c(0x04)
	float ScoreUpdatePeriod; // 0x10(0x04)
	float SuddenDeathScoreUpdatePeriod; // 0x14(0x04)
	bool bPlayerMustBePresentToKeep; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<int32_t> AcceptedTeamNums; // 0x20(0x10)
};

// ScriptStruct Killstreak.CurrencyImageRow
// Size: 0xb0 (Inherited: 0x08)
struct FCurrencyImageRow : FTableRowBase {
	int32_t Quantity; // 0x08(0x04)
	int32_t BonusQuantity; // 0x0c(0x04)
	struct TSoftObjectPtr<UTexture2D> Image; // 0x10(0x28)
	struct TSoftObjectPtr<UTexture2D> FullSplashImage; // 0x38(0x28)
	struct TMap<enum class EExternalSkuSource, struct FString> ExternalProductSkus; // 0x60(0x50)
};

// ScriptStruct Killstreak.KSDamageEventInfo
// Size: 0x20 (Inherited: 0x00)
struct FKSDamageEventInfo {
	struct UDamageType* DamageTypeClass; // 0x00(0x08)
	int32_t DamageClassId; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FHitResult> HitResults; // 0x10(0x10)
};

// ScriptStruct Killstreak.KSFlashBangRecord
// Size: 0x18 (Inherited: 0x00)
struct FKSFlashBangRecord {
	enum class EFlashBangIntensity FlashBangIntensity; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UCurveFloat* IntensityCurve; // 0x08(0x08)
	float TimeElapsed; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSRandomDropEntry
// Size: 0x18 (Inherited: 0x00)
struct FKSRandomDropEntry {
	struct UDataTable* RandomDropTable; // 0x00(0x08)
	struct TArray<int32_t> SidesToDropItems; // 0x08(0x10)
};

// ScriptStruct Killstreak.KSRandomDropRow
// Size: 0x18 (Inherited: 0x08)
struct FKSRandomDropRow : FTableRowBase {
	struct UKSItem* DropAsset; // 0x08(0x08)
	float DropChance; // 0x10(0x04)
	enum class EDropPickupConfig DropPickupConfig; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct Killstreak.WeaponTypeToAntiCheatId
// Size: 0x0c (Inherited: 0x00)
struct FWeaponTypeToAntiCheatId {
	struct FGameplayTag WeaponType; // 0x00(0x08)
	uint16_t AntiCheatId; // 0x08(0x02)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct Killstreak.KSEmoteInterruptTickFunction
// Size: 0x30 (Inherited: 0x28)
struct FKSEmoteInterruptTickFunction : FTickFunction {
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct Killstreak.KSEmoteConversionEntry
// Size: 0x0c (Inherited: 0x00)
struct FKSEmoteConversionEntry {
	struct FName EmotionName; // 0x00(0x08)
	enum class EKSEmotion EmotionEnum; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct Killstreak.EncounterManagedBotInstance
// Size: 0x48 (Inherited: 0x00)
struct FEncounterManagedBotInstance {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct Killstreak.KSEquipmentCommonDummyStruct
// Size: 0x01 (Inherited: 0x00)
struct FKSEquipmentCommonDummyStruct {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct Killstreak.KSEquipmentContainer
// Size: 0x228 (Inherited: 0x108)
struct FKSEquipmentContainer : FFastArraySerializer {
	struct AActor* Owner; // 0x108(0x08)
	struct TScriptInterface<IKSEquipmentContainerOwner> OwnerAsEquipmentContainerOwner; // 0x110(0x10)
	struct TMap<struct FKSEquipmentId, struct FKSEquipmentContainerEntry> PendingEquipment; // 0x120(0x50)
	struct TArray<struct FKSEquipmentContainerEntry> Equipment; // 0x170(0x10)
	struct TArray<struct FKSEquipmentContainerEntry> PropEquipment; // 0x180(0x10)
	uint16_t NextEquipmentId; // 0x190(0x02)
	uint16_t NextPropId; // 0x192(0x02)
	char pad_194[0x4]; // 0x194(0x04)
	struct TArray<struct FKSEquipmentContainerEntry> StaleEquipment; // 0x198(0x10)
	char pad_1A8[0x80]; // 0x1a8(0x80)
};

// ScriptStruct Killstreak.KSEquipmentContainerEntry
// Size: 0xb8 (Inherited: 0x0c)
struct FKSEquipmentContainerEntry : FFastArraySerializerItem {
	uint16_t EquipmentId; // 0x0c(0x02)
	char pad_E[0x2]; // 0x0e(0x02)
	uint16_t ParentEquipmentId; // 0x10(0x02)
	char pad_12[0x2]; // 0x12(0x02)
	struct FGameplayTag EquipPoint; // 0x14(0x08)
	char pad_1C[0x8]; // 0x1c(0x08)
	bool bAlwaysReplicateExtraInfo; // 0x24(0x01)
	char pad_25[0x1]; // 0x25(0x01)
	uint16_t ExtraInfo; // 0x26(0x02)
	char pad_28[0x8]; // 0x28(0x08)
	struct UKSItem* Item; // 0x30(0x08)
	struct UKSItem* LocalItem; // 0x38(0x08)
	bool bWeaponComponentIsReplicated; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	struct TWeakObjectPtr<struct UKSEquipmentCosmeticComponent> CosmeticComponent; // 0x44(0x08)
	struct TWeakObjectPtr<struct UKSWeaponAttachmentCosmeticInst> AttachmentCosmeticComponent; // 0x4c(0x08)
	bool bMarkedStale; // 0x54(0x01)
	char pad_55[0x3b]; // 0x55(0x3b)
	struct TSoftObjectPtr<UKSItem> ParentAsset; // 0x90(0x28)
};

// ScriptStruct Killstreak.KSEquipmentId
// Size: 0x04 (Inherited: 0x00)
struct FKSEquipmentId {
	enum class EKSEquipmentType Type; // 0x00(0x01)
	char pad_1[0x1]; // 0x01(0x01)
	uint16_t EquipmentIdNumber; // 0x02(0x02)
};

// ScriptStruct Killstreak.GrandPrizeProgression
// Size: 0x0c (Inherited: 0x00)
struct FGrandPrizeProgression {
	int32_t CurrentProgression; // 0x00(0x04)
	int32_t EndingProgression; // 0x04(0x04)
	bool IsUnlocked; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct Killstreak.KSExperimentConfig
// Size: 0x18 (Inherited: 0x00)
struct FKSExperimentConfig {
	struct FString Name; // 0x00(0x10)
	bool Value; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct Killstreak.KSFreezeFramePropBase
// Size: 0x80 (Inherited: 0x00)
struct FKSFreezeFramePropBase {
	struct FName AttachPoint; // 0x00(0x08)
	struct FVector LocationOffset; // 0x08(0x0c)
	struct FRotator Rotation; // 0x14(0x0c)
	struct FVector Scale; // 0x20(0x0c)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct UAnimationAsset* PropAnimation; // 0x30(0x08)
	bool bUseParentAnimationStartTime; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float PropAnimationStartTime; // 0x3c(0x04)
	struct FKSFreezeFrameVFXEntry VFXEntry; // 0x40(0x30)
	struct FGuid propId; // 0x70(0x10)
};

// ScriptStruct Killstreak.KSFreezeFrameVFXEntry
// Size: 0x30 (Inherited: 0x00)
struct FKSFreezeFrameVFXEntry {
	struct UParticleSystem* VFX; // 0x00(0x08)
	struct FName AttachPoint; // 0x08(0x08)
	struct FVector Offset; // 0x10(0x0c)
	float TimeDilation; // 0x1c(0x04)
	struct FGuid VFXID; // 0x20(0x10)
};

// ScriptStruct Killstreak.KSFreezeFramePawnWeaponProp
// Size: 0x90 (Inherited: 0x80)
struct FKSFreezeFramePawnWeaponProp : FKSFreezeFramePropBase {
	struct UDataTable* MeshDataTable; // 0x80(0x08)
	struct UDataTable* WrapDataTable; // 0x88(0x08)
};

// ScriptStruct Killstreak.KSFreezeFramePawnProp
// Size: 0x88 (Inherited: 0x80)
struct FKSFreezeFramePawnProp : FKSFreezeFramePropBase {
	struct UStreamableRenderAsset* Mesh; // 0x80(0x08)
};

// ScriptStruct Killstreak.KSGameHUDSettings
// Size: 0x18 (Inherited: 0x00)
struct FKSGameHUDSettings {
	bool ShouldShowEnemyCaptureProgress; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UUserWidget* GameModeWidget; // 0x08(0x08)
	bool ShowRoundEndResults; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct Killstreak.LoadingScreenImageRow
// Size: 0x90 (Inherited: 0x08)
struct FLoadingScreenImageRow : FTableRowBase {
	struct FSoftObjectPath Map; // 0x08(0x18)
	struct TSoftObjectPtr<UTexture2D> LoadingScreenImage; // 0x20(0x28)
	struct FText MapDisplayName; // 0x48(0x18)
	struct FText MapRegion; // 0x60(0x18)
	struct FText MapDescription; // 0x78(0x18)
};

// ScriptStruct Killstreak.LoadingScreenTipTextRow
// Size: 0x28 (Inherited: 0x08)
struct FLoadingScreenTipTextRow : FTableRowBase {
	struct FText TipText; // 0x08(0x18)
	bool IsStaticTip; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct Killstreak.KSSeamlessTravelSettings
// Size: 0x10 (Inherited: 0x00)
struct FKSSeamlessTravelSettings {
	bool bRestoreLoadouts; // 0x00(0x01)
	bool bSkipDestinationDefaultInventory; // 0x01(0x01)
	bool bRestoreCharacterState; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	struct FCharacterRestoreOptions CharacterStateRestoreOptions; // 0x04(0x08)
	bool bCanReuseControllers; // 0x0c(0x01)
	bool bRestoreBotDataPlayerStates; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct Killstreak.KSEventAssistants
// Size: 0x10 (Inherited: 0x00)
struct FKSEventAssistants {
	struct TArray<struct APlayerState*> Assistants; // 0x00(0x10)
};

// ScriptStruct Killstreak.KSPlayerProfile
// Size: 0x28 (Inherited: 0x20)
struct FKSPlayerProfile : FPGame_PlayerProfile {
	int32_t TeamNumber; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct Killstreak.KSLootRaritySwapInfo
// Size: 0x0c (Inherited: 0x00)
struct FKSLootRaritySwapInfo {
	float Chance; // 0x00(0x04)
	int32_t Amount; // 0x04(0x04)
	enum class ELootSiteRarity OldRarity; // 0x08(0x01)
	enum class ELootSiteRarity NewRarity; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct Killstreak.KSLootGroupGuaranteeMap
// Size: 0x58 (Inherited: 0x00)
struct FKSLootGroupGuaranteeMap {
	int32_t TotalLootSitesActive; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TMap<char, struct FKSLootGroupGuarantee> GuaranteeMap; // 0x08(0x50)
};

// ScriptStruct Killstreak.KSLootGroupGuarantee
// Size: 0x18 (Inherited: 0x00)
struct FKSLootGroupGuarantee {
	int32_t Quantity; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<int32_t> ObjectiveLootGroups; // 0x08(0x10)
};

// ScriptStruct Killstreak.KSTimerPriorityConfig
// Size: 0x03 (Inherited: 0x00)
struct FKSTimerPriorityConfig {
	enum class EKSPriority RoundTimerPriority; // 0x00(0x01)
	enum class EKSPriority PhaseTimerPriority; // 0x01(0x01)
	enum class EKSPriority ObjectiveTimerPriority; // 0x02(0x01)
};

// ScriptStruct Killstreak.KSPlayerIdentitiesContainer
// Size: 0x120 (Inherited: 0x108)
struct FKSPlayerIdentitiesContainer : FFastArraySerializer {
	struct TArray<struct FKSPlayerIdentityData> ReplicatedData; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct Killstreak.KSPlayerIdentityData
// Size: 0xe8 (Inherited: 0x0c)
struct FKSPlayerIdentityData : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FKSPersistentPlayerId ID; // 0x10(0x10)
	struct TSoftObjectPtr<UKSItem> avatar; // 0x20(0x28)
	struct TSoftObjectPtr<UKSItem> Banner; // 0x48(0x28)
	struct TSoftObjectPtr<UKSItem> PreferredJob; // 0x70(0x28)
	struct TSoftObjectPtr<UKSItem> Border; // 0x98(0x28)
	struct TSoftObjectPtr<UKSItem> Title; // 0xc0(0x28)
};

// ScriptStruct Killstreak.QueuedCinematicInfo
// Size: 0x28 (Inherited: 0x00)
struct FQueuedCinematicInfo {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct Killstreak.KSLootRarityTimerPair
// Size: 0x10 (Inherited: 0x00)
struct FKSLootRarityTimerPair {
	enum class ELootSiteRarity Rarity; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UKSTimerComponent* Timer; // 0x08(0x08)
};

// ScriptStruct Killstreak.AssistEventList
// Size: 0x88 (Inherited: 0x70)
struct FAssistEventList : FSizedArraySerializer {
	struct TArray<struct FAssistEventItem> Items; // 0x70(0x10)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct Killstreak.AssistEventItem
// Size: 0x28 (Inherited: 0x01)
struct FAssistEventItem : FReplicatedLogItem {
	struct FAssistInfo AssistInfo; // 0x00(0x28)
};

// ScriptStruct Killstreak.RadialMenuItemEventList
// Size: 0x88 (Inherited: 0x70)
struct FRadialMenuItemEventList : FSizedArraySerializer {
	struct TArray<struct FRadialMenuItemEventItem> Items; // 0x70(0x10)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct Killstreak.RadialMenuItemEventItem
// Size: 0x10 (Inherited: 0x01)
struct FRadialMenuItemEventItem : FReplicatedLogItem {
	struct FRadialMenuItemEventInfo RadialMenuItemEvent; // 0x00(0x10)
};

// ScriptStruct Killstreak.CombatEventList
// Size: 0x88 (Inherited: 0x70)
struct FCombatEventList : FSizedArraySerializer {
	struct TArray<struct FCombatEventItem> Items; // 0x70(0x10)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct Killstreak.CombatEventItem
// Size: 0x60 (Inherited: 0x01)
struct FCombatEventItem : FReplicatedLogItem {
	struct FCombatEventInfo CombatEvent; // 0x00(0x60)
};

// ScriptStruct Killstreak.ReviveEventList
// Size: 0x88 (Inherited: 0x70)
struct FReviveEventList : FSizedArraySerializer {
	struct TArray<struct FReviveEventItem> Items; // 0x70(0x10)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct Killstreak.ReviveEventItem
// Size: 0x14 (Inherited: 0x01)
struct FReviveEventItem : FReplicatedLogItem {
	struct FReviveEvent ReviveEvent; // 0x00(0x14)
};

// ScriptStruct Killstreak.ReviveEvent
// Size: 0x14 (Inherited: 0x00)
struct FReviveEvent {
	struct TWeakObjectPtr<struct AKSPlayerState> Reviver; // 0x00(0x08)
	struct TWeakObjectPtr<struct AKSPlayerState> Revivee; // 0x08(0x08)
	int32_t ExpBonus; // 0x10(0x04)
};

// ScriptStruct Killstreak.InitialGameObjectiveInfo
// Size: 0x60 (Inherited: 0x00)
struct FInitialGameObjectiveInfo {
	int32_t ID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AActor* ObjectiveAsActor; // 0x08(0x08)
	struct FKSObjectiveState ObjectiveState; // 0x10(0x28)
	struct FKSObjectiveState PreviousObjectiveState; // 0x38(0x28)
};

// ScriptStruct Killstreak.KSObjectiveState
// Size: 0x28 (Inherited: 0x00)
struct FKSObjectiveState {
	enum class EKSObjectiveState State; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Team; // 0x04(0x04)
	struct AKSPlayerState* Holder; // 0x08(0x08)
	struct TScriptInterface<IKSPointOfInterest> PointOfInterest; // 0x10(0x10)
	struct UObject* POI; // 0x20(0x08)
};

// ScriptStruct Killstreak.ReplicatedRoundInfo
// Size: 0x10 (Inherited: 0x00)
struct FReplicatedRoundInfo {
	struct FMatchPhase RoundState; // 0x00(0x0c)
	char RoundNumber; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct Killstreak.PlayerHealthMeterState
// Size: 0x18 (Inherited: 0x00)
struct FPlayerHealthMeterState {
	int32_t HealthValue; // 0x00(0x04)
	int32_t MaxHealth; // 0x04(0x04)
	int32_t MaxHealthBonus; // 0x08(0x04)
	int32_t ArmorValue; // 0x0c(0x04)
	int32_t OverhealValue; // 0x10(0x04)
	bool IsDowned; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct Killstreak.KSWidgetInfoParams
// Size: 0x48 (Inherited: 0x00)
struct FKSWidgetInfoParams {
	struct TSoftClassPtr<UObject> Widget; // 0x00(0x28)
	bool bPreloadWidget; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString WidgetParentTarget; // 0x30(0x10)
	struct AKSWidgetInfoActor* InfoActor; // 0x40(0x08)
};

// ScriptStruct Killstreak.KSInteractionBlocker
// Size: 0x08 (Inherited: 0x00)
struct FKSInteractionBlocker {
	struct FName BlockReason; // 0x00(0x08)
};

// ScriptStruct Killstreak.KSInteractableCameraTransition
// Size: 0x30 (Inherited: 0x00)
struct FKSInteractableCameraTransition {
	struct FName CameraName; // 0x00(0x08)
	float TransitionInTime; // 0x08(0x04)
	enum class EViewTargetBlendFunction TransitionInFunction; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float TransitionInExp; // 0x10(0x04)
	float TransitionOutTime; // 0x14(0x04)
	bool bForceCameraShoulder; // 0x18(0x01)
	enum class ECameraShoulder CameraShoulder; // 0x19(0x01)
	char pad_1A[0x2]; // 0x1a(0x02)
	float RotationLockAngle; // 0x1c(0x04)
	bool RotationLockout; // 0x20(0x01)
	bool bLockPitch; // 0x21(0x01)
	bool bLockYaw; // 0x22(0x01)
	bool bCameraShake; // 0x23(0x01)
	char pad_24[0x4]; // 0x24(0x04)
	struct UCameraShake* CameraShake; // 0x28(0x08)
};

// ScriptStruct Killstreak.SkinnableAudioEvent
// Size: 0x10 (Inherited: 0x00)
struct FSkinnableAudioEvent {
	struct FName SoundRowName; // 0x00(0x08)
	struct UAkAudioEvent* DefaultSound; // 0x08(0x08)
};

// ScriptStruct Killstreak.ItemDisplayStat
// Size: 0x38 (Inherited: 0x00)
struct FItemDisplayStat {
	struct FText DisplayText; // 0x00(0x18)
	float Value; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FItemDisplayStatParams StatProperties; // 0x20(0x18)
};

// ScriptStruct Killstreak.ItemDisplayStatParams
// Size: 0x18 (Inherited: 0x08)
struct FItemDisplayStatParams : FTableRowBase {
	float RangeMin; // 0x08(0x04)
	float RangeMax; // 0x0c(0x04)
	bool ShowsBar; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct Killstreak.KSItemMasterTableRow
// Size: 0x48 (Inherited: 0x08)
struct FKSItemMasterTableRow : FTableRowBase {
	struct FString ItemDisplayName; // 0x08(0x10)
	int32_t ItemId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TSoftObjectPtr<UKSItem> KSItemSoftObject; // 0x20(0x28)
};

// ScriptStruct Killstreak.KSJobEquipmentTypesToGive
// Size: 0x0d (Inherited: 0x00)
struct FKSJobEquipmentTypesToGive {
	bool bPrimaryWeaponOptionOne; // 0x00(0x01)
	bool bPrimaryWeaponOptionTwo; // 0x01(0x01)
	bool bSecondaryWeaponOptionOne; // 0x02(0x01)
	bool bSecondaryWeaponOptionTwo; // 0x03(0x01)
	bool bMeleeWeapon; // 0x04(0x01)
	bool bGadgetOptionOne; // 0x05(0x01)
	bool bGadgetOptionTwo; // 0x06(0x01)
	bool bPerkOptionOne; // 0x07(0x01)
	bool bPerkOptionTwo; // 0x08(0x01)
	bool bPerkOptionThree; // 0x09(0x01)
	bool bPerkOptionFour; // 0x0a(0x01)
	bool bPerkOptionFive; // 0x0b(0x01)
	bool bPerkOptionSix; // 0x0c(0x01)
};

// ScriptStruct Killstreak.KSJobSelectionAllowUnownedJobs
// Size: 0x20 (Inherited: 0x00)
struct FKSJobSelectionAllowUnownedJobs {
	enum class EAllowUnownedJobsState AllowUnownedJobsState; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<int32_t> AllowedUnownedJobIds; // 0x08(0x10)
	bool IsInitializationFinished; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct Killstreak.JobSelectionList
// Size: 0x120 (Inherited: 0x108)
struct FJobSelectionList : FFastArraySerializer {
	struct TArray<struct FJobSelectionEntry> EntryMap; // 0x108(0x10)
	struct UKSJobSelectionComponent* Owner; // 0x118(0x08)
};

// ScriptStruct Killstreak.SelectionActivityStatus
// Size: 0x50 (Inherited: 0x00)
struct FSelectionActivityStatus {
	char pad_0[0x30]; // 0x00(0x30)
	enum class ESelectionActivityState SelectionState; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct AKSPlayerState*> CurrentlySelectingPlayers; // 0x38(0x10)
	int32_t NumBansOccurred; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct Killstreak.JobSelectDraftingTask
// Size: 0x10 (Inherited: 0x00)
struct FJobSelectDraftingTask {
	enum class EJobSelectDraftingTaskType TaskyType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t TeamNum; // 0x04(0x04)
	float TimeLimit; // 0x08(0x04)
	bool bHalting; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct Killstreak.JobSelectionChoice
// Size: 0x10 (Inherited: 0x00)
struct FJobSelectionChoice {
	struct UKSJobItem* Job; // 0x00(0x08)
	char bIsVisibleToUI : 1; // 0x08(0x01)
	char bIsUnavailable : 1; // 0x08(0x01)
	char bIsUnavailableByOwnership : 1; // 0x08(0x01)
	char bIsBanned : 1; // 0x08(0x01)
	char bAlreadyPicked : 1; // 0x08(0x01)
	char bAlreadyLocked : 1; // 0x08(0x01)
	char bCannotLock : 1; // 0x08(0x01)
	char bSelectedByTeammate : 1; // 0x08(0x01)
	char bSelectedByOpponent : 1; // 0x09(0x01)
	char bSelectedBySelf : 1; // 0x09(0x01)
	char bPendingCompleteBySelf : 1; // 0x09(0x01)
	char bPickedByLocalTeam : 1; // 0x09(0x01)
	char bPickedByOpponent : 1; // 0x09(0x01)
	char bLockedByLocalPlayer : 1; // 0x09(0x01)
	char pad_9_6 : 2; // 0x09(0x01)
	enum class EJobOwnershipState OwnershipState; // 0x0a(0x01)
	char pad_B[0x5]; // 0x0b(0x05)
};

// ScriptStruct Killstreak.JobSelectionTaskList
// Size: 0x130 (Inherited: 0x108)
struct FJobSelectionTaskList : FFastArraySerializer {
	struct TArray<struct FJobSelectionTask> Tasks; // 0x108(0x10)
	char pad_118[0x18]; // 0x118(0x18)
};

// ScriptStruct Killstreak.PreviewActorPropSkinInfo
// Size: 0x48 (Inherited: 0x00)
struct FPreviewActorPropSkinInfo {
	struct UKSItem* Prop; // 0x00(0x08)
	bool bIsSet; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UKSItem* LastSetSkin; // 0x10(0x08)
	struct UKSItem* ActiveSkin; // 0x18(0x08)
	char pad_20[0x10]; // 0x20(0x10)
	struct UKSItem* PendingSkin; // 0x30(0x08)
	char pad_38[0x10]; // 0x38(0x10)
};

// ScriptStruct Killstreak.WeaponWrapTestPairs
// Size: 0x30 (Inherited: 0x00)
struct FWeaponWrapTestPairs {
	struct FSoftObjectPath Weapon; // 0x00(0x18)
	struct FSoftObjectPath Attachment; // 0x18(0x18)
};

// ScriptStruct Killstreak.TrackedPlayers
// Size: 0x18 (Inherited: 0x00)
struct FTrackedPlayers {
	int32_t PlayerId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AKSPlayerState* PlayerState; // 0x08(0x08)
	int32_t KillCount; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.LootSiteTableRow
// Size: 0xb0 (Inherited: 0x08)
struct FLootSiteTableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSItem> Item; // 0x08(0x28)
	struct TSoftObjectPtr<UKSWeaponAttachment> Attachment1; // 0x30(0x28)
	struct TSoftObjectPtr<UKSWeaponAttachment> Attachment2; // 0x58(0x28)
	struct TSoftObjectPtr<UKSWeaponAttachment> Attachment3; // 0x80(0x28)
	float Weight; // 0xa8(0x04)
	float ChanceToSkipAttachment; // 0xac(0x04)
};

// ScriptStruct Killstreak.LootSiteDropInfo
// Size: 0x30 (Inherited: 0x00)
struct FLootSiteDropInfo {
	struct UKSItem* Item; // 0x00(0x08)
	struct UKSWeaponAttachment* Attachment1; // 0x08(0x08)
	struct UKSWeaponAttachment* Attachment2; // 0x10(0x08)
	struct UKSWeaponAttachment* Attachment3; // 0x18(0x08)
	float Weight; // 0x20(0x04)
	int32_t Price; // 0x24(0x04)
	float ChanceToSkipAttachment; // 0x28(0x04)
	bool bRandomizeAttachments; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct Killstreak.MantleConfig
// Size: 0xa8 (Inherited: 0x00)
struct FMantleConfig {
	struct FName MantleSequenceName; // 0x00(0x08)
	struct UAnimSequence* DefaultMantleSequence; // 0x08(0x08)
	enum class EKSMantleScaleType DistanceScaleMethod; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float IdealHeight; // 0x14(0x04)
	float MaxHeight; // 0x18(0x04)
	float DefaultMinHeight; // 0x1c(0x04)
	float ShaveCutoffTime; // 0x20(0x04)
	bool bHasDropSegment; // 0x24(0x01)
	bool bUseOnJump; // 0x25(0x01)
	bool bCanStartWhileFalling; // 0x26(0x01)
	char pad_27[0x1]; // 0x27(0x01)
	float EarlyOutTime; // 0x28(0x04)
	bool bCanEndWithStand; // 0x2c(0x01)
	bool bCanEndWithSlide; // 0x2d(0x01)
	bool bCanEndWithFall; // 0x2e(0x01)
	char pad_2F[0x49]; // 0x2f(0x49)
	struct UAnimSequence* CachedSequence; // 0x78(0x08)
	char pad_80[0x28]; // 0x80(0x28)
};

// ScriptStruct Killstreak.MatchRecord
// Size: 0x198 (Inherited: 0x00)
struct FMatchRecord {
	int32_t version_major; // 0x00(0x04)
	int32_t version_minor; // 0x04(0x04)
	struct FSerializedInstanceId instance_id; // 0x08(0x10)
	int32_t instance_site_id; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FSerializedMatchId match_id; // 0x20(0x10)
	struct FString map_name; // 0x30(0x10)
	struct FString mode_name; // 0x40(0x10)
	int32_t map_game_id; // 0x50(0x04)
	int32_t queue_id; // 0x54(0x04)
	int32_t team_size; // 0x58(0x04)
	int32_t winning_team; // 0x5c(0x04)
	struct FString match_start_time; // 0x60(0x10)
	struct FString match_end_time; // 0x70(0x10)
	int32_t match_fubar_state; // 0x80(0x04)
	int32_t Duration; // 0x84(0x04)
	int32_t total_rounds; // 0x88(0x04)
	int32_t total_players; // 0x8c(0x04)
	int32_t total_bots; // 0x90(0x04)
	int32_t total_earned; // 0x94(0x04)
	int32_t total_spent; // 0x98(0x04)
	int32_t total_refunded; // 0x9c(0x04)
	int32_t total_on_time; // 0xa0(0x04)
	int32_t total_deserters; // 0xa4(0x04)
	int32_t total_deserter_rounds; // 0xa8(0x04)
	int32_t total_surrender_polls; // 0xac(0x04)
	bool ended_in_surrender; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	int32_t total_penalized_players; // 0xb4(0x04)
	struct FMinimapData Minimap; // 0xb8(0x20)
	struct TArray<struct FPlayerRecord> Players; // 0xd8(0x10)
	struct TArray<struct FJobSelectionRecord> job_selection_records; // 0xe8(0x10)
	struct TArray<struct FJobBanRecord> job_ban_records; // 0xf8(0x10)
	struct TMap<int32_t, struct FClientContextRecord> client_context_records; // 0x108(0x50)
	struct TArray<struct FRoundEventRecord> rounds; // 0x158(0x10)
	struct TArray<struct FPlayerConnectionEventRecord> player_connections; // 0x168(0x10)
	struct TArray<struct FBotBackfillEventRecord> bot_backfill; // 0x178(0x10)
	struct TArray<struct FObjectiveCaptureEventRecord> objective_capture_events; // 0x188(0x10)
};

// ScriptStruct Killstreak.ObjectiveCaptureEventRecord
// Size: 0x60 (Inherited: 0x00)
struct FObjectiveCaptureEventRecord {
	int32_t hz_player_id; // 0x00(0x04)
	int32_t ue_player_id; // 0x04(0x04)
	int32_t team_id; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString mode_name; // 0x10(0x10)
	int32_t round_id; // 0x20(0x04)
	int32_t objective_type; // 0x24(0x04)
	struct FString capture_action; // 0x28(0x10)
	struct FLocationRecord Location; // 0x38(0x0c)
	struct FRotationRecord Rotation; // 0x44(0x08)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FString Timestamp; // 0x50(0x10)
};

// ScriptStruct Killstreak.RotationRecord
// Size: 0x08 (Inherited: 0x00)
struct FRotationRecord {
	float Yaw; // 0x00(0x04)
	float Pitch; // 0x04(0x04)
};

// ScriptStruct Killstreak.LocationRecord
// Size: 0x0c (Inherited: 0x00)
struct FLocationRecord {
	float X; // 0x00(0x04)
	float Y; // 0x04(0x04)
	float Z; // 0x08(0x04)
};

// ScriptStruct Killstreak.BotBackfillEventRecord
// Size: 0x20 (Inherited: 0x00)
struct FBotBackfillEventRecord {
	int32_t hz_player_id; // 0x00(0x04)
	int32_t bot_ue_player_id; // 0x04(0x04)
	int32_t round_id; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString Timestamp; // 0x10(0x10)
};

// ScriptStruct Killstreak.PlayerConnectionEventRecord
// Size: 0x20 (Inherited: 0x00)
struct FPlayerConnectionEventRecord {
	int32_t hz_player_id; // 0x00(0x04)
	int32_t ue_player_id; // 0x04(0x04)
	int32_t round_id; // 0x08(0x04)
	int8_t is_connected; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FString Timestamp; // 0x10(0x10)
};

// ScriptStruct Killstreak.RoundEventRecord
// Size: 0x198 (Inherited: 0x00)
struct FRoundEventRecord {
	int32_t round_id; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString round_start_time; // 0x08(0x10)
	int32_t Duration; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FTeamSideRecord> team_sides; // 0x20(0x10)
	int32_t winning_team; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString win_condition; // 0x38(0x10)
	struct TArray<struct FMirrorMatchupRecord> mirror_matchup_records; // 0x48(0x10)
	struct TArray<struct FPlayerStartingCashRecord> round_starting_cash; // 0x58(0x10)
	struct TArray<struct FPurchasedItemEventRecord> purchased_item_events; // 0x68(0x10)
	struct TArray<struct FPurchasedItemEventRecord> refunded_item_events; // 0x78(0x10)
	struct TArray<struct FCashCollectionEventRecord> cash_collection_events; // 0x88(0x10)
	struct TArray<struct FDownEventRecord> down_events; // 0x98(0x10)
	struct TArray<struct FExecuteEventRecord> execute_events; // 0xa8(0x10)
	struct TArray<struct FAssistEventRecord> assist_events; // 0xb8(0x10)
	struct TArray<struct FReviveEventRecord> revive_events; // 0xc8(0x10)
	struct TArray<struct FWeaponUseSummaryRecord> weapon_use_summaries; // 0xd8(0x10)
	struct TArray<struct FAbilityUseEventRecord> ability_use_events; // 0xe8(0x10)
	struct TArray<struct FRadialMenuItemUseEventRecord> radial_menu_item_use_events; // 0xf8(0x10)
	struct TArray<struct FCommunicationUseEventRecord> communication_use_events; // 0x108(0x10)
	struct TArray<struct FGadgetUseEventRecord> gadget_use_events; // 0x118(0x10)
	struct TArray<struct FEliminationStreakEventRecord> elimination_streak_events; // 0x128(0x10)
	struct TArray<struct FMultipleKillEventRecord> multiple_kill_events; // 0x138(0x10)
	struct TArray<struct FBotStartingDifficultyRecord> round_starting_bot_difficulties; // 0x148(0x10)
	struct TArray<struct FBotDifficultyChangeEventRecord> bot_difficulty_change_events; // 0x158(0x10)
	struct TArray<struct FOrientationEventRecord> orientation_events; // 0x168(0x10)
	struct TArray<struct FPollEndEventRecord> poll_end_events; // 0x178(0x10)
	struct TArray<struct FRoundClientInputTypeUse> client_input_use; // 0x188(0x10)
};

// ScriptStruct Killstreak.RoundClientInputTypeUse
// Size: 0x0c (Inherited: 0x00)
struct FRoundClientInputTypeUse {
	int32_t hz_player_id; // 0x00(0x04)
	int16_t input_type_kbm; // 0x04(0x02)
	int16_t input_type_gpad; // 0x06(0x02)
	int16_t input_type_touch; // 0x08(0x02)
	int16_t input_type_other; // 0x0a(0x02)
};

// ScriptStruct Killstreak.PollEndEventRecord
// Size: 0x60 (Inherited: 0x00)
struct FPollEndEventRecord {
	int32_t round_id; // 0x00(0x04)
	bool poll_passed; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FString poll_name; // 0x08(0x10)
	int32_t team_id; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<int32_t> hz_player_ids_for; // 0x20(0x10)
	struct TArray<int32_t> hz_player_ids_against; // 0x30(0x10)
	struct FString game_phase; // 0x40(0x10)
	struct FString Timestamp; // 0x50(0x10)
};

// ScriptStruct Killstreak.OrientationEventRecord
// Size: 0x88 (Inherited: 0x00)
struct FOrientationEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	struct FLocationRecord Location; // 0x04(0x0c)
	struct FRotationRecord Rotation; // 0x10(0x08)
	int32_t movement_state; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString Timestamp; // 0x20(0x10)
	int32_t ping_ms; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TMap<struct FString, struct FClientStatisticsRecord> client_statistics; // 0x38(0x50)
};

// ScriptStruct Killstreak.ClientStatisticsRecord
// Size: 0x14 (Inherited: 0x00)
struct FClientStatisticsRecord {
	float smoothed; // 0x00(0x04)
	float Maximum; // 0x04(0x04)
	float Minimum; // 0x08(0x04)
	float average; // 0x0c(0x04)
	int32_t sample_count; // 0x10(0x04)
};

// ScriptStruct Killstreak.BotDifficultyChangeEventRecord
// Size: 0x18 (Inherited: 0x00)
struct FBotDifficultyChangeEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t difficulty_index; // 0x04(0x04)
	struct FString Timestamp; // 0x08(0x10)
};

// ScriptStruct Killstreak.BotStartingDifficultyRecord
// Size: 0x08 (Inherited: 0x00)
struct FBotStartingDifficultyRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t difficulty_index; // 0x04(0x04)
};

// ScriptStruct Killstreak.MultipleKillEventRecord
// Size: 0x08 (Inherited: 0x00)
struct FMultipleKillEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t Count; // 0x04(0x04)
};

// ScriptStruct Killstreak.EliminationStreakEventRecord
// Size: 0x08 (Inherited: 0x00)
struct FEliminationStreakEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t Count; // 0x04(0x04)
};

// ScriptStruct Killstreak.GadgetUseEventRecord
// Size: 0x50 (Inherited: 0x00)
struct FGadgetUseEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	struct FLocationRecord Location; // 0x04(0x0c)
	int32_t gadget_id; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Timestamp; // 0x18(0x10)
	int32_t accumulated_damage; // 0x28(0x04)
	int32_t accumulated_self_damage; // 0x2c(0x04)
	int32_t accumulated_friendly_damage; // 0x30(0x04)
	int32_t accumulated_reverse_friendly_damage; // 0x34(0x04)
	float AccumulatingDamage; // 0x38(0x04)
	float AccumulatingSelfDamage; // 0x3c(0x04)
	float AccumulatingFriendlyDamage; // 0x40(0x04)
	float AccumulatingReverseFriendlyDamage; // 0x44(0x04)
	float FireGameTime; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct Killstreak.CommunicationUseEventRecord
// Size: 0x70 (Inherited: 0x00)
struct FCommunicationUseEventRecord {
	int32_t hz_player_id; // 0x00(0x04)
	int32_t ue_player_id; // 0x04(0x04)
	int32_t round_id; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString cosmetic_type; // 0x10(0x10)
	int32_t item_id; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString item_name; // 0x28(0x10)
	struct FLocationRecord Location; // 0x38(0x0c)
	struct FRotationRecord Rotation; // 0x44(0x08)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FString game_phase; // 0x50(0x10)
	struct FString Timestamp; // 0x60(0x10)
};

// ScriptStruct Killstreak.RadialMenuItemUseEventRecord
// Size: 0x70 (Inherited: 0x00)
struct FRadialMenuItemUseEventRecord {
	int32_t hz_player_id; // 0x00(0x04)
	int32_t ue_player_id; // 0x04(0x04)
	int32_t round_id; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString cosmetic_type; // 0x10(0x10)
	int32_t item_id; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString item_name; // 0x28(0x10)
	struct FLocationRecord Location; // 0x38(0x0c)
	struct FRotationRecord Rotation; // 0x44(0x08)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FString game_phase; // 0x50(0x10)
	struct FString Timestamp; // 0x60(0x10)
};

// ScriptStruct Killstreak.AbilityUseEventRecord
// Size: 0x50 (Inherited: 0x00)
struct FAbilityUseEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	struct FLocationRecord Location; // 0x04(0x0c)
	int32_t ability_id; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Timestamp; // 0x18(0x10)
	int32_t accumulated_damage; // 0x28(0x04)
	int32_t accumulated_self_damage; // 0x2c(0x04)
	int32_t accumulated_friendly_damage; // 0x30(0x04)
	int32_t accumulated_reverse_friendly_damage; // 0x34(0x04)
	float AccumulatingDamage; // 0x38(0x04)
	float AccumulatingSelfDamage; // 0x3c(0x04)
	float AccumulatingFriendlyDamage; // 0x40(0x04)
	float AccumulatingReverseFriendlyDamage; // 0x44(0x04)
	float FireGameTime; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct Killstreak.WeaponUseSummaryRecord
// Size: 0x34 (Inherited: 0x00)
struct FWeaponUseSummaryRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t weapon_id; // 0x04(0x04)
	int32_t shots_fired; // 0x08(0x04)
	int32_t shots_hit; // 0x0c(0x04)
	int32_t head_shots; // 0x10(0x04)
	int32_t accumulated_damage; // 0x14(0x04)
	int32_t accumulated_self_damage; // 0x18(0x04)
	int32_t accumulated_friendly_damage; // 0x1c(0x04)
	int32_t accumulated_reverse_friendly_damage; // 0x20(0x04)
	float AccumulatingDamage; // 0x24(0x04)
	float AccumulatingSelfDamage; // 0x28(0x04)
	float AccumulatingFriendlyDamage; // 0x2c(0x04)
	float AccumulatingReverseFriendlyDamage; // 0x30(0x04)
};

// ScriptStruct Killstreak.ReviveEventRecord
// Size: 0x30 (Inherited: 0x00)
struct FReviveEventRecord {
	int32_t reviver_ue_player_id; // 0x00(0x04)
	struct FLocationRecord reviver_location; // 0x04(0x0c)
	int32_t revivee_ue_player_id; // 0x10(0x04)
	struct FLocationRecord revivee_location; // 0x14(0x0c)
	struct FString Timestamp; // 0x20(0x10)
};

// ScriptStruct Killstreak.AssistEventRecord
// Size: 0x28 (Inherited: 0x00)
struct FAssistEventRecord {
	int32_t assistor_ue_player_id; // 0x00(0x04)
	int32_t victim_ue_player_id; // 0x04(0x04)
	struct FLocationRecord victim_location; // 0x08(0x0c)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Timestamp; // 0x18(0x10)
};

// ScriptStruct Killstreak.ExecuteEventRecord
// Size: 0x38 (Inherited: 0x00)
struct FExecuteEventRecord {
	int32_t instigator_ue_player_id; // 0x00(0x04)
	struct FLocationRecord instigator_location; // 0x04(0x0c)
	int32_t victim_ue_player_id; // 0x10(0x04)
	struct FLocationRecord victim_location; // 0x14(0x0c)
	int32_t weapon_id; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString Timestamp; // 0x28(0x10)
};

// ScriptStruct Killstreak.DownEventRecord
// Size: 0x38 (Inherited: 0x00)
struct FDownEventRecord {
	int32_t instigator_ue_player_id; // 0x00(0x04)
	struct FLocationRecord instigator_location; // 0x04(0x0c)
	int32_t victim_ue_player_id; // 0x10(0x04)
	struct FLocationRecord victim_location; // 0x14(0x0c)
	int32_t weapon_id; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString Timestamp; // 0x28(0x10)
};

// ScriptStruct Killstreak.CashCollectionEventRecord
// Size: 0x28 (Inherited: 0x00)
struct FCashCollectionEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	struct FLocationRecord Location; // 0x04(0x0c)
	struct FString Timestamp; // 0x10(0x10)
	int32_t Amount; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct Killstreak.PurchasedItemEventRecord
// Size: 0x0c (Inherited: 0x00)
struct FPurchasedItemEventRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t item_id; // 0x04(0x04)
	int32_t cost; // 0x08(0x04)
};

// ScriptStruct Killstreak.PlayerStartingCashRecord
// Size: 0x08 (Inherited: 0x00)
struct FPlayerStartingCashRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t cash; // 0x04(0x04)
};

// ScriptStruct Killstreak.MirrorMatchupRecord
// Size: 0x14 (Inherited: 0x00)
struct FMirrorMatchupRecord {
	int32_t hz_player_id; // 0x00(0x04)
	int32_t ue_player_id; // 0x04(0x04)
	int32_t team_id; // 0x08(0x04)
	int32_t class_id; // 0x0c(0x04)
	int32_t has_mirror_match; // 0x10(0x04)
};

// ScriptStruct Killstreak.TeamSideRecord
// Size: 0x0c (Inherited: 0x00)
struct FTeamSideRecord {
	int32_t team_id; // 0x00(0x04)
	int32_t side_id; // 0x04(0x04)
	int32_t team_role; // 0x08(0x04)
};

// ScriptStruct Killstreak.ClientContextRecord
// Size: 0x178 (Inherited: 0x00)
struct FClientContextRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t hz_player_id; // 0x04(0x04)
	struct FString client_current_language; // 0x08(0x10)
	int32_t client_selected_site_id; // 0x18(0x04)
	int32_t divert_from_queue_id; // 0x1c(0x04)
	int32_t divert_to_queue_id; // 0x20(0x04)
	enum class EQueueDivertType queue_divert_type; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	float sheltered_mm_attempt_timeout; // 0x28(0x04)
	float sheltered_mm_level_limit; // 0x2c(0x04)
	int32_t forced_bot_match_limit; // 0x30(0x04)
	int32_t mercy_match_losses_required; // 0x34(0x04)
	struct TMap<struct FString, struct FString> strings; // 0x38(0x50)
	struct TMap<struct FString, uint64_t> uint64_values; // 0x88(0x50)
	struct TMap<struct FString, float> float_values; // 0xd8(0x50)
	struct TMap<struct FString, int32_t> int32_values; // 0x128(0x50)
};

// ScriptStruct Killstreak.JobBanRecord
// Size: 0x20 (Inherited: 0x00)
struct FJobBanRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t hz_player_id; // 0x04(0x04)
	int32_t round_id; // 0x08(0x04)
	int32_t class_id; // 0x0c(0x04)
	struct FString Timestamp; // 0x10(0x10)
};

// ScriptStruct Killstreak.JobSelectionRecord
// Size: 0x68 (Inherited: 0x00)
struct FJobSelectionRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t hz_player_id; // 0x04(0x04)
	int32_t round_id; // 0x08(0x04)
	int32_t class_id; // 0x0c(0x04)
	struct FString Timestamp; // 0x10(0x10)
	int32_t skin_id; // 0x20(0x04)
	int32_t wingsuit_id; // 0x24(0x04)
	int32_t primary_weapon_1_wrap_id; // 0x28(0x04)
	int32_t primary_weapon_2_wrap_id; // 0x2c(0x04)
	int32_t secondary_weapon_wrap_id; // 0x30(0x04)
	int32_t melee_weapon_wrap_id; // 0x34(0x04)
	struct TArray<int32_t> emotes_and_sprays; // 0x38(0x10)
	struct TArray<int32_t> quips; // 0x48(0x10)
	struct TArray<int32_t> communications; // 0x58(0x10)
};

// ScriptStruct Killstreak.PlayerRecord
// Size: 0x100 (Inherited: 0x00)
struct FPlayerRecord {
	int32_t ue_player_id; // 0x00(0x04)
	int32_t hz_player_id; // 0x04(0x04)
	struct FString player_name; // 0x08(0x10)
	int32_t team_id; // 0x18(0x04)
	int32_t class_id; // 0x1c(0x04)
	int32_t player_type; // 0x20(0x04)
	int32_t portal_id; // 0x24(0x04)
	int32_t input_type; // 0x28(0x04)
	int32_t platform_type; // 0x2c(0x04)
	int32_t ranking_id; // 0x30(0x04)
	float ranking; // 0x34(0x04)
	float ranking_variance; // 0x38(0x04)
	int32_t task_force_id; // 0x3c(0x04)
	struct FGuid group_id; // 0x40(0x10)
	int32_t party_id; // 0x50(0x04)
	int32_t party_size; // 0x54(0x04)
	int32_t skin_id; // 0x58(0x04)
	int32_t account_level; // 0x5c(0x04)
	int32_t ranked_level; // 0x60(0x04)
	int32_t class_level; // 0x64(0x04)
	float time_played; // 0x68(0x04)
	float time_alive; // 0x6c(0x04)
	int32_t kills_single; // 0x70(0x04)
	int32_t kills_double; // 0x74(0x04)
	int32_t kills_triple; // 0x78(0x04)
	int32_t kills_quadra; // 0x7c(0x04)
	int32_t kills_penta; // 0x80(0x04)
	int32_t deaths; // 0x84(0x04)
	int32_t executes; // 0x88(0x04)
	int32_t Assists; // 0x8c(0x04)
	int32_t downs; // 0x90(0x04)
	int32_t eliminations; // 0x94(0x04)
	int32_t Revives; // 0x98(0x04)
	int32_t shots_fired; // 0x9c(0x04)
	int32_t shots_hit; // 0xa0(0x04)
	int32_t head_shots; // 0xa4(0x04)
	int32_t accumulated_damage; // 0xa8(0x04)
	int32_t accumulated_self_damage; // 0xac(0x04)
	int32_t accumulated_friendly_damage; // 0xb0(0x04)
	int32_t accumulated_reverse_friendly_damage; // 0xb4(0x04)
	int32_t gadget_uses; // 0xb8(0x04)
	int32_t ability_uses; // 0xbc(0x04)
	int32_t total_earned; // 0xc0(0x04)
	int32_t total_spent; // 0xc4(0x04)
	int32_t total_refunded; // 0xc8(0x04)
	int32_t on_time; // 0xcc(0x04)
	int32_t connect_count; // 0xd0(0x04)
	int32_t disconnect_round; // 0xd4(0x04)
	int32_t deserter_rounds; // 0xd8(0x04)
	int32_t penalties; // 0xdc(0x04)
	int32_t afk_kicked; // 0xe0(0x04)
	int32_t client_selected_site_id; // 0xe4(0x04)
	int32_t client_selected_queue_id; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FString client_current_language; // 0xf0(0x10)
};

// ScriptStruct Killstreak.MinimapData
// Size: 0x20 (Inherited: 0x00)
struct FMinimapData {
	struct FLocationRecord northwest_corner; // 0x00(0x0c)
	float Width; // 0x0c(0x04)
	struct TArray<struct FObjectiveRecord> objectives; // 0x10(0x10)
};

// ScriptStruct Killstreak.ObjectiveRecord
// Size: 0x10 (Inherited: 0x00)
struct FObjectiveRecord {
	int32_t Type; // 0x00(0x04)
	struct FLocationRecord Location; // 0x04(0x0c)
};

// ScriptStruct Killstreak.StateMachineObjectEntry
// Size: 0x18 (Inherited: 0x00)
struct FStateMachineObjectEntry {
	struct FName Key; // 0x00(0x08)
	struct UObject* Entry; // 0x08(0x08)
	int64_t IntEntry; // 0x10(0x08)
};

// ScriptStruct Killstreak.StateMachineModEntry
// Size: 0x10 (Inherited: 0x00)
struct FStateMachineModEntry {
	struct FName Key; // 0x00(0x08)
	struct UKSModInst_Activated* ModInst; // 0x08(0x08)
};

// ScriptStruct Killstreak.DownedEnemyPingHandle
// Size: 0x18 (Inherited: 0x00)
struct FDownedEnemyPingHandle {
	struct TWeakObjectPtr<struct AKSPlayerState> DownedEnemyPlayer; // 0x00(0x08)
	struct FTimerHandle PingTimerHandle; // 0x08(0x08)
	int32_t PingsSent; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSModZoneModInfo
// Size: 0x10 (Inherited: 0x00)
struct FKSModZoneModInfo {
	struct UKSPlayerMod* PlayerMod; // 0x00(0x08)
	bool bUnique; // 0x08(0x01)
	bool bRemove; // 0x09(0x01)
	bool bRemoveAll; // 0x0a(0x01)
	char pad_B[0x5]; // 0x0b(0x05)
};

// ScriptStruct Killstreak.AccoladeMultiDownTracker
// Size: 0x70 (Inherited: 0x00)
struct FAccoladeMultiDownTracker {
	int32_t DownReqAmount; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FAccoladeDisplayInfo AccoladeReward; // 0x08(0x68)
};

// ScriptStruct Killstreak.AccoladeMultiElimTracker
// Size: 0x70 (Inherited: 0x00)
struct FAccoladeMultiElimTracker {
	int32_t ElimReqAmount; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FAccoladeDisplayInfo AccoladeReward; // 0x08(0x68)
};

// ScriptStruct Killstreak.KSMVPOrderHelper
// Size: 0x10 (Inherited: 0x00)
struct FKSMVPOrderHelper {
	struct UKSPersistentPlayerData* OwningPersistentPlayerData; // 0x00(0x08)
	int32_t OrderPoints; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct Killstreak.AirElimTracker
// Size: 0x08 (Inherited: 0x00)
struct FAirElimTracker {
	int32_t InstigatorId; // 0x00(0x04)
	int32_t DownCount; // 0x04(0x04)
};

// ScriptStruct Killstreak.KSObjectiveInfo
// Size: 0x68 (Inherited: 0x00)
struct FKSObjectiveInfo {
	int32_t ID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FKSObjectiveState ObjectiveState; // 0x08(0x28)
	struct FKSObjectiveState PreviousObjectiveState; // 0x30(0x28)
	struct TArray<struct FDelegate> ObjectiveStateChangedCallbacks; // 0x58(0x10)
};

// ScriptStruct Killstreak.KSObjectiveTimerInfo
// Size: 0x38 (Inherited: 0x00)
struct FKSObjectiveTimerInfo {
	struct UKSTimerComponent* ObjectiveTimer; // 0x00(0x08)
	struct TArray<struct FDelegate> ObjectiveTimerActiveCallbacks; // 0x08(0x10)
	struct TArray<struct FDelegate> ObjectiveTimerCompleteCallbacks; // 0x18(0x10)
	struct TArray<struct FDelegate> ObjectiveTimerTickCallbacks; // 0x28(0x10)
};

// ScriptStruct Killstreak.KSObjectiveCaptureInfo
// Size: 0x14 (Inherited: 0x00)
struct FKSObjectiveCaptureInfo {
	float BaseCaptureTime; // 0x00(0x04)
	float BaseRecaptureTime; // 0x04(0x04)
	float CaptureRatePercentIncreasePerPlayer; // 0x08(0x04)
	float FullCaptureDecayTime; // 0x0c(0x04)
	bool bPlayerMustBePresentToKeep; // 0x10(0x01)
	bool bIsValid; // 0x11(0x01)
	char pad_12[0x2]; // 0x12(0x02)
};

// ScriptStruct Killstreak.TrackPlayerElim
// Size: 0x08 (Inherited: 0x00)
struct FTrackPlayerElim {
	int32_t PlayerInstigatorId; // 0x00(0x04)
	int32_t PlayerVictimId; // 0x04(0x04)
};

// ScriptStruct Killstreak.AccountJobStatReplicator
// Size: 0x230 (Inherited: 0x108)
struct FAccountJobStatReplicator : FFastArraySerializer {
	char pad_108[0x10]; // 0x108(0x10)
	struct TArray<struct FAccountJobStatReplicatorEntry> RepItems; // 0x118(0x10)
	struct TMap<struct FAccountJobStatKey, int32_t> AccountJobStatsMap; // 0x128(0x50)
	char pad_178[0x50]; // 0x178(0x50)
	struct TMap<struct FInventoryId, struct FAccountJobStatKey> InventoryIdToStatKeyMap; // 0x1c8(0x50)
	char pad_218[0x18]; // 0x218(0x18)
};

// ScriptStruct Killstreak.AccountJobStatKey
// Size: 0x40 (Inherited: 0x00)
struct FAccountJobStatKey {
	struct FKSPersistentPlayerId PlayerId; // 0x00(0x10)
	struct TSoftObjectPtr<UKSJobItem> Job; // 0x10(0x28)
	enum class EAccountJobStatType AccountJobStatType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct Killstreak.AccountJobStatReplicatorEntry
// Size: 0x58 (Inherited: 0x0c)
struct FAccountJobStatReplicatorEntry : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FAccountJobStatKey Key; // 0x10(0x40)
	int32_t Value; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct Killstreak.KSPersistentMinPlayerDataContainer
// Size: 0x210 (Inherited: 0x108)
struct FKSPersistentMinPlayerDataContainer : FFastArraySerializer {
	struct TArray<struct FKSPersistentMinPlayerData> ReplicatedPlayerData; // 0x108(0x10)
	struct TMap<struct FKSPersistentPlayerId, struct UKSPersistentPlayerData*> LocalPlayerData; // 0x118(0x50)
	struct TSet<struct UKSPersistentPlayerData*> AllLocalPlayerData; // 0x168(0x50)
	struct TSet<int32_t> KnownDeadEnginePlayerIds; // 0x1b8(0x50)
	char pad_208[0x8]; // 0x208(0x08)
};

// ScriptStruct Killstreak.KSPersistentMinPlayerData
// Size: 0x38 (Inherited: 0x0c)
struct FKSPersistentMinPlayerData : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FKSPersistentPlayerId ID; // 0x10(0x10)
	int32_t TeamNum; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString PlayerName; // 0x28(0x10)
};

// ScriptStruct Killstreak.PingInfoChangeList
// Size: 0x120 (Inherited: 0x108)
struct FPingInfoChangeList : FFastArraySerializer {
	struct TArray<struct FPingInfoChangeItem> Items; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct Killstreak.PingInfoChangeItem
// Size: 0x60 (Inherited: 0x0c)
struct FPingInfoChangeItem : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FPingInfo PingInfo; // 0x10(0x50)
};

// ScriptStruct Killstreak.PingCacher
// Size: 0x10 (Inherited: 0x00)
struct FPingCacher {
	struct AKSPlayerState* PingingPlayer; // 0x00(0x08)
	int32_t PingId; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct Killstreak.InternalPingInfo
// Size: 0x10 (Inherited: 0x00)
struct FInternalPingInfo {
	int32_t PingId; // 0x00(0x04)
	int32_t DisplayId; // 0x04(0x04)
	struct AKSPlayerState* CreatingPlayer; // 0x08(0x08)
};

// ScriptStruct Killstreak.ClientStatistics
// Size: 0x18 (Inherited: 0x00)
struct FClientStatistics {
	float smoothed; // 0x00(0x04)
	float Maximum; // 0x04(0x04)
	float Minimum; // 0x08(0x04)
	float average; // 0x0c(0x04)
	int32_t SampleCount; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.ClientInputTypeUse
// Size: 0x08 (Inherited: 0x00)
struct FClientInputTypeUse {
	int16_t InputTypeKbm; // 0x00(0x02)
	int16_t InputTypeGpad; // 0x02(0x02)
	int16_t InputTypeTouch; // 0x04(0x02)
	int16_t InputTypeOther; // 0x06(0x02)
};

// ScriptStruct Killstreak.ClientContext
// Size: 0xc8 (Inherited: 0x00)
struct FClientContext {
	struct FString ClientCurrentLanguage; // 0x00(0x10)
	int32_t ClientSelectedSiteId; // 0x10(0x04)
	int32_t DivertFromQueueId; // 0x14(0x04)
	int32_t DivertToQueueId; // 0x18(0x04)
	enum class EQueueDivertType QueueDivertType; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	float ShelteredMMAttemptTimeout; // 0x20(0x04)
	float ShelteredMMLevelLimit; // 0x24(0x04)
	int32_t ForcedBotMatchLimit; // 0x28(0x04)
	int32_t MercyMatchLossesRequired; // 0x2c(0x04)
	struct FString BuildVersion; // 0x30(0x10)
	int32_t ViewportSizeX; // 0x40(0x04)
	int32_t ViewPortSizeY; // 0x44(0x04)
	struct FString DeviceMakeAndModel; // 0x48(0x10)
	struct FString PrimaryGPUBrand; // 0x58(0x10)
	struct FString BranchName; // 0x68(0x10)
	uint64_t AvailablePhysicalMemory; // 0x78(0x08)
	uint64_t TotalPhysicalMemory; // 0x80(0x08)
	uint64_t AvailableVirtualMemory; // 0x88(0x08)
	uint64_t TotalVirtualMemory; // 0x90(0x08)
	float CPUBenchmarkResults; // 0x98(0x04)
	float GPUBenchmarkResults; // 0x9c(0x04)
	float ResolutionQuality; // 0xa0(0x04)
	int32_t GlobalQuality; // 0xa4(0x04)
	int32_t ViewDistanceQuality; // 0xa8(0x04)
	int32_t AntiAliasingQuality; // 0xac(0x04)
	int32_t ShadowQuality; // 0xb0(0x04)
	int32_t PostProcessQuality; // 0xb4(0x04)
	int32_t TextureQuality; // 0xb8(0x04)
	int32_t EffectsQuality; // 0xbc(0x04)
	int32_t FoliageQuality; // 0xc0(0x04)
	int32_t ShadingQuality; // 0xc4(0x04)
};

// ScriptStruct Killstreak.DeferredViewTargetChangeInfo
// Size: 0x10 (Inherited: 0x00)
struct FDeferredViewTargetChangeInfo {
	struct AActor* OldTarget; // 0x00(0x08)
	struct AActor* NewTarget; // 0x08(0x08)
};

// ScriptStruct Killstreak.KickbackPlayback
// Size: 0x20 (Inherited: 0x00)
struct FKickbackPlayback {
	float AccumulatedTime; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FInterpCurveVector2D KickbackCurve; // 0x08(0x18)
};

// ScriptStruct Killstreak.PlayerAlias
// Size: 0x20 (Inherited: 0x00)
struct FPlayerAlias {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct Killstreak.KSCustomInputAxisKeyMappings
// Size: 0xf0 (Inherited: 0x00)
struct FKSCustomInputAxisKeyMappings {
	struct TMap<float, struct FKSInputAxisKeyMappings> KBM_Mappings; // 0x00(0x50)
	struct TMap<float, struct FKSInputAxisKeyMappings> GP_Mappings; // 0x50(0x50)
	struct TMap<float, struct FKSInputAxisKeyMappings> Touch_Mappings; // 0xa0(0x50)
};

// ScriptStruct Killstreak.KSInputAxisKeyMappings
// Size: 0x10 (Inherited: 0x00)
struct FKSInputAxisKeyMappings {
	struct TArray<struct FInputAxisKeyMapping> InputAxisKeyMappings; // 0x00(0x10)
};

// ScriptStruct Killstreak.KSCustomInputActionKeyMappings
// Size: 0x30 (Inherited: 0x00)
struct FKSCustomInputActionKeyMappings {
	struct TArray<struct FKSInputActionKeyMapping> KBM_Mappings; // 0x00(0x10)
	struct TArray<struct FKSInputActionKeyMapping> GP_Mappings; // 0x10(0x10)
	struct TArray<struct FKSInputActionKeyMapping> Touch_Mappings; // 0x20(0x10)
};

// ScriptStruct Killstreak.KSInputActionKeyMapping
// Size: 0x30 (Inherited: 0x00)
struct FKSInputActionKeyMapping {
	struct FInputActionKeyMapping Mapping; // 0x00(0x28)
	enum class EKSInputActionType Type; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct Killstreak.KSInputActionKey
// Size: 0x20 (Inherited: 0x00)
struct FKSInputActionKey {
	struct FKey Key; // 0x00(0x18)
	enum class EKSInputActionType Type; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct Killstreak.KSCustomInputAxisKey
// Size: 0x1c (Inherited: 0x00)
struct FKSCustomInputAxisKey {
	int32_t propId; // 0x00(0x04)
	struct FName KeyboardName; // 0x04(0x08)
	float KeyboardScale; // 0x0c(0x04)
	struct FName GamepadName; // 0x10(0x08)
	float GamepadScale; // 0x18(0x04)
};

// ScriptStruct Killstreak.KSCustomInputActionKey
// Size: 0x14 (Inherited: 0x00)
struct FKSCustomInputActionKey {
	int32_t propId; // 0x00(0x04)
	struct FName KeyboardName; // 0x04(0x08)
	struct FName GamepadName; // 0x0c(0x08)
};

// ScriptStruct Killstreak.KSInputActionTiedNames
// Size: 0x18 (Inherited: 0x00)
struct FKSInputActionTiedNames {
	struct FName Press; // 0x00(0x08)
	struct FName Hold; // 0x08(0x08)
	struct FName Repeat; // 0x10(0x08)
};

// ScriptStruct Killstreak.KSInputActionNameTypePair
// Size: 0x0c (Inherited: 0x00)
struct FKSInputActionNameTypePair {
	struct FName Name; // 0x00(0x08)
	enum class EKSInputActionType Type; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct Killstreak.KSPlayerModInputBinding
// Size: 0x0c (Inherited: 0x00)
struct FKSPlayerModInputBinding {
	struct FName ActionName; // 0x00(0x08)
	bool bListenForPress; // 0x08(0x01)
	bool bListenForRelease; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct Killstreak.ShopManifest
// Size: 0x120 (Inherited: 0x108)
struct FShopManifest : FFastArraySerializer {
	struct TArray<struct FShopItem> Manifest; // 0x108(0x10)
	struct AKSPlayerShop* Owner; // 0x118(0x08)
};

// ScriptStruct Killstreak.KSShopPricing
// Size: 0x108 (Inherited: 0x00)
struct FKSShopPricing {
	bool bOverridePistolPrice; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t PistolPrice; // 0x04(0x04)
	bool bOverridePistolUpgradePrice; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t PistolUpgradePrice; // 0x0c(0x04)
	bool bOverrideAssaultRiflePrice; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t AssaultRiflePrice; // 0x14(0x04)
	bool bOverrideAssaultRifleUpgradePrice; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t AssaultRifleUpgradePrice; // 0x1c(0x04)
	bool bOverrideDMRPrice; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t DMRPrice; // 0x24(0x04)
	bool bOverrideDMRUpgradePrice; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	int32_t DMRUpgradePrice; // 0x2c(0x04)
	bool bOverrideSMGPrice; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t SMGPrice; // 0x34(0x04)
	bool bOverrideSMGUpgradePrice; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t SMGUpgradePrice; // 0x3c(0x04)
	bool bOverrideLMGPrice; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32_t LMGPrice; // 0x44(0x04)
	bool bOverrideLMGUpgradePrice; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32_t LMGUpgradePrice; // 0x4c(0x04)
	bool bOverrideShotgunPrice; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	int32_t ShotgunPrice; // 0x54(0x04)
	bool bOverrideShotgunUpgradePrice; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	int32_t ShotgunUpgradePrice; // 0x5c(0x04)
	bool bOverrideSniperPrice; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	int32_t SniperPrice; // 0x64(0x04)
	bool bOverrideSniperUpgradePrice; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	int32_t SniperUpgradePrice; // 0x6c(0x04)
	bool bOverrideMeleePrice; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t MeleePrice; // 0x74(0x04)
	bool bOverrideMeleeUpgradePrice; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	int32_t MeleeUpgradePrice; // 0x7c(0x04)
	bool bOverrideLethalPrice; // 0x80(0x01)
	char pad_81[0x3]; // 0x81(0x03)
	int32_t LethalPrice; // 0x84(0x04)
	bool bOverrideLethalUpgradePrice; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	int32_t LethalUpgradePrice; // 0x8c(0x04)
	bool bOverrideUtilityPrice; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	int32_t UtilityPrice; // 0x94(0x04)
	bool bOverrideUtilityUpgradePrice; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	int32_t UtilityUpgradePrice; // 0x9c(0x04)
	bool bOverrideTier1PerkPrice; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	int32_t Tier1PerkPrice; // 0xa4(0x04)
	bool bOverrideTier2PerkPrice; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	int32_t Tier2PerkPrice; // 0xac(0x04)
	bool bOverrideTier3PerkPrice; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	int32_t Tier3PerkPrice; // 0xb4(0x04)
	struct TMap<struct UKSItem*, int32_t> OverridePricingMap; // 0xb8(0x50)
};

// ScriptStruct Killstreak.ShopOptions
// Size: 0x06 (Inherited: 0x00)
struct FShopOptions {
	bool bPrimary; // 0x00(0x01)
	bool bSecondary; // 0x01(0x01)
	bool bMelee; // 0x02(0x01)
	bool bGadgets; // 0x03(0x01)
	bool bPerks; // 0x04(0x01)
	bool bGambits; // 0x05(0x01)
};

// ScriptStruct Killstreak.KSScoreChangeList
// Size: 0x90 (Inherited: 0x70)
struct FKSScoreChangeList : FSizedArraySerializer {
	char pad_70[0x8]; // 0x70(0x08)
	struct TArray<struct FKSScoreChangeItem> Items; // 0x78(0x10)
	char pad_88[0x8]; // 0x88(0x08)
};

// ScriptStruct Killstreak.KSScoreChangeItem
// Size: 0x30 (Inherited: 0x01)
struct FKSScoreChangeItem : FReplicatedLogItem {
	struct FKSScoreChangeEvent ScoreChange; // 0x00(0x30)
};

// ScriptStruct Killstreak.KSCashChangeList
// Size: 0x90 (Inherited: 0x90)
struct FKSCashChangeList : FKSScoreChangeList {
};

// ScriptStruct Killstreak.LaggedProjectileHit
// Size: 0x94 (Inherited: 0x00)
struct FLaggedProjectileHit {
	struct FHitResult HitResult; // 0x00(0x88)
	float ClientHitTimeStamp; // 0x88(0x04)
	float AdditionalPredictionTime; // 0x8c(0x04)
	enum class EProjectilePredictionType PredictionType; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
};

// ScriptStruct Killstreak.ProjectileWidgetInfo
// Size: 0x30 (Inherited: 0x00)
struct FProjectileWidgetInfo {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct Killstreak.KSSpreadList
// Size: 0x120 (Inherited: 0x108)
struct FKSSpreadList : FFastArraySerializer {
	struct TArray<struct FKSSpreadEntry> List; // 0x108(0x10)
	struct AKSProjectile_GrenadeSpread* Owner; // 0x118(0x08)
};

// ScriptStruct Killstreak.KSSpreadEntry
// Size: 0x80 (Inherited: 0x0c)
struct FKSSpreadEntry : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FKSSpreadTransform Entry; // 0x10(0x70)
};

// ScriptStruct Killstreak.KSSpreadTransform
// Size: 0x70 (Inherited: 0x00)
struct FKSSpreadTransform {
	int32_t ID; // 0x00(0x04)
	char pad_4[0xc]; // 0x04(0x0c)
	struct FTransform Transform; // 0x10(0x30)
	struct UParticleSystemComponent* ParticleSystem; // 0x40(0x08)
	struct UDecalComponent* Decal; // 0x48(0x08)
	struct USphereComponent* Sphere; // 0x50(0x08)
	struct UMeshComponent* Mesh; // 0x58(0x08)
	float CurrentHealth; // 0x60(0x04)
	char pad_64[0xc]; // 0x64(0x0c)
};

// ScriptStruct Killstreak.KSProximityFilter
// Size: 0x20 (Inherited: 0x00)
struct FKSProximityFilter {
	struct TArray<struct AActor*> ValidActorClasses; // 0x00(0x10)
	bool bCountAllies; // 0x10(0x01)
	bool bCountEnemies; // 0x11(0x01)
	bool bCountUnaffiliated; // 0x12(0x01)
	bool bCheckLOS; // 0x13(0x01)
	struct FVector LOSTraceStartOffset; // 0x14(0x0c)
};

// ScriptStruct Killstreak.EndMatchPunishConfigEntry
// Size: 0x18 (Inherited: 0x00)
struct FEndMatchPunishConfigEntry {
	int32_t PointsRequired; // 0x00(0x04)
	bool PassThresholdOnDecrease; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct TArray<struct FPunishmentConfigEntry> Punishments; // 0x08(0x10)
};

// ScriptStruct Killstreak.PunishmentConfigEntry
// Size: 0x08 (Inherited: 0x00)
struct FPunishmentConfigEntry {
	int32_t PunishmentLootTableId; // 0x00(0x04)
	int32_t PunishmentQuantity; // 0x04(0x04)
};

// ScriptStruct Killstreak.BadBehaviorConfigEntry
// Size: 0x20 (Inherited: 0x00)
struct FBadBehaviorConfigEntry {
	enum class EBadBehaviorType BehaviorType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t TimeRequired; // 0x04(0x04)
	bool IsRepeatable; // 0x08(0x01)
	bool IsImmediate; // 0x09(0x01)
	bool AppliesDeserterPenalty; // 0x0a(0x01)
	char pad_B[0x5]; // 0x0b(0x05)
	struct TArray<struct FPunishmentConfigEntry> Punishments; // 0x10(0x10)
};

// ScriptStruct Killstreak.PlayerPunishmentTracker
// Size: 0x28 (Inherited: 0x00)
struct FPlayerPunishmentTracker {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct Killstreak.BadBehaviorTracker
// Size: 0x0c (Inherited: 0x00)
struct FBadBehaviorTracker {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct Killstreak.KSQueuePlatformFilter
// Size: 0x38 (Inherited: 0x00)
struct FKSQueuePlatformFilter {
	struct FString Platform; // 0x00(0x10)
	int32_t QueueMaxAllowedPartySize; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<int32_t> QueueIdWhitelist; // 0x18(0x10)
	struct TArray<int32_t> QueueIdBlacklist; // 0x28(0x10)
};

// ScriptStruct Killstreak.KSQueueSectionSort
// Size: 0x0c (Inherited: 0x00)
struct FKSQueueSectionSort {
	struct FName QueueType; // 0x00(0x08)
	int32_t SortOrder; // 0x08(0x04)
};

// ScriptStruct Killstreak.KSLimitedTimeEventMetadataRow
// Size: 0x60 (Inherited: 0x08)
struct FKSLimitedTimeEventMetadataRow : FTableRowBase {
	struct FText EventName; // 0x08(0x18)
	struct FText EventDescription; // 0x20(0x18)
	struct TSoftObjectPtr<UTexture2D> EventIcon; // 0x38(0x28)
};

// ScriptStruct Killstreak.KSLimitedTimeEventRow
// Size: 0x38 (Inherited: 0x00)
struct FKSLimitedTimeEventRow {
	struct FString LimitedTimeEventKey; // 0x00(0x10)
	struct TArray<struct FString> BonusProgressionKeys; // 0x10(0x10)
	struct TArray<struct FString> AllowedQueueGroups; // 0x20(0x10)
	int32_t RequiredItemId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct Killstreak.KSRankedSeasonRow
// Size: 0x38 (Inherited: 0x00)
struct FKSRankedSeasonRow {
	struct FString RankedSeasonKey; // 0x00(0x10)
	struct FString RankedProgressionKey; // 0x10(0x10)
	bool UsesPlacementMatches; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t PlacementMatchItemId; // 0x24(0x04)
	int32_t PlacementMatchLootId; // 0x28(0x04)
	int32_t InitXpLootId; // 0x2c(0x04)
	int32_t XpTableId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct Killstreak.KSRankedProgressionRow
// Size: 0x58 (Inherited: 0x00)
struct FKSRankedProgressionRow {
	struct FString RankedProgressionKey; // 0x00(0x10)
	float WinBaseValue; // 0x10(0x04)
	float LossBaseValue; // 0x14(0x04)
	float MaxBonusClamp; // 0x18(0x04)
	float MinBonusClamp; // 0x1c(0x04)
	float RankDifferenceMultiplier; // 0x20(0x04)
	int32_t RequiredPlacementMatches; // 0x24(0x04)
	int32_t PartyRankRange; // 0x28(0x04)
	int32_t InitialPlacementDifference; // 0x2c(0x04)
	int32_t MinPlacementPartyLevel; // 0x30(0x04)
	int32_t MaxPlacementPartyLevel; // 0x34(0x04)
	struct TArray<struct FKSFavoredMatchBonusEntry> FavoredMatchBonusList; // 0x38(0x10)
	struct TArray<float> MMRZoneList; // 0x48(0x10)
};

// ScriptStruct Killstreak.KSFavoredMatchBonusEntry
// Size: 0x08 (Inherited: 0x00)
struct FKSFavoredMatchBonusEntry {
	float MaxDifference; // 0x00(0x04)
	int32_t BonusValue; // 0x04(0x04)
};

// ScriptStruct Killstreak.KSQueueGroupRow
// Size: 0x20 (Inherited: 0x00)
struct FKSQueueGroupRow {
	struct FString GroupKey; // 0x00(0x10)
	struct TArray<struct FString> BonusProgressionKeys; // 0x10(0x10)
};

// ScriptStruct Killstreak.KSSurrenderRow
// Size: 0x20 (Inherited: 0x00)
struct FKSSurrenderRow {
	struct FString SurrenderConfigKey; // 0x00(0x10)
	bool bDoesQueueAllowSurrender; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float SecondsFromMatchStart; // 0x14(0x04)
	float SecondsFromPlayerDisconnect; // 0x18(0x04)
	float SecondsFromSurrenderFailure; // 0x1c(0x04)
};

// ScriptStruct Killstreak.KSBonusProgressionRow
// Size: 0x60 (Inherited: 0x00)
struct FKSBonusProgressionRow {
	struct FString BonusProgressionKey; // 0x00(0x10)
	struct TMap<struct FString, float> BonusProgressionList; // 0x10(0x50)
};

// ScriptStruct Killstreak.KSMapRow
// Size: 0x48 (Inherited: 0x00)
struct FKSMapRow {
	struct FString MapKey; // 0x00(0x10)
	int32_t MapId; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FText mapName; // 0x18(0x18)
	struct FSoftObjectPath MapThumbnailPath; // 0x30(0x18)
};

// ScriptStruct Killstreak.KSMapListRow
// Size: 0x20 (Inherited: 0x00)
struct FKSMapListRow {
	struct FString MapListKey; // 0x00(0x10)
	struct TArray<struct FString> MapKeys; // 0x10(0x10)
};

// ScriptStruct Killstreak.KSQueueRow
// Size: 0xe0 (Inherited: 0x00)
struct FKSQueueRow {
	struct FText Name; // 0x00(0x18)
	struct FText Description; // 0x18(0x18)
	int32_t ID; // 0x30(0x04)
	int32_t LevelLock; // 0x34(0x04)
	int32_t MinPartySize; // 0x38(0x04)
	int32_t MaxPartySize; // 0x3c(0x04)
	int32_t SortOrder; // 0x40(0x04)
	int32_t MaxPlayerPerSide; // 0x44(0x04)
	bool IsCustom; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	struct FName QueueType; // 0x4c(0x08)
	char pad_54[0x4]; // 0x54(0x04)
	struct FString MapListKey; // 0x58(0x10)
	struct FString SurrenderConfigKey; // 0x68(0x10)
	struct FString RankedSeasonKey; // 0x78(0x10)
	struct FString QueueThumbnail; // 0x88(0x10)
	struct TArray<struct FString> QueueGroupKeys; // 0x98(0x10)
	bool AllowAllUnownedJobs; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct TArray<int32_t> AllowedUnownedJobIds; // 0xb0(0x10)
	struct TArray<struct FString> AllowedPlatforms; // 0xc0(0x10)
	struct TArray<struct FString> DisallowedPlatforms; // 0xd0(0x10)
};

// ScriptStruct Killstreak.KSRadialMenuItemInterruptRules
// Size: 0x04 (Inherited: 0x00)
struct FKSRadialMenuItemInterruptRules {
	char pad_0_0 : 2; // 0x00(0x01)
	char Walking : 1; // 0x00(0x01)
	char Sprinting : 1; // 0x00(0x01)
	char Crouching : 1; // 0x00(0x01)
	char Downed : 1; // 0x00(0x01)
	char Dead : 1; // 0x00(0x01)
	char Interacting : 1; // 0x00(0x01)
	char Zipline : 1; // 0x01(0x01)
	char SkyDiving : 1; // 0x01(0x01)
	char DodgeRolling : 1; // 0x01(0x01)
	char Falling : 1; // 0x01(0x01)
	char NonRadialMenuItemEquipment : 1; // 0x01(0x01)
	char RadialMenuItemActivated : 1; // 0x01(0x01)
	char Cooldown : 1; // 0x01(0x01)
	char DistFromOrigin : 1; // 0x01(0x01)
	char Throttled : 1; // 0x02(0x01)
	char pad_2_1 : 7; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
};

// ScriptStruct Killstreak.RecoilProfile2
// Size: 0x1c0 (Inherited: 0x00)
struct FRecoilProfile2 {
	struct FRecoilInfo2 PelvisRecoil; // 0x00(0x70)
	struct FRecoilInfo2 SpineRecoil; // 0x70(0x70)
	struct FRecoilInfo2 NeckRecoil; // 0xe0(0x70)
	struct FRecoilInfo2 HandRecoil; // 0x150(0x70)
};

// ScriptStruct Killstreak.RecoilInfo2
// Size: 0x70 (Inherited: 0x00)
struct FRecoilInfo2 {
	float TimeToGo; // 0x00(0x04)
	float TimeDuration; // 0x04(0x04)
	struct FVector RotAmplitude; // 0x08(0x0c)
	struct FVector RotFrequency; // 0x14(0x0c)
	char pad_20[0xc]; // 0x20(0x0c)
	struct FRecoilParams2 RotParams; // 0x2c(0x03)
	char pad_2F[0x1]; // 0x2f(0x01)
	struct FRotator RotOffset; // 0x30(0x0c)
	struct FVector LocAmplitude; // 0x3c(0x0c)
	struct FVector LocFrequency; // 0x48(0x0c)
	char pad_54[0xc]; // 0x54(0x0c)
	struct FRecoilParams2 LocParams; // 0x60(0x03)
	char pad_63[0x1]; // 0x63(0x01)
	struct FVector LocOffset; // 0x64(0x0c)
};

// ScriptStruct Killstreak.RecoilParams2
// Size: 0x03 (Inherited: 0x00)
struct FRecoilParams2 {
	char pad_0[0x3]; // 0x00(0x03)
};

// ScriptStruct Killstreak.KSResourceInfoSerializerContainer
// Size: 0x120 (Inherited: 0x108)
struct FKSResourceInfoSerializerContainer : FFastArraySerializer {
	struct TArray<struct FKSResourceInfoSerializerItem> ResourceInfoSerializerItems; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct Killstreak.KSResourceInfoSerializerItem
// Size: 0x28 (Inherited: 0x0c)
struct FKSResourceInfoSerializerItem : FFastArraySerializerItem {
	struct FKSResourceInfo ResourceInfo; // 0x0c(0x1c)
};

// ScriptStruct Killstreak.KSResourceInfo
// Size: 0x1c (Inherited: 0x00)
struct FKSResourceInfo {
	struct FName ResourceKeyName; // 0x00(0x08)
	enum class EKSResourceReplicationType ResourceReplicationType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float CurrentResourceValue; // 0x0c(0x04)
	float LastLocalCurrentResourceValue; // 0x10(0x04)
	float MinResourceValue; // 0x14(0x04)
	float MaxResourceValue; // 0x18(0x04)
};

// ScriptStruct Killstreak.KSRevealInfoSerializerContainer
// Size: 0x120 (Inherited: 0x108)
struct FKSRevealInfoSerializerContainer : FFastArraySerializer {
	struct TArray<struct FKSRevealInfoSerializerItem> RevealInfoSerializerItems; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct Killstreak.KSRevealInfoSerializerItem
// Size: 0x58 (Inherited: 0x0c)
struct FKSRevealInfoSerializerItem : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FKSRevealInfo RevealInfo; // 0x10(0x48)
};

// ScriptStruct Killstreak.PlayerDamageInfo
// Size: 0x30 (Inherited: 0x00)
struct FPlayerDamageInfo {
	int32_t InstigatorPlayerId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString InstigatorPlayerName; // 0x08(0x10)
	int32_t VictimPlayerId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString VictimPlayerName; // 0x20(0x10)
};

// ScriptStruct Killstreak.PlayerRewardsSummaryReplicated
// Size: 0x30 (Inherited: 0x00)
struct FPlayerRewardsSummaryReplicated {
	struct TArray<int64_t> ActivityKeys; // 0x00(0x10)
	struct TArray<struct FRewardProgress> ActivityValues; // 0x10(0x10)
	struct TArray<struct FPlayerMatchStatInfo> BestStats; // 0x20(0x10)
};

// ScriptStruct Killstreak.SafeZoneParams
// Size: 0x10 (Inherited: 0x00)
struct FSafeZoneParams {
	struct FVector CenterPosition; // 0x00(0x0c)
	float Radius; // 0x0c(0x04)
};

// ScriptStruct Killstreak.RoyaleZoneData
// Size: 0x14 (Inherited: 0x00)
struct FRoyaleZoneData {
	float ZoneRadius; // 0x00(0x04)
	float TimeToShrink; // 0x04(0x04)
	float TimeAfterShrink; // 0x08(0x04)
	float DamagePerTick; // 0x0c(0x04)
	float DamageTickPeriod; // 0x10(0x04)
};

// ScriptStruct Killstreak.SeasonalSublevels
// Size: 0x10 (Inherited: 0x00)
struct FSeasonalSublevels {
	struct TArray<struct FString> SublevelSuffixes; // 0x00(0x10)
};

// ScriptStruct Killstreak.SeasonalItemSpawnInfo
// Size: 0x18 (Inherited: 0x00)
struct FSeasonalItemSpawnInfo {
	struct AKSLootSiteBase* LootSiteToSpawn; // 0x00(0x08)
	int32_t MinimumAmountToSpawn; // 0x08(0x04)
	int32_t MaximumAmountToSpawn; // 0x0c(0x04)
	char pad_10[0x8]; // 0x10(0x08)
};

// ScriptStruct Killstreak.SettingDelegateStruct
// Size: 0x20 (Inherited: 0x00)
struct FSettingDelegateStruct {
	struct FDelegate SettingApplied; // 0x00(0x10)
	struct FDelegate SettingSaved; // 0x10(0x10)
};

// ScriptStruct Killstreak.PlayerShopTransaction
// Size: 0x08 (Inherited: 0x00)
struct FPlayerShopTransaction {
	enum class EPlayerShopTransactionType TransactionType; // 0x00(0x01)
	enum class EShopItemType ItemType; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	uint32_t TransactionRequestId; // 0x04(0x04)
};

// ScriptStruct Killstreak.ShopItemList
// Size: 0x10 (Inherited: 0x00)
struct FShopItemList {
	struct TArray<enum class EShopItemType> ShopItems; // 0x00(0x10)
};

// ScriptStruct Killstreak.KSPlayerEventRecord
// Size: 0x18 (Inherited: 0x00)
struct FKSPlayerEventRecord {
	int32_t PlayerId; // 0x00(0x04)
	int32_t PlayerSide; // 0x04(0x04)
	struct FVector EventLocation; // 0x08(0x0c)
	float Timestamp; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSSpawnSelectorTreeNode
// Size: 0x28 (Inherited: 0x00)
struct FKSSpawnSelectorTreeNode {
	struct FKSSpawnSelectorTier SelectorTier; // 0x00(0x20)
	struct UKSSpawnSelectorTierBranch* SelectorTierBranch; // 0x20(0x08)
};

// ScriptStruct Killstreak.KSSpawnSelectorTier
// Size: 0x20 (Inherited: 0x00)
struct FKSSpawnSelectorTier {
	struct FName Name; // 0x00(0x08)
	float Tolerance; // 0x08(0x04)
	float MinScore; // 0x0c(0x04)
	struct TArray<struct FKSSpawnSelectorTierRule> SpawnSelectorTierRules; // 0x10(0x10)
};

// ScriptStruct Killstreak.KSSpawnSelectorTierRule
// Size: 0x10 (Inherited: 0x00)
struct FKSSpawnSelectorTierRule {
	struct UKSSpawnRule* SpawnRule; // 0x00(0x08)
	float Multiplier; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct Killstreak.AccountConsumableDetails
// Size: 0x10 (Inherited: 0x00)
struct FAccountConsumableDetails {
	struct UKSItem* KSItem; // 0x00(0x08)
	int32_t QuantityOwned; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct Killstreak.StoreItemWithTrueSort
// Size: 0x18 (Inherited: 0x00)
struct FStoreItemWithTrueSort {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct Killstreak.EquipPointDefinition
// Size: 0x60 (Inherited: 0x00)
struct FEquipPointDefinition {
	struct FGameplayTag EquipPoint; // 0x00(0x08)
	struct FGameplayTagQuery WeaponTypeQuery; // 0x08(0x48)
	bool bCanSwapToManually; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	struct FName HandlerSubType; // 0x54(0x08)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct Killstreak.KSTargeterConfig
// Size: 0x0c (Inherited: 0x00)
struct FKSTargeterConfig {
	float MaxTargetingRange; // 0x00(0x04)
	float TargetingConeHalfAngle; // 0x04(0x04)
	bool bUseNearestTarget; // 0x08(0x01)
	bool bRequiresVisibility; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct Killstreak.PlayerTeamTracker
// Size: 0x18 (Inherited: 0x00)
struct FPlayerTeamTracker {
	int32_t PlayerId; // 0x00(0x04)
	int32_t PlayerTeamNum; // 0x04(0x04)
	struct TArray<int32_t> PlayerElimIds; // 0x08(0x10)
};

// ScriptStruct Killstreak.KSTimerState
// Size: 0x08 (Inherited: 0x00)
struct FKSTimerState {
	bool bIsTimerActive; // 0x00(0x01)
	bool bIsTimerComplete; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t Counter; // 0x04(0x04)
};

// ScriptStruct Killstreak.QuantityRarity
// Size: 0x30 (Inherited: 0x08)
struct FQuantityRarity : FTableRowBase {
	int32_t MinQuantityRange; // 0x08(0x04)
	int32_t MaxQuantityRange; // 0x0c(0x04)
	struct FGameplayTagContainer RarityTag; // 0x10(0x20)
};

// ScriptStruct Killstreak.KSCompressedHit
// Size: 0x3c (Inherited: 0x00)
struct FKSCompressedHit {
	char bBlockingHit : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Time; // 0x04(0x04)
	struct FVector_NetQuantizeNormal Normal; // 0x08(0x0c)
	struct FVector_NetQuantize TraceStart; // 0x14(0x0c)
	struct FVector_NetQuantize TraceEnd; // 0x20(0x0c)
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // 0x2c(0x08)
	struct FName BoneName; // 0x34(0x08)
};

// ScriptStruct Killstreak.RestoreInfoInitParams
// Size: 0x05 (Inherited: 0x00)
struct FRestoreInfoInitParams {
	enum class ERestoreInfoInitBindType BindType; // 0x00(0x01)
	enum class ERestoreInfoInitRestoreType RestoreType; // 0x01(0x01)
	bool bRestoreOnce; // 0x02(0x01)
	bool bRestoreExhausted; // 0x03(0x01)
	bool bIncludeDefaultCosmetics; // 0x04(0x01)
};

// ScriptStruct Killstreak.KSSettingsState
// Size: 0x05 (Inherited: 0x00)
struct FKSSettingsState {
	bool bIsGamepadAttached; // 0x00(0x01)
	bool bIsMouseAttached; // 0x01(0x01)
	bool bIsDockedMode; // 0x02(0x01)
	bool bIsHandheldMode; // 0x03(0x01)
	bool bIsTouchMode; // 0x04(0x01)
};

// ScriptStruct Killstreak.SettingConfigPair
// Size: 0x18 (Inherited: 0x00)
struct FSettingConfigPair {
	struct FName Name; // 0x00(0x08)
	struct FString Value; // 0x08(0x10)
};

// ScriptStruct Killstreak.KSActionRestrictor
// Size: 0x08 (Inherited: 0x00)
struct FKSActionRestrictor {
	bool bRestrictMove; // 0x00(0x01)
	bool bRestrictFire; // 0x01(0x01)
	bool bRestrictAltFire; // 0x02(0x01)
	bool bRestrictAbility; // 0x03(0x01)
	bool bRestrictAim; // 0x04(0x01)
	bool bRestrictRoll; // 0x05(0x01)
	bool bRestrictWeaponSwaps; // 0x06(0x01)
	bool bRestrictReload; // 0x07(0x01)
};

// ScriptStruct Killstreak.KSCSVRow
// Size: 0x10 (Inherited: 0x00)
struct FKSCSVRow {
	struct TArray<struct FString> CSVColumn; // 0x00(0x10)
};

// ScriptStruct Killstreak.ContextualPingMessagesRow
// Size: 0x38 (Inherited: 0x08)
struct FContextualPingMessagesRow : FTableRowBase {
	enum class EPingMessage PingMessage; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TSoftObjectPtr<UTexture2D> PingMessageIcon; // 0x10(0x28)
};

// ScriptStruct Killstreak.ContextualPingTypesRow
// Size: 0x48 (Inherited: 0x08)
struct FContextualPingTypesRow : FTableRowBase {
	enum class EPingType PingType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	struct FLinearColor PingColor; // 0x0c(0x10)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TSoftObjectPtr<UTexture2D> PingIcon; // 0x20(0x28)
};

// ScriptStruct Killstreak.KSParticleSystemAttachment
// Size: 0x38 (Inherited: 0x00)
struct FKSParticleSystemAttachment {
	struct UParticleSystem* ParticleSystem; // 0x00(0x08)
	struct FName SocketName; // 0x08(0x08)
	struct FVector Scale; // 0x10(0x0c)
	struct FVector AttachmentOffset; // 0x1c(0x0c)
	struct FRotator AttachmentRotationOffset; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct Killstreak.KSSpecialEffect
// Size: 0x50 (Inherited: 0x00)
struct FKSSpecialEffect {
	struct FName FXID; // 0x00(0x08)
	float EffectEndTime; // 0x08(0x04)
	bool bLoop; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float LoopStartTime; // 0x10(0x04)
	float LoopEndTime; // 0x14(0x04)
	bool bRemoveOnForwardComplete; // 0x18(0x01)
	bool bRemoveOnReverseComplete; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
	struct TArray<struct FKSPostProcessFloatCurve> FloatCurves; // 0x20(0x10)
	struct TArray<struct FKSPostProcessColorCurve> ColorCurves; // 0x30(0x10)
	struct UKSFXCurveComponent* FXCurveClass; // 0x40(0x08)
	struct UObject* EffectAsset; // 0x48(0x08)
};

// ScriptStruct Killstreak.KSPostProcessColorCurve
// Size: 0x10 (Inherited: 0x00)
struct FKSPostProcessColorCurve {
	struct UCurveLinearColor* ColorCurve; // 0x00(0x08)
	struct FName ColorParameterName; // 0x08(0x08)
};

// ScriptStruct Killstreak.KSPostProcessFloatCurve
// Size: 0x10 (Inherited: 0x00)
struct FKSPostProcessFloatCurve {
	struct UCurveFloat* FloatCurve; // 0x00(0x08)
	struct FName FloatParameterName; // 0x08(0x08)
};

// ScriptStruct Killstreak.ScreenLogData
// Size: 0x30 (Inherited: 0x00)
struct FScreenLogData {
	enum class EScreenLogType ScreenLogData; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct APlayerState* Instigator; // 0x08(0x08)
	struct APlayerState* Victim; // 0x10(0x08)
	struct UKSItem* Weapon; // 0x18(0x08)
	bool bDowned; // 0x20(0x01)
	bool bMastered; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
	struct UKSRadialMenuItem* RadialMenuItem; // 0x28(0x08)
};

// ScriptStruct Killstreak.KSActiveEmotePropInfo
// Size: 0x18 (Inherited: 0x00)
struct FKSActiveEmotePropInfo {
	struct FGuid EmotePropGuid; // 0x00(0x10)
	struct TWeakObjectPtr<struct UMeshComponent> SpawnedEmotePropMeshComponent; // 0x10(0x08)
};

// ScriptStruct Killstreak.KSTargetingModuleInfo
// Size: 0x28 (Inherited: 0x00)
struct FKSTargetingModuleInfo {
	struct FName Key; // 0x00(0x08)
	struct UKSWeaponTargetingModule* TargetingModuleClass; // 0x08(0x08)
	struct TArray<struct FKSTargetingStateValidator> TargetingStateValidators; // 0x10(0x10)
	struct UKSWeaponTargetingModule* TargetingModuleInstance; // 0x20(0x08)
};

// ScriptStruct Killstreak.KSTargetingStateValidator
// Size: 0x04 (Inherited: 0x00)
struct FKSTargetingStateValidator {
	bool bAnyWeaponState; // 0x00(0x01)
	bool bAnyCharacterAimMode; // 0x01(0x01)
	enum class EWeaponStateNew WeaponState; // 0x02(0x01)
	enum class EKSCharacterAimMode CharacterAimMode; // 0x03(0x01)
};

// ScriptStruct Killstreak.KSProjectileTargetingStateValidator
// Size: 0x04 (Inherited: 0x00)
struct FKSProjectileTargetingStateValidator {
	bool bAnyWeaponState; // 0x00(0x01)
	bool bAnyCharacterAimMode; // 0x01(0x01)
	enum class EWeaponStateNew WeaponState; // 0x02(0x01)
	enum class EKSCharacterAimMode CharacterAimMode; // 0x03(0x01)
};

// ScriptStruct Killstreak.KSProjectileWeaponInfo
// Size: 0x58 (Inherited: 0x00)
struct FKSProjectileWeaponInfo {
	struct FName Key; // 0x00(0x08)
	struct TSoftClassPtr<UObject> SoftProjectileClass; // 0x08(0x28)
	struct TSoftObjectPtr<UKSWeaponAsset> SoftWeaponAsset; // 0x30(0x28)
};

// ScriptStruct Killstreak.KSProjectileClusterSegment
// Size: 0x38 (Inherited: 0x00)
struct FKSProjectileClusterSegment {
	struct AKSProjectile* ProjectileClass; // 0x00(0x08)
	struct UKSWeaponAsset* WeaponAsset; // 0x08(0x08)
	struct FVector SpawnOffset; // 0x10(0x0c)
	struct FRotator InitialRotation; // 0x1c(0x0c)
	struct FVector Direction; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct Killstreak.KSCinematicData
// Size: 0x38 (Inherited: 0x00)
struct FKSCinematicData {
	struct FText CinematicDisplayName; // 0x00(0x18)
	struct FString CinematicSubLevelName; // 0x18(0x10)
	enum class EKSLevelStreamingMethod CinematicLevelStreamingMethod; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FName DefaultCameraTag; // 0x2c(0x08)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct Killstreak.KSFootprintInfo
// Size: 0x30 (Inherited: 0x00)
struct FKSFootprintInfo {
	struct FTimerHandle FootprintTimerHandle; // 0x00(0x08)
	struct TWeakObjectPtr<struct UPoolableDecalComponent> FootprintPoolableDecalComponent; // 0x08(0x08)
	int32_t FootprintId; // 0x10(0x04)
	struct FVector FootprintLocation; // 0x14(0x0c)
	struct FRotator FootprintRotation; // 0x20(0x0c)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct Killstreak.KSRespawnConfig
// Size: 0x18 (Inherited: 0x00)
struct FKSRespawnConfig {
	enum class EKSRespawnMode RespawnMode; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t TotalRespawns; // 0x04(0x04)
	int32_t PersonalRespawns; // 0x08(0x04)
	float RespawnTime; // 0x0c(0x04)
	bool WaveRespawn; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t CostPerRespawn; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSCharacterGender
// Size: 0x02 (Inherited: 0x00)
struct FKSCharacterGender {
	enum class EKSCharacterGender Apparel; // 0x00(0x01)
	enum class EKSCharacterGender Vocal; // 0x01(0x01)
};

// ScriptStruct Killstreak.KSOutlineParameters
// Size: 0x38 (Inherited: 0x00)
struct FKSOutlineParameters {
	enum class EPlayerSilhouetteType ColorType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FLinearColor OutlineColor; // 0x04(0x10)
	struct FLinearColor FillColor; // 0x14(0x10)
	float OutlineThickness; // 0x24(0x04)
	bool bShouldFill; // 0x28(0x01)
	bool bHideWhenOccluded; // 0x29(0x01)
	bool bShowOnlyWhileOccluded; // 0x2a(0x01)
	bool bIsHot; // 0x2b(0x01)
	bool bIsFriendly; // 0x2c(0x01)
	bool bCutoutOtherOutlines; // 0x2d(0x01)
	char pad_2E[0x2]; // 0x2e(0x02)
	float OutlineZFadeMin; // 0x30(0x04)
	float OutlineZFadeMax; // 0x34(0x04)
};

// ScriptStruct Killstreak.KSInitialLoadout
// Size: 0x10 (Inherited: 0x00)
struct FKSInitialLoadout {
	struct TArray<struct UKSItem*> LoadoutItems; // 0x00(0x10)
};

// ScriptStruct Killstreak.KSInitialInventoryItem
// Size: 0x20 (Inherited: 0x00)
struct FKSInitialInventoryItem {
	struct FGameplayTag EquipPoint; // 0x00(0x08)
	struct UKSItem* ItemAsset; // 0x08(0x08)
	struct TArray<struct UKSWeaponAttachment*> Attachments; // 0x10(0x10)
};

// ScriptStruct Killstreak.KSInitialInventoryTableEntry
// Size: 0x40 (Inherited: 0x00)
struct FKSInitialInventoryTableEntry {
	struct FGameplayTag EquipPoint; // 0x00(0x08)
	struct TSoftObjectPtr<UKSItem> ItemAsset; // 0x08(0x28)
	struct TArray<struct TSoftObjectPtr<UKSWeaponAttachment>> Attachments; // 0x30(0x10)
};

// ScriptStruct Killstreak.ReplicatedViewInfo
// Size: 0x08 (Inherited: 0x00)
struct FReplicatedViewInfo {
	float Pitch; // 0x00(0x04)
	float Yaw; // 0x04(0x04)
};

// ScriptStruct Killstreak.ObjectiveState
// Size: 0x14 (Inherited: 0x00)
struct FObjectiveState {
	struct FName CurrentState; // 0x00(0x08)
	struct FName PreviousState; // 0x08(0x08)
	int32_t Owner; // 0x10(0x04)
};

// ScriptStruct Killstreak.SkeletalMeshMaterialToReductionGroup
// Size: 0x18 (Inherited: 0x00)
struct FSkeletalMeshMaterialToReductionGroup {
	struct FString NameToMatch; // 0x00(0x10)
	int32_t ReductionGroup; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Killstreak.KSRiderSeatPair
// Size: 0x10 (Inherited: 0x00)
struct FKSRiderSeatPair {
	struct AKSCharacter* Rider; // 0x00(0x08)
	struct UKSVehicleSeatComponent* Seat; // 0x08(0x08)
};

// ScriptStruct Killstreak.KSVehicleDestructionStage
// Size: 0x60 (Inherited: 0x00)
struct FKSVehicleDestructionStage {
	struct UParticleSystem* StageVFX; // 0x00(0x08)
	struct UAkAudioEvent* StageSFX; // 0x08(0x08)
	struct UAkAudioEvent* StageEcho; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct FTransform StageEffectTransform; // 0x20(0x30)
	float StageDeteriorationRate; // 0x50(0x04)
	char pad_54[0xc]; // 0x54(0x0c)
};

// ScriptStruct Killstreak.KSVehicleDeathInfo
// Size: 0x20 (Inherited: 0x00)
struct FKSVehicleDeathInfo {
	enum class EKSVehicleDeathState DeathState; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UDamageType* DamageType; // 0x08(0x08)
	struct FVector DamageDirection; // 0x10(0x0c)
	float FinalBlowDamage; // 0x1c(0x04)
};

// ScriptStruct Killstreak.KSVehicleOutOfBoundsInfo
// Size: 0x08 (Inherited: 0x00)
struct FKSVehicleOutOfBoundsInfo {
	bool bOutOfBounds; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float WarningLength; // 0x04(0x04)
};

// ScriptStruct Killstreak.PendingCosmeticInfo
// Size: 0x20 (Inherited: 0x00)
struct FPendingCosmeticInfo {
	char Slot; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UKSWeaponAttachment* DesiredAttachment; // 0x08(0x08)
	struct FKSEquipmentId AttachmentId; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct UKSWeaponAttachmentCosmeticInst* CosmeticInstance; // 0x18(0x08)
};

// ScriptStruct Killstreak.PriorityVoiceLine
// Size: 0x18 (Inherited: 0x00)
struct FPriorityVoiceLine {
	enum class EKSVoiceOverState State; // 0x00(0x01)
	enum class EKSVoiceOverPriority Priority; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TScriptInterface<IKSVoiceActor> Source; // 0x08(0x10)
};

// ScriptStruct Killstreak.WaveBotTableRow
// Size: 0x1a8 (Inherited: 0x198)
struct FWaveBotTableRow : FBotSpawnTableRow {
	float fSelectionWeight; // 0x198(0x04)
	float fAutoSpawnCostMultiplier; // 0x19c(0x04)
	int32_t nMaxInstancesPerWave; // 0x1a0(0x04)
	enum class ECharacterBehaviorState InitialBehaviorState; // 0x1a4(0x01)
	bool bPermanentlyRevealed; // 0x1a5(0x01)
	char pad_1A6[0x2]; // 0x1a6(0x02)
};

// ScriptStruct Killstreak.KSWayPointLink
// Size: 0x20 (Inherited: 0x00)
struct FKSWayPointLink {
	struct TArray<struct AKSWayPoint*> NextWayPoints; // 0x00(0x10)
	struct TArray<struct AKSWayPoint*> PrevWayPoints; // 0x10(0x10)
};

// ScriptStruct Killstreak.AuxiliaryWeaponInfo
// Size: 0x10 (Inherited: 0x00)
struct FAuxiliaryWeaponInfo {
	struct FName AuxiliarySlot; // 0x00(0x08)
	struct AKSWeapon* ParentWeapon; // 0x08(0x08)
};

// ScriptStruct Killstreak.HitValidationRecoveryInfo
// Size: 0x60 (Inherited: 0x00)
struct FHitValidationRecoveryInfo {
	struct TArray<struct FKSCompressedHit> Hits; // 0x00(0x10)
	struct FAimData AimData; // 0x10(0x50)
};

// ScriptStruct Killstreak.WeaponLeadingInfo
// Size: 0x10 (Inherited: 0x00)
struct FWeaponLeadingInfo {
	float fMaxWeaponLeading; // 0x00(0x04)
	float fWeaponLeadingSmoothingFactor; // 0x04(0x04)
	float fWeaponLeadingInterpSpeed; // 0x08(0x04)
	float fWeaponLeadingRecoverInterpSpeed; // 0x0c(0x04)
};

// ScriptStruct Killstreak.ADSBlurValues
// Size: 0x30 (Inherited: 0x00)
struct FADSBlurValues {
	bool AdsBlurDisabled; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float BlurDistance; // 0x04(0x04)
	float MaskExponential; // 0x08(0x04)
	float HardnessOfMask; // 0x0c(0x04)
	float SphereMaskRadius; // 0x10(0x04)
	float SphereMaskScaleX; // 0x14(0x04)
	float SphereMaskScaleY; // 0x18(0x04)
	bool EnableCubeMask; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	float CubeMaskPosX; // 0x20(0x04)
	float CubeMaskPosY; // 0x24(0x04)
	float CubeMaskScaleX; // 0x28(0x04)
	float CubeMaskScaleY; // 0x2c(0x04)
};

// ScriptStruct Killstreak.KSWeaponDropAttachmentContainer
// Size: 0x128 (Inherited: 0x108)
struct FKSWeaponDropAttachmentContainer : FFastArraySerializer {
	struct TArray<struct FKSWeaponDropAttachmentContainerEntry> Attachments; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
	struct AKSWeaponAssetDrop* Owner; // 0x120(0x08)
};

// ScriptStruct Killstreak.KSWeaponDropAttachmentContainerEntry
// Size: 0x38 (Inherited: 0x0c)
struct FKSWeaponDropAttachmentContainerEntry : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct UKSWeaponAttachment* Attachment; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct FGameplayTag ReplicatedAttachPoint; // 0x20(0x08)
	char pad_28[0xc]; // 0x28(0x0c)
	uint16_t ExtraInfo; // 0x34(0x02)
	char pad_36[0x2]; // 0x36(0x02)
};

// ScriptStruct Killstreak.ReactiveWrapMilestoneDisplay
// Size: 0x30 (Inherited: 0x00)
struct FReactiveWrapMilestoneDisplay {
	struct FText PreviewMilestoneDescription; // 0x00(0x18)
	float TargetProgressionValueA; // 0x18(0x04)
	float TransitionSpeedA; // 0x1c(0x04)
	float TargetProgressionValueB; // 0x20(0x04)
	float TransitionSpeedB; // 0x24(0x04)
	float TargetProgressionValueC; // 0x28(0x04)
	float TransitionSpeedC; // 0x2c(0x04)
};

// ScriptStruct Killstreak.LoadedWeaponAttachmentAnimationData
// Size: 0xb0 (Inherited: 0x00)
struct FLoadedWeaponAttachmentAnimationData {
	struct USkeletalMesh* WeaponAttachmentMesh; // 0x00(0x08)
	struct UAnimSequence* WeaponAttachmentSequence; // 0x08(0x08)
	struct UAnimMontage* Player3PHolsterMontage; // 0x10(0x08)
	struct UAnimMontage* Player3PRetrieveMontage; // 0x18(0x08)
	struct UAnimMontage* Player3PFireMontage; // 0x20(0x08)
	struct UAnimMontage* Player3PReloadMontage; // 0x28(0x08)
	struct UAimOffsetBlendSpace* Player3PStandingAimOffset; // 0x30(0x08)
	struct UAimOffsetBlendSpace* Player3PCrouchedAimOffset; // 0x38(0x08)
	struct UBlendSpace* Player3PStandingBlendSpace; // 0x40(0x08)
	struct UBlendSpace* Player3PCrouchedBlendSpace; // 0x48(0x08)
	struct UAnimSequence* Player3PStandingIdleSequence; // 0x50(0x08)
	struct UAnimSequence* Player3PCrouchedIdleSequence; // 0x58(0x08)
	struct UAnimMontage* Player1PFireMontage; // 0x60(0x08)
	struct UBlendSpace* Player1PStandingBlendSpace; // 0x68(0x08)
	struct UBlendSpace* Player1PCrouchedBlendSpace; // 0x70(0x08)
	struct UAimOffsetBlendSpace* Player1PStandingAimOffset; // 0x78(0x08)
	struct UAnimMontage* Player1PRetrieveMontage; // 0x80(0x08)
	struct UAnimMontage* Player1PReloadMontage; // 0x88(0x08)
	struct UCameraShake* Player1PCameraShake; // 0x90(0x08)
	struct UCameraShake* Player1PADSCameraShake; // 0x98(0x08)
	struct UAnimSequence* Player1PAdditiveStandGunPose; // 0xa0(0x08)
	struct UAnimSequence* Player1PAdditiveCrouchGunPose; // 0xa8(0x08)
};

// ScriptStruct Killstreak.WeaponAttachmentAnimationData
// Size: 0x3a8 (Inherited: 0x08)
struct FWeaponAttachmentAnimationData : FTableRowBase {
	bool bUseDefaultIfNone; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TSoftObjectPtr<UKSWeaponAsset> WeaponAsset; // 0x10(0x28)
	struct TSoftObjectPtr<USkeletalMesh> WeaponAttachmentMesh; // 0x38(0x28)
	struct TSoftObjectPtr<UAnimSequence> WeaponAttachmentSequence; // 0x60(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player3PHolsterMontage; // 0x88(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player3PRetrieveMontage; // 0xb0(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player3PFireMontage; // 0xd8(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player3PReloadMontage; // 0x100(0x28)
	struct TSoftObjectPtr<UAimOffsetBlendSpace> Player3PStandingAimOffset; // 0x128(0x28)
	struct TSoftObjectPtr<UAimOffsetBlendSpace> Player3PCrouchedAimOffset; // 0x150(0x28)
	struct TSoftObjectPtr<UBlendSpace> Player3PStandingBlendSpace; // 0x178(0x28)
	struct TSoftObjectPtr<UBlendSpace> Player3PCrouchedBlendSpace; // 0x1a0(0x28)
	struct TSoftObjectPtr<UAnimSequence> Player3PStandingIdleSequence; // 0x1c8(0x28)
	struct TSoftObjectPtr<UAnimSequence> Player3PCrouchedIdleSequence; // 0x1f0(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player1PFireMontage; // 0x218(0x28)
	struct TSoftObjectPtr<UBlendSpace> Player1PStandingBlendSpace; // 0x240(0x28)
	struct TSoftObjectPtr<UBlendSpace> Player1PCrouchedBlendSpace; // 0x268(0x28)
	struct TSoftObjectPtr<UAimOffsetBlendSpace> Player1PStandingAimOffset; // 0x290(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player1PRetrieveMontage; // 0x2b8(0x28)
	struct TSoftObjectPtr<UAnimMontage> Player1PReloadMontage; // 0x2e0(0x28)
	struct TSoftClassPtr<UObject> Player1PCameraShake; // 0x308(0x28)
	struct TSoftClassPtr<UObject> Player1PADSCameraShake; // 0x330(0x28)
	struct TSoftObjectPtr<UAnimSequence> Player1PAdditiveStandGunPose; // 0x358(0x28)
	struct TSoftObjectPtr<UAnimSequence> Player1PAdditiveCrouchGunPose; // 0x380(0x28)
};

// ScriptStruct Killstreak.KSAssetOverrideTable_TableRow
// Size: 0xa8 (Inherited: 0x08)
struct FKSAssetOverrideTable_TableRow : FTableRowBase {
	struct TSoftObjectPtr<UKSWeaponAsset> WeaponAsset; // 0x08(0x28)
	struct TSoftObjectPtr<UDataTable> WeaponSpecificOverrideTable; // 0x30(0x28)
	int32_t TablePriority; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FGameplayTagQuery SkinTagQuery; // 0x60(0x48)
};

// ScriptStruct Killstreak.PrefireSkipWindow
// Size: 0x28 (Inherited: 0x00)
struct FPrefireSkipWindow {
	float WindowDuration; // 0x00(0x04)
	float WindowExpiration; // 0x04(0x04)
	struct FString LungeMontageSequence; // 0x08(0x10)
	struct FString TargetMontageSequence; // 0x18(0x10)
};

// ScriptStruct Killstreak.BundledAmmoInfo
// Size: 0x0c (Inherited: 0x00)
struct FBundledAmmoInfo {
	enum class EBundledAmmoType BundleType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t ReserveAmmo; // 0x04(0x04)
	int32_t AmmoInClip; // 0x08(0x04)
};

// ScriptStruct Killstreak.KSEquipRepInfo
// Size: 0x14 (Inherited: 0x00)
struct FKSEquipRepInfo {
	bool NoEquipPoint; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag EquipPoint; // 0x04(0x08)
	uint32_t UpdateId; // 0x0c(0x04)
	struct FKSEquipmentId ComponentId; // 0x10(0x04)
};

// ScriptStruct Killstreak.InventoryRestoreInfo
// Size: 0x10 (Inherited: 0x00)
struct FInventoryRestoreInfo {
	struct FGameplayTag EquipPoint; // 0x00(0x08)
	struct UKSItem* Item; // 0x08(0x08)
};

// ScriptStruct Killstreak.WeaponStateGraph
// Size: 0x140 (Inherited: 0x00)
struct FWeaponStateGraph {
	char pad_0[0x140]; // 0x00(0x140)
};

// ScriptStruct Killstreak.WeaponGraphEdge
// Size: 0x02 (Inherited: 0x00)
struct FWeaponGraphEdge {
	enum class EWeaponStateNew OldState; // 0x00(0x01)
	enum class EWeaponStateNew NewState; // 0x01(0x01)
};

// ScriptStruct Killstreak.FullFireRepData
// Size: 0x68 (Inherited: 0x00)
struct FFullFireRepData {
	struct FAimData Aim; // 0x00(0x50)
	bool bIgnoreExtraData; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	struct FRandomStream RandomStream; // 0x54(0x08)
	float Accuracy; // 0x5c(0x04)
	char AmmoAfterThisShot; // 0x60(0x01)
	bool bIgnoreAmmo; // 0x61(0x01)
	char pad_62[0x6]; // 0x62(0x06)
};

// ScriptStruct Killstreak.AncillaryWeaponMeshInfo
// Size: 0x18 (Inherited: 0x00)
struct FAncillaryWeaponMeshInfo {
	struct USkeletalMesh* Mesh; // 0x00(0x08)
	struct FName DefaultAttachSocket; // 0x08(0x08)
	struct FName DefaultDetachSocket; // 0x10(0x08)
};

// ScriptStruct Killstreak.HitDecalInfo
// Size: 0x28 (Inherited: 0x00)
struct FHitDecalInfo {
	struct UMaterialInterface* DecalMaterial; // 0x00(0x08)
	struct FVector Size; // 0x08(0x0c)
	float MinimumScaling; // 0x14(0x04)
	float MaximumScaling; // 0x18(0x04)
	float MinimumAngle; // 0x1c(0x04)
	float MaximumAngle; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct Killstreak.WeaponMasteryRewardDisplayData
// Size: 0x98 (Inherited: 0x00)
struct FWeaponMasteryRewardDisplayData {
	struct FText Name; // 0x00(0x18)
	struct FText Description; // 0x18(0x18)
	struct TSoftObjectPtr<UTexture2D> SoftIcon; // 0x30(0x28)
	struct FGameplayTag RarityTag; // 0x58(0x08)
	struct FText ItemTypeText; // 0x60(0x18)
	enum class EWeaponMasteryRewardGroup RewardGroup; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	int32_t DisplayQuantity; // 0x7c(0x04)
	bool AlreadyOwned; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct UPUMG_StoreItem* PreviewStoreItem; // 0x88(0x08)
	enum class EWeaponMasteryRewardPreviewType RewardPreviewType; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// ScriptStruct Killstreak.MiscRewardsTableRow
// Size: 0x58 (Inherited: 0x08)
struct FMiscRewardsTableRow : FTableRowBase {
	struct TMap<int32_t, struct FMasteryMiscRewardContainer> MiscRewardsByLevel; // 0x08(0x50)
};

// ScriptStruct Killstreak.MasteryMiscRewardContainer
// Size: 0x10 (Inherited: 0x00)
struct FMasteryMiscRewardContainer {
	struct TArray<struct UKSMasteryMiscReward*> MiscRewards; // 0x00(0x10)
};

// ScriptStruct Killstreak.LegacyWeaponProp
// Size: 0xf0 (Inherited: 0x00)
struct FLegacyWeaponProp {
	char pad_0[0x10]; // 0x00(0x10)
	struct FLobbySkeletalPropInfo LegacyInfo; // 0x10(0x80)
	char pad_90[0x8]; // 0x90(0x08)
	struct USkinnableSkeletalMeshComponent* MeshComp; // 0x98(0x08)
	char pad_A0[0x50]; // 0xa0(0x50)
};

// ScriptStruct Killstreak.LobbySkeletalPropInfo
// Size: 0x80 (Inherited: 0x00)
struct FLobbySkeletalPropInfo {
	bool Enable; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSoftObjectPath WeaponAsset; // 0x08(0x18)
	struct FName AttachPoint; // 0x20(0x08)
	struct UAnimInstance* AnimInstance; // 0x28(0x08)
	struct UAnimMontage* Montage; // 0x30(0x08)
	int32_t TargetLOD; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FTransform TransformOffset; // 0x40(0x30)
	int32_t WeaponAnimIndex; // 0x70(0x04)
	char pad_74[0xc]; // 0x74(0x0c)
};

// ScriptStruct Killstreak.ActiveWeaponProp
// Size: 0x90 (Inherited: 0x00)
struct FActiveWeaponProp {
	char pad_0[0x88]; // 0x00(0x88)
	struct USkinnableSkeletalMeshComponent* MeshComp; // 0x88(0x08)
};

// ScriptStruct Killstreak.WeaponStateChangeRequest
// Size: 0x10 (Inherited: 0x00)
struct FWeaponStateChangeRequest {
	uint16_t RequestID; // 0x00(0x02)
	bool bChangeWeaponState; // 0x02(0x01)
	enum class EWeaponStateNew PreviousState; // 0x03(0x01)
	enum class EWeaponStateNew NextState; // 0x04(0x01)
	bool bChangeWeaponAimMode; // 0x05(0x01)
	enum class EKSCharacterAimMode AimMode; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
	struct FRandomStream RandomStream; // 0x08(0x08)
};

// ScriptStruct Killstreak.TargetingModuleTickFunction
// Size: 0x30 (Inherited: 0x28)
struct FTargetingModuleTickFunction : FTickFunction {
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct Killstreak.LoadingScreenImageInfo
// Size: 0x70 (Inherited: 0x00)
struct FLoadingScreenImageInfo {
	struct TSoftObjectPtr<UTexture2D> LoadingScreenImage; // 0x00(0x28)
	struct FText MapDisplayName; // 0x28(0x18)
	struct FText MapRegion; // 0x40(0x18)
	struct FText MapDescription; // 0x58(0x18)
};

// ScriptStruct Killstreak.LobbyStaticPropInfo
// Size: 0x50 (Inherited: 0x00)
struct FLobbyStaticPropInfo {
	bool Enable; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName AttachPoint; // 0x04(0x08)
	char pad_C[0x4]; // 0x0c(0x04)
	struct UStaticMesh* StaticMesh; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct FTransform TransformOffset; // 0x20(0x30)
};

// ScriptStruct Killstreak.MultiPlayerSkinMapReplicator
// Size: 0x1d8 (Inherited: 0x108)
struct FMultiPlayerSkinMapReplicator : FFastArraySerializer {
	struct TArray<struct FMultiSkinMapReplicatorEntry> RepItems; // 0x108(0x10)
	struct TMap<struct FKSPersistentPlayerId, struct FPlayerSkinMap> PlayerSkinMaps; // 0x118(0x50)
	char pad_168[0x70]; // 0x168(0x70)
};

// ScriptStruct Killstreak.PlayerSkinMap
// Size: 0x78 (Inherited: 0x00)
struct FPlayerSkinMap {
	struct FKSPersistentPlayerId PlayerId; // 0x00(0x10)
	struct TMap<struct UKSItem*, struct UKSItem*> SkinMap; // 0x10(0x50)
	char pad_60[0x18]; // 0x60(0x18)
};

// ScriptStruct Killstreak.MultiSkinMapReplicatorEntry
// Size: 0x30 (Inherited: 0x0c)
struct FMultiSkinMapReplicatorEntry : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct FKSPersistentPlayerId PlayerId; // 0x10(0x10)
	struct UKSItem* Item; // 0x20(0x08)
	struct UKSItem* Skin; // 0x28(0x08)
};

// ScriptStruct Killstreak.SkinMapReplicator
// Size: 0x188 (Inherited: 0x108)
struct FSkinMapReplicator : FFastArraySerializer {
	struct TArray<struct FSingleSkinMapReplicatorEntry> RepItems; // 0x108(0x10)
	struct TMap<struct UKSItem*, struct UKSItem*> SkinMap; // 0x118(0x50)
	char pad_168[0x20]; // 0x168(0x20)
};

// ScriptStruct Killstreak.SingleSkinMapReplicatorEntry
// Size: 0x20 (Inherited: 0x0c)
struct FSingleSkinMapReplicatorEntry : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct UKSItem* Item; // 0x10(0x08)
	struct UKSItem* Skin; // 0x18(0x08)
};

// ScriptStruct Killstreak.TimelineSimulationHandler
// Size: 0x14 (Inherited: 0x00)
struct FTimelineSimulationHandler {
	float ServerTimeStamp; // 0x00(0x04)
	float ErrorTolerance; // 0x04(0x04)
	char bLooping : 1; // 0x08(0x01)
	char bReversePlayback : 1; // 0x08(0x01)
	char bPlaying : 1; // 0x08(0x01)
	char pad_8_3 : 5; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float PlayRate; // 0x0c(0x04)
	float Position; // 0x10(0x04)
};

// ScriptStruct Killstreak.SoftDataTableInfo
// Size: 0x78 (Inherited: 0x00)
struct FSoftDataTableInfo {
	struct TSoftObjectPtr<UDataTable> DataTable; // 0x00(0x28)
	int32_t TablePriority; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FGameplayTagQuery SkinTagQuery; // 0x30(0x48)
};

// ScriptStruct Killstreak.ActiveThermalPPComponentInfo
// Size: 0x10 (Inherited: 0x00)
struct FActiveThermalPPComponentInfo {
	struct UThermalScopePPComponent* ThermalPPComponent; // 0x00(0x08)
	struct AKSPlayerCameraManager* PlayerCameraManager; // 0x08(0x08)
};

// ScriptStruct Killstreak.TraceCommonEmpty
// Size: 0x01 (Inherited: 0x00)
struct FTraceCommonEmpty {
	char pad_0[0x1]; // 0x00(0x01)
};

