// BlueprintGeneratedClass EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C
// Size: 0x214 (Inherited: 0x208)
struct UEventTracker_Conditional_Purchase_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	int32_t CashSpent; // 0x210(0x04)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnShopItemPurchased(struct FShopItem ShopItem); // Function EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C.OnShopItemPurchased // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnShopItemRefunded(struct FShopItem ShopItem); // Function EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C.OnShopItemRefunded // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Conditional_Purchase(int32_t EntryPoint); // Function EventTracker_Conditional_Purchase.EventTracker_Conditional_Purchase_C.ExecuteUbergraph_EventTracker_Conditional_Purchase // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

