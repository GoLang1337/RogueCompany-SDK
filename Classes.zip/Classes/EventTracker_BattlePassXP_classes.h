// BlueprintGeneratedClass EventTracker_BattlePassXP.EventTracker_BattlePassXP_C
// Size: 0x240 (Inherited: 0x208)
struct UEventTracker_BattlePassXP_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	struct AKSPlayerState* PlayerState; // 0x210(0x08)
	float BaseProgress; // 0x218(0x04)
	float AccumulatedProgress; // 0x21c(0x04)
	float XpPerMinute; // 0x220(0x04)
	float PremiumBoostMultiplier; // 0x224(0x04)
	float WinMultiplier; // 0x228(0x04)
	char pad_22C[0x4]; // 0x22c(0x04)
	struct FString BonusKey; // 0x230(0x10)

	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessEventBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessWinBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessQueueBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessBoosterBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ComputeBaseProgress // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_BattlePassXP(int32_t EntryPoint); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ExecuteUbergraph_EventTracker_BattlePassXP // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

