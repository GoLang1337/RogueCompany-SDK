// WidgetBlueprintGeneratedClass LoggedInProcessRewards.LoggedInProcessRewards_C
// Size: 0x530 (Inherited: 0x518)
struct ULoggedInProcessRewards_C : UKSLoginProcessRewards {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UImage* background; // 0x520(0x08)
	struct UWBP_ThrobberShield_C* WBP_ThrobberShield; // 0x528(0x08)

	void OnShown(); // Function LoggedInProcessRewards.LoggedInProcessRewards_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoggedInProcessRewards(int32_t EntryPoint); // Function LoggedInProcessRewards.LoggedInProcessRewards_C.ExecuteUbergraph_LoggedInProcessRewards // (Final|UbergraphFunction) // @ game+0x24d5b40
};

