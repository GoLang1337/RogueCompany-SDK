// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C
// Size: 0x40 (Inherited: 0x38)
struct UActivityBehavior_ResetAccumulationOnRoundStart_C : UKSActivityBehavior {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x38(0x08)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.HandleBehaviorInitialized // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleRoundStart(struct FRoundInitState& RoundInitState); // Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.HandleRoundStart // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRoundStart(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRoundStart // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

