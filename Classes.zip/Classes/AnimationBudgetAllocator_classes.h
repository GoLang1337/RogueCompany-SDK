// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0xc21ca0
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget // (Final|Native|Static|Private|BlueprintCallable) // @ game+0xc21be0
};

// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xbb0 (Inherited: 0xb90)
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	char pad_B90[0x18]; // 0xb90(0x18)
	char bAutoRegisterWithBudgetAllocator : 1; // 0xba8(0x01)
	char bAutoCalculateSignificance : 1; // 0xba8(0x01)
	char bShouldUseActorRenderedFlag : 1; // 0xba8(0x01)
	char pad_BA8_3 : 5; // 0xba8(0x01)
	char pad_BA9[0x7]; // 0xba9(0x07)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator // (Final|Native|Public|BlueprintCallable) // @ game+0xc21e40
};

