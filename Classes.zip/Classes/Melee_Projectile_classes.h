// BlueprintGeneratedClass Melee_Projectile.Melee_Projectile_C
// Size: 0x988 (Inherited: 0x938)
struct AMelee_Projectile_C : AKSProjectile_Melee {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x938(0x08)
	struct UParticleSystemComponent* Trail; // 0x940(0x08)
	struct USphereComponent* NearMissOverlap; // 0x948(0x08)
	struct UDecalSpawner_C* DecalSpawner; // 0x950(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x958(0x08)
	struct UAkAudioEvent* ImpactSFX; // 0x960(0x08)
	struct UAkAudioEvent* WhizByAudio; // 0x968(0x08)
	bool bIsStopped; // 0x970(0x01)
	char pad_971[0x3]; // 0x971(0x03)
	struct FRotator InitialMeshRotation; // 0x974(0x0c)
	struct UAkAudioEvent* ProjStopAudio; // 0x980(0x08)

	void GetStoppingRotation(struct FHitResult StoppingHit, struct FRotator& Rotator); // Function Melee_Projectile.Melee_Projectile_C.GetStoppingRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x24d5b40
	void SetWeaponComponentSpinRotation(); // Function Melee_Projectile.Melee_Projectile_C.SetWeaponComponentSpinRotation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void FixupWeaponComponent(); // Function Melee_Projectile.Melee_Projectile_C.FixupWeaponComponent // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct USceneComponent* GetComponentToRotate(); // Function Melee_Projectile.Melee_Projectile_C.GetComponentToRotate // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	void PlayImpactSFX(struct FHitResult Hit Result); // Function Melee_Projectile.Melee_Projectile_C.PlayImpactSFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void TryPlayNearMissSound(struct AActor* OverlapActor); // Function Melee_Projectile.Melee_Projectile_C.TryPlayNearMissSound // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayStoppedEffect(struct FHitResult HitResult); // Function Melee_Projectile.Melee_Projectile_C.PlayStoppedEffect // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GetCollisionRadius(float& Radius); // Function Melee_Projectile.Melee_Projectile_C.GetCollisionRadius // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool OnProjectileStopped(struct FHitResult& HitResult); // Function Melee_Projectile.Melee_Projectile_C.OnProjectileStopped // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveTick(float DeltaSeconds); // Function Melee_Projectile.Melee_Projectile_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__CollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function Melee_Projectile.Melee_Projectile_C.BndEvt__CollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function Melee_Projectile.Melee_Projectile_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__NearMissOverlap_K2Node_ComponentBoundEvent_0_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function Melee_Projectile.Melee_Projectile_C.BndEvt__NearMissOverlap_K2Node_ComponentBoundEvent_0_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void InitializeRealActor(); // Function Melee_Projectile.Melee_Projectile_C.InitializeRealActor // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void OnTakeOverAsRealActor(); // Function Melee_Projectile.Melee_Projectile_C.OnTakeOverAsRealActor // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void UpdateSpinRotation(float DeltaSeconds); // Function Melee_Projectile.Melee_Projectile_C.UpdateSpinRotation // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_Melee_Projectile(int32_t EntryPoint); // Function Melee_Projectile.Melee_Projectile_C.ExecuteUbergraph_Melee_Projectile // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

