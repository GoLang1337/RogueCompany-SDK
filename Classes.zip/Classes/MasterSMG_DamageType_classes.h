// BlueprintGeneratedClass MasterSMG_DamageType.MasterSMG_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UMasterSMG_DamageType_C : UMasterGun_DamageType_C {
};

