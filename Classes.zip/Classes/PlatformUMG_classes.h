// Class PlatformUMG.PUMG_AcquisitionManager
// Size: 0x50 (Inherited: 0x28)
struct UPUMG_AcquisitionManager : UObject {
	struct FMulticastInlineDelegate OnAcquisitionSuccess; // 0x28(0x10)
	struct FMulticastInlineDelegate OnAcquisitionFailed; // 0x38(0x10)
	struct UPUMG_StoreItemHelper* StoreItemHelper; // 0x48(0x08)
};

// Class PlatformUMG.PUMG_AsyncImage
// Size: 0x260 (Inherited: 0x218)
struct UPUMG_AsyncImage : UImage {
	struct UWidget* WaitingWidget; // 0x218(0x08)
	struct FMulticastInlineDelegate OnAsyncImageLoadStarted; // 0x220(0x10)
	struct FMulticastInlineDelegate OnAsyncImageLoadComplete; // 0x230(0x10)
	struct FMulticastInlineDelegate OnAsyncImageLoadCanceled; // 0x240(0x10)
	struct FMulticastInlineDelegate OnAsyncImageBrushChanged; // 0x250(0x10)

	void ShowWaitingWidget(); // Function PlatformUMG.PUMG_AsyncImage.ShowWaitingWidget // (Native|Event|Public|BlueprintEvent) // @ game+0xb44290
	void HideWaitingWidget(); // Function PlatformUMG.PUMG_AsyncImage.HideWaitingWidget // (Native|Event|Public|BlueprintEvent) // @ game+0xb43a20
};

// Class PlatformUMG.PUMG_BlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPUMG_BlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsWithEditor(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.IsWithEditor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb43c30
	float GetUMG_DPI_Scaling(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetUMG_DPI_Scaling // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb43990
	struct FName GetKeyName(struct FKey Key); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetKeyName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb436e0
	struct FKey GetGamepadConfirmButton(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetGamepadConfirmButton // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb43670
	struct FKey GetGamepadCancelButton(); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetGamepadCancelButton // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb43600
	bool GetGamepadButtonForAction(struct FName Action, struct FKey& Button); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetGamepadButtonForAction // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb434f0
	bool GetButtonForActionMappingUsingWidget(struct UWidget* InWidget, struct FName Action, struct FKey& Button); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetButtonForActionMappingUsingWidget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb42f10
	bool GetButtonForActionMapping(struct FName Action, struct FKey& Button, bool IsGamepadKey); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetButtonForActionMapping // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb42dc0
	bool GetAllButtonsForActionMappingUsingWidget(struct UWidget* InWidget, struct FName Action, struct TArray<struct FKey>& Buttons); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetAllButtonsForActionMappingUsingWidget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb42c50
	bool GetAllButtonsForActionMapping(struct FName Action, struct TArray<struct FKey>& Buttons, bool IsGamepadKey); // Function PlatformUMG.PUMG_BlueprintFunctionLibrary.GetAllButtonsForActionMapping // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb42ae0
};

// Class PlatformUMG.PUMG_CanvasPanel
// Size: 0x138 (Inherited: 0x138)
struct UPUMG_CanvasPanel : UCanvasPanel {

	void PlaceWidgetUnder(struct UUserWidget* BottomWidget, struct UUserWidget* TopWidget); // Function PlatformUMG.PUMG_CanvasPanel.PlaceWidgetUnder // (Final|Native|Public|BlueprintCallable) // @ game+0xb43d00
};

// Class PlatformUMG.PUMG_DataFactory
// Size: 0x38 (Inherited: 0x28)
struct UPUMG_DataFactory : UObject {
	struct APUMG_HUD* MyHud; // 0x28(0x08)
	char pad_30[0x8]; // 0x30(0x08)

	bool IsLoggedIn(); // Function PlatformUMG.PUMG_DataFactory.IsLoggedIn // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb43a70
};

// Class PlatformUMG.PUMG_ChatDataFactory
// Size: 0x118 (Inherited: 0x38)
struct UPUMG_ChatDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnChatMessageReceived; // 0x38(0x10)
	struct FMulticastInlineDelegate OnChatMessageRead; // 0x48(0x10)
	struct FMulticastInlineDelegate OnChatChannelJoined; // 0x58(0x10)
	struct FMulticastInlineDelegate OnChatChannelLeft; // 0x68(0x10)
	struct TArray<int32_t> ChatMessageIds; // 0x78(0x10)
	struct TArray<int32_t> PendingChatMessageIds; // 0x88(0x10)
	struct TMap<int32_t, struct FPUMG_ChatData> ChatMessagesById; // 0x98(0x50)
	int32_t LastCreatedMessageId; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct TArray<int64_t> m_FilteredPlayerIds; // 0xf0(0x10)
	struct TArray<struct FPUMG_ChatCommand> ChatCommands; // 0x100(0x10)
	char pad_110[0x8]; // 0x110(0x08)

	void SetMaxMessageCount(int32_t MaxMessageCount); // Function PlatformUMG.PUMG_ChatDataFactory.SetMaxMessageCount // (Final|Native|Public|BlueprintCallable) // @ game+0xb44210
	void SendChatToPlayer(struct FString Message, int64_t TargetPlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.SendChatToPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0xb440b0
	void SendChatToChannel(struct FString Message, enum class EPUMG_ChatChannel Channel); // Function PlatformUMG.PUMG_ChatDataFactory.SendChatToChannel // (Final|Native|Public|BlueprintCallable) // @ game+0xb43fd0
	bool RemovePlayerFilter(int64_t PlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.RemovePlayerFilter // (Final|Native|Public|BlueprintCallable) // @ game+0xb43f20
	bool RemoveChatCommand(struct FString Command); // Function PlatformUMG.PUMG_ChatDataFactory.RemoveChatCommand // (Final|Native|Public|BlueprintCallable) // @ game+0xb43e70
	bool RemoveAllChatCommands(struct UObject* Target); // Function PlatformUMG.PUMG_ChatDataFactory.RemoveAllChatCommands // (Final|Native|Public|BlueprintCallable) // @ game+0xb43de0
	void QueueCheckPendingMessages(); // Function PlatformUMG.PUMG_ChatDataFactory.QueueCheckPendingMessages // (Final|Native|Protected) // @ game+0xb43dc0
	void MarkMessageAsRead(int32_t MessageId); // Function PlatformUMG.PUMG_ChatDataFactory.MarkMessageAsRead // (Final|Native|Public|BlueprintCallable) // @ game+0xb43c80
	void ListChatCommands(); // Function PlatformUMG.PUMG_ChatDataFactory.ListChatCommands // (Final|Native|Public|BlueprintCallable) // @ game+0xb43c60
	bool IsValidMessage(struct FPUMG_ChatData& Message); // Function PlatformUMG.PUMG_ChatDataFactory.IsValidMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb43b30
	bool IsPlayerFilteredFromChat(int64_t PlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.IsPlayerFilteredFromChat // (Final|Native|Public|BlueprintCallable) // @ game+0xb43aa0
	void HandleCommunicationSettingChanged(); // Function PlatformUMG.PUMG_ChatDataFactory.HandleCommunicationSettingChanged // (Final|Native|Protected) // @ game+0xb439c0
	struct FPUMG_ChatData GetMessage(int32_t MessageId); // Function PlatformUMG.PUMG_ChatDataFactory.GetMessage // (Final|Native|Public|BlueprintCallable) // @ game+0xb43800
	int32_t GetMaxMessageCount(); // Function PlatformUMG.PUMG_ChatDataFactory.GetMaxMessageCount // (Final|Native|Public|BlueprintCallable) // @ game+0xb437d0
	enum class EPCOM_PrivilegeStatus GetChatPrivilegeStatus(); // Function PlatformUMG.PUMG_ChatDataFactory.GetChatPrivilegeStatus // (Final|Native|Public|BlueprintCallable) // @ game+0xb43060
	void GetActiveChatChannels(bool IncludePersonalChannel, struct TArray<struct FPUMG_ActiveChatChannelData>& ActiveChatChatChannels); // Function PlatformUMG.PUMG_ChatDataFactory.GetActiveChatChannels // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb429e0
	int32_t FindChatCommandIndex(struct FString Command); // Function PlatformUMG.PUMG_ChatDataFactory.FindChatCommandIndex // (Final|Native|Protected) // @ game+0xb42910
	bool ExecuteChatCommandLine(struct FString CommandLine); // Function PlatformUMG.PUMG_ChatDataFactory.ExecuteChatCommandLine // (Final|Native|Public|BlueprintCallable) // @ game+0xb42860
	void CheckPendingMessages(); // Function PlatformUMG.PUMG_ChatDataFactory.CheckPendingMessages // (Final|Native|Protected) // @ game+0xb42840
	void BeginProcessingChatMessage(struct FPUMG_ChatData& Message); // Function PlatformUMG.PUMG_ChatDataFactory.BeginProcessingChatMessage // (Final|Native|Public|HasOutParms) // @ game+0xb42660
	void AddSystemMessage(struct FText& Message); // Function PlatformUMG.PUMG_ChatDataFactory.AddSystemMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb42590
	bool AddPlayerFilter(int64_t PlayerId); // Function PlatformUMG.PUMG_ChatDataFactory.AddPlayerFilter // (Final|Native|Public|BlueprintCallable) // @ game+0xb42500
	void AddGameMessage(struct FText& Message, enum class EPUMG_ChatChannel Channel); // Function PlatformUMG.PUMG_ChatDataFactory.AddGameMessage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb423e0
	bool AddChatCommand(struct FString Command, struct FText& Desc, struct UObject* Target, struct FString Function, struct FString Alias1, struct FString Alias2, struct FString Alias3, struct FString Alias4); // Function PlatformUMG.PUMG_ChatDataFactory.AddChatCommand // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb420d0
};

// Class PlatformUMG.PUMG_CollectionDataFactory
// Size: 0x68 (Inherited: 0x38)
struct UPUMG_CollectionDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnCollectionAvatarsUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnCollectionAvatarAcquisition; // 0x48(0x10)
	struct TArray<struct FPUMG_AvatarData> CollectionAvatars; // 0x58(0x10)
};

// Class PlatformUMG.PUMG_FriendDataFactory
// Size: 0x128 (Inherited: 0x38)
struct UPUMG_FriendDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnFriendDataUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnFriendAddSuccess; // 0x48(0x10)
	struct FMulticastInlineDelegate OnFriendAddError; // 0x58(0x10)
	struct FMulticastInlineDelegate FriendInviteReceived; // 0x68(0x10)
	struct FMulticastInlineDelegate OnFriendAdded; // 0x78(0x10)
	struct FMulticastInlineDelegate OnFriendRejected; // 0x88(0x10)
	int32_t OnlineFriends; // 0x98(0x04)
	int32_t TotalFriends; // 0x9c(0x04)
	struct TArray<struct FPUMG_FriendData> CachedFriends; // 0xa0(0x10)
	struct TArray<struct FPUMG_FriendData> CachedPendingFriends; // 0xb0(0x10)
	struct TArray<struct FPUMG_FriendData> CachedFriendRequests; // 0xc0(0x10)
	char pad_D0[0x30]; // 0xd0(0x30)
	float FriendsListUpdatePollInterval; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FTimerHandle FriendsListUpdatePollingTimerHandle; // 0x108(0x08)
	bool IsFriendsListUpdatePollingEnabled; // 0x110(0x01)
	char pad_111[0x17]; // 0x111(0x17)

	void UIX_OnRemoveFriend(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnRemoveFriend // (Final|Native|Public|BlueprintCallable) // @ game+0xb444b0
	void UIX_OnRejectFriendRequest(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnRejectFriendRequest // (Final|Native|Public|BlueprintCallable) // @ game+0xb44430
	void UIX_OnCancelFriendRequest(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnCancelFriendRequest // (Final|Native|Public|BlueprintCallable) // @ game+0xb443b0
	void UIX_OnAddFriend(struct UPUMG_PlayerInfo* playerinfo); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnAddFriend // (Final|Native|Public|BlueprintCallable) // @ game+0xb44330
	void UIX_OnAcceptFriendRequest(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.UIX_OnAcceptFriendRequest // (Final|Native|Public|BlueprintCallable) // @ game+0xb442b0
	void SetEnableFriendsListUpdatePolling(bool InBool); // Function PlatformUMG.PUMG_FriendDataFactory.SetEnableFriendsListUpdatePolling // (Final|Native|Public|BlueprintCallable) // @ game+0xb44190
	void RequestUpdateFriendsList(); // Function PlatformUMG.PUMG_FriendDataFactory.RequestUpdateFriendsList // (Final|Native|Public|BlueprintCallable) // @ game+0xb43fb0
	bool IsCrossplaySocialEnabled(); // Function PlatformUMG.PUMG_FriendDataFactory.IsCrossplaySocialEnabled // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0xb43a40
	void HandleFriendsListUpdatePolling(); // Function PlatformUMG.PUMG_FriendDataFactory.HandleFriendsListUpdatePolling // (Final|Native|Public) // @ game+0xb43a00
	void HandleCrossplaySettingChanged(); // Function PlatformUMG.PUMG_FriendDataFactory.HandleCrossplaySettingChanged // (Final|Native|Protected) // @ game+0xb439e0
	struct TArray<struct FPUMG_FriendData> GetPendingFriends(); // Function PlatformUMG.PUMG_FriendDataFactory.GetPendingFriends // (Final|Native|Public|BlueprintCallable) // @ game+0xb438a0
	struct TArray<struct FPUMG_FriendData> GetFriends(); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriends // (Final|Native|Public|BlueprintCallable) // @ game+0xb43400
	struct TArray<struct FPUMG_FriendData> GetFriendRequests(); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriendRequests // (Final|Native|Public|BlueprintCallable) // @ game+0xb43310
	struct FText GetFriendName(int64_t PlayerId); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriendName // (Final|Native|Protected|BlueprintCallable|BlueprintPure) // @ game+0xb43220
	struct TSoftObjectPtr<UTexture2D> GetFriendAvatarTexture(struct FPUMG_FriendData Friend); // Function PlatformUMG.PUMG_FriendDataFactory.GetFriendAvatarTexture // (Native|Public|BlueprintCallable) // @ game+0xb430b0
	bool GetEnableFriendsListUpdatePolling(); // Function PlatformUMG.PUMG_FriendDataFactory.GetEnableFriendsListUpdatePolling // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb43090
	void FriendRemoveResponse(); // Function PlatformUMG.PUMG_FriendDataFactory.FriendRemoveResponse // (Final|Native|Public) // @ game+0xb429c0
	bool CheckAlreadyFriends(struct FString FriendName); // Function PlatformUMG.PUMG_FriendDataFactory.CheckAlreadyFriends // (Final|Native|Public|BlueprintCallable) // @ game+0xb42750
};

// Class PlatformUMG.GamepadPromptInterface
// Size: 0x28 (Inherited: 0x28)
struct UGamepadPromptInterface : UInterface {

	bool UnregisterOnClear(); // Function PlatformUMG.GamepadPromptInterface.UnregisterOnClear // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetPrompt(struct FText& PromptText); // Function PlatformUMG.GamepadPromptInterface.SetPrompt // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void ClearPrompt(); // Function PlatformUMG.GamepadPromptInterface.ClearPrompt // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
};

// Class PlatformUMG.PUMG_GamepadDataFactory
// Size: 0x88 (Inherited: 0x38)
struct UPUMG_GamepadDataFactory : UPUMG_DataFactory {
	char pad_38[0x50]; // 0x38(0x50)

	bool UnregisterPromptForButton(struct FKey Button); // Function PlatformUMG.PUMG_GamepadDataFactory.UnregisterPromptForButton // (Final|Native|Public|BlueprintCallable) // @ game+0xb494f0
	void SetPromptForGamepadButton(struct FKey Button, struct FText& PromptText); // Function PlatformUMG.PUMG_GamepadDataFactory.SetPromptForGamepadButton // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb48610
	void RemovePromptForGamepadButton(struct FKey Button); // Function PlatformUMG.PUMG_GamepadDataFactory.RemovePromptForGamepadButton // (Final|Native|Public|BlueprintCallable) // @ game+0xb484a0
	bool RegisterPromptWidgetForButton(struct UWidget* Widget, struct FKey Button); // Function PlatformUMG.PUMG_GamepadDataFactory.RegisterPromptWidgetForButton // (Final|Native|Public|BlueprintCallable) // @ game+0xb48370
	void ClearAllGamepadPrompts(); // Function PlatformUMG.PUMG_GamepadDataFactory.ClearAllGamepadPrompts // (Final|Native|Public|BlueprintCallable) // @ game+0xb47350
};

// Class PlatformUMG.PUMG_GameViewportClient
// Size: 0x348 (Inherited: 0x338)
struct UPUMG_GameViewportClient : UGameViewportClient {
	char pad_338[0x10]; // 0x338(0x10)
};

// Class PlatformUMG.PUMG_LobbyHUD
// Size: 0x28 (Inherited: 0x28)
struct UPUMG_LobbyHUD : UInterface {
};

// Class PlatformUMG.PUMG_HUD
// Size: 0x5a0 (Inherited: 0x310)
struct APUMG_HUD : AHUD {
	struct FMulticastInlineDelegate OnInputStateChanged; // 0x310(0x10)
	struct TMap<int64_t, struct FMulticastInlineDelegate> PlayerDataUpdated; // 0x320(0x50)
	struct UPUMG_InputManager* InputManager; // 0x370(0x08)
	struct UPUMG_ViewManager* ViewManager; // 0x378(0x08)
	struct UPUMG_InputManager* InputManagerClass; // 0x380(0x08)
	struct UPUMG_UISoundTheme* SoundTheme; // 0x388(0x08)
	char pad_390[0x210]; // 0x390(0x210)

	void TestHirezLogin(struct FString User, struct FString password); // Function PlatformUMG.PUMG_HUD.TestHirezLogin // (Final|Exec|Native|Protected) // @ game+0xb489a0
	void TestAutoLogin(int32_t ControllerId); // Function PlatformUMG.PUMG_HUD.TestAutoLogin // (Final|Exec|Native|Protected) // @ game+0xb48920
	void ShowSystemTrayNotification(struct FString popupType); // Function PlatformUMG.PUMG_HUD.ShowSystemTrayNotification // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0xb48880
	void SetUseNewUIFeatures(bool UseNewFeatures); // Function PlatformUMG.PUMG_HUD.SetUseNewUIFeatures // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void SetUIFocus(); // Function PlatformUMG.PUMG_HUD.SetUIFocus // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb48780
	void SetNavigationEnabled(bool Enabled); // Function PlatformUMG.PUMG_HUD.SetNavigationEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0xb48580
	void OnQuit(); // Function PlatformUMG.PUMG_HUD.OnQuit // (Native|Public|BlueprintCallable) // @ game+0xb482d0
	bool OnNavigateBack(); // Function PlatformUMG.PUMG_HUD.OnNavigateBack // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnConfirmQuit(); // Function PlatformUMG.PUMG_HUD.OnConfirmQuit // (Native|Protected) // @ game+0xb482b0
	struct UPUMG_PlayerInfo* NewPlayerInfo(); // Function PlatformUMG.PUMG_HUD.NewPlayerInfo // (Final|Native|Protected) // @ game+0xb48280
	bool IsLobbyHUD(); // Function PlatformUMG.PUMG_HUD.IsLobbyHUD // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb47de0
	bool IsCrossplayEnabled(); // Function PlatformUMG.PUMG_HUD.IsCrossplayEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb43a40
	void InputStateChangePassthrough(enum class PGAME_INPUT_STATE InputState); // Function PlatformUMG.PUMG_HUD.InputStateChangePassthrough // (Final|Native|Public) // @ game+0xb47d60
	void gmmf(bool bAutolaunch); // Function PlatformUMG.PUMG_HUD.gmmf // (Final|Exec|Native|Protected) // @ game+0xb49610
	struct UPUMG_ViewManager* GetViewManager(); // Function PlatformUMG.PUMG_HUD.GetViewManager // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb479a0
	void GetPortalTokenDetails(); // Function PlatformUMG.PUMG_HUD.GetPortalTokenDetails // (Final|Exec|Native|Protected) // @ game+0xb47900
	struct UPUMG_PopupManager* GetPopupManager(); // Function PlatformUMG.PUMG_HUD.GetPopupManager // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct APlayerController* GetPlayerControllerOwner(); // Function PlatformUMG.PUMG_HUD.GetPlayerControllerOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb478d0
	struct UPUMG_PlayerInfo* GetOrCreatePlayerInfo(int64_t PlayerId); // Function PlatformUMG.PUMG_HUD.GetOrCreatePlayerInfo // (Final|Native|Public) // @ game+0xb47840
	struct UPUMG_InputManager* GetInputManager(); // Function PlatformUMG.PUMG_HUD.GetInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0xb47740
	enum class PGAME_INPUT_STATE GetCurrentInputState(); // Function PlatformUMG.PUMG_HUD.GetCurrentInputState // (Final|Native|Public|BlueprintCallable) // @ game+0xb47540
	void DisplayGenericPopup(struct FString sTitle, struct FString sDesc); // Function PlatformUMG.PUMG_HUD.DisplayGenericPopup // (Final|Native|Public|BlueprintCallable) // @ game+0xb47450
	void DisplayGenericError(struct FString sDesc); // Function PlatformUMG.PUMG_HUD.DisplayGenericError // (Final|Native|Public|BlueprintCallable) // @ game+0xb473b0
};

// Class PlatformUMG.PUMG_InputManager
// Size: 0xd8 (Inherited: 0x28)
struct UPUMG_InputManager : UObject {
	struct TMap<struct UPUMG_Widget*, struct FPUMG_InputFocusDetails> InputFocusData; // 0x28(0x50)
	char pad_78[0x28]; // 0x78(0x28)
	struct UInputComponent* InputComponent; // 0xa0(0x08)
	char pad_A8[0x30]; // 0xa8(0x30)

	void HandleModeChange(enum class PGAME_INPUT_STATE Mode); // Function PlatformUMG.PUMG_InputManager.HandleModeChange // (Final|Native|Public) // @ game+0xb47ce0
	bool GetFocusedWidget(struct UPUMG_Widget* ParentWidget, struct UWidget*& FocusWidget); // Function PlatformUMG.PUMG_InputManager.GetFocusedWidget // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb47670
	void ClearNavInputThrottled(); // Function PlatformUMG.PUMG_InputManager.ClearNavInputThrottled // (Final|Native|Public) // @ game+0xb47390
	void ClearNavInputDebouncedThrottled(); // Function PlatformUMG.PUMG_InputManager.ClearNavInputDebouncedThrottled // (Final|Native|Public) // @ game+0xb47370
};

// Class PlatformUMG.PUMG_JsonDataFactory
// Size: 0x48 (Inherited: 0x38)
struct UPUMG_JsonDataFactory : UPUMG_DataFactory {
	char pad_38[0x10]; // 0x38(0x10)

	void HandleJsonReady(struct UPGame_LandingPanelJSONHandler* pHandler); // Function PlatformUMG.PUMG_JsonDataFactory.HandleJsonReady // (Native|Protected) // @ game+0xb47c50
	void HandleImagesReady(struct UPGame_LandingPanelJSONHandler* pHandler); // Function PlatformUMG.PUMG_JsonDataFactory.HandleImagesReady // (Native|Protected) // @ game+0xb47bc0
};

// Class PlatformUMG.PUMG_Loadout
// Size: 0xb0 (Inherited: 0x28)
struct UPUMG_Loadout : UObject {
	struct FMulticastInlineDelegate OnRenamed; // 0x28(0x10)
	struct FMulticastInlineDelegate OnNumberChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnTypeChanged; // 0x48(0x10)
	struct FMulticastInlineDelegate OnServerUpdate; // 0x58(0x10)
	struct FMulticastInlineDelegate OnLocalUpdate; // 0x68(0x10)
	char pad_78[0x38]; // 0x78(0x38)
};

// Class PlatformUMG.PUMG_LoadoutDataFactory
// Size: 0xa8 (Inherited: 0x28)
struct UPUMG_LoadoutDataFactory : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FMulticastInlineDelegate OnLoadoutsInitialized; // 0x30(0x10)
	struct FMulticastInlineDelegate OnLoadoutsUpdatedFromServer; // 0x40(0x10)
	struct FMulticastInlineDelegate OnLoadoutFactoryReadyNoLoadouts; // 0x50(0x10)
	struct FMulticastInlineDelegate OnLoadoutChanged; // 0x60(0x10)
	struct FMulticastInlineDelegate OnLoadoutAdded; // 0x70(0x10)
	struct FMulticastInlineDelegate OnLoadoutDeleted; // 0x80(0x10)
	char pad_90[0x8]; // 0x90(0x08)
	struct TArray<struct UPUMG_Loadout*> Loadouts; // 0x98(0x10)
};

// Class PlatformUMG.PUMG_LoginDataFactory
// Size: 0x118 (Inherited: 0x38)
struct UPUMG_LoginDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnLoginUserChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnLoginStateChanged; // 0x48(0x10)
	struct FMulticastInlineDelegate OnLoginError; // 0x58(0x10)
	char pad_68[0x8]; // 0x68(0x08)
	struct FMulticastInlineDelegate OnControllerDisconnected; // 0x70(0x10)
	bool bAllowLoginDuringPartialInstall; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct UDataTable* ErrorMsgsDT; // 0x88(0x08)
	bool bAttemptedDeferredInviteAutoLogin; // 0x90(0x01)
	char pad_91[0x77]; // 0x91(0x77)
	struct FMulticastInlineDelegate OnLoginWaitQueueMessage; // 0x108(0x10)

	bool UpdateControllers(); // Function PlatformUMG.PUMG_LoginDataFactory.UpdateControllers // (Final|Native|Public|BlueprintCallable) // @ game+0xb495e0
	void UIX_TriggerAutoLogin(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_TriggerAutoLogin // (Native|Public|BlueprintCallable) // @ game+0xb494d0
	void UIX_OnTwoFactorSubmit(struct FString AuthCode); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnTwoFactorSubmit // (Final|Native|Public|BlueprintCallable) // @ game+0xb493f0
	void UIX_OnTwoFactorDecline(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnTwoFactorDecline // (Final|Native|Public|BlueprintCallable) // @ game+0xb48cf0
	void UIX_OnSubmitLogin(struct FString UserName, struct FString password); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnSubmitLogin // (Final|Native|Public|BlueprintCallable) // @ game+0xb49280
	void UIX_OnSubmitConsoleLogin(int32_t ControllerId); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnSubmitConsoleLogin // (Final|Native|Public|BlueprintCallable) // @ game+0xb49200
	void UIX_OnSubmitAutoLogin(int32_t ControllerId); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnSubmitAutoLogin // (Final|Native|Public|BlueprintCallable) // @ game+0xb49200
	void UIX_OnPlayerCreate(struct FString PlayerName); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnPlayerCreate // (Final|Native|Public|BlueprintCallable) // @ game+0xb49120
	void UIX_OnLinkExistingAccount(struct FString UserName, struct FString password); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnLinkExistingAccount // (Final|Native|Public|BlueprintCallable) // @ game+0xb48fb0
	void UIX_OnLinkDecline(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnLinkDecline // (Final|Native|Public|BlueprintCallable) // @ game+0xb48f90
	void UIX_OnLinkCreateAccount(struct FString UserName, struct FString password, struct FString Email, bool bAcceptAgeReqs); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnLinkCreateAccount // (Final|Native|Public|BlueprintCallable) // @ game+0xb48d50
	void UIX_OnEulaDecline(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnEulaDecline // (Final|Native|Public|BlueprintCallable) // @ game+0xb48cf0
	void UIX_OnEulaAccept(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnEulaAccept // (Final|Native|Public|BlueprintCallable) // @ game+0xb48d30
	void UIX_OnChangeUserAccount(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnChangeUserAccount // (Final|Native|Public|BlueprintCallable) // @ game+0xb48d10
	void UIX_OnCancelLogin(); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnCancelLogin // (Final|Native|Public|BlueprintCallable) // @ game+0xb48cf0
	void UIX_OnAccountCreate(struct FString UserName, struct FString password, struct FString Email, bool bAcceptAgeReqs); // Function PlatformUMG.PUMG_LoginDataFactory.UIX_OnAccountCreate // (Final|Native|Public|BlueprintCallable) // @ game+0xb48ab0
	void TriggerAutoLogin(); // Function PlatformUMG.PUMG_LoginDataFactory.TriggerAutoLogin // (Native|Public) // @ game+0xb48a90
	bool ShouldDisplayUsername(); // Function PlatformUMG.PUMG_LoginDataFactory.ShouldDisplayUsername // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb48850
	bool ShouldDisplayDisconnectError(); // Function PlatformUMG.PUMG_LoginDataFactory.ShouldDisplayDisconnectError // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb48820
	void SetUserErrorDataTable(struct UDataTable* ErrorMsgTable); // Function PlatformUMG.PUMG_LoginDataFactory.SetUserErrorDataTable // (Final|Native|Public|BlueprintCallable) // @ game+0xb487a0
	void RecordLoginState(enum class EPUMG_LoginState NewState); // Function PlatformUMG.PUMG_LoginDataFactory.RecordLoginState // (Final|Native|Private) // @ game+0xb482f0
	void LoginEvent_ShowAgreements(bool bNeedsEULA, bool bNeedsTOS, bool bNeedsPP); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_ShowAgreements // (Final|Native|Private) // @ game+0xb48160
	void LoginEvent_Queued(uint32_t QueuePosition, uint32_t QueueSize, uint32_t queueEstimatedWait); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_Queued // (Final|Native|Private) // @ game+0xb48060
	void LoginEvent_LoginRequested(); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_LoginRequested // (Final|Native|Private) // @ game+0xb48040
	void LoginEvent_LoggedIn(); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_LoggedIn // (Final|Native|Private) // @ game+0xb48020
	void LoginEvent_FailedClient(struct FText ErrorMsg); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_FailedClient // (Final|Native|Private) // @ game+0xb47f40
	void LoginEvent_Failed(uint32_t ErrorMsgId); // Function PlatformUMG.PUMG_LoginDataFactory.LoginEvent_Failed // (Final|Native|Private) // @ game+0xb47ec0
	bool LoadEULAFile(struct FString& SaveText); // Function PlatformUMG.PUMG_LoginDataFactory.LoadEULAFile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb47e10
	void HandleControllerPairingChange(int32_t ControllerIndex, int32_t NewUserId, int32_t OldUserId); // Function PlatformUMG.PUMG_LoginDataFactory.HandleControllerPairingChange // (Final|Native|Private) // @ game+0xb47ac0
	void HandleControllerConnectionChange(bool IsConnection, int32_t UserId, int32_t ControllerIndex); // Function PlatformUMG.PUMG_LoginDataFactory.HandleControllerConnectionChange // (Final|Native|Private) // @ game+0xb479c0
	struct FString GetVersion(); // Function PlatformUMG.PUMG_LoginDataFactory.GetVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb47920
	bool GetLastDisconnectReason(struct FText& ErrorMsg); // Function PlatformUMG.PUMG_LoginDataFactory.GetLastDisconnectReason // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb47760
	bool GetCurrentPlayerName(struct FText& NameText); // Function PlatformUMG.PUMG_LoginDataFactory.GetCurrentPlayerName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb47590
	enum class EPUMG_LoginState GetCurrentLoginState(); // Function PlatformUMG.PUMG_LoginDataFactory.GetCurrentLoginState // (Final|Native|Public|BlueprintCallable) // @ game+0xb47570
};

// Class PlatformUMG.PUMG_MobileLayoutSequencePlayer
// Size: 0x7a8 (Inherited: 0x7a8)
struct UPUMG_MobileLayoutSequencePlayer : UUMGSequencePlayer {
};

// Class PlatformUMG.PUMG_PartyDataFactory
// Size: 0x1a8 (Inherited: 0x38)
struct UPUMG_PartyDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnPartyDataUpdated; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPartyLocalPlayerLeft; // 0x48(0x10)
	struct FMulticastInlineDelegate OnPartyLocalPlayerPromoted; // 0x58(0x10)
	struct FMulticastInlineDelegate OnPartyMemberPromoted; // 0x68(0x10)
	struct FMulticastInlineDelegate OnPartyMemberDataUpdated; // 0x78(0x10)
	struct FMulticastInlineDelegate OnPendingPartyMemberDataAdded; // 0x88(0x10)
	struct FMulticastInlineDelegate OnPendingPartyMemberAccepted; // 0x98(0x10)
	struct FMulticastInlineDelegate OnPartyMemberRemoved; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnPartyMemberLeft; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnPartyDisbanded; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationError; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationSent; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationReceived; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnPartyMessageReceived; // 0x108(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationAccepted; // 0x118(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationRejected; // 0x128(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationExpired; // 0x138(0x10)
	struct FMulticastInlineDelegate OnPartyInfoUpdated; // 0x148(0x10)
	struct TArray<struct FPUMG_PartyMemberData> PartyMembers; // 0x158(0x10)
	struct UPUMG_PlayerInfo* PartyInviter; // 0x168(0x08)
	struct FString LastInviteSentErrorMessage; // 0x170(0x10)
	char pad_180[0x28]; // 0x180(0x28)

	void UIX_PromoteMemberToLeader(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_PromoteMemberToLeader // (Native|Public|BlueprintCallable) // @ game+0xb50150
	void UIX_LeaveParty(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_LeaveParty // (Native|Public|BlueprintCallable) // @ game+0xb50130
	void UIX_KickMemberFromParty(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_KickMemberFromParty // (Native|Public|BlueprintCallable) // @ game+0xb500a0
	bool UIX_InviteMemberToParty(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_InviteMemberToParty // (Native|Public|BlueprintCallable) // @ game+0xb50000
	void UIX_GiveInvitePermission(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_GiveInvitePermission // (Native|Public|BlueprintCallable) // @ game+0xb4ff70
	void UIX_DisbandParty(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_DisbandParty // (Native|Public|BlueprintCallable) // @ game+0xb4ff50
	void UIX_DenyPartyInvitation(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_DenyPartyInvitation // (Final|Native|Public|BlueprintCallable) // @ game+0xb4ff30
	void UIX_AcceptPartyInvitation(); // Function PlatformUMG.PUMG_PartyDataFactory.UIX_AcceptPartyInvitation // (Final|Native|Public|BlueprintCallable) // @ game+0xb4ff10
	void SetPartyInfo(struct FString Key, struct FString Value); // Function PlatformUMG.PUMG_PartyDataFactory.SetPartyInfo // (Final|Native|Public|BlueprintCallable) // @ game+0xb4fc50
	void SendPartyMessage(struct FString Data); // Function PlatformUMG.PUMG_PartyDataFactory.SendPartyMessage // (Final|Native|Public|BlueprintCallable) // @ game+0xb4faa0
	void PartyPromoteResponse(); // Function PlatformUMG.PUMG_PartyDataFactory.PartyPromoteResponse // (Final|Native|Public) // @ game+0xb4fa00
	void PartyLeaveResponse(); // Function PlatformUMG.PUMG_PartyDataFactory.PartyLeaveResponse // (Final|Native|Public) // @ game+0xb4f9e0
	void PartyKickResponse(); // Function PlatformUMG.PUMG_PartyDataFactory.PartyKickResponse // (Final|Native|Public) // @ game+0xb4f9c0
	bool IsPlayerInParty(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.IsPlayerInParty // (Native|Public|BlueprintCallable) // @ game+0xb4f540
	bool IsPartyMaxed(); // Function PlatformUMG.PUMG_PartyDataFactory.IsPartyMaxed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f520
	bool IsLeader(); // Function PlatformUMG.PUMG_PartyDataFactory.IsLeader // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f4f0
	bool IsInParty(); // Function PlatformUMG.PUMG_PartyDataFactory.IsInParty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f490
	bool HasInvitePrivileges(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.HasInvitePrivileges // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f1e0
	int32_t GetQueueId(); // Function PlatformUMG.PUMG_PartyDataFactory.GetQueueId // (Final|Native|Public|BlueprintCallable) // @ game+0xb4ef00
	struct FText GetPartyMemeberName(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMemeberName // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb4ed40
	struct TArray<struct FPUMG_PartyMemberData> GetPartyMembers(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ebb0
	int32_t GetPartyMemberCount(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMemberCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4eb90
	struct FPUMG_PartyMemberData GetPartyMemberByID(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyMemberByID // (Final|Native|Public|BlueprintCallable) // @ game+0xb4ea60
	struct UPUMG_PlayerInfo* GetPartyInviter(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyInviter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ea40
	enum class EPUMG_PartyInviteRightsMode GetPartyInviteMode(); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyInviteMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ea20
	struct FString GetPartyInfo(struct FString Key); // Function PlatformUMG.PUMG_PartyDataFactory.GetPartyInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e930
	int32_t GetMaxPartyMembers(); // Function PlatformUMG.PUMG_PartyDataFactory.GetMaxPartyMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e750
	bool CheckPartyMemberIsLeader(int64_t PlayerId); // Function PlatformUMG.PUMG_PartyDataFactory.CheckPartyMemberIsLeader // (Final|Native|Public|BlueprintCallable) // @ game+0xb4e0b0
};

// Class PlatformUMG.PUMG_PlayerDataFactory
// Size: 0xb0 (Inherited: 0x38)
struct UPUMG_PlayerDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnPlayerDataChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPlayerRankChanged; // 0x48(0x10)
	struct FMulticastInlineDelegate OnCrossplayChanged; // 0x58(0x10)
	int64_t PlayerId; // 0x68(0x08)
	struct FString PlayerName; // 0x70(0x10)
	int32_t Level; // 0x80(0x04)
	int32_t AvatarId; // 0x84(0x04)
	int32_t LastMMR; // 0x88(0x04)
	int32_t CurrentMMR; // 0x8c(0x04)
	int32_t BestMMR; // 0x90(0x04)
	int32_t CurrentWinRank; // 0x94(0x04)
	int32_t PreviousWinRank; // 0x98(0x04)
	int32_t CurrentWinPeak; // 0x9c(0x04)
	int32_t PreviousWinPeak; // 0xa0(0x04)
	int32_t CurrentWinStreak; // 0xa4(0x04)
	int32_t PreviousWinStreak; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)

	void OnSelectAvatar(int32_t ItemId); // Function PlatformUMG.PUMG_PlayerDataFactory.OnSelectAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0xb4f940
	struct TSoftObjectPtr<UTexture2D> GetAvatarIcon(); // Function PlatformUMG.PUMG_PlayerDataFactory.GetAvatarIcon // (Native|Public|BlueprintCallable) // @ game+0xb4e290
};

// Class PlatformUMG.PUMG_PlayerInfo
// Size: 0x80 (Inherited: 0x28)
struct UPUMG_PlayerInfo : UObject {
	struct FMulticastInlineDelegate OnFilteredNameSetDel; // 0x28(0x10)
	char pad_38[0x48]; // 0x38(0x48)

	void SetIgnored(bool Ignored); // Function PlatformUMG.PUMG_PlayerInfo.SetIgnored // (Final|Native|Public|BlueprintCallable) // @ game+0xb4fb40
	bool IsIgnored(); // Function PlatformUMG.PUMG_PlayerInfo.IsIgnored // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f400
	int64_t GetPlayerId(); // Function PlatformUMG.PUMG_PlayerInfo.GetPlayerId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ee50
	struct FText GetName(); // Function PlatformUMG.PUMG_PlayerInfo.GetName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e7f0
	struct FString GetMctsName(); // Function PlatformUMG.PUMG_PlayerInfo.GetMctsName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e770
	int32_t GetAvatarItemId(); // Function PlatformUMG.PUMG_PlayerInfo.GetAvatarItemId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e300
};

// Class PlatformUMG.PUMG_PlayerInventoryHelper
// Size: 0x118 (Inherited: 0x28)
struct UPUMG_PlayerInventoryHelper : UObject {
	char pad_28[0xf0]; // 0x28(0xf0)
};

// Class PlatformUMG.PUMG_PlayerWhoDataFactory
// Size: 0x60 (Inherited: 0x38)
struct UPUMG_PlayerWhoDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnSearchByNameResultsUpdated; // 0x38(0x10)
	struct TArray<struct UPUMG_PlayerInfo*> CachedSearchByNameResults; // 0x48(0x10)
	char pad_58[0x8]; // 0x58(0x08)

	void UIX_SearchByNameForPlayer(struct FString PlayerName, bool bIncludeOfflinePlayers); // Function PlatformUMG.PUMG_PlayerWhoDataFactory.UIX_SearchByNameForPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0xb501e0
	struct TArray<struct UPUMG_PlayerInfo*> GetSearchByNameResults(); // Function PlatformUMG.PUMG_PlayerWhoDataFactory.GetSearchByNameResults // (Final|Native|Public|BlueprintCallable) // @ game+0xb4eff0
};

// Class PlatformUMG.PUMG_Widget
// Size: 0x4b8 (Inherited: 0x238)
struct UPUMG_Widget : UUserWidget {
	struct FMulticastInlineDelegate OnGamepadHovered; // 0x238(0x10)
	struct FMulticastInlineDelegate OnMouseEntered; // 0x248(0x10)
	struct FMulticastInlineDelegate OnNavigateBack; // 0x258(0x10)
	struct FMulticastInlineDelegate OnTextureLoadComplete; // 0x268(0x10)
	struct FMulticastInlineDelegate OnNavigateUpFailed; // 0x278(0x10)
	struct FMulticastInlineDelegate OnNavigateDownFailed; // 0x288(0x10)
	struct FMulticastInlineDelegate OnNavigateLeftFailed; // 0x298(0x10)
	struct FMulticastInlineDelegate OnNavigateRightFailed; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateUpFailed; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateDownFailed; // 0x2c8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateLeftFailed; // 0x2d8(0x10)
	struct FMulticastInlineDelegate OnFocusGroupNavigateRightFailed; // 0x2e8(0x10)
	struct FMulticastInlineDelegate OnHideSequenceFinished; // 0x2f8(0x10)
	struct FMulticastInlineDelegate OnShowSequenceFinished; // 0x308(0x10)
	struct TWeakObjectPtr<struct APUMG_HUD> MyHud; // 0x318(0x08)
	bool CloseOnLogout; // 0x320(0x01)
	bool IsComponent; // 0x321(0x01)
	bool StartsHidden; // 0x322(0x01)
	bool UsesBlocker; // 0x323(0x01)
	bool BlockerClickToClose; // 0x324(0x01)
	bool EnableGameStateSetNotify; // 0x325(0x01)
	char pad_326[0x2]; // 0x326(0x02)
	struct TSoftObjectPtr<UTexture2D> LoadedTexture; // 0x328(0x28)
	char pad_350[0x150]; // 0x350(0x150)
	struct UPUMG_MobileLayoutSequencePlayer* MobileLayoutSequencePlayer; // 0x4a0(0x08)
	struct UWidgetAnimation* MobileLayoutAnim; // 0x4a8(0x08)
	bool bMobileLayoutActive; // 0x4b0(0x01)
	char pad_4B1[0x7]; // 0x4b1(0x07)

	void UpdateRegistrationToInputManager(struct UWidget* Widget, int32_t FocusGroup, struct UWidget* Up, struct UWidget* Down, struct UWidget* Left, struct UWidget* Right); // Function PlatformUMG.PUMG_Widget.UpdateRegistrationToInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0xb5a100
	void UnregisterWidgetFromInputManager(struct UWidget* Widget); // Function PlatformUMG.PUMG_Widget.UnregisterWidgetFromInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0xb5a080
	void UnregisterFocusGroup(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.UnregisterFocusGroup // (Final|Native|Public|BlueprintCallable) // @ game+0xb5a000
	void UninitializeWidget(); // Function PlatformUMG.PUMG_Widget.UninitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb59fe0
	void ToggleMobileLayout(enum class PGAME_INPUT_STATE InputState); // Function PlatformUMG.PUMG_Widget.ToggleMobileLayout // (Final|Native|Private) // @ game+0xb59f60
	bool SwapViewRoute(struct FName RouteName, struct FName SwapTargetRoute, bool ForceTransition); // Function PlatformUMG.PUMG_Widget.SwapViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59e60
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function PlatformUMG.PUMG_Widget.StartShowSequence // (Native|Event|Public|BlueprintEvent) // @ game+0xb59c90
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function PlatformUMG.PUMG_Widget.StartHideSequence // (Native|Event|Public|BlueprintEvent) // @ game+0xb59bc0
	void ShowWidget(); // Function PlatformUMG.PUMG_Widget.ShowWidget // (Native|Public|BlueprintCallable) // @ game+0xb59ba0
	void SetPendingRouteData(struct FName RouteName, struct UObject* Data); // Function PlatformUMG.PUMG_Widget.SetPendingRouteData // (Final|Native|Public|BlueprintCallable) // @ game+0xb599c0
	void SetFocusToWidgetOfGroup(int32_t FocusGroup, struct UPUMG_Widget* Widget); // Function PlatformUMG.PUMG_Widget.SetFocusToWidgetOfGroup // (Final|Native|Public|BlueprintCallable) // @ game+0xb59840
	struct UWidget* SetFocusToThis(); // Function PlatformUMG.PUMG_Widget.SetFocusToThis // (Final|Native|Public|BlueprintCallable) // @ game+0xb59810
	void SetFocusToGroup(int32_t FocusGroup, bool KeepLastFocus); // Function PlatformUMG.PUMG_Widget.SetFocusToGroup // (Native|Public|BlueprintCallable) // @ game+0xb59740
	void SetDefaultFocusForGroup(struct UWidget* Widget, int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.SetDefaultFocusForGroup // (Final|Native|Public|BlueprintCallable) // @ game+0xb59680
	bool RemoveViewRoute(struct FName RouteName, bool ForceTransition); // Function PlatformUMG.PUMG_Widget.RemoveViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb594b0
	bool RemoveTopViewRoute(bool ForceTransition); // Function PlatformUMG.PUMG_Widget.RemoveTopViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59420
	void RegisterWidgetToInputManager(struct UWidget* Widget, int32_t FocusGroup, struct UWidget* Up, struct UWidget* Down, struct UWidget* Left, struct UWidget* Right); // Function PlatformUMG.PUMG_Widget.RegisterWidgetToInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0xb591a0
	void OnShown(); // Function PlatformUMG.PUMG_Widget.OnShown // (Native|Event|Public|BlueprintEvent) // @ game+0xb58fe0
	void OnHide(); // Function PlatformUMG.PUMG_Widget.OnHide // (Native|Event|Public|BlueprintEvent) // @ game+0xb58f20
	void OnGamepadUnhover(); // Function PlatformUMG.PUMG_Widget.OnGamepadUnhover // (Final|Native|Public|BlueprintCallable) // @ game+0xb58f00
	void OnGamepadHover(); // Function PlatformUMG.PUMG_Widget.OnGamepadHover // (Final|Native|Public|BlueprintCallable) // @ game+0xb58ee0
	void OnExitMobileLayout(); // Function PlatformUMG.PUMG_Widget.OnExitMobileLayout // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnEnterMobileLayout(); // Function PlatformUMG.PUMG_Widget.OnEnterMobileLayout // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void NavigateUpFailure(); // Function PlatformUMG.PUMG_Widget.NavigateUpFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void NavigateRightFailure(); // Function PlatformUMG.PUMG_Widget.NavigateRightFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void NavigateLeftFailure(); // Function PlatformUMG.PUMG_Widget.NavigateLeftFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void NavigateDownFailure(); // Function PlatformUMG.PUMG_Widget.NavigateDownFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool NavigateConfirmPressed(); // Function PlatformUMG.PUMG_Widget.NavigateConfirmPressed // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xb58eb0
	void NavigateConfirmCancelled(); // Function PlatformUMG.PUMG_Widget.NavigateConfirmCancelled // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xb58e90
	bool NavigateConfirm(); // Function PlatformUMG.PUMG_Widget.NavigateConfirm // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xb58e60
	bool NavigateBackPressed(); // Function PlatformUMG.PUMG_Widget.NavigateBackPressed // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xb58e30
	void NavigateBackCancelled(); // Function PlatformUMG.PUMG_Widget.NavigateBackCancelled // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xb58e10
	bool NavigateBack(); // Function PlatformUMG.PUMG_Widget.NavigateBack // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xb58de0
	bool IsTopViewRoute(); // Function PlatformUMG.PUMG_Widget.IsTopViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb58db0
	bool IsFocusEnabled(); // Function PlatformUMG.PUMG_Widget.IsFocusEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xb58c60
	void InitializeWidgetNavigation(); // Function PlatformUMG.PUMG_Widget.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetButtonListeners(); // Function PlatformUMG.PUMG_Widget.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function PlatformUMG.PUMG_Widget.InitializeWidget // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb58b70
	void InheritFocusGroupFromWidget(int32_t TargetFocusGroupNum, struct UPUMG_Widget* SourceWidget, int32_t SourceFocusGroupNum); // Function PlatformUMG.PUMG_Widget.InheritFocusGroupFromWidget // (Final|Native|Public|BlueprintCallable) // @ game+0xb589d0
	void HideWidget(); // Function PlatformUMG.PUMG_Widget.HideWidget // (Native|Public|BlueprintCallable) // @ game+0xb589b0
	struct UPUMG_ViewManager* GetViewManager(); // Function PlatformUMG.PUMG_Widget.GetViewManager // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb587a0
	bool GetUsesBlocker(); // Function PlatformUMG.PUMG_Widget.GetUsesBlocker // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb58780
	bool GetPendingRouteData(struct FName RouteName, struct UObject*& Data); // Function PlatformUMG.PUMG_Widget.GetPendingRouteData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58610
	struct FGeometry GetGeometryFromLastTick(); // Function PlatformUMG.PUMG_Widget.GetGeometryFromLastTick // (Final|Native|Public|BlueprintCallable) // @ game+0xb584d0
	bool GetCurrentFocusGroup(int32_t& OutFocusGroup); // Function PlatformUMG.PUMG_Widget.GetCurrentFocusGroup // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb58280
	struct UWidget* GetCurrentFocusForGroup(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.GetCurrentFocusForGroup // (Final|Native|Public|BlueprintCallable) // @ game+0xb581f0
	void GameStateSet(struct AGameStateBase* GameState); // Function PlatformUMG.PUMG_Widget.GameStateSet // (Native|Event|Protected|BlueprintEvent) // @ game+0xb57f00
	void GamepadUnhover(); // Function PlatformUMG.PUMG_Widget.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadHover(); // Function PlatformUMG.PUMG_Widget.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	struct FEventReply GamepadButtonUp(struct FKey Button); // Function PlatformUMG.PUMG_Widget.GamepadButtonUp // (Native|Event|Public|BlueprintEvent) // @ game+0xb580c0
	struct FEventReply GamepadButtonDown(struct FKey Button); // Function PlatformUMG.PUMG_Widget.GamepadButtonDown // (Native|Event|Public|BlueprintEvent) // @ game+0xb57f90
	void FocusGroupNavigateUpFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateUpFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void FocusGroupNavigateRightFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateRightFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void FocusGroupNavigateLeftFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateLeftFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void FocusGroupNavigateDownFailure(int32_t FocusGroup); // Function PlatformUMG.PUMG_Widget.FocusGroupNavigateDownFailure // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	bool ExplicitNavigateUp(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateUp // (Final|Native|Public|BlueprintCallable) // @ game+0xb57ed0
	bool ExplicitNavigateRight(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateRight // (Final|Native|Public|BlueprintCallable) // @ game+0xb57ea0
	bool ExplicitNavigateLeft(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateLeft // (Final|Native|Public|BlueprintCallable) // @ game+0xb57e70
	bool ExplicitNavigateDown(); // Function PlatformUMG.PUMG_Widget.ExplicitNavigateDown // (Final|Native|Public|BlueprintCallable) // @ game+0xb57e40
	void DisplayGenericPopup(struct FString sTitle, struct FString sDesc); // Function PlatformUMG.PUMG_Widget.DisplayGenericPopup // (Final|Native|Public|BlueprintCallable) // @ game+0xb57d50
	void DisplayGenericError(struct FString sDesc); // Function PlatformUMG.PUMG_Widget.DisplayGenericError // (Final|Native|Public|BlueprintCallable) // @ game+0xb57cb0
	void ClearNavigationInputThrottle(); // Function PlatformUMG.PUMG_Widget.ClearNavigationInputThrottle // (Final|Native|Public|BlueprintCallable) // @ game+0xb57c00
	bool CanCloseOnLogout(); // Function PlatformUMG.PUMG_Widget.CanCloseOnLogout // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb57bd0
	void CallOnShowSequenceFinished(); // Function PlatformUMG.PUMG_Widget.CallOnShowSequenceFinished // (Final|Native|Public|BlueprintCallable) // @ game+0xb57bb0
	void CallOnHideSequenceFinished(); // Function PlatformUMG.PUMG_Widget.CallOnHideSequenceFinished // (Final|Native|Public|BlueprintCallable) // @ game+0xb57b90
	void BindToInputManager(int32_t DefaultFocusGroup); // Function PlatformUMG.PUMG_Widget.BindToInputManager // (Final|Native|Public|BlueprintCallable) // @ game+0xb57b10
	void AsyncLoadTexture2D(struct TSoftObjectPtr<UTexture2D> Texture2DRef); // Function PlatformUMG.PUMG_Widget.AsyncLoadTexture2D // (Final|Native|Public|BlueprintCallable) // @ game+0xb57a30
	bool AddViewRoute(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, struct UObject* Data); // Function PlatformUMG.PUMG_Widget.AddViewRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb578c0
};

// Class PlatformUMG.PUMG_PopupManager
// Size: 0x5d8 (Inherited: 0x4b8)
struct UPUMG_PopupManager : UPUMG_Widget {
	char pad_4B8[0x10]; // 0x4b8(0x10)
	struct TArray<struct FPUMG_PopupConfig> PopupQueue; // 0x4c8(0x10)
	int32_t m_nPopupId; // 0x4d8(0x04)
	char pad_4DC[0xe4]; // 0x4dc(0xe4)
	struct FText CommittedText; // 0x5c0(0x18)

	void ShowPopup(struct FPUMG_PopupConfig popupData); // Function PlatformUMG.PUMG_PopupManager.ShowPopup // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void RemovePopup(int32_t PopupId); // Function PlatformUMG.PUMG_PopupManager.RemovePopup // (Final|Native|Public|BlueprintCallable) // @ game+0xb4fa20
	void OnPopupResponse(int32_t nPopupId, int32_t nResponseIndex); // Function PlatformUMG.PUMG_PopupManager.OnPopupResponse // (Final|Native|Public|BlueprintCallable) // @ game+0xb4f880
	void OnPopupCanceled(); // Function PlatformUMG.PUMG_PopupManager.OnPopupCanceled // (Final|Native|Public|BlueprintCallable) // @ game+0xb4f860
	void NextPopup(); // Function PlatformUMG.PUMG_PopupManager.NextPopup // (Final|Native|Public|BlueprintCallable) // @ game+0xb4f840
	void HidePopup(); // Function PlatformUMG.PUMG_PopupManager.HidePopup // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void CloseUnimportantPopups(); // Function PlatformUMG.PUMG_PopupManager.CloseUnimportantPopups // (Final|Native|Public|BlueprintCallable) // @ game+0xb4e160
	void CloseAllPopups(); // Function PlatformUMG.PUMG_PopupManager.CloseAllPopups // (Final|Native|Public|BlueprintCallable) // @ game+0xb4e140
	int32_t AddPopup(struct FPUMG_PopupConfig& popupData); // Function PlatformUMG.PUMG_PopupManager.AddPopup // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb4dce0
};

// Class PlatformUMG.PUMG_QueueDataFactory
// Size: 0x210 (Inherited: 0x38)
struct UPUMG_QueueDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnQueueJoined; // 0x38(0x10)
	struct FMulticastInlineDelegate OnQueueLeft; // 0x48(0x10)
	struct FMulticastInlineDelegate OnQueueStatusChange; // 0x58(0x10)
	struct FMulticastInlineDelegate OnQueueDataUpdated; // 0x68(0x10)
	struct FMulticastInlineDelegate OnMatchStatusUpdatedError; // 0x78(0x10)
	struct FMulticastInlineDelegate OnCustomMatchJoined; // 0x88(0x10)
	struct FMulticastInlineDelegate OnCustomQueueMemberAdded; // 0x98(0x10)
	struct FMulticastInlineDelegate OnCustomQueueMemberRemoved; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnCustomQueueMemberUpdated; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnCustomQueueChanged; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnCustomInviteErrorRecieved; // 0xd8(0x10)
	int32_t PendingCustomMatchMapId; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct TArray<struct FPUMG_ActivityQueuePair> ActivityQueuePairs; // 0xf0(0x10)
	struct FString ActivityToJoin; // 0x100(0x10)
	bool bActivityToJoinIsMultiplayer; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct TArray<int32_t> QueueIds; // 0x118(0x10)
	char pad_128[0x50]; // 0x128(0x50)
	float QueueUpdatePollInterval; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct FTimerHandle QueueUpdateTimerHandle; // 0x180(0x08)
	struct TArray<struct FPUMG_CustomMatchMember> CustomMatchMembers; // 0x188(0x10)
	char pad_198[0x70]; // 0x198(0x70)
	int32_t CustomMatchSpectateTeamId; // 0x208(0x04)
	char pad_20C[0x4]; // 0x20c(0x04)

	void StartCustomMatch(bool bDoChecks); // Function PlatformUMG.PUMG_QueueDataFactory.StartCustomMatch // (Final|Native|Public|BlueprintCallable) // @ game+0xb4fe80
	void SetPlayerTeamCustomMatch(int64_t PlayerId, int32_t TeamId); // Function PlatformUMG.PUMG_QueueDataFactory.SetPlayerTeamCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb4fdc0
	void SetPendingMapForCustomQueue(int32_t MapId); // Function PlatformUMG.PUMG_QueueDataFactory.SetPendingMapForCustomQueue // (Final|Native|Public|BlueprintCallable) // @ game+0xb4fd40
	void SetMapForCustomMatch(int32_t MapId); // Function PlatformUMG.PUMG_QueueDataFactory.SetMapForCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb4fbd0
	bool LeaveQueue(bool bLeaveMatch); // Function PlatformUMG.PUMG_QueueDataFactory.LeaveQueue // (Native|Public|BlueprintCallable) // @ game+0xb4f7a0
	void KickFromCustomMatch(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.KickFromCustomMatch // (Final|Native|Public|BlueprintCallable) // @ game+0xb4f720
	bool JoinQueue(int32_t QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.JoinQueue // (Native|Public|BlueprintCallable) // @ game+0xb4f680
	bool IsQueueActive(int32_t QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.IsQueueActive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f5e0
	bool IsInQueue(); // Function PlatformUMG.PUMG_QueueDataFactory.IsInQueue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb4f4c0
	bool IsInGame(); // Function PlatformUMG.PUMG_QueueDataFactory.IsInGame // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb4f460
	bool IsInCustomMatch(); // Function PlatformUMG.PUMG_QueueDataFactory.IsInCustomMatch // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb4f430
	bool IsCustomInvitePending(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.IsCustomInvitePending // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f370
	void InviteToCustomMatch(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.InviteToCustomMatch // (Final|Native|Public|BlueprintCallable) // @ game+0xb4f2f0
	void IncrementPlayerTeamCustomMatch(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.IncrementPlayerTeamCustomMatch // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb4f270
	bool HasCurrentMatchId(); // Function PlatformUMG.PUMG_QueueDataFactory.HasCurrentMatchId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb4f1b0
	void HandleInviteCooldowns(); // Function PlatformUMG.PUMG_QueueDataFactory.HandleInviteCooldowns // (Final|Native|Protected) // @ game+0xb4f190
	void HandleConfirmKickCustomPlayer(); // Function PlatformUMG.PUMG_QueueDataFactory.HandleConfirmKickCustomPlayer // (Final|Native|Protected) // @ game+0xb4f170
	float GetTimeInQueueSeconds(); // Function PlatformUMG.PUMG_QueueDataFactory.GetTimeInQueueSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f140
	int32_t GetTeamMemberCount(int32_t TeamId); // Function PlatformUMG.PUMG_QueueDataFactory.GetTeamMemberCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4f0b0
	struct TArray<int32_t> GetQueueIds(); // Function PlatformUMG.PUMG_QueueDataFactory.GetQueueIds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ef30
	int32_t GetPlayerTeamId(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.GetPlayerTeamId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ee70
	int32_t GetPendingCustomMatchMapId(); // Function PlatformUMG.PUMG_QueueDataFactory.GetPendingCustomMatchMapId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ee30
	int32_t GetNextTeamId(int32_t RelativeToTeamId); // Function PlatformUMG.PUMG_QueueDataFactory.GetNextTeamId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e8a0
	bool GetIsJoiningBackfillGame(); // Function PlatformUMG.PUMG_QueueDataFactory.GetIsJoiningBackfillGame // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e730
	enum class EPUMG_CustomMatchPermission GetCustomMatchPermissions(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchPermissions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e6a0
	struct TArray<struct FPUMG_CustomMatchMember> GetCustomMatchMembers(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchMembers // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb4e610
	int32_t GetCustomMatchMapId(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchMapId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e5e0
	struct UPUMG_PlayerInfo* GetCustomMatchInviterPlayerInfo(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCustomMatchInviterPlayerInfo // (Final|Native|Public|BlueprintCallable) // @ game+0xb4e5b0
	enum class EPUMG_MatchStatus GetCurrentQueueMatchState(); // Function PlatformUMG.PUMG_QueueDataFactory.GetCurrentQueueMatchState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e580
	bool GetCurrentQueueId(int32_t& QueueId); // Function PlatformUMG.PUMG_QueueDataFactory.GetCurrentQueueId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb4e4f0
	bool GetBaseQueueInfoById(int32_t QueueId, struct FPUMG_ClientQueueInfo& InClientQueueInfo); // Function PlatformUMG.PUMG_QueueDataFactory.GetBaseQueueInfoById // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e330
	void DeclineMatchInvite(); // Function PlatformUMG.PUMG_QueueDataFactory.DeclineMatchInvite // (Native|Public|BlueprintCallable) // @ game+0xb4e270
	void CreateCustomMatch(int32_t QueueId, int32_t TeamSize, int32_t TaskForceCount); // Function PlatformUMG.PUMG_QueueDataFactory.CreateCustomMatch // (Native|Public|BlueprintCallable) // @ game+0xb4e180
	enum class EPUMG_CustomMatchError CheckCustomMatch(bool bAllowGMOverride); // Function PlatformUMG.PUMG_QueueDataFactory.CheckCustomMatch // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4e020
	bool CanQueue(); // Function PlatformUMG.PUMG_QueueDataFactory.CanQueue // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4dff0
	bool CanLocalPlayerPromoteCustomLobbyPlayer(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.CanLocalPlayerPromoteCustomLobbyPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4df60
	bool CanLocalPlayerKickCustomLobbyPlayer(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.CanLocalPlayerKickCustomLobbyPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4ded0
	bool CanLocalPlayerControlCustomLobbyPlayer(int64_t PlayerId); // Function PlatformUMG.PUMG_QueueDataFactory.CanLocalPlayerControlCustomLobbyPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb4de40
	bool AttemptRejoinMatch(bool Forced); // Function PlatformUMG.PUMG_QueueDataFactory.AttemptRejoinMatch // (Native|Public|BlueprintCallable) // @ game+0xb4dda0
	void AcceptMatchInvite(); // Function PlatformUMG.PUMG_QueueDataFactory.AcceptMatchInvite // (Final|Native|Public|BlueprintCallable) // @ game+0xb4dcc0
};

// Class PlatformUMG.PUMG_SettingsDataFactory
// Size: 0xd8 (Inherited: 0x38)
struct UPUMG_SettingsDataFactory : UPUMG_DataFactory {
	struct FMulticastInlineDelegate OnPopulateUserSettings; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPopulateUserBindings; // 0x48(0x10)
	struct FMulticastInlineDelegate OnPopulateUserGPBindings; // 0x58(0x10)
	struct FMulticastInlineDelegate OnPostLogin; // 0x68(0x10)
	struct FMulticastInlineDelegate OnPostLogoff; // 0x78(0x10)
	struct FMulticastInlineDelegate OnSettingValueChanged; // 0x88(0x10)
	char pad_98[0x40]; // 0x98(0x40)

	bool OnSettingChanged(struct FName SettingId, int32_t SettingValue); // Function PlatformUMG.PUMG_SettingsDataFactory.OnSettingChanged // (Native|Public|BlueprintCallable) // @ game+0xb54860
	void InitSettingsForPlayer(); // Function PlatformUMG.PUMG_SettingsDataFactory.InitSettingsForPlayer // (Native|Protected|BlueprintCallable) // @ game+0xb48a90
};

// Class PlatformUMG.PUMG_Coupon
// Size: 0x1b8 (Inherited: 0x1b8)
struct UPUMG_Coupon : UPlatformInventoryItem {
};

// Class PlatformUMG.PUMG_StorePurchaseRequest
// Size: 0x60 (Inherited: 0x28)
struct UPUMG_StorePurchaseRequest : UObject {
	int32_t LootTableItemId; // 0x28(0x04)
	int32_t VendorId; // 0x2c(0x04)
	int32_t PriceInUI; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct UPlatformInventoryItem* CurrencyType; // 0x38(0x08)
	int32_t Quantity; // 0x40(0x04)
	int32_t LocationId; // 0x44(0x04)
	int32_t CouponId; // 0x48(0x04)
	int32_t GiftPlayerId; // 0x4c(0x04)
	int32_t GiftMsgIndex; // 0x50(0x04)
	bool AnonymousGift; // 0x54(0x01)
	bool SkipCurrencyAmountValidation; // 0x55(0x01)
	char pad_56[0x2]; // 0x56(0x02)
	struct TWeakObjectPtr<struct UPUMG_StoreItemHelper> pItemHelper; // 0x58(0x08)

	bool SubmitPurchaseRequest(); // Function PlatformUMG.PUMG_StorePurchaseRequest.SubmitPurchaseRequest // (Final|Native|Public|BlueprintCallable) // @ game+0xb54a80
};

// Class PlatformUMG.PUMG_PortalOffer
// Size: 0xf0 (Inherited: 0x28)
struct UPUMG_PortalOffer : UObject {
	struct FString SKU; // 0x28(0x10)
	float PreSaleCost; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FText DisplayPreSaleCost; // 0x40(0x18)
	float cost; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FText DisplayCost; // 0x60(0x18)
	struct FText CurrencyCode; // 0x78(0x18)
	struct FText Name; // 0x90(0x18)
	struct FText Desc; // 0xa8(0x18)
	struct FText ShortDesc; // 0xc0(0x18)
	struct FText TaxMessage; // 0xd8(0x18)

	int32_t GetDiscountPercentage(); // Function PlatformUMG.PUMG_PortalOffer.GetDiscountPercentage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53300
};

// Class PlatformUMG.PUMG_StoreItemPrice
// Size: 0x60 (Inherited: 0x28)
struct UPUMG_StoreItemPrice : UObject {
	int32_t PreSalePrice; // 0x28(0x04)
	int32_t Price; // 0x2c(0x04)
	struct TSoftObjectPtr<UPlatformInventoryItem> CurrencyType; // 0x30(0x28)
	struct TWeakObjectPtr<struct UPUMG_StoreItemHelper> pItemHelper; // 0x58(0x08)

	int32_t GetPriceWithCoupon(struct UPUMG_StoreItem* Coupon); // Function PlatformUMG.PUMG_StoreItemPrice.GetPriceWithCoupon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53980
	int32_t GetDiscountPercentage(); // Function PlatformUMG.PUMG_StoreItemPrice.GetDiscountPercentage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53330
	bool CanAfford(int32_t Quantity, struct UPUMG_StoreItem* Coupon); // Function PlatformUMG.PUMG_StoreItemPrice.CanAfford // (Final|Native|Public|BlueprintCallable) // @ game+0xb52f30
};

// Class PlatformUMG.PUMG_StoreItem
// Size: 0x80 (Inherited: 0x28)
struct UPUMG_StoreItem : UObject {
	struct FMulticastInlineDelegate OnPriceSetDirty; // 0x28(0x10)
	char pad_38[0x10]; // 0x38(0x10)
	struct TWeakObjectPtr<struct UPUMG_StoreItemHelper> pItemHelper; // 0x48(0x08)
	struct TSoftObjectPtr<UPlatformInventoryItem> InventoryItem; // 0x50(0x28)
	struct UPUMG_PortalOffer* PortalOffer; // 0x78(0x08)

	void UIX_ShowPurchaseConfirmation(struct UPUMG_StoreItemPrice* pPrice); // Function PlatformUMG.PUMG_StoreItem.UIX_ShowPurchaseConfirmation // (Native|Public|BlueprintCallable) // @ game+0xb54c30
	bool ShouldDisplayToUser(); // Function PlatformUMG.PUMG_StoreItem.ShouldDisplayToUser // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54a50
	void PurchaseFromPortal(); // Function PlatformUMG.PUMG_StoreItem.PurchaseFromPortal // (Final|Native|Public|BlueprintCallable) // @ game+0xb54930
	bool IsRented(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.IsRented // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb547c0
	bool IsRecipeFulfilled(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.IsRecipeFulfilled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54720
	bool IsOwned(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.IsOwned // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb54680
	bool IsOnSale(); // Function PlatformUMG.PUMG_StoreItem.IsOnSale // (Native|Public|BlueprintCallable) // @ game+0xb54650
	bool IsActive(); // Function PlatformUMG.PUMG_StoreItem.IsActive // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54620
	bool HasPortalOffer(); // Function PlatformUMG.PUMG_StoreItem.HasPortalOffer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb545f0
	int32_t GetVendorId(); // Function PlatformUMG.PUMG_StoreItem.GetVendorId // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb543c0
	int32_t GetUIHint(); // Function PlatformUMG.PUMG_StoreItem.GetUIHint // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54390
	int32_t GetType(); // Function PlatformUMG.PUMG_StoreItem.GetType // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54360
	int32_t GetSubType(); // Function PlatformUMG.PUMG_StoreItem.GetSubType // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54330
	int32_t GetSortOrder(); // Function PlatformUMG.PUMG_StoreItem.GetSortOrder // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53c90
	struct FSoftObjectPath GetSoftItemIconAsPath(); // Function PlatformUMG.PUMG_StoreItem.GetSoftItemIconAsPath // (Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53c00
	struct TSoftObjectPtr<UTexture2D> GetSoftItemIcon(); // Function PlatformUMG.PUMG_StoreItem.GetSoftItemIcon // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53b90
	int32_t GetRecipeEntryType(); // Function PlatformUMG.PUMG_StoreItem.GetRecipeEntryType // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53b60
	int32_t GetQuantityOwned(int64_t PlayerId); // Function PlatformUMG.PUMG_StoreItem.GetQuantityOwned // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53ac0
	struct UPUMG_StorePurchaseRequest* GetPurchaseRequest(); // Function PlatformUMG.PUMG_StoreItem.GetPurchaseRequest // (Native|Public|BlueprintCallable) // @ game+0xb53a90
	struct TArray<struct UPUMG_StoreItemPrice*> GetPrices(); // Function PlatformUMG.PUMG_StoreItem.GetPrices // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb53a10
	struct UPUMG_StoreItemPrice* GetPrice(struct TSoftObjectPtr<UPlatformInventoryItem> nCurrencyType); // Function PlatformUMG.PUMG_StoreItem.GetPrice // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb53890
	struct UPUMG_PortalOffer* GetPortalOffer(); // Function PlatformUMG.PUMG_StoreItem.GetPortalOffer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53870
	struct FText GetName(); // Function PlatformUMG.PUMG_StoreItem.GetName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53710
	int32_t GetLootQuantity(); // Function PlatformUMG.PUMG_StoreItem.GetLootQuantity // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb536b0
	int32_t GetLootId(); // Function PlatformUMG.PUMG_StoreItem.GetLootId // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53680
	int32_t GetItemId(); // Function PlatformUMG.PUMG_StoreItem.GetItemId // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53590
	struct TSoftObjectPtr<UPlatformInventoryItem> GetInventoryItem(); // Function PlatformUMG.PUMG_StoreItem.GetInventoryItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53530
	struct FText GetFormattedNameDisplay(int32_t ExternalQuantity); // Function PlatformUMG.PUMG_StoreItem.GetFormattedNameDisplay // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53400
	struct FText GetFormattedDescDisplay(); // Function PlatformUMG.PUMG_StoreItem.GetFormattedDescDisplay // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53360
	struct FText GetDescription(); // Function PlatformUMG.PUMG_StoreItem.GetDescription // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53260
	struct TArray<struct UPUMG_StoreItem*> GetCouponsForPrice(struct UPUMG_StoreItemPrice* Price); // Function PlatformUMG.PUMG_StoreItem.GetCouponsForPrice // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53180
	int32_t GetBundleId(); // Function PlatformUMG.PUMG_StoreItem.GetBundleId // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53150
	int32_t GetBestDiscount(); // Function PlatformUMG.PUMG_StoreItem.GetBestDiscount // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb53120
	struct UPUMG_StoreItem* GetBestCouponForPrice(struct UPUMG_StoreItemPrice* Price); // Function PlatformUMG.PUMG_StoreItem.GetBestCouponForPrice // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53090
	void ConfirmGotoPortalOffer(); // Function PlatformUMG.PUMG_StoreItem.ConfirmGotoPortalOffer // (Final|Native|Public|BlueprintCallable) // @ game+0xb52ff0
	bool CanAfford(struct UPUMG_StoreItemPrice* Price, int32_t Quantity); // Function PlatformUMG.PUMG_StoreItem.CanAfford // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb52e70
};

// Class PlatformUMG.PUMG_XpTable
// Size: 0x30 (Inherited: 0x28)
struct UPUMG_XpTable : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	int64_t GetXpAtLevel(int32_t XpLevel); // Function PlatformUMG.PUMG_XpTable.GetXpAtLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb54480
	int64_t GetXpAtIndex(int32_t Index); // Function PlatformUMG.PUMG_XpTable.GetXpAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb543f0
	int32_t GetMinXpLevel(); // Function PlatformUMG.PUMG_XpTable.GetMinXpLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb536e0
	int32_t GetLevelCount(); // Function PlatformUMG.PUMG_XpTable.GetLevelCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53650
	int32_t GetLevelAtXp(int64_t XpPoints); // Function PlatformUMG.PUMG_XpTable.GetLevelAtXp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb535c0
	int64_t GetId(); // Function PlatformUMG.PUMG_XpTable.GetId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53500
};

// Class PlatformUMG.PUMG_StoreItemHelper
// Size: 0x290 (Inherited: 0x28)
struct UPUMG_StoreItemHelper : UObject {
	struct FMulticastInlineDelegate OnPurchaseItem; // 0x28(0x10)
	struct FMulticastInlineDelegate OnPurchasePortalItem; // 0x38(0x10)
	struct FMulticastInlineDelegate OnNotEnoughCurrency; // 0x48(0x10)
	struct FMulticastInlineDelegate OnReceiveVendor; // 0x58(0x10)
	struct FMulticastInlineDelegate OnReceiveXpTables; // 0x68(0x10)
	struct FMulticastInlineDelegate OnReceivePricePoints; // 0x78(0x10)
	struct FMulticastInlineDelegate OnPortalOffersReceived; // 0x88(0x10)
	struct FMulticastInlineDelegate OnPendingPurchaseReceived; // 0x98(0x10)
	struct FMulticastInlineDelegate OnPurchaseSubmitted; // 0xa8(0x10)
	char pad_B8[0x28]; // 0xb8(0x28)
	struct TMap<struct FString, struct UPUMG_StoreItem*> SkuToStoreItem; // 0xe0(0x50)
	struct TMap<int32_t, struct UPUMG_StoreItem*> StoreItems; // 0x130(0x50)
	char pad_180[0x60]; // 0x180(0x60)
	struct TMap<int64_t, struct UPUMG_XpTable*> XpTables; // 0x1e0(0x50)
	char pad_230[0x50]; // 0x230(0x50)
	bool XpTablesLoaded; // 0x280(0x01)
	bool PricePointsLoaded; // 0x281(0x01)
	bool PortalOffersLoaded; // 0x282(0x01)
	char pad_283[0x5]; // 0x283(0x05)
	struct UGameInstance* GameInstance; // 0x288(0x08)

	void UIX_RedeemCode(struct FString Code); // Function PlatformUMG.PUMG_StoreItemHelper.UIX_RedeemCode // (Final|Native|Public|BlueprintCallable) // @ game+0xb54b50
	bool UIX_CompletePurchaseItem(struct UPUMG_StorePurchaseRequest* PurchaseRequest); // Function PlatformUMG.PUMG_StoreItemHelper.UIX_CompletePurchaseItem // (Native|Public|BlueprintCallable) // @ game+0xb54ab0
	int32_t RequestVendorData(struct TArray<int32_t> VendorIds); // Function PlatformUMG.PUMG_StoreItemHelper.RequestVendorData // (Native|Public|BlueprintCallable) // @ game+0xb54950
	bool HasPendingPurchase(); // Function PlatformUMG.PUMG_StoreItemHelper.HasPendingPurchase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb545b0
	struct UPUMG_XpTable* GetXpTable(int64_t XpTableId); // Function PlatformUMG.PUMG_StoreItemHelper.GetXpTable // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb54510
	struct TArray<struct UPUMG_StoreItem*> GetStoreItemsForVendor(int32_t nVendorId, bool bIncludeInactiveItems, bool bSearchSubContainers); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemsForVendor // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb541e0
	struct TArray<struct UPUMG_StoreItem*> GetStoreItemsAndQuantitiesForVendor(int32_t nVendorId, bool bIncludeInactiveItems, bool bSearchSubContainers, struct TMap<int32_t, int32_t>& QuantityMap, int32_t ExternalQuantity); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemsAndQuantitiesForVendor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb53f40
	struct UPUMG_StoreItem* GetStoreItemForVendorByItemId(int32_t nVendorId, int32_t nItemId, bool bSearchSubVendors); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemForVendorByItemId // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb53e30
	struct UPUMG_StoreItem* GetStoreItemForVendor(int32_t nVendorId, int32_t nLootItemId); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItemForVendor // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb53d60
	struct UPUMG_StoreItem* GetStoreItem(int32_t LootId); // Function PlatformUMG.PUMG_StoreItemHelper.GetStoreItem // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb53cc0
	struct TArray<struct UPUMG_StorePurchaseRequest*> GetPendingPurchaseData(); // Function PlatformUMG.PUMG_StoreItemHelper.GetPendingPurchaseData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb537b0
	void ExitInGameStoreUI(); // Function PlatformUMG.PUMG_StoreItemHelper.ExitInGameStoreUI // (Final|Native|Public|BlueprintCallable) // @ game+0xb53070
	void EnterInGameStoreUI(); // Function PlatformUMG.PUMG_StoreItemHelper.EnterInGameStoreUI // (Final|Native|Public|BlueprintCallable) // @ game+0xb53050
	bool DoesPortalHaveOffers(); // Function PlatformUMG.PUMG_StoreItemHelper.DoesPortalHaveOffers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb53010
	bool AreXpTablesLoaded(); // Function PlatformUMG.PUMG_StoreItemHelper.AreXpTablesLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb52e50
	bool ArePricePointsLoaded(); // Function PlatformUMG.PUMG_StoreItemHelper.ArePricePointsLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb52e30
	bool ArePortalOffersLoaded(); // Function PlatformUMG.PUMG_StoreItemHelper.ArePortalOffersLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb52e10
};

// Class PlatformUMG.PUMG_UISoundTheme
// Size: 0x78 (Inherited: 0x28)
struct UPUMG_UISoundTheme : UObject {
	struct TMap<struct FName, struct FPUMG_SoundThemeEventMapping> SoundEventBindings; // 0x28(0x50)
};

// Class PlatformUMG.PUMG_GenericRouteDataObject
// Size: 0x48 (Inherited: 0x28)
struct UPUMG_GenericRouteDataObject : UObject {
	struct FString StringValue; // 0x28(0x10)
	int32_t IntValue; // 0x38(0x04)
	struct FName NameValue; // 0x3c(0x08)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class PlatformUMG.PUMG_ViewRedirecter
// Size: 0x28 (Inherited: 0x28)
struct UPUMG_ViewRedirecter : UObject {

	bool ShouldRedirect(struct APUMG_HUD* HUD, struct FName Route, struct UObject*& SceneData); // Function PlatformUMG.PUMG_ViewRedirecter.ShouldRedirect // (Native|Public|HasOutParms) // @ game+0xb59a80
};

// Class PlatformUMG.PUMG_ViewLayer
// Size: 0x118 (Inherited: 0x28)
struct UPUMG_ViewLayer : UObject {
	struct UCanvasPanel* DisplayTarget; // 0x28(0x08)
	struct UPUMG_ViewManager* MyManager; // 0x30(0x08)
	enum class EViewManagerTransitionState CurrentTransitionState; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FName> CurrentRouteStack; // 0x40(0x10)
	struct TArray<struct FName> CurrentTransitionRouteStack; // 0x50(0x10)
	struct TMap<struct FName, struct UPUMG_Widget*> RouteWidgetMap; // 0x60(0x50)
	struct FName DefaultRoute; // 0xb0(0x08)
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TMap<struct FName, struct UObject*> PendingRouteData; // 0xc0(0x50)
	struct UDataTable* Routes; // 0x110(0x08)

	bool IsRouteValid(struct FName RouteName); // Function PlatformUMG.PUMG_ViewLayer.IsRouteValid // (Final|Native|Protected|BlueprintCallable) // @ game+0xb58d20
	void GoToRoute_InternalShowStep(); // Function PlatformUMG.PUMG_ViewLayer.GoToRoute_InternalShowStep // (Final|Native|Protected) // @ game+0xb58900
	void GoToRoute_HandleShowFinished(struct UPUMG_Widget* Widget); // Function PlatformUMG.PUMG_ViewLayer.GoToRoute_HandleShowFinished // (Final|Native|Protected) // @ game+0xb58880
	void GoToRoute_HandleHideFinished(struct UPUMG_Widget* Widget); // Function PlatformUMG.PUMG_ViewLayer.GoToRoute_HandleHideFinished // (Final|Native|Protected) // @ game+0xb58800
};

// Class PlatformUMG.PUMG_ViewManager
// Size: 0xe8 (Inherited: 0x28)
struct UPUMG_ViewManager : UObject {
	struct TArray<struct UPUMG_ViewLayer*> ViewLayers; // 0x28(0x10)
	struct TMap<struct FName, struct UPUMG_Widget*> StickyWidgetMap; // 0x38(0x50)
	struct FMulticastInlineDelegate OnViewStateChanged; // 0x88(0x10)
	struct FMulticastInlineDelegate OnViewStateChangeStarted; // 0x98(0x10)
	struct APUMG_HUD* HudRef; // 0xa8(0x08)
	struct TArray<struct UCanvasPanel*> CanvasPanels; // 0xb0(0x10)
	struct TArray<struct FStickyWidgetData> StickyWidgets; // 0xc0(0x10)
	struct UDataTable* Routes; // 0xd0(0x08)
	struct TArray<struct FViewRouteRedirectData> AlwaysCheckRouteData; // 0xd8(0x10)

	bool SwapRoute(struct FName RouteName, struct FName SwapTargetRoute, bool ForceTransition); // Function PlatformUMG.PUMG_ViewManager.SwapRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59d60
	void SetPendingRouteData(struct FName RouteName, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.SetPendingRouteData // (Final|Native|Public|BlueprintCallable) // @ game+0xb59900
	bool ReplaceRoute(struct FName RouteName, bool ForceTransition, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.ReplaceRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59570
	bool RemoveRoute(struct FName RouteName, bool ForceTransition); // Function PlatformUMG.PUMG_ViewManager.RemoveRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59360
	bool PushRoute(struct FName RouteName, bool ForceTransition, struct UObject* Data); // Function PlatformUMG.PUMG_ViewManager.PushRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59090
	bool PopRoute(bool ForceTransition); // Function PlatformUMG.PUMG_ViewManager.PopRoute // (Final|Native|Public|BlueprintCallable) // @ game+0xb59000
	bool IsLayerIdle(enum class EViewManagerLayer LayerType); // Function PlatformUMG.PUMG_ViewManager.IsLayerIdle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58c90
	bool IsEveryLayerIdle(); // Function PlatformUMG.PUMG_ViewManager.IsEveryLayerIdle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58c30
	bool IsBlockingAcquisitions(); // Function PlatformUMG.PUMG_ViewManager.IsBlockingAcquisitions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58c00
	void InitializeRoutes(struct UDataTable* RouteTable); // Function PlatformUMG.PUMG_ViewManager.InitializeRoutes // (Final|Native|Protected) // @ game+0xb58af0
	void Initialize(); // Function PlatformUMG.PUMG_ViewManager.Initialize // (Final|Native|Public|BlueprintCallable) // @ game+0xb58ad0
	bool HasCompletedRedirectFlow(enum class EViewRouteRedirectionPhase RedirectPhase); // Function PlatformUMG.PUMG_ViewManager.HasCompletedRedirectFlow // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58920
	int32_t GetViewRouteCount(); // Function PlatformUMG.PUMG_ViewManager.GetViewRouteCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb587d0
	struct UPUMG_Widget* GetTopViewRouteWidget(); // Function PlatformUMG.PUMG_ViewManager.GetTopViewRouteWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58750
	struct FName GetTopViewRoute(); // Function PlatformUMG.PUMG_ViewManager.GetTopViewRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58710
	enum class EViewManagerLayer GetTopLayer(); // Function PlatformUMG.PUMG_ViewManager.GetTopLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb586e0
	bool GetPendingRouteData(struct FName RouteName, struct UObject*& Data); // Function PlatformUMG.PUMG_ViewManager.GetPendingRouteData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb58540
	struct FName GetDefaultRouteForLayer(enum class EViewManagerLayer LayerType); // Function PlatformUMG.PUMG_ViewManager.GetDefaultRouteForLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58440
	struct FName GetCurrentTransitionRoute(enum class EViewManagerLayer Layer); // Function PlatformUMG.PUMG_ViewManager.GetCurrentTransitionRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb583b0
	struct FName GetCurrentRoute(enum class EViewManagerLayer Layer); // Function PlatformUMG.PUMG_ViewManager.GetCurrentRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb58320
	bool ContainsRoute(struct FName RouteName); // Function PlatformUMG.PUMG_ViewManager.ContainsRoute // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb57c20
};

// Class PlatformUMG.PUMG_VoiceChatManager
// Size: 0x88 (Inherited: 0x28)
struct UPUMG_VoiceChatManager : UObject {
	bool bPendingPartyVoipJoin; // 0x28(0x01)
	bool bPendingMatchVoipJoin; // 0x29(0x01)
	char pad_2A[0x6]; // 0x2a(0x06)
	struct FString CurrentPartyVoiceChatChannel; // 0x30(0x10)
	int32_t CurrentPartyId; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FString CurrentMatchVoiceChatChannel; // 0x48(0x10)
	enum class EPUMG_MatchStatus CurrentMatchStatus; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FSerializedMatchId CurrentMatchId; // 0x60(0x10)
	bool bCurrentIsTokenForTaskForce; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct UPUMG_PartyDataFactory* PartyDataFactory; // 0x78(0x08)
	struct UPUMG_QueueDataFactory* QueueDataFactory; // 0x80(0x08)

	void OnPartyDataUpdated(); // Function PlatformUMG.PUMG_VoiceChatManager.OnPartyDataUpdated // (Final|Native|Protected) // @ game+0xb58fc0
	void OnMatchStatusUpdated(enum class EPUMG_MatchStatus MatchStatus); // Function PlatformUMG.PUMG_VoiceChatManager.OnMatchStatusUpdated // (Final|Native|Protected) // @ game+0xb58f40
};

