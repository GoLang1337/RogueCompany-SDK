// Enum E_RankedTiers.E_RankedTiers
enum class E_RankedTiers : uint8 {
	NewEnumerator8 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	NewEnumerator4 = 5,
	NewEnumerator6 = 6,
	E_MAX = 7
};

