// BlueprintGeneratedClass Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C
// Size: 0x248 (Inherited: 0x228)
struct ALobby_Core_RogueScreen_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	bool Enable Pose Rogue Time Dilation; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct ARogueScreenPreviewActor_WithPose_C* PosedRogueActor_ExecuteUbergraph_Lobby_Core_RogueScreen_RefProperty; // 0x238(0x08)
	struct AKSLobbyCameraActor* PosedRogueCamera_ExecuteUbergraph_Lobby_Core_RogueScreen_RefProperty; // 0x240(0x08)

	void On Rogue Preview Fully Loaded(struct TSet<struct FName>& Keywords); // Function Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C.On Rogue Preview Fully Loaded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Time Dilation for  Posed Rogues(); // Function Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C.Time Dilation for  Posed Rogues // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveTick(float DeltaSeconds); // Function Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void On Player Rogue Preview Changed(struct AKSJobSelectPreviewActor* PreviewActor, enum class EKSJobSelectPreviewLoadState PreviousState); // Function Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C.On Player Rogue Preview Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_Lobby_Core_RogueScreen(int32_t EntryPoint); // Function Lobby_Core_RogueScreen.Lobby_Core_RogueScreen_C.ExecuteUbergraph_Lobby_Core_RogueScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

