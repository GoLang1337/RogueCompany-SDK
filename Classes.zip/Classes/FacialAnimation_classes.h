// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x830 (Inherited: 0x7f0)
struct UAudioCurveSourceComponent : UAudioComponent {
	struct FName CurveSourceBindingName; // 0x7f0(0x08)
	float CurveSyncOffset; // 0x7f8(0x04)
	char pad_7FC[0x34]; // 0x7fc(0x34)
};

