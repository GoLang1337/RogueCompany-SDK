// BlueprintGeneratedClass AKSAnimNotifyState_WeaponProp.AKSAnimNotifyState_WeaponProp_C
// Size: 0x98 (Inherited: 0x98)
struct UAKSAnimNotifyState_WeaponProp_C : UKSAnimNotifyState_WeaponProp {
};

