// WidgetBlueprintGeneratedClass PlayerHealthMeterPadding.PlayerHealthMeterPadding_C
// Size: 0x240 (Inherited: 0x238)
struct UPlayerHealthMeterPadding_C : UUserWidget {
	struct UHorizontalBox* PaddingContainer; // 0x238(0x08)

	void SetNumSegments(int32_t NumSegments); // Function PlayerHealthMeterPadding.PlayerHealthMeterPadding_C.SetNumSegments // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

