// BlueprintGeneratedClass LobbyMainCharacter.LobbyMainCharacter_C
// Size: 0x3eb3 (Inherited: 0x3e10)
struct ALobbyMainCharacter_C : AKSLobbyCharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3e10(0x08)
	enum class ETimelineDirection LobbyProp01_Timeline__Direction_311B7F8B46533A11B70CFAA92E9DA987; // 0x3e18(0x01)
	char pad_3E19[0x7]; // 0x3e19(0x07)
	struct UTimelineComponent* LobbyProp01_Timeline; // 0x3e20(0x08)
	enum class ETimelineDirection LobbyWeapon02_Timeline__Direction_6E3E791441C09FAF955C7099C1934001; // 0x3e28(0x01)
	char pad_3E29[0x7]; // 0x3e29(0x07)
	struct UTimelineComponent* LobbyWeapon02_Timeline; // 0x3e30(0x08)
	enum class ETimelineDirection LobbyWeapon01_Timeline__Direction_A9FF0C36405CB79CE4A5609C33E7F935; // 0x3e38(0x01)
	char pad_3E39[0x7]; // 0x3e39(0x07)
	struct UTimelineComponent* LobbyWeapon01_Timeline; // 0x3e40(0x08)
	struct TArray<struct FName> LobbyFidgetKeywordArray; // 0x3e48(0x10)
	char pad_3E58[0x8]; // 0x3e58(0x08)
	struct FTransform Transform Reset; // 0x3e60(0x30)
	float Lobby Anim total duration; // 0x3e90(0x04)
	char pad_3E94[0x4]; // 0x3e94(0x04)
	struct FTimerHandle Lobby Anim timer; // 0x3e98(0x08)
	bool Loop montage; // 0x3ea0(0x01)
	char pad_3EA1[0x3]; // 0x3ea1(0x03)
	int32_t NewVar_1; // 0x3ea4(0x04)
	enum class EKSLobbyCharacterAnimationPose Lobby Character Animation Pose; // 0x3ea8(0x01)
	char pad_3EA9[0x3]; // 0x3ea9(0x03)
	float Lobby Anim Starting Time; // 0x3eac(0x04)
	bool HasInitializedNameplate; // 0x3eb0(0x01)
	bool Emote; // 0x3eb1(0x01)
	bool Emote Queued; // 0x3eb2(0x01)

	void OnGenderChanged(); // Function LobbyMainCharacter.LobbyMainCharacter_C.OnGenderChanged // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeNameplate(struct UNewWBP_LobbyNameplate_C* Nameplate); // Function LobbyMainCharacter.LobbyMainCharacter_C.InitializeNameplate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Randomize Lobby Idle anim start(); // Function LobbyMainCharacter.LobbyMainCharacter_C.Randomize Lobby Idle anim start // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Make Lobby Fidget Keyword Array(); // Function LobbyMainCharacter.LobbyMainCharacter_C.Make Lobby Fidget Keyword Array // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Parse Lobby Fidget Animation(struct TArray<struct FName>& LobbyFidgetKeywordArray, enum class EKSLobbyCharacterAnimationPose& Lobby Character Animation Pose); // Function LobbyMainCharacter.LobbyMainCharacter_C.Parse Lobby Fidget Animation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void Get Montage Position of Lobby Characater(float& Position); // Function LobbyMainCharacter.LobbyMainCharacter_C.Get Montage Position of Lobby Characater // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void Init Body Apparel(); // Function LobbyMainCharacter.LobbyMainCharacter_C.Init Body Apparel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void LobbyWeapon01_Timeline__FinishedFunc(); // Function LobbyMainCharacter.LobbyMainCharacter_C.LobbyWeapon01_Timeline__FinishedFunc // (BlueprintEvent) // @ game+0x24d5b40
	void LobbyWeapon01_Timeline__UpdateFunc(); // Function LobbyMainCharacter.LobbyMainCharacter_C.LobbyWeapon01_Timeline__UpdateFunc // (BlueprintEvent) // @ game+0x24d5b40
	void LobbyWeapon02_Timeline__FinishedFunc(); // Function LobbyMainCharacter.LobbyMainCharacter_C.LobbyWeapon02_Timeline__FinishedFunc // (BlueprintEvent) // @ game+0x24d5b40
	void LobbyWeapon02_Timeline__UpdateFunc(); // Function LobbyMainCharacter.LobbyMainCharacter_C.LobbyWeapon02_Timeline__UpdateFunc // (BlueprintEvent) // @ game+0x24d5b40
	void LobbyProp01_Timeline__FinishedFunc(); // Function LobbyMainCharacter.LobbyMainCharacter_C.LobbyProp01_Timeline__FinishedFunc // (BlueprintEvent) // @ game+0x24d5b40
	void LobbyProp01_Timeline__UpdateFunc(); // Function LobbyMainCharacter.LobbyMainCharacter_C.LobbyProp01_Timeline__UpdateFunc // (BlueprintEvent) // @ game+0x24d5b40
	void OnNotifyEnd_AA177F3D4F176F58A7691D84D8C329C7(struct FName NotifyName, int32_t MontageInstanceID); // Function LobbyMainCharacter.LobbyMainCharacter_C.OnNotifyEnd_AA177F3D4F176F58A7691D84D8C329C7 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnNotifyBegin_AA177F3D4F176F58A7691D84D8C329C7(struct FName NotifyName, int32_t MontageInstanceID); // Function LobbyMainCharacter.LobbyMainCharacter_C.OnNotifyBegin_AA177F3D4F176F58A7691D84D8C329C7 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnInterrupted_AA177F3D4F176F58A7691D84D8C329C7(struct FName NotifyName, int32_t MontageInstanceID); // Function LobbyMainCharacter.LobbyMainCharacter_C.OnInterrupted_AA177F3D4F176F58A7691D84D8C329C7 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnBlendOut_AA177F3D4F176F58A7691D84D8C329C7(struct FName NotifyName, int32_t MontageInstanceID); // Function LobbyMainCharacter.LobbyMainCharacter_C.OnBlendOut_AA177F3D4F176F58A7691D84D8C329C7 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnCompleted_AA177F3D4F176F58A7691D84D8C329C7(struct FName NotifyName, int32_t MontageInstanceID); // Function LobbyMainCharacter.LobbyMainCharacter_C.OnCompleted_AA177F3D4F176F58A7691D84D8C329C7 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StopRightPropEffect(); // Function LobbyMainCharacter.LobbyMainCharacter_C.StopRightPropEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayRightPropEffect(float Duration, struct FName MaterialParameter, struct UCurveFloat* FloatCurve); // Function LobbyMainCharacter.LobbyMainCharacter_C.PlayRightPropEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StopLeftPropEffect(); // Function LobbyMainCharacter.LobbyMainCharacter_C.StopLeftPropEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayLeftPropEffect(float Duration, struct FName MaterialParameter, struct UCurveFloat* FloatCurve); // Function LobbyMainCharacter.LobbyMainCharacter_C.PlayLeftPropEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StopScenePropEffect(); // Function LobbyMainCharacter.LobbyMainCharacter_C.StopScenePropEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayScenePropEffect(float Duration, struct FName MaterialParameter, struct UCurveFloat* FloatCurve); // Function LobbyMainCharacter.LobbyMainCharacter_C.PlayScenePropEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function LobbyMainCharacter.LobbyMainCharacter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void Add Body Apparel As Parent(struct USkinnableSkeletalMeshComponent* Skinnable Mesh Component); // Function LobbyMainCharacter.LobbyMainCharacter_C.Add Body Apparel As Parent // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayLobbyCharacterMontage(); // Function LobbyMainCharacter.LobbyMainCharacter_C.PlayLobbyCharacterMontage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StopLobbyCharacterMontage(); // Function LobbyMainCharacter.LobbyMainCharacter_C.StopLobbyCharacterMontage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeLobbyCharacterAnimation(); // Function LobbyMainCharacter.LobbyMainCharacter_C.InitializeLobbyCharacterAnimation // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdateSilhouette(float DeltaSeconds); // Function LobbyMainCharacter.LobbyMainCharacter_C.UpdateSilhouette // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LobbyMainCharacter(int32_t EntryPoint); // Function LobbyMainCharacter.LobbyMainCharacter_C.ExecuteUbergraph_LobbyMainCharacter // (Final|UbergraphFunction) // @ game+0x24d5b40
};

