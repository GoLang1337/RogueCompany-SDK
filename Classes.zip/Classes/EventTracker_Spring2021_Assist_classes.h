// BlueprintGeneratedClass EventTracker_Spring2021_Assist.EventTracker_Spring2021_Assist_C
// Size: 0x214 (Inherited: 0x208)
struct UEventTracker_Spring2021_Assist_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	int32_t Assists; // 0x210(0x04)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Spring2021_Assist.EventTracker_Spring2021_Assist_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Spring2021_Assist.EventTracker_Spring2021_Assist_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_Spring2021_Assist.EventTracker_Spring2021_Assist_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void On Money Earned(int32_t Money, struct FText Reason); // Function EventTracker_Spring2021_Assist.EventTracker_Spring2021_Assist_C.On Money Earned // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Spring2021_Assist(int32_t EntryPoint); // Function EventTracker_Spring2021_Assist.EventTracker_Spring2021_Assist_C.ExecuteUbergraph_EventTracker_Spring2021_Assist // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

