// BlueprintGeneratedClass DamageResistModInst.DamageResistModInst_C
// Size: 0x1c0 (Inherited: 0x1b8)
struct UDamageResistModInst_C : UKSPlayerModInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1b8(0x08)

	void OnNewCharacterFoundation(); // Function DamageResistModInst.DamageResistModInst_C.OnNewCharacterFoundation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void DamageTaken(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function DamageResistModInst.DamageResistModInst_C.DamageTaken // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_DamageResistModInst(int32_t EntryPoint); // Function DamageResistModInst.DamageResistModInst_C.ExecuteUbergraph_DamageResistModInst // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

