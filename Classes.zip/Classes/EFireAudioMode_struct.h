// Enum EFireAudioMode.EFireAudioMode
enum class EFireAudioMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	EFireAudioMode_MAX = 3
};

