// BlueprintGeneratedClass Katana_Drop.Katana_Drop_C
// Size: 0x851 (Inherited: 0x848)
struct AKatana_Drop_C : AKSMeleeWeaponAssetDrop {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x848(0x08)
	bool Stuck; // 0x850(0x01)

	void SetStuck(); // Function Katana_Drop.Katana_Drop_C.SetStuck // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Katana_Drop.Katana_Drop_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_Katana_Drop(int32_t EntryPoint); // Function Katana_Drop.Katana_Drop_C.ExecuteUbergraph_Katana_Drop // (Final|UbergraphFunction) // @ game+0x24d5b40
};

