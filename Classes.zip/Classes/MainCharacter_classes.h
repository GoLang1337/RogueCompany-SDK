// DynamicClass MainCharacter.MainCharacter_C
// Size: 0x54a0 (Inherited: 0x3c80)
struct AMainCharacter_C : AKSCharacter {
	struct UKSCharacterSocketComponent* MountedAimOrigin; // 0x3c78(0x08)
	struct UKSCharacterSocketComponent* UnderslungAimOrigin; // 0x3c80(0x08)
	struct UParticleSystemComponent* FX_Blinded; // 0x3c88(0x08)
	struct UCharacterHeatSourceComponent_C* CharacterHeatSourceComponent; // 0x3c90(0x08)
	struct UKSCharacterSocketComponent* PerformanceAimOrigin; // 0x3c98(0x08)
	struct UCharacterEmotionComponent_C* CharacterEmotionComponent; // 0x3ca0(0x08)
	struct USpringArmComponent* SkyDiveCameraBoom; // 0x3ca8(0x08)
	struct UWidgetComponent* Nameplate; // 0x3cb0(0x08)
	struct UMainCharacterThreatComponent_C* MainCharacterThreatComponent; // 0x3cb8(0x08)
	struct UKSTabletMeshComponent* NewTablet; // 0x3cc0(0x08)
	struct UMainEnvironmentTracker_C* MainEnvironmentTracker; // 0x3cc8(0x08)
	struct UKSAimAssistAnchorComponent* BodyAimAssistAnchor; // 0x3cd0(0x08)
	struct UKSAimAssistAnchorComponent* HeadAimAssistAnchor; // 0x3cd8(0x08)
	struct UParticleSystemComponent* Free Fall Particle Component; // 0x3ce0(0x08)
	struct UCameraComponent* SkyDiveCamera; // 0x3ce8(0x08)
	float EnterFreeFallFOVTimeline_FOV_214483C64B8EF94ABEE010ACC0C82B47; // 0x3cf0(0x04)
	enum class ETimelineDirection EnterFreeFallFOVTimeline__Direction_214483C64B8EF94ABEE010ACC0C82B47; // 0x3cf4(0x01)
	struct UTimelineComponent* EnterFreeFallFOVTimeline; // 0x3cf8(0x08)
	float NoseDiveFOVTimeline_FOV_B4B28FE84FD9F70D4702AD94CD02429F; // 0x3d00(0x04)
	enum class ETimelineDirection NoseDiveFOVTimeline__Direction_B4B28FE84FD9F70D4702AD94CD02429F; // 0x3d04(0x01)
	struct UTimelineComponent* NoseDiveFOVTimeline; // 0x3d08(0x08)
	struct FVector Martial_Artist_Target_Front_Camera_Offset_2353812C44E84070E58EA28AC0C39A7A; // 0x3d10(0x0c)
	struct FVector Martial_Artist_Target_Front_Camera_Rotation_2353812C44E84070E58EA28AC0C39A7A; // 0x3d1c(0x0c)
	enum class ETimelineDirection Martial_Artist_Target_Front__Direction_2353812C44E84070E58EA28AC0C39A7A; // 0x3d28(0x01)
	char pad_3D2B[0x5]; // 0x3d2b(0x05)
	struct UTimelineComponent* Martial Artist Target Front; // 0x3d30(0x08)
	struct FVector Martial_Artist_Target_Back_Camera_Offset_1BFA9A6E4FC29401CE8D43B8AAD4581C; // 0x3d38(0x0c)
	struct FVector Martial_Artist_Target_Back_Camera_Rotation_1BFA9A6E4FC29401CE8D43B8AAD4581C; // 0x3d44(0x0c)
	enum class ETimelineDirection Martial_Artist_Target_Back__Direction_1BFA9A6E4FC29401CE8D43B8AAD4581C; // 0x3d50(0x01)
	char pad_3D51[0x7]; // 0x3d51(0x07)
	struct UTimelineComponent* Martial Artist Target Back; // 0x3d58(0x08)
	struct FVector Martial_Artist_Instigator_Front_Camera_Offset_F70AEBFB4CDEF611144DE3BBA0C06E0C; // 0x3d60(0x0c)
	struct FVector Martial_Artist_Instigator_Front_Camera_Rotation_F70AEBFB4CDEF611144DE3BBA0C06E0C; // 0x3d6c(0x0c)
	enum class ETimelineDirection Martial_Artist_Instigator_Front__Direction_F70AEBFB4CDEF611144DE3BBA0C06E0C; // 0x3d78(0x01)
	char pad_3D79[0x7]; // 0x3d79(0x07)
	struct UTimelineComponent* Martial Artist Instigator Front; // 0x3d80(0x08)
	struct FVector Martial_Artist_Instigator_Back_Camera_Offset_28F092594C0CD50C0A3EA1BF17E2C5E1; // 0x3d88(0x0c)
	struct FVector Martial_Artist_Instigator_Back_Camera_Rotation_28F092594C0CD50C0A3EA1BF17E2C5E1; // 0x3d94(0x0c)
	enum class ETimelineDirection Martial_Artist_Instigator_Back__Direction_28F092594C0CD50C0A3EA1BF17E2C5E1; // 0x3da0(0x01)
	char pad_3DA1[0x7]; // 0x3da1(0x07)
	struct UTimelineComponent* Martial Artist Instigator Back; // 0x3da8(0x08)
	struct FVector CameraDodgeRoll_Relative_Position_4B7EB20A461034BB0B80418AE71BD9F4; // 0x3db0(0x0c)
	float CameraDodgeRoll_Camera_Boom_Length_4B7EB20A461034BB0B80418AE71BD9F4; // 0x3dbc(0x04)
	enum class ETimelineDirection CameraDodgeRoll__Direction_4B7EB20A461034BB0B80418AE71BD9F4; // 0x3dc0(0x01)
	char pad_3DC1[0x7]; // 0x3dc1(0x07)
	struct UTimelineComponent* CameraDodgeRoll; // 0x3dc8(0x08)
	float SprintFOVTimeline_FOVAlpha_F9A879E74FD1B4D844684CBEE4230863; // 0x3dd0(0x04)
	enum class ETimelineDirection SprintFOVTimeline__Direction_F9A879E74FD1B4D844684CBEE4230863; // 0x3dd4(0x01)
	char pad_3DD5[0x3]; // 0x3dd5(0x03)
	struct UTimelineComponent* SprintFOVTimeline; // 0x3dd8(0x08)
	float EndImmunity_Invulnerable_4A69979040C00E80AB6D5687355E98EA; // 0x3de0(0x04)
	enum class ETimelineDirection EndImmunity__Direction_4A69979040C00E80AB6D5687355E98EA; // 0x3de4(0x01)
	char pad_3DE5[0x3]; // 0x3de5(0x03)
	struct UTimelineComponent* EndImmunity; // 0x3de8(0x08)
	float StartImmunity_Invulnerable_F2F49BA44D30D2903638919AFE6C1704; // 0x3df0(0x04)
	enum class ETimelineDirection StartImmunity__Direction_F2F49BA44D30D2903638919AFE6C1704; // 0x3df4(0x01)
	char pad_3DF5[0x3]; // 0x3df5(0x03)
	struct UTimelineComponent* StartImmunity; // 0x3df8(0x08)
	float Camera_Boom_Timeline_Player_Mesh_ADS_Weight_Reverse_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3e00(0x04)
	float Camera_Boom_Timeline_Player_Mesh_ADS_Weight_Forward_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3e04(0x04)
	float Camera_Boom_Timeline_FOV_Weight_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3e08(0x04)
	float Camera_Boom_Timeline_Camera_Boom_Length_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3e0c(0x04)
	enum class ETimelineDirection Camera_Boom_Timeline__Direction_7F7960E24E458B7FB9796A9428D9E3C5; // 0x3e10(0x01)
	char pad_3E11[0x7]; // 0x3e11(0x07)
	struct UTimelineComponent* Camera Boom Timeline; // 0x3e18(0x08)
	float Elapsed; // 0x3e20(0x04)
	bool StopwatchOn; // 0x3e24(0x01)
	char pad_3E25[0x3]; // 0x3e25(0x03)
	struct FVector PlayerLocation; // 0x3e28(0x0c)
	char pad_3E34[0x4]; // 0x3e34(0x04)
	struct UAkAudioEvent* Successful Hit AkEvent; // 0x3e38(0x08)
	bool ADS Test; // 0x3e40(0x01)
	char pad_3E41[0x3]; // 0x3e41(0x03)
	float Camera Boom Arm Max; // 0x3e44(0x04)
	float Cached 1p Field of View; // 0x3e48(0x04)
	float Test Alpha; // 0x3e4c(0x04)
	bool InFreeFall; // 0x3e50(0x01)
	bool Turn Right; // 0x3e51(0x01)
	bool Turn Left; // 0x3e52(0x01)
	char pad_3E53[0x1]; // 0x3e53(0x01)
	float Pitch; // 0x3e54(0x04)
	struct UParticleSystem* Friendly Free Fall; // 0x3e58(0x08)
	struct UParticleSystem* Enemy Free Fall; // 0x3e60(0x08)
	float Yaw; // 0x3e68(0x04)
	float Main Camera Cached FOV; // 0x3e6c(0x04)
	int32_t HitDirs; // 0x3e70(0x04)
	enum class HitEnum HitEnum; // 0x3e74(0x01)
	char pad_3E75[0x3]; // 0x3e75(0x03)
	struct FKSSpecialEffect DownedPPEffect; // 0x3e78(0x50)
	float Downed PP Transition Duration; // 0x3ec8(0x04)
	bool IsTrailActive; // 0x3ecc(0x01)
	char pad_3ECD[0x3]; // 0x3ecd(0x03)
	struct UMaterialInterface* FlashBang PP Material; // 0x3ed0(0x08)
	struct UMaterialInstanceDynamic* FlashBang PP Material Instance; // 0x3ed8(0x08)
	struct TArray<struct UObject*> SFX Grenade Damage Type; // 0x3ee0(0x10)
	struct TArray<struct UObject*> SFX Blade Damage Type; // 0x3ef0(0x10)
	struct AActor* SFX Damage Target; // 0x3f00(0x08)
	struct FVector LeftTempLoc; // 0x3f08(0x0c)
	float AffectRange; // 0x3f14(0x04)
	struct FVector RightTempLoc; // 0x3f18(0x0c)
	char pad_3F24[0x4]; // 0x3f24(0x04)
	struct UMaterialInterface* Out Of Bounds PP Material; // 0x3f28(0x08)
	struct UMaterialInstanceDynamic* Out Of Bounds PP Material Instance; // 0x3f30(0x08)
	float CachedFOV; // 0x3f38(0x04)
	char pad_3F3C[0x4]; // 0x3f3c(0x04)
	struct FLastHitImpulse LastHitInfo; // 0x3f40(0x40)
	struct FRotator KnockbackRotation; // 0x3f80(0x0c)
	float DeltaTime; // 0x3f8c(0x04)
	bool bIsRagdoll; // 0x3f90(0x01)
	bool bIsLaunchedOnDown; // 0x3f91(0x01)
	bool bSnapshotPoseFacingUp; // 0x3f92(0x01)
	char pad_3F93[0x5]; // 0x3f93(0x05)
	struct UAnimMontage* GetUpMontage; // 0x3f98(0x08)
	bool bIsRagdollOnGround; // 0x3fa0(0x01)
	char pad_3FA1[0x3]; // 0x3fa1(0x03)
	struct FVector RagdollPelvisLocation; // 0x3fa4(0x0c)
	struct FVector RagdollCapsuleLocation; // 0x3fb0(0x0c)
	float TimeInRagdoll; // 0x3fbc(0x04)
	float MaxTimeInRagdoll; // 0x3fc0(0x04)
	char pad_3FC4[0x4]; // 0x3fc4(0x04)
	struct UParticleSystemComponent* FireParticle; // 0x3fc8(0x08)
	struct UMaterialInstanceDynamic* GrenadeImpactPointMID; // 0x3fd0(0x08)
	bool ZiplineActive1; // 0x3fd8(0x01)
	char pad_3FD9[0x3]; // 0x3fd9(0x03)
	float SprintFov; // 0x3fdc(0x04)
	float SprintFOVChangeDuration; // 0x3fe0(0x04)
	float ZiplineFov; // 0x3fe4(0x04)
	float PreviousFov; // 0x3fe8(0x04)
	char pad_3FEC[0x4]; // 0x3fec(0x04)
	struct FDebugFloatHistory InterpLengthHist; // 0x3ff0(0x20)
	struct UKSFXCurveComponent* AppliedDownedCurveComponent; // 0x4010(0x08)
	struct FDamageEffect Effect; // 0x4018(0x50)
	struct FKSSpecialEffect BloodPPEffect; // 0x4068(0x50)
	struct UMaterial* HealthPostProcess; // 0x40b8(0x08)
	struct UMaterialInstanceDynamic* Health PP MID; // 0x40c0(0x08)
	float HealthPPInterpSpeed; // 0x40c8(0x04)
	char pad_40CC[0x4]; // 0x40cc(0x04)
	struct FKSSpecialEffect SonarPPEffect; // 0x40d0(0x50)
	struct FKSSpecialEffect EMPPPEffect; // 0x4120(0x50)
	bool bEnableDirectionalDowns; // 0x4170(0x01)
	bool bEnableComplexDirectionalDowns; // 0x4171(0x01)
	char pad_4172[0x2]; // 0x4172(0x02)
	float FreeFallParticleDetachTime; // 0x4174(0x04)
	struct FKSSpecialEffect OutOfBoundsPPEffect; // 0x4178(0x50)
	struct UKSFXCurveComponent* OutOfBoundsEffectCurve; // 0x41c8(0x08)
	struct FKSSpecialEffect ConfirmHitPPEffect; // 0x41d0(0x50)
	int32_t Active Index; // 0x4220(0x04)
	char pad_4224[0x4]; // 0x4224(0x04)
	struct FKSSpecialEffect FirePostProcess; // 0x4228(0x50)
	struct TArray<struct FDamageEffect> QueuedDamageEffects; // 0x4278(0x10)
	bool InLowTreshold; // 0x4288(0x01)
	char pad_4289[0x3]; // 0x4289(0x03)
	float LowHealthTreshold; // 0x428c(0x04)
	struct FKSSpecialEffect PP_SkyDive; // 0x4290(0x50)
	struct UAkAudioEvent* GadgetSwapSound; // 0x42e0(0x08)
	bool ConfirmHitPPEffectEnabled; // 0x42e8(0x01)
	char pad_42E9[0x7]; // 0x42e9(0x07)
	struct FKSSpecialEffect ConfirmPickupPPEffect; // 0x42f0(0x50)
	int32_t StopLoopingReviveSFX; // 0x4340(0x04)
	int32_t StopLoopingArmorSFX; // 0x4344(0x04)
	struct FMulticastInlineDelegate OnPrimaryOneWeaponHolstered; // 0x4348(0x10)
	struct FMulticastInlineDelegate OnPrimaryTwoWeaponHolstered; // 0x4358(0x10)
	struct FName Temp_name_Variable; // 0x4368(0x08)
	struct FName Temp_name_Variable_2; // 0x4370(0x08)
	struct FName Temp_name_Variable_3; // 0x4378(0x08)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable; // 0x4380(0x10)
	struct FDelegate Temp_delegate_Variable; // 0x4390(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2; // 0x43a0(0x10)
	struct FDelegate Temp_delegate_Variable_2; // 0x43b0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3; // 0x43c0(0x10)
	struct FDelegate Temp_delegate_Variable_3; // 0x43d0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4; // 0x43e0(0x10)
	struct FDelegate Temp_delegate_Variable_4; // 0x43f0(0x10)
	struct FName Temp_name_Variable_4; // 0x4400(0x08)
	enum class EKSPowerSlideEndReason K2Node_Event_EndReason; // 0x4408(0x01)
	bool Temp_bool_IsClosed_Variable; // 0x4409(0x01)
	char pad_440A[0x6]; // 0x440a(0x06)
	struct FDamageEffect K2Node_CustomEvent_Effect_3; // 0x4410(0x50)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base; // 0x4460(0x08)
	bool K2Node_ClassDynamicCast_bSuccess; // 0x4468(0x01)
	char pad_4469[0x3]; // 0x4469(0x03)
	struct FName Temp_name_Variable_5; // 0x446c(0x08)
	struct FName Temp_name_Variable_6; // 0x4474(0x08)
	struct FName Temp_name_Variable_7; // 0x447c(0x08)
	struct FName Temp_name_Variable_8; // 0x4484(0x08)
	struct FName Temp_name_Variable_9; // 0x448c(0x08)
	struct FName Temp_name_Variable_10; // 0x4494(0x08)
	float K2Node_Event_Damage; // 0x449c(0x04)
	struct UObject* K2Node_Event_DamageTypeClass_2; // 0x44a0(0x08)
	float K2Node_Event_DamageImpulse; // 0x44a8(0x04)
	struct FVector K2Node_Event_RelativeImpactLocation; // 0x44ac(0x0c)
	struct FName K2Node_Event_BoneName; // 0x44b8(0x08)
	struct AActor* K2Node_Event_DamageCauser_2; // 0x44c0(0x08)
	struct FDelegate Temp_delegate_Variable_5; // 0x44c8(0x10)
	bool Temp_bool_Has_Been_Initd_Variable; // 0x44d8(0x01)
	bool CallFunc_GetRagdollFacingDirection_IsUp; // 0x44d9(0x01)
	char pad_44DA[0x6]; // 0x44da(0x06)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_5; // 0x44e0(0x10)
	struct FDelegate Temp_delegate_Variable_6; // 0x44f0(0x10)
	bool K2Node_CustomEvent_IsGrounded; // 0x4500(0x01)
	char pad_4501[0x7]; // 0x4501(0x07)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_6; // 0x4508(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0x4518(0x10)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult; // 0x4528(0x88)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0x45b0(0x10)
	struct FVector CallFunc_GetPhysicsLinearVelocity_ReturnValue; // 0x45c0(0x0c)
	struct FDelegate Temp_delegate_Variable_7; // 0x45cc(0x10)
	char pad_45DC[0x4]; // 0x45dc(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_7; // 0x45e0(0x10)
	struct FDelegate Temp_delegate_Variable_8; // 0x45f0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_8; // 0x4600(0x10)
	struct FDelegate Temp_delegate_Variable_9; // 0x4610(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_9; // 0x4620(0x10)
	struct FDelegate Temp_delegate_Variable_10; // 0x4630(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_10; // 0x4640(0x10)
	struct FDelegate Temp_delegate_Variable_11; // 0x4650(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_11; // 0x4660(0x10)
	bool CallFunc_ShouldLastHitLaunchIntoRagdoll_bShouldRagdoll; // 0x4670(0x01)
	char pad_4671[0x3]; // 0x4671(0x03)
	struct FDelegate Temp_delegate_Variable_12; // 0x4674(0x10)
	char pad_4684[0x4]; // 0x4684(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_12; // 0x4688(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0x4698(0x10)
	bool Temp_bool_Has_Been_Initd_Variable_2; // 0x46a8(0x01)
	char pad_46A9[0x3]; // 0x46a9(0x03)
	float K2Node_CustomEvent_DeltaSeconds; // 0x46ac(0x04)
	struct FName Temp_name_Variable_11; // 0x46b0(0x08)
	struct FName Temp_name_Variable_12; // 0x46b8(0x08)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitLocation; // 0x46c0(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitNormal; // 0x46cc(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_VectorToHitSource; // 0x46d8(0x0c)
	enum class EKSMovementDirection CallFunc_ProcessTakePointHitDamage_HitDirection; // 0x46e4(0x01)
	char pad_46E5[0x3]; // 0x46e5(0x03)
	struct FName K2Node_Event_SequenceName; // 0x46e8(0x08)
	bool K2Node_SwitchName_CmpSuccess; // 0x46f0(0x01)
	char pad_46F1[0x3]; // 0x46f1(0x03)
	struct FVector K2Node_CustomEvent_Camera_Rotation; // 0x46f4(0x0c)
	bool K2Node_CustomEvent_Uses_Rotation; // 0x4700(0x01)
	char pad_4701[0x3]; // 0x4701(0x03)
	struct FVector K2Node_CustomEvent_Camera_Offset; // 0x4704(0x0c)
	float CallFunc_BreakVector_X; // 0x4710(0x04)
	float CallFunc_BreakVector_Y; // 0x4714(0x04)
	float CallFunc_BreakVector_Z; // 0x4718(0x04)
	float CallFunc_BreakVector_X_2; // 0x471c(0x04)
	float CallFunc_BreakVector_Y_2; // 0x4720(0x04)
	float CallFunc_BreakVector_Z_2; // 0x4724(0x04)
	struct FDelegate Temp_delegate_Variable_13; // 0x4728(0x10)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult; // 0x4738(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult; // 0x47c0(0x88)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_13; // 0x4848(0x10)
	struct USkinnableSkeletalMeshComponent* K2Node_DynamicCast_AsSkinnable_Skeletal_Mesh_Component; // 0x4858(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0x4860(0x01)
	char pad_4861[0x7]; // 0x4861(0x07)
	struct USkinnableSkeletalMeshComponent* K2Node_DynamicCast_AsSkinnable_Skeletal_Mesh_Component_2; // 0x4868(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0x4870(0x01)
	bool Temp_bool_IsClosed_Variable_2; // 0x4871(0x01)
	bool K2Node_Event_bVisible; // 0x4872(0x01)
	char pad_4873[0x1]; // 0x4873(0x01)
	struct FDelegate Temp_delegate_Variable_14; // 0x4874(0x10)
	char pad_4884[0x4]; // 0x4884(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_14; // 0x4888(0x10)
	bool Temp_bool_Has_Been_Initd_Variable_3; // 0x4898(0x01)
	bool Temp_bool_IsClosed_Variable_3; // 0x4899(0x01)
	char pad_489A[0x2]; // 0x489a(0x02)
	struct FDelegate Temp_delegate_Variable_15; // 0x489c(0x10)
	char pad_48AC[0x4]; // 0x48ac(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_15; // 0x48b0(0x10)
	struct FDamageEffect K2Node_CustomEvent_Effect_2; // 0x48c0(0x50)
	struct FDelegate Temp_delegate_Variable_16; // 0x4910(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_16; // 0x4920(0x10)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base_2; // 0x4930(0x08)
	bool K2Node_ClassDynamicCast_bSuccess_2; // 0x4938(0x01)
	char pad_4939[0x3]; // 0x4939(0x03)
	struct FDelegate Temp_delegate_Variable_17; // 0x493c(0x10)
	char pad_494C[0x4]; // 0x494c(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_17; // 0x4950(0x10)
	struct UKSBloodSplatterComponent* K2Node_DynamicCast_AsKSBlood_Splatter_Component; // 0x4960(0x08)
	bool K2Node_DynamicCast_bSuccess_3; // 0x4968(0x01)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable; // 0x4969(0x01)
	bool CallFunc_GetLocalSettingAsBool_OutBool; // 0x496a(0x01)
	char pad_496B[0x5]; // 0x496b(0x05)
	struct FDamageEffect K2Node_CustomEvent_Effect; // 0x4970(0x50)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base_3; // 0x49c0(0x08)
	bool K2Node_ClassDynamicCast_bSuccess_3; // 0x49c8(0x01)
	char pad_49C9[0x7]; // 0x49c9(0x07)
	struct FCombatEventInfo K2Node_Event_DamageInfo_2; // 0x49d0(0x60)
	float K2Node_Event_DamageAmount; // 0x4a30(0x04)
	char pad_4A34[0x4]; // 0x4a34(0x04)
	struct UObject* K2Node_Event_DamageTypeClass; // 0x4a38(0x08)
	struct AActor* K2Node_Event_DamageCauser; // 0x4a40(0x08)
	struct FVector K2Node_Event_DamageOrigin; // 0x4a48(0x0c)
	char pad_4A54[0x4]; // 0x4a54(0x04)
	struct FCombatEventInfo K2Node_Event_DamageInfo; // 0x4a58(0x60)
	struct FDelegate Temp_delegate_Variable_18; // 0x4ab8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_18; // 0x4ac8(0x10)
	struct FDelegate Temp_delegate_Variable_19; // 0x4ad8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_19; // 0x4ae8(0x10)
	struct UParticleSystem* CallFunc_GetHitPawnEffectOverride_ParticleSystem; // 0x4af8(0x08)
	struct FDamageEffect K2Node_Event_Effect_2; // 0x4b00(0x50)
	struct FDamageEffect K2Node_Event_Effect; // 0x4b50(0x50)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitLocation_2; // 0x4ba0(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_WorldHitNormal_2; // 0x4bac(0x0c)
	struct FVector CallFunc_ProcessTakePointHitDamage_VectorToHitSource_2; // 0x4bb8(0x0c)
	enum class EKSMovementDirection CallFunc_ProcessTakePointHitDamage_HitDirection_2; // 0x4bc4(0x01)
	char pad_4BC5[0x3]; // 0x4bc5(0x03)
	struct UObject* K2Node_ClassDynamicCast_AsKSDamage_Type_Base_4; // 0x4bc8(0x08)
	bool K2Node_ClassDynamicCast_bSuccess_4; // 0x4bd0(0x01)
	char pad_4BD1[0x7]; // 0x4bd1(0x07)
	struct AKSCharacterBase* K2Node_CustomEvent_Character_2; // 0x4bd8(0x08)
	struct FDelegate Temp_delegate_Variable_20; // 0x4be0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_20; // 0x4bf0(0x10)
	struct FDelegate Temp_delegate_Variable_21; // 0x4c00(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_21; // 0x4c10(0x10)
	struct FDelegate Temp_delegate_Variable_22; // 0x4c20(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_22; // 0x4c30(0x10)
	struct FDelegate Temp_delegate_Variable_23; // 0x4c40(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_23; // 0x4c50(0x10)
	struct FDelegate Temp_delegate_Variable_24; // 0x4c60(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_24; // 0x4c70(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0x4c80(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0x4c90(0x10)
	struct APlayerState* K2Node_CustomEvent_Player; // 0x4ca0(0x08)
	struct TScriptInterface<IINameplateWidget_C> K2Node_DynamicCast_AsINameplate_Widget; // 0x4ca8(0x10)
	bool K2Node_DynamicCast_bSuccess_4; // 0x4cb8(0x01)
	char pad_4CB9[0x3]; // 0x4cb9(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x4cbc(0x10)
	char pad_4CCC[0x4]; // 0x4ccc(0x04)
	struct TScriptInterface<IINameplateWidget_C> K2Node_DynamicCast_AsINameplate_Widget_2; // 0x4cd0(0x10)
	bool K2Node_DynamicCast_bSuccess_5; // 0x4ce0(0x01)
	char pad_4CE1[0x3]; // 0x4ce1(0x03)
	float K2Node_Event_ExtraTime; // 0x4ce4(0x04)
	struct TScriptInterface<IINameplateWidget_C> K2Node_DynamicCast_AsINameplate_Widget_3; // 0x4ce8(0x10)
	bool K2Node_DynamicCast_bSuccess_6; // 0x4cf8(0x01)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_2; // 0x4cf9(0x01)
	enum class EMovementMode K2Node_Event_PrevMovementMode; // 0x4cfa(0x01)
	enum class EMovementMode K2Node_Event_NewMovementMode; // 0x4cfb(0x01)
	char K2Node_Event_PrevCustomMode; // 0x4cfc(0x01)
	char K2Node_Event_NewCustomMode; // 0x4cfd(0x01)
	char pad_4CFE[0x2]; // 0x4cfe(0x02)
	struct UKSCharacterMovementComponent* K2Node_DynamicCast_AsKSCharacter_Movement_Component; // 0x4d00(0x08)
	bool K2Node_DynamicCast_bSuccess_7; // 0x4d08(0x01)
	char pad_4D09[0x7]; // 0x4d09(0x07)
	struct FCombatEventInfo K2Node_CustomEvent_EventInfo_2; // 0x4d10(0x60)
	int32_t K2Node_CustomEvent_ExpBonus_2; // 0x4d70(0x04)
	char pad_4D74[0x4]; // 0x4d74(0x04)
	struct AKSPlayerState* K2Node_CustomEvent_Revivee; // 0x4d78(0x08)
	struct AKSPlayerState* K2Node_CustomEvent_Reviver; // 0x4d80(0x08)
	int32_t K2Node_CustomEvent_ExpBonus; // 0x4d88(0x04)
	char pad_4D8C[0x4]; // 0x4d8c(0x04)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State; // 0x4d90(0x08)
	bool K2Node_DynamicCast_bSuccess_8; // 0x4d98(0x01)
	char pad_4D99[0x7]; // 0x4d99(0x07)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_2; // 0x4da0(0x08)
	bool K2Node_DynamicCast_bSuccess_9; // 0x4da8(0x01)
	char pad_4DA9[0x3]; // 0x4da9(0x03)
	struct FDelegate Temp_delegate_Variable_25; // 0x4dac(0x10)
	char pad_4DBC[0x4]; // 0x4dbc(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_25; // 0x4dc0(0x10)
	struct FCombatEventInfo K2Node_CustomEvent_EventInfo; // 0x4dd0(0x60)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_3; // 0x4e30(0x08)
	bool K2Node_DynamicCast_bSuccess_10; // 0x4e38(0x01)
	char pad_4E39[0x7]; // 0x4e39(0x07)
	struct AKSPlayerState* K2Node_DynamicCast_AsKSPlayer_State_4; // 0x4e40(0x08)
	bool K2Node_DynamicCast_bSuccess_11; // 0x4e48(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_4; // 0x4e49(0x01)
	bool Temp_bool_IsClosed_Variable_4; // 0x4e4a(0x01)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_3; // 0x4e4b(0x01)
	bool K2Node_Event_Enabled; // 0x4e4c(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_5; // 0x4e4d(0x01)
	char pad_4E4E[0x2]; // 0x4e4e(0x02)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7; // 0x4e50(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8; // 0x4e60(0x10)
	struct AKSCharacter* K2Node_Event_Reviver_3; // 0x4e70(0x08)
	float K2Node_Event_ReviveTime; // 0x4e78(0x04)
	bool K2Node_Event_Remote; // 0x4e7c(0x01)
	char pad_4E7D[0x3]; // 0x4e7d(0x03)
	struct AKSCharacter* K2Node_Event_Reviver_2; // 0x4e80(0x08)
	struct AKSCharacter* K2Node_Event_Reviver; // 0x4e88(0x08)
	bool K2Node_CustomEvent_IsSprinting; // 0x4e90(0x01)
	bool K2Node_CustomEvent_IsDodgeRolling_2; // 0x4e91(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_6; // 0x4e92(0x01)
	char pad_4E93[0x1]; // 0x4e93(0x01)
	struct FVector CallFunc_KeepActionCameraAboveWater_OutBoomPosition; // 0x4e94(0x0c)
	bool Temp_bool_IsClosed_Variable_5; // 0x4ea0(0x01)
	char pad_4EA1[0x3]; // 0x4ea1(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9; // 0x4ea4(0x10)
	char pad_4EB4[0x4]; // 0x4eb4(0x04)
	struct FKey K2Node_InputKeyEvent_Key; // 0x4eb8(0x18)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2; // 0x4ed0(0x88)
	float K2Node_Event_DeltaSeconds; // 0x4f58(0x04)
	char pad_4F5C[0x4]; // 0x4f5c(0x04)
	struct UParticleSystem* Temp_object_Variable; // 0x4f60(0x08)
	bool Temp_bool_IsClosed_Variable_6; // 0x4f68(0x01)
	bool Temp_bool_Variable; // 0x4f69(0x01)
	char pad_4F6A[0x2]; // 0x4f6a(0x02)
	struct FVector K2Node_Event_BreakingLocation; // 0x4f6c(0x0c)
	struct FVector K2Node_Event_BreakingDirection; // 0x4f78(0x0c)
	struct FVector K2Node_Event_BreakingNormal; // 0x4f84(0x0c)
	bool K2Node_CustomEvent_IsPowerSliding; // 0x4f90(0x01)
	char pad_4F91[0x3]; // 0x4f91(0x03)
	float CallFunc_GetTargetFov_TargetFov; // 0x4f94(0x04)
	bool K2Node_CustomEvent_IsZiplining; // 0x4f98(0x01)
	char pad_4F99[0x3]; // 0x4f99(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10; // 0x4f9c(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11; // 0x4fac(0x10)
	bool K2Node_Event_bEnterNoseDive; // 0x4fbc(0x01)
	char pad_4FBD[0x3]; // 0x4fbd(0x03)
	float K2Node_Event_AnimLength; // 0x4fc0(0x04)
	char pad_4FC4[0x4]; // 0x4fc4(0x04)
	struct FString K2Node_Event_SwingMontageSectionName; // 0x4fc8(0x10)
	struct UMaster_WeaponComponent_C* K2Node_DynamicCast_AsMaster_Weapon_Component; // 0x4fd8(0x08)
	bool K2Node_DynamicCast_bSuccess_12; // 0x4fe0(0x01)
	char pad_4FE1[0x3]; // 0x4fe1(0x03)
	struct FDelegate Temp_delegate_Variable_26; // 0x4fe4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12; // 0x4ff4(0x10)
	char pad_5004[0x4]; // 0x5004(0x04)
	struct APlayerController* K2Node_Event_PC_2; // 0x5008(0x08)
	struct APlayerController* K2Node_Event_PC; // 0x5010(0x08)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_26; // 0x5018(0x10)
	bool K2Node_Event_UpdateTargetRotation; // 0x5028(0x01)
	bool K2Node_Event_AffectCapsule; // 0x5029(0x01)
	char pad_502A[0x2]; // 0x502a(0x02)
	struct FRotator CallFunc_DetermineKnockbackFacing_ActorRotation; // 0x502c(0x0c)
	struct FDelegate Temp_delegate_Variable_27; // 0x5038(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_27; // 0x5048(0x10)
	enum class HitEnum Temp_byte_Variable; // 0x5058(0x01)
	char pad_5059[0x3]; // 0x5059(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13; // 0x505c(0x10)
	enum class HitEnum Temp_byte_Variable_2; // 0x506c(0x01)
	enum class HitEnum Temp_byte_Variable_3; // 0x506d(0x01)
	enum class HitEnum Temp_byte_Variable_4; // 0x506e(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_7; // 0x506f(0x01)
	enum class EKSMovementDirection Temp_byte_Variable_5; // 0x5070(0x01)
	enum class HitEnum K2Node_Select_Default; // 0x5071(0x01)
	char pad_5072[0x2]; // 0x5072(0x02)
	struct FHitResult K2Node_Event_Hit; // 0x5074(0x88)
	struct FVector Temp_struct_Variable_28; // 0x50fc(0x0c)
	bool Temp_bool_Variable_2; // 0x5108(0x01)
	bool Temp_bool_Variable_3; // 0x5109(0x01)
	char pad_510A[0x2]; // 0x510a(0x02)
	struct FVector K2Node_Select_Default_2; // 0x510c(0x0c)
	struct UParticleSystem* K2Node_Select_Default_3; // 0x5118(0x08)
	struct UParticleSystem* K2Node_Select_Default_4; // 0x5120(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14; // 0x5128(0x10)
	struct FSettingDelegateStruct K2Node_MakeStruct_SettingDelegateStruct; // 0x5138(0x20)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15; // 0x5158(0x10)
	struct FDelegate Temp_delegate_Variable_28; // 0x5168(0x10)
	bool K2Node_CustomEvent_IsDodgeRolling; // 0x5178(0x01)
	char pad_5179[0x7]; // 0x5179(0x07)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_29; // 0x5180(0x10)
	struct FDelegate Temp_delegate_Variable_29; // 0x5190(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_30; // 0x51a0(0x10)
	struct FDelegate Temp_delegate_Variable_30; // 0x51b0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_31; // 0x51c0(0x10)
	struct FDelegate Temp_delegate_Variable_31; // 0x51d0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_32; // 0x51e0(0x10)
	struct FDelegate Temp_delegate_Variable_32; // 0x51f0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_33; // 0x5200(0x10)
	struct FDelegate Temp_delegate_Variable_33; // 0x5210(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_34; // 0x5220(0x10)
	bool Temp_bool_IsClosed_Variable_7; // 0x5230(0x01)
	char pad_5231[0x3]; // 0x5231(0x03)
	struct FDelegate Temp_delegate_Variable_34; // 0x5234(0x10)
	char pad_5244[0x4]; // 0x5244(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_35; // 0x5248(0x10)
	bool Temp_bool_Variable_4; // 0x5258(0x01)
	char pad_5259[0x3]; // 0x5259(0x03)
	struct FDelegate Temp_delegate_Variable_35; // 0x525c(0x10)
	bool K2Node_Event_bFullyHealed; // 0x526c(0x01)
	char pad_526D[0x3]; // 0x526d(0x03)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_36; // 0x5270(0x10)
	struct FDelegate Temp_delegate_Variable_36; // 0x5280(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_37; // 0x5290(0x10)
	struct FDelegate Temp_delegate_Variable_37; // 0x52a0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_38; // 0x52b0(0x10)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component; // 0x52c0(0x08)
	bool K2Node_DynamicCast_bSuccess_13; // 0x52c8(0x01)
	char pad_52C9[0x7]; // 0x52c9(0x07)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component_2; // 0x52d0(0x08)
	bool K2Node_DynamicCast_bSuccess_14; // 0x52d8(0x01)
	char pad_52D9[0x3]; // 0x52d9(0x03)
	float K2Node_InputAxisKeyEvent_AxisValue_2; // 0x52dc(0x04)
	float K2Node_InputAxisKeyEvent_AxisValue; // 0x52e0(0x04)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_4; // 0x52e4(0x01)
	char pad_52E5[0x3]; // 0x52e5(0x03)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16; // 0x52e8(0x10)
	enum class HitEnum Temp_byte_Variable_6; // 0x52f8(0x01)
	char pad_52F9[0x7]; // 0x52f9(0x07)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component_3; // 0x5300(0x08)
	bool K2Node_DynamicCast_bSuccess_15; // 0x5308(0x01)
	char pad_5309[0x7]; // 0x5309(0x07)
	struct UKSZiplineMeshComponent* K2Node_DynamicCast_AsKSZipline_Mesh_Component_4; // 0x5310(0x08)
	bool K2Node_DynamicCast_bSuccess_16; // 0x5318(0x01)
	char pad_5319[0x7]; // 0x5319(0x07)
	struct AKSCharacter* K2Node_CustomEvent_Character; // 0x5320(0x08)
	struct AKSItemDrop* K2Node_CustomEvent_ItemDrop; // 0x5328(0x08)
	struct UKSItem* K2Node_CustomEvent_Item; // 0x5330(0x08)
	enum class HitEnum Temp_byte_Variable_7; // 0x5338(0x01)
	char pad_5339[0x3]; // 0x5339(0x03)
	float K2Node_Event_InteractTime; // 0x533c(0x04)
	float CallFunc_BreakVector_X_3; // 0x5340(0x04)
	float CallFunc_BreakVector_Y_3; // 0x5344(0x04)
	float CallFunc_BreakVector_Z_3; // 0x5348(0x04)
	char pad_534C[0x4]; // 0x534c(0x04)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller; // 0x5350(0x08)
	bool K2Node_DynamicCast_bSuccess_17; // 0x5358(0x01)
	char pad_5359[0x3]; // 0x5359(0x03)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_3; // 0x535c(0x88)
	bool K2Node_SwitchEnum_CmpSuccess; // 0x53e4(0x01)
	char pad_53E5[0x3]; // 0x53e5(0x03)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller_2; // 0x53e8(0x08)
	bool K2Node_DynamicCast_bSuccess_18; // 0x53f0(0x01)
	char pad_53F1[0x7]; // 0x53f1(0x07)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller_3; // 0x53f8(0x08)
	bool K2Node_DynamicCast_bSuccess_19; // 0x5400(0x01)
	bool K2Node_SwitchEnum_CmpSuccess_2; // 0x5401(0x01)
	bool K2Node_SwitchEnum_CmpSuccess_3; // 0x5402(0x01)
	enum class EFlashBangIntensity K2Node_Event_Intensity; // 0x5403(0x01)
	bool K2Node_SwitchEnum_CmpSuccess_4; // 0x5404(0x01)
	bool Temp_bool_Has_Been_Initd_Variable_8; // 0x5405(0x01)
	char pad_5406[0x2]; // 0x5406(0x02)
	struct TScriptInterface<IBlendableInterface> CallFunc_AddOrUpdateBlendable_InBlendableObject_CastInput; // 0x5408(0x10)
	struct TScriptInterface<IBlendableInterface> CallFunc_AddOrUpdateBlendable_InBlendableObject_CastInput_2; // 0x5418(0x10)
	enum class HitEnum Temp_byte_Variable_8; // 0x5428(0x01)
	enum class HitEnum Temp_byte_Variable_9; // 0x5429(0x01)
	enum class EKSMovementDirection Temp_byte_Variable_10; // 0x542a(0x01)
	enum class HitEnum K2Node_Select_Default_5; // 0x542b(0x01)
	char pad_542C[0x4]; // 0x542c(0x04)
	struct UAnimMontage* Temp_object_Variable_2; // 0x5430(0x08)
	struct UAnimMontage* Temp_object_Variable_3; // 0x5438(0x08)
	bool Temp_bool_Variable_5; // 0x5440(0x01)
	char pad_5441[0x7]; // 0x5441(0x07)
	struct UAnimMontage* K2Node_Select_Default_6; // 0x5448(0x08)
	bool Temp_bool_IsClosed_Variable_8; // 0x5450(0x01)
	char pad_5451[0x7]; // 0x5451(0x07)
	struct FLastHitImpulse K2Node_MakeStruct_LastHitImpulse; // 0x5458(0x40)
	char pad_5498[0x8]; // 0x5498(0x08)

	void OnPrimaryTwoWeaponHolstered__DelegateSignature(struct UKSWeaponComponent* bpp__WeaponComponent__pf, bool bpp__PrimaryTwoHolstered__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnPrimaryTwoWeaponHolstered__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24d5b40
	void OnPrimaryOneWeaponHolstered__DelegateSignature(struct UKSWeaponComponent* bpp__WeaponComponent__pf, bool bpp__PrimaryOneHolstered__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnPrimaryOneWeaponHolstered__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x24d5b40
	void Zipline Pulley Unhide(); // Function MainCharacter.MainCharacter_C.Zipline Pulley Unhide // (Native|Public|BlueprintCallable) // @ game+0x183dfb0
	void Zipline Pulley Hide(); // Function MainCharacter.MainCharacter_C.Zipline Pulley Hide // (Native|Public|BlueprintCallable) // @ game+0x183df90
	void WasLastHitHeadshot(bool& bpp__bHeadshot__pf); // Function MainCharacter.MainCharacter_C.WasLastHitHeadshot // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183def0
	void VerifyLastHitDamageType(struct UObject* bpp__DamageType__pf, bool& bpp__IsRelatedToThisType__pf); // Function MainCharacter.MainCharacter_C.VerifyLastHitDamageType // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183de10
	void VerifyLastHitBone(struct FName bpp__ParentBoneName__pf, bool& bpp__IsRelatedToThisBone__pf); // Function MainCharacter.MainCharacter_C.VerifyLastHitBone // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183dd30
	void UserConstructionScript(); // Function MainCharacter.MainCharacter_C.UserConstructionScript // (Native|Event|Public|BlueprintCallable) // @ game+0x183dd10
	void Update Flash Bang PP(); // Function MainCharacter.MainCharacter_C.Update Flash Bang PP // (Native|Public|BlueprintCallable) // @ game+0x183dcf0
	void Update Action Camera(struct FVector bpp__CameraxRotation__pfT, bool bpp__UsesxRotation__pfT, struct FVector bpp__CameraxOffset__pfT); // Function MainCharacter.MainCharacter_C.Update Action Camera // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x183dbb0
	void UpdateRagdollOnGround(bool bpp__IsGrounded__pf); // Function MainCharacter.MainCharacter_C.UpdateRagdollOnGround // (Net|Native|Event|NetMulticast|Public|BlueprintCallable) // @ game+0x183daa0
	void UpdateRagdollMeshLocation(); // Function MainCharacter.MainCharacter_C.UpdateRagdollMeshLocation // (Native|Public|BlueprintCallable) // @ game+0x183da80
	void UpdateRagdoll(float bpp__DeltaSeconds__pf); // Function MainCharacter.MainCharacter_C.UpdateRagdoll // (Native|Public|BlueprintCallable) // @ game+0x183db30
	void UpdatePlayerState(struct APlayerState* bpp__Player__pf); // Function MainCharacter.MainCharacter_C.UpdatePlayerState // (Native|Public|BlueprintCallable) // @ game+0x183d9f0
	void UpdateHealthPP(); // Function MainCharacter.MainCharacter_C.UpdateHealthPP // (Native|Public|BlueprintCallable) // @ game+0x183d9d0
	void UpdateDebugHealthVisibility(); // Function MainCharacter.MainCharacter_C.UpdateDebugHealthVisibility // (Native|Event|Public|BlueprintCallable) // @ game+0x183d9b0
	void UnhideZiplinePulley(); // Function MainCharacter.MainCharacter_C.UnhideZiplinePulley // (Native|Event|Public|BlueprintCallable) // @ game+0x183d990
	void UnhideUplineDevice(); // Function MainCharacter.MainCharacter_C.UnhideUplineDevice // (Native|Event|Public|BlueprintCallable) // @ game+0x183d970
	void TurnOffCapsulePhysics_Server(); // Function MainCharacter.MainCharacter_C.TurnOffCapsulePhysics_Server // (Net|Native|Event|Public|NetServer|BlueprintCallable) // @ game+0x183d930
	void TurnOffCapsulePhysics(); // Function MainCharacter.MainCharacter_C.TurnOffCapsulePhysics // (Net|Native|Event|NetMulticast|Public|BlueprintCallable) // @ game+0x183d950
	void Transition To Main Camera(); // Function MainCharacter.MainCharacter_C.Transition To Main Camera // (Native|Public|BlueprintCallable) // @ game+0x183d910
	void Transition To ADS Camera(); // Function MainCharacter.MainCharacter_C.Transition To ADS Camera // (Native|Public|BlueprintCallable) // @ game+0x183d8f0
	void SwitchToSnapshotPose(); // Function MainCharacter.MainCharacter_C.SwitchToSnapshotPose // (Native|Public|BlueprintCallable) // @ game+0x183d8d0
	void StopReviveSFX(); // Function MainCharacter.MainCharacter_C.StopReviveSFX // (Native|Public|BlueprintCallable) // @ game+0x183d8b0
	void StopLowHealthSFX(); // Function MainCharacter.MainCharacter_C.StopLowHealthSFX // (Native|Public|BlueprintCallable) // @ game+0x183d890
	void Start Viewed Down Hit(); // Function MainCharacter.MainCharacter_C.Start Viewed Down Hit // (Native|Public|BlueprintCallable) // @ game+0x183d870
	void StartImmunity__UpdateFunc(); // Function MainCharacter.MainCharacter_C.StartImmunity__UpdateFunc // (Native|Public) // @ game+0x183d850
	void StartImmunity__FinishedFunc(); // Function MainCharacter.MainCharacter_C.StartImmunity__FinishedFunc // (Native|Public) // @ game+0x183d830
	void StartHacking(); // Function MainCharacter.MainCharacter_C.StartHacking // (Native|Event|Public|BlueprintCallable) // @ game+0x183d810
	void SprintFOVTimeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.SprintFOVTimeline__UpdateFunc // (Native|Public) // @ game+0x183d7f0
	void SprintFOVTimeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.SprintFOVTimeline__FinishedFunc // (Native|Public) // @ game+0x183d7d0
	void ShowDebugLocation(bool bpp__bVisible__pf); // Function MainCharacter.MainCharacter_C.ShowDebugLocation // (Native|Event|Public) // @ game+0x183d740
	void ShouldLastHitLaunchIntoRagdoll(bool& bpp__bShouldRagdoll__pf); // Function MainCharacter.MainCharacter_C.ShouldLastHitLaunchIntoRagdoll // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183d6a0
	void SFXStateChangeReset(); // Function MainCharacter.MainCharacter_C.SFXStateChangeReset // (Native|Public|BlueprintCallable) // @ game+0x183d5a0
	void SFXStateChangeMax(); // Function MainCharacter.MainCharacter_C.SFXStateChangeMax // (Native|Public|BlueprintCallable) // @ game+0x183d580
	void SFXStateChangeHalf(); // Function MainCharacter.MainCharacter_C.SFXStateChangeHalf // (Native|Public|BlueprintCallable) // @ game+0x183d560
	void SFXRingHalfSTOP(); // Function MainCharacter.MainCharacter_C.SFXRingHalfSTOP // (Native|Public|BlueprintCallable) // @ game+0x183d540
	void SFXRingHalfPlay(); // Function MainCharacter.MainCharacter_C.SFXRingHalfPlay // (Native|Public|BlueprintCallable) // @ game+0x183d520
	void SFXRingFullSTOP(); // Function MainCharacter.MainCharacter_C.SFXRingFullSTOP // (Native|Public|BlueprintCallable) // @ game+0x183d500
	void SFXRingFullPlay(); // Function MainCharacter.MainCharacter_C.SFXRingFullPlay // (Native|Public|BlueprintCallable) // @ game+0x183d4e0
	void Set up ADS Blur Dynamic Material(); // Function MainCharacter.MainCharacter_C.Set up ADS Blur Dynamic Material // (Native|Public|BlueprintCallable) // @ game+0x183d680
	void Set Health SFX RTPC(); // Function MainCharacter.MainCharacter_C.Set Health SFX RTPC // (Native|Public|BlueprintCallable) // @ game+0x183d660
	void Setup Debug Info Widget(); // Function MainCharacter.MainCharacter_C.Setup Debug Info Widget // (Native|Public|BlueprintCallable) // @ game+0x183d640
	void SetPostProcessHealthValue(float bpp__Health__pf); // Function MainCharacter.MainCharacter_C.SetPostProcessHealthValue // (Native|Public|BlueprintCallable) // @ game+0x183d5c0
	void RestoreNormalCamera(); // Function MainCharacter.MainCharacter_C.RestoreNormalCamera // (Native|Public|BlueprintCallable) // @ game+0x183d4c0
	void ReevaluateDebugWidgetAttachment(); // Function MainCharacter.MainCharacter_C.ReevaluateDebugWidgetAttachment // (Native|Public|BlueprintCallable) // @ game+0x183d4a0
	void ReceiveTick(float bpp__DeltaSeconds__pf); // Function MainCharacter.MainCharacter_C.ReceiveTick // (Native|Event|Public) // @ game+0x183d420
	void ReceiveBeginPlay(); // Function MainCharacter.MainCharacter_C.ReceiveBeginPlay // (Native|Event|Public) // @ game+0x183d400
	void Play Viewed Sonar Hit(struct FDamageEffect bpp__Effect__pf); // Function MainCharacter.MainCharacter_C.Play Viewed Sonar Hit // (Native|Public|BlueprintCallable) // @ game+0x183d310
	void Play Viewed EMP Hit(struct FDamageEffect bpp__Effect__pf); // Function MainCharacter.MainCharacter_C.Play Viewed EMP Hit // (Native|Public|BlueprintCallable) // @ game+0x183d220
	void Play Viewed Blood Hit(struct FDamageEffect bpp__Effect__pf); // Function MainCharacter.MainCharacter_C.Play Viewed Blood Hit // (Native|Public|BlueprintCallable) // @ game+0x183d130
	void Play Martial Artist Target Front(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Target Front // (Native|Public|BlueprintCallable) // @ game+0x183d110
	void Play Martial Artist Target Back(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Target Back // (Native|Public|BlueprintCallable) // @ game+0x183d0f0
	void Play Martial Artist Instigator Front(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Instigator Front // (Native|Public|BlueprintCallable) // @ game+0x183d0d0
	void Play Martial Artist Instigator Back(); // Function MainCharacter.MainCharacter_C.Play Martial Artist Instigator Back // (Native|Public|BlueprintCallable) // @ game+0x183d0b0
	void PlayReviveSFX(); // Function MainCharacter.MainCharacter_C.PlayReviveSFX // (Native|Public|BlueprintCallable) // @ game+0x183cd40
	void PlayPickupFX(struct AActor* bpp__ItemActor__pf); // Function MainCharacter.MainCharacter_C.PlayPickupFX // (Native|Public|BlueprintCallable) // @ game+0x183ccb0
	void PlayHitMarkerSFX(struct FCombatEventInfo bpp__CombatEventInfo__pf); // Function MainCharacter.MainCharacter_C.PlayHitMarkerSFX // (Native|Public|BlueprintCallable) // @ game+0x183cba0
	void PlayHitFromRadialDamage(struct FDamageEffect& bpp__Effect__pf__const); // Function MainCharacter.MainCharacter_C.PlayHitFromRadialDamage // (BlueprintCosmetic|Native|Event|Public|HasOutParms) // @ game+0x183cae0
	void PlayHitFromPointDamage(struct FDamageEffect& bpp__Effect__pf__const); // Function MainCharacter.MainCharacter_C.PlayHitFromPointDamage // (BlueprintCosmetic|Native|Event|Public|HasOutParms) // @ game+0x183ca20
	void PlayHitBySFX(struct FDamageEffect bpp__DamageEffect__pf); // Function MainCharacter.MainCharacter_C.PlayHitBySFX // (Native|Public|BlueprintCallable) // @ game+0x183c930
	void PlayerRevived(struct AKSPlayerState* bpp__Revivee__pf, struct AKSPlayerState* bpp__Reviver__pf, int32_t bpp__ExpBonus__pf); // Function MainCharacter.MainCharacter_C.PlayerRevived // (Native|Public|BlueprintCallable) // @ game+0x183cfb0
	void PlayerDown(struct FCombatEventInfo bpp__EventInfo__pf, int32_t bpp__ExpBonus__pf); // Function MainCharacter.MainCharacter_C.PlayerDown // (Native|Public|BlueprintCallable) // @ game+0x183ce70
	void PlayerDeath(struct FCombatEventInfo bpp__EventInfo__pf); // Function MainCharacter.MainCharacter_C.PlayerDeath // (Native|Public|BlueprintCallable) // @ game+0x183cd60
	void PlayDownPPOnce(); // Function MainCharacter.MainCharacter_C.PlayDownPPOnce // (Native|Public|BlueprintCallable) // @ game+0x183c910
	void PlayActionCameraSequence(struct FName bpp__SequenceName__pf); // Function MainCharacter.MainCharacter_C.PlayActionCameraSequence // (Native|Event|Public|BlueprintCallable) // @ game+0x183c880
	void OnZiplineChangeForFov(bool bpp__IsZiplining__pf); // Function MainCharacter.MainCharacter_C.OnZiplineChangeForFov // (Native|Public|BlueprintCallable) // @ game+0x183c7d0
	void On Anim Initialized(); // Function MainCharacter.MainCharacter_C.On Anim Initialized // (Native|Public|BlueprintCallable) // @ game+0x183c860
	void OnUnhovered(float bpp__ExtraTime__pf); // Function MainCharacter.MainCharacter_C.OnUnhovered // (Native|Event|Public) // @ game+0x183c750
	void OnStartSkydive(); // Function MainCharacter.MainCharacter_C.OnStartSkydive // (Native|Public|BlueprintCallable) // @ game+0x183c730
	void OnSprintChangedCallback(bool bpp__IsSprinting__pf); // Function MainCharacter.MainCharacter_C.OnSprintChangedCallback // (Native|Public|BlueprintCallable) // @ game+0x183c6a0
	void OnReviveStart(struct AKSCharacter* bpp__Reviver__pf, float bpp__ReviveTime__pf, bool bpp__Remote__pf); // Function MainCharacter.MainCharacter_C.OnReviveStart // (Native|Event|Public) // @ game+0x183c5a0
	void OnReviveInterrupt(struct AKSCharacter* bpp__Reviver__pf); // Function MainCharacter.MainCharacter_C.OnReviveInterrupt // (Native|Event|Public) // @ game+0x183c510
	void OnReviveComplete(struct AKSCharacter* bpp__Reviver__pf); // Function MainCharacter.MainCharacter_C.OnReviveComplete // (Native|Event|Public) // @ game+0x183c480
	void OnPowerSlideChangedCallback(bool bpp__IsPowerSliding__pf); // Function MainCharacter.MainCharacter_C.OnPowerSlideChangedCallback // (Native|Public|BlueprintCallable) // @ game+0x183c3f0
	void OnLanded(struct FHitResult& bpp__Hit__pf__const); // Function MainCharacter.MainCharacter_C.OnLanded // (Native|Event|Public|HasOutParms) // @ game+0x183c330
	void OnItemPickedUp_Event_1(struct AKSCharacter* bpp__Character__pf, struct AKSItemDrop* bpp__ItemDrop__pf, struct UKSItem* bpp__Item__pf); // Function MainCharacter.MainCharacter_C.OnItemPickedUp_Event_1 // (Native|Public|BlueprintCallable) // @ game+0x183c230
	void OnImmuneStart(); // Function MainCharacter.MainCharacter_C.OnImmuneStart // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable) // @ game+0x183c210
	void OnImmuneEnd(); // Function MainCharacter.MainCharacter_C.OnImmuneEnd // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable) // @ game+0x183c1f0
	void OnHovered(); // Function MainCharacter.MainCharacter_C.OnHovered // (Native|Event|Public) // @ game+0x183c1d0
	void OnHealthChanged(struct AKSCharacterBase* bpp__Character__pf__const); // Function MainCharacter.MainCharacter_C.OnHealthChanged // (Native|Public|BlueprintCallable) // @ game+0x183c140
	void OnGenderChanged(); // Function MainCharacter.MainCharacter_C.OnGenderChanged // (Native|Event|Public|BlueprintCallable) // @ game+0x183c120
	void OnGadgetSwapped(); // Function MainCharacter.MainCharacter_C.OnGadgetSwapped // (Native|Event|Public) // @ game+0x183c100
	void OnFlashEffectStarted(); // Function MainCharacter.MainCharacter_C.OnFlashEffectStarted // (Native|Event|Public) // @ game+0x183c0e0
	void OnFlashEffectEnded(); // Function MainCharacter.MainCharacter_C.OnFlashEffectEnded // (Native|Event|Public) // @ game+0x183c0c0
	void OnFlashBangHit(enum class EFlashBangIntensity bpp__Intensity__pf); // Function MainCharacter.MainCharacter_C.OnFlashBangHit // (Native|Event|Public) // @ game+0x183c040
	void OnFieldOfViewModChange(); // Function MainCharacter.MainCharacter_C.OnFieldOfViewModChange // (Native|Event|Public|BlueprintCallable) // @ game+0x183c020
	void OnEndZiplineRagdoll(); // Function MainCharacter.MainCharacter_C.OnEndZiplineRagdoll // (Native|Public|BlueprintCallable) // @ game+0x183c000
	void OnEndSkydive(); // Function MainCharacter.MainCharacter_C.OnEndSkydive // (Native|Public|BlueprintCallable) // @ game+0x183bfe0
	void OnEndPowerSlide(enum class EKSPowerSlideEndReason bpp__EndReason__pf); // Function MainCharacter.MainCharacter_C.OnEndPowerSlide // (Native|Event|Public) // @ game+0x183bf60
	void OnEndOutOfBounds(); // Function MainCharacter.MainCharacter_C.OnEndOutOfBounds // (Native|Event|Public) // @ game+0x183bf40
	void OnDodgeRollChangedEvent(bool bpp__IsDodgeRolling__pf); // Function MainCharacter.MainCharacter_C.OnDodgeRollChangedEvent // (Native|Public|BlueprintCallable) // @ game+0x183beb0
	void OnBeginZiplineRagdoll(); // Function MainCharacter.MainCharacter_C.OnBeginZiplineRagdoll // (Native|Public|BlueprintCallable) // @ game+0x183be90
	void OnBeginPowerSlide(); // Function MainCharacter.MainCharacter_C.OnBeginPowerSlide // (Native|Event|Public) // @ game+0x183be70
	void OnBeginOutOfBounds(); // Function MainCharacter.MainCharacter_C.OnBeginOutOfBounds // (Native|Event|Public) // @ game+0x183be50
	void OnArmorInteractStart(float bpp__InteractTime__pf); // Function MainCharacter.MainCharacter_C.OnArmorInteractStart // (Native|Event|Public) // @ game+0x183bdd0
	void OnArmorInteractInterrupt(); // Function MainCharacter.MainCharacter_C.OnArmorInteractInterrupt // (Native|Event|Public) // @ game+0x183bdb0
	void OnArmorInteractComplete(); // Function MainCharacter.MainCharacter_C.OnArmorInteractComplete // (Native|Event|Public) // @ game+0x183bd90
	void OnADSBlurSettingChanged(); // Function MainCharacter.MainCharacter_C.OnADSBlurSettingChanged // (Native|Public|BlueprintCallable) // @ game+0x183bd70
	void NoseDiveFOVTimeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.NoseDiveFOVTimeline__UpdateFunc // (Native|Public) // @ game+0x183bd50
	void NoseDiveFOVTimeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.NoseDiveFOVTimeline__FinishedFunc // (Native|Public) // @ game+0x183bd30
	void NoseDiveCameraTransition(bool bpp__bEnterNoseDive__pf, float bpp__AnimLength__pf); // Function MainCharacter.MainCharacter_C.NoseDiveCameraTransition // (Native|Event|Public|BlueprintCallable) // @ game+0x183bc60
	void Martial Artist Target Front__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Front__UpdateFunc // (Native|Public) // @ game+0x183bc40
	void Martial Artist Target Front__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Front__FinishedFunc // (Native|Public) // @ game+0x183bc20
	void Martial Artist Target Back__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Back__UpdateFunc // (Native|Public) // @ game+0x183bc00
	void Martial Artist Target Back__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Target Back__FinishedFunc // (Native|Public) // @ game+0x183bbe0
	void Martial Artist Instigator Front__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Front__UpdateFunc // (Native|Public) // @ game+0x183bbc0
	void Martial Artist Instigator Front__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Front__FinishedFunc // (Native|Public) // @ game+0x183bba0
	void Martial Artist Instigator Back__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Back__UpdateFunc // (Native|Public) // @ game+0x183bb80
	void Martial Artist Instigator Back__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Martial Artist Instigator Back__FinishedFunc // (Native|Public) // @ game+0x183bb60
	void LandingRollEvent(bool bpp__IsDodgeRolling__pf); // Function MainCharacter.MainCharacter_C.LandingRollEvent // (Native|Public|BlueprintCallable) // @ game+0x183bad0
	void KeepActionCameraAboveWater(struct FVector bpp__InBoomPosition__pf, struct FVector& bpp__OutBoomPosition__pf); // Function MainCharacter.MainCharacter_C.KeepActionCameraAboveWater // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x183b9f0
	void K2_OnMovementModeChanged(enum class EMovementMode bpp__PrevMovementMode__pf, enum class EMovementMode bpp__NewMovementMode__pf, char bpp__PrevCustomMode__pf, char bpp__NewCustomMode__pf); // Function MainCharacter.MainCharacter_C.K2_OnMovementModeChanged // (Native|Event|Public) // @ game+0x183b8a0
	void K2_OnEndViewTarget(struct APlayerController* bpp__PC__pf); // Function MainCharacter.MainCharacter_C.K2_OnEndViewTarget // (Native|Event|Public) // @ game+0x183b810
	void K2_OnBecomeViewTarget(struct APlayerController* bpp__PC__pf); // Function MainCharacter.MainCharacter_C.K2_OnBecomeViewTarget // (Native|Event|Public) // @ game+0x183b780
	void InpAxisKeyEvt_Gamepad_LeftY_K2Node_InputAxisKeyEvent_1(float bpp__AxisValue__pf); // Function MainCharacter.MainCharacter_C.InpAxisKeyEvt_Gamepad_LeftY_K2Node_InputAxisKeyEvent_1 // (Native|Public) // @ game+0x183b700
	void InpAxisKeyEvt_Gamepad_LeftX_K2Node_InputAxisKeyEvent_2(float bpp__AxisValue__pf); // Function MainCharacter.MainCharacter_C.InpAxisKeyEvt_Gamepad_LeftX_K2Node_InputAxisKeyEvent_2 // (Native|Public) // @ game+0x183b680
	void InpActEvt_T_K2Node_InputKeyEvent_1(struct FKey bpp__Key__pf); // Function MainCharacter.MainCharacter_C.InpActEvt_T_K2Node_InputKeyEvent_1 // (Native|Public) // @ game+0x183b5a0
	void InitializeHealthPP(); // Function MainCharacter.MainCharacter_C.InitializeHealthPP // (Native|Public|BlueprintCallable) // @ game+0x183b580
	void HideZiplinePulley(); // Function MainCharacter.MainCharacter_C.HideZiplinePulley // (Native|Event|Public|BlueprintCallable) // @ game+0x183b560
	void HideUplineDevice(); // Function MainCharacter.MainCharacter_C.HideUplineDevice // (Native|Event|Public|BlueprintCallable) // @ game+0x183b540
	void HealthRegenerationStopped(bool bpp__bFullyHealed__pf); // Function MainCharacter.MainCharacter_C.HealthRegenerationStopped // (Native|Event|Public) // @ game+0x183b4b0
	void HealthRegenerationStarted(); // Function MainCharacter.MainCharacter_C.HealthRegenerationStarted // (Native|Event|Public) // @ game+0x183b490
	void Handle Downed Ragdoll(); // Function MainCharacter.MainCharacter_C.Handle Downed Ragdoll // (Native|Public|BlueprintCallable) // @ game+0x183b470
	void Get ADS Camera By Tag(struct FName bpp__Tag__pf, struct UCameraComponent*& bpp__CameraxComponent__pfT); // Function MainCharacter.MainCharacter_C.Get ADS Camera By Tag // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183b390
	void Get ADS Bend Target Camera Component(struct UCameraComponent*& bpp__CameraxComponent__pfT); // Function MainCharacter.MainCharacter_C.Get ADS Bend Target Camera Component // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183b2f0
	void GetTargetFov(float& bpp__TargetFov__pf); // Function MainCharacter.MainCharacter_C.GetTargetFov // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183b250
	void GetTargetArmorLevel(struct AActor* bpp__HitxTarget__pfT, int32_t& bpp__ArmorxLevel__pfT); // Function MainCharacter.MainCharacter_C.GetTargetArmorLevel // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183b170
	void GetRagdollFacingDirection(bool& bpp__IsUp__pf); // Function MainCharacter.MainCharacter_C.GetRagdollFacingDirection // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183b0d0
	void GetLastHitDistance(float& bpp__OutDistance__pf); // Function MainCharacter.MainCharacter_C.GetLastHitDistance // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x183b030
	void GetDownedTransitionMontage(struct UAnimMontage*& bpp__OutAnimMontage__pf); // Function MainCharacter.MainCharacter_C.GetDownedTransitionMontage // (Native|Event|Public|HasOutParms|BlueprintCallable) // @ game+0x183af90
	void GetDeathTransitionAnimation(struct UAnimSequence*& bpp__OutAnimSequence__pf); // Function MainCharacter.MainCharacter_C.GetDeathTransitionAnimation // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x183aef0
	void FreeFall Camera Burst(); // Function MainCharacter.MainCharacter_C.FreeFall Camera Burst // (Native|Public|BlueprintCallable) // @ game+0x183aed0
	void Finish Action Camera Update(); // Function MainCharacter.MainCharacter_C.Finish Action Camera Update // (Native|Public|BlueprintCallable) // @ game+0x183aeb0
	void FinishHacking(); // Function MainCharacter.MainCharacter_C.FinishHacking // (Native|Event|Public|BlueprintCallable) // @ game+0x183ae90
	void ExitDownedRagdoll(); // Function MainCharacter.MainCharacter_C.ExitDownedRagdoll // (Net|Native|Event|NetMulticast|Public|BlueprintCallable) // @ game+0x183ae70
	void ExecuteUbergraph_MainCharacter_8(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_8 // (Final|Native|Public) // @ game+0x183adf0
	void ExecuteUbergraph_MainCharacter_64(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_64 // (Final|Native|Public) // @ game+0x183ad70
	void ExecuteUbergraph_MainCharacter_55(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_55 // (Final|Native|Public) // @ game+0x183acf0
	void ExecuteUbergraph_MainCharacter_49(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_49 // (Final|Native|Public) // @ game+0x183ac70
	void ExecuteUbergraph_MainCharacter_40(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_40 // (Final|Native|Public) // @ game+0x183abf0
	void ExecuteUbergraph_MainCharacter_16(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_16 // (Final|Native|Public) // @ game+0x183ab70
	void ExecuteUbergraph_MainCharacter_131(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_131 // (Final|Native|Public) // @ game+0x183aaf0
	void ExecuteUbergraph_MainCharacter_130(int32_t bpp__EntryPoint__pf); // Function MainCharacter.MainCharacter_C.ExecuteUbergraph_MainCharacter_130 // (Final|Native|Public) // @ game+0x183aa70
	void EventSetupCamerasForSpectator(bool bpp__Enabled__pf); // Function MainCharacter.MainCharacter_C.EventSetupCamerasForSpectator // (Native|Event|Public) // @ game+0x183a9e0
	void EnterFreeFallFOVTimeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.EnterFreeFallFOVTimeline__UpdateFunc // (Native|Public) // @ game+0x183a9c0
	void EnterFreeFallFOVTimeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.EnterFreeFallFOVTimeline__FinishedFunc // (Native|Public) // @ game+0x183a9a0
	void EnterDownedRagdoll(); // Function MainCharacter.MainCharacter_C.EnterDownedRagdoll // (Native|Public|BlueprintCallable) // @ game+0x183a980
	void End Down PP(); // Function MainCharacter.MainCharacter_C.End Down PP // (Native|Public|BlueprintCallable) // @ game+0x183a960
	void EndImmunity__UpdateFunc(); // Function MainCharacter.MainCharacter_C.EndImmunity__UpdateFunc // (Native|Public) // @ game+0x183a940
	void EndImmunity__FinishedFunc(); // Function MainCharacter.MainCharacter_C.EndImmunity__FinishedFunc // (Native|Public) // @ game+0x183a920
	void DoSetOnFire(); // Function MainCharacter.MainCharacter_C.DoSetOnFire // (Native|Event|Public) // @ game+0x183a900
	void DoExtinguishFire(); // Function MainCharacter.MainCharacter_C.DoExtinguishFire // (Native|Event|Public) // @ game+0x183a8e0
	void DoBindZiplineEvents(); // Function MainCharacter.MainCharacter_C.DoBindZiplineEvents // (Native|Public|BlueprintCallable) // @ game+0x183a8c0
	void DoBindSprintEvents(); // Function MainCharacter.MainCharacter_C.DoBindSprintEvents // (Native|Public|BlueprintCallable) // @ game+0x183a8a0
	void DoBindDodgeRollEvents(); // Function MainCharacter.MainCharacter_C.DoBindDodgeRollEvents // (Native|Public|BlueprintCallable) // @ game+0x183a880
	void DetermineKnockbackFacing(struct FVector bpp__HitDirection__pf, enum class HitEnum bpp__SideHit__pf, struct FRotator& bpp__ActorRotation__pf); // Function MainCharacter.MainCharacter_C.DetermineKnockbackFacing // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x183a760
	void DetachSkydiveParticle(); // Function MainCharacter.MainCharacter_C.DetachSkydiveParticle // (Native|Public|BlueprintCallable) // @ game+0x183a740
	void DestructibleSpeedGateOverlappedEvent(struct FVector bpp__BreakingLocation__pf, struct FVector bpp__BreakingDirection__pf, struct FVector bpp__BreakingNormal__pf); // Function MainCharacter.MainCharacter_C.DestructibleSpeedGateOverlappedEvent // (Native|Event|Public|HasDefaults) // @ game+0x183a610
	void DeathStateChange(); // Function MainCharacter.MainCharacter_C.DeathStateChange // (Native|Public|BlueprintCallable) // @ game+0x183a5f0
	void Check Low Health(); // Function MainCharacter.MainCharacter_C.Check Low Health // (Native|Public|BlueprintCallable) // @ game+0x183a5d0
	void CheckFlashBangOnViewTargetChange(); // Function MainCharacter.MainCharacter_C.CheckFlashBangOnViewTargetChange // (Native|Public|BlueprintCallable) // @ game+0x183a5b0
	void Camera Boom Timeline__UpdateFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__UpdateFunc // (Native|Public) // @ game+0x183a590
	void Camera Boom Timeline__Switch To Main Camera__EventFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__Switch To Main Camera__EventFunc // (Native|Public) // @ game+0x183a570
	void Camera Boom Timeline__Switch To ADS Camera__EventFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__Switch To ADS Camera__EventFunc // (Native|Public) // @ game+0x183a550
	void Camera Boom Timeline__FinishedFunc(); // Function MainCharacter.MainCharacter_C.Camera Boom Timeline__FinishedFunc // (Native|Public) // @ game+0x183a530
	void CameraDodgeRoll__UpdateFunc(); // Function MainCharacter.MainCharacter_C.CameraDodgeRoll__UpdateFunc // (Native|Public) // @ game+0x183a510
	void CameraDodgeRoll__FinishedFunc(); // Function MainCharacter.MainCharacter_C.CameraDodgeRoll__FinishedFunc // (Native|Public) // @ game+0x183a4f0
	void CacheRagdollPelvisLocation(); // Function MainCharacter.MainCharacter_C.CacheRagdollPelvisLocation // (Net|Native|Event|Public|NetServer|BlueprintCallable) // @ game+0x183a4d0
	void BlueprintOnStopSwimming(); // Function MainCharacter.MainCharacter_C.BlueprintOnStopSwimming // (Native|Event|Public) // @ game+0x183a4b0
	void BlueprintOnStartSwimming(); // Function MainCharacter.MainCharacter_C.BlueprintOnStartSwimming // (Native|Event|Public) // @ game+0x183a490
	bool BlueprintHandleDeath(); // Function MainCharacter.MainCharacter_C.BlueprintHandleDeath // (Native|Event|Public|BlueprintCallable) // @ game+0x183a460
	void BindADSBlurSetting(); // Function MainCharacter.MainCharacter_C.BindADSBlurSetting // (Native|Public|BlueprintCallable) // @ game+0x183a440
	void Audio_Init(); // Function MainCharacter.MainCharacter_C.Audio_Init // (Native|Public|BlueprintCallable) // @ game+0x183a420
	void ApplyLastHitImpulse(bool bpp__UpdateTargetRotation__pf, bool bpp__AffectCapsule__pf); // Function MainCharacter.MainCharacter_C.ApplyLastHitImpulse // (Native|Event|Public|BlueprintCallable) // @ game+0x183a350
	void PlayerReviveDelegate__DelegateSignature(struct AKSPlayerState* bpp__Revivee__pf, struct AKSPlayerState* bpp__Reviver__pf, int32_t bpp__ExpBonus__pf); // DelegateFunction MainCharacter.MainCharacter_C.PlayerReviveDelegate__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void PlayerDownInfo__DelegateSignature(struct FCombatEventInfo bpp__EventInfo__pf, int32_t bpp__ExpBonus__pf); // DelegateFunction MainCharacter.MainCharacter_C.PlayerDownInfo__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void PlayerDeathInfo__DelegateSignature(struct FCombatEventInfo bpp__EventInfo__pf); // DelegateFunction MainCharacter.MainCharacter_C.PlayerDeathInfo__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnSprintChanged__DelegateSignature(bool bpp__IsSprinting__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnSprintChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnPowerSlideChanged__DelegateSignature(bool bpp__IsPowerSliding__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnPowerSlideChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnPlayerStateChanged__DelegateSignature(struct APlayerState* bpp__PlayerState__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnPlayerStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnItemPickedUp__DelegateSignature(struct AKSCharacter* bpp__Character__pf, struct AKSItemDrop* bpp__ItemDrop__pf, struct UKSItem* bpp__Item__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnItemPickedUp__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnHealthChanged__DelegateSignature(struct AKSCharacterBase* bpp__Character__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnHealthChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnGoDown__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnGoDown__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnEndZipline__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnEndZipline__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnDodgeRollChanged__DelegateSignature(bool bpp__IsDodgeRolling__pf); // DelegateFunction MainCharacter.MainCharacter_C.OnDodgeRollChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnDeathStateChanged__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnDeathStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnBeginZipline__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnBeginZipline__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnAnimInitialized__DelegateSignature(); // DelegateFunction MainCharacter.MainCharacter_C.OnAnimInitialized__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
};

