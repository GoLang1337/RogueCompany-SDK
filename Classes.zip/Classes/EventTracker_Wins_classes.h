// BlueprintGeneratedClass EventTracker_Wins.EventTracker_Wins_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_Wins_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_Wins.EventTracker_Wins_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Wins.EventTracker_Wins_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Wins.EventTracker_Wins_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_Wins.EventTracker_Wins_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Wins(int32_t EntryPoint); // Function EventTracker_Wins.EventTracker_Wins_C.ExecuteUbergraph_EventTracker_Wins // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

