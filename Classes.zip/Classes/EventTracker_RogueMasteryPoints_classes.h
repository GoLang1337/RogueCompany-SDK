// BlueprintGeneratedClass EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C
// Size: 0x250 (Inherited: 0x208)
struct UEventTracker_RogueMasteryPoints_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	int32_t JobItemId; // 0x210(0x04)
	float XpPerMinute; // 0x214(0x04)
	float PremiumBoostMultiplier; // 0x218(0x04)
	float WinMultiplier; // 0x21c(0x04)
	bool IsSelected; // 0x220(0x01)
	char pad_221[0x3]; // 0x221(0x03)
	float TimeSpentInJob; // 0x224(0x04)
	struct FDateTime TimeWhenSelected; // 0x228(0x08)
	float BaseProgress; // 0x230(0x04)
	float AccumulatedProgress; // 0x234(0x04)
	struct AKSPlayerState* PlayerState; // 0x238(0x08)
	struct FString BonusKey; // 0x240(0x10)

	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessEventBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessWinBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessQueueBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessBoosterBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ComputeBaseProgress // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AccumulateTimeSpent(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.AccumulateTimeSpent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void AwardRogueMasteryPoints(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.AwardRogueMasteryPoints // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdateJobSelected(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.UpdateJobSelected // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleMatchEnded(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandleMatchEnded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandlePhaseChanged(struct FMatchPhase PreviousPhase, struct FMatchPhase NewPhase); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandlePhaseChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_RogueMasteryPoints(int32_t EntryPoint); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ExecuteUbergraph_EventTracker_RogueMasteryPoints // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

