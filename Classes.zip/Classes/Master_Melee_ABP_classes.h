// AnimBlueprintGeneratedClass Master_Melee_ABP.Master_Melee_ABP_C
// Size: 0xd91 (Inherited: 0x3f0)
struct UMaster_Melee_ABP_C : UKSWeaponAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x3f8(0x40)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x438(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x470(0x38)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose_3; // 0x4a8(0x28)
	struct FAnimNode_SequenceSkinned AnimGraphNode_SequenceSkinned_4; // 0x4d0(0x160)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x630(0x40)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose_2; // 0x670(0x28)
	struct FAnimNode_SequenceSkinned AnimGraphNode_SequenceSkinned_3; // 0x698(0x160)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x7f8(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x838(0xc0)
	struct FAnimNode_SequenceSkinned AnimGraphNode_SequenceSkinned_2; // 0x8f8(0x160)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose; // 0xa58(0x28)
	struct FAnimNode_SequenceSkinned AnimGraphNode_SequenceSkinned; // 0xa80(0x160)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0xbe0(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0xc20(0xc0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0xce0(0xb0)
	bool Is Holstered; // 0xd90(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Master_Melee_ABP.Master_Melee_ABP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Set Weapon State(enum class EWeaponStateNew Weapon State); // Function Master_Melee_ABP.Master_Melee_ABP_C.Set Weapon State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitSetWeaponState(enum class EWeaponStateNew NewWeaponState); // Function Master_Melee_ABP.Master_Melee_ABP_C.InitSetWeaponState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_Master_Melee_ABP(int32_t EntryPoint); // Function Master_Melee_ABP.Master_Melee_ABP_C.ExecuteUbergraph_Master_Melee_ABP // (Final|UbergraphFunction) // @ game+0x24d5b40
};

