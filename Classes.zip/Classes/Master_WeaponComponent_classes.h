// DynamicClass Master_WeaponComponent.Master_WeaponComponent_C
// Size: 0x1230 (Inherited: 0x638)
struct UMaster_WeaponComponent_C : UKSWeaponComponent {
	bool Is ADS; // 0x638(0x01)
	char pad_639[0x3]; // 0x639(0x03)
	struct FName Owner Fire Section; // 0x63c(0x08)
	char pad_644[0x4]; // 0x644(0x04)
	struct TArray<struct FName> Owner 1p ADS Fire Section; // 0x648(0x10)
	struct FName Deattach Slot Name; // 0x658(0x08)
	struct FName Attach Slot Name; // 0x660(0x08)
	struct FName MIrror Attach Slot Name; // 0x668(0x08)
	int32_t Weapon Fire Sound ID; // 0x670(0x04)
	bool Weapon Fire Sound Interrupts; // 0x674(0x01)
	char pad_675[0x3]; // 0x675(0x03)
	struct UAkAudioEvent* Weapon Casing Sound; // 0x678(0x08)
	struct UAkAudioEvent* Equip Sound; // 0x680(0x08)
	float Speed of Sound; // 0x688(0x04)
	float Echo Max Distance; // 0x68c(0x04)
	struct TArray<struct FRotator> Echo Directions; // 0x690(0x10)
	struct FVector Echo Sound Location; // 0x6a0(0x0c)
	char pad_6AC[0x4]; // 0x6ac(0x04)
	struct UParticleSystem* Muzzle Flash 3p; // 0x6b0(0x08)
	struct UParticleSystem* Muzzle Flash 1p; // 0x6b8(0x08)
	struct FName MuzzleSocketName; // 0x6c0(0x08)
	struct FName Cartridge Ejection Attach Name; // 0x6c8(0x08)
	struct FHitDecalInfo Default Decal Info; // 0x6d0(0x28)
	struct TMap<enum class EPhysicalSurface, struct FHitDecalInfo> Physical Decal Materials; // 0x6f8(0x50)
	struct UParticleSystem* Tracer Template; // 0x748(0x08)
	float Next Tracer Time; // 0x750(0x04)
	float Minimum Tracer Delay; // 0x754(0x04)
	float Maximum Tracer Delay; // 0x758(0x04)
	int32_t Shot Count; // 0x75c(0x04)
	struct UStaticMesh* Tracer Mesh; // 0x760(0x08)
	int32_t Tracer Frequency; // 0x768(0x04)
	enum class EPhysicalSurface Decal Physical Surface; // 0x76c(0x01)
	char pad_76D[0x3]; // 0x76d(0x03)
	struct FVector Decal Location; // 0x770(0x0c)
	char pad_77C[0x4]; // 0x77c(0x04)
	struct UMaterialInterface* Temp Mesh Material Override; // 0x780(0x08)
	int32_t CountedShotsLeft; // 0x788(0x04)
	char pad_78C[0x4]; // 0x78c(0x04)
	struct UObject* 1P ADS Camera Shake; // 0x790(0x08)
	struct TArray<struct FName> Owner 3p Fire Section; // 0x798(0x10)
	int32_t Counter; // 0x7a8(0x04)
	char pad_7AC[0x4]; // 0x7ac(0x04)
	struct UObject* AOS Camera Shake; // 0x7b0(0x08)
	struct UObject* 3P Camera Shake; // 0x7b8(0x08)
	int32_t CountedMagSize; // 0x7c0(0x04)
	bool bIsSecondaryWeapon; // 0x7c4(0x01)
	bool Is Pistol; // 0x7c5(0x01)
	bool Is Dual Guns; // 0x7c6(0x01)
	bool ShouldSpawnTracers; // 0x7c7(0x01)
	bool ShouldHaveBulletFX; // 0x7c8(0x01)
	bool ShouldHaveBulletSpangs; // 0x7c9(0x01)
	bool bWasFiredByOwner; // 0x7ca(0x01)
	char pad_7CB[0x1]; // 0x7cb(0x01)
	struct FName MagazineDropBone; // 0x7cc(0x08)
	bool Mirror Reload Enabled; // 0x7d4(0x01)
	char pad_7D5[0x3]; // 0x7d5(0x03)
	struct FName Mirror_MagazineDropBone; // 0x7d8(0x08)
	bool DropBoneOnWeapon; // 0x7e0(0x01)
	bool TrackingMagDropBone; // 0x7e1(0x01)
	char pad_7E2[0xe]; // 0x7e2(0x0e)
	struct FTransform DropMagSpawnTransformOveride; // 0x7f0(0x30)
	struct FVector DropBonePreviousPosition; // 0x820(0x0c)
	struct FVector DropBoneVelocity; // 0x82c(0x0c)
	struct FVector DropVelocityOverride; // 0x838(0x0c)
	bool Is Gun Holstered; // 0x844(0x01)
	bool DropMultipleMags; // 0x845(0x01)
	bool Drop Multiple Mags Velocity Inheritance Override; // 0x846(0x01)
	char pad_847[0x1]; // 0x847(0x01)
	struct TArray<struct FMultiMagDropInfo> MultiMagArray; // 0x848(0x10)
	bool Maintain Holster; // 0x858(0x01)
	bool Is Shotgun; // 0x859(0x01)
	char pad_85A[0x2]; // 0x85a(0x02)
	struct FRotator Target Shell Housing Spin; // 0x85c(0x0c)
	int32_t Missing Shell Count; // 0x868(0x04)
	float Interp Speed; // 0x86c(0x04)
	float VsWorldAlphaDiff; // 0x870(0x04)
	float LastUpdatedAlpha; // 0x874(0x04)
	bool Prevent Vs World Active; // 0x878(0x01)
	bool Is Vs World Force Reset Delay; // 0x879(0x01)
	char pad_87A[0x2]; // 0x87a(0x02)
	float Vs World Reset Delay Time; // 0x87c(0x04)
	bool Able to Magdrop?; // 0x880(0x01)
	bool Force Holster Mantle; // 0x881(0x01)
	bool Force Holster Zipline; // 0x882(0x01)
	bool Scope Mesh Scale; // 0x883(0x01)
	float Scope Scale Alpha; // 0x884(0x04)
	struct TArray<struct UMaterialInterface*> Hide Materials Array; // 0x888(0x10)
	bool Is Vcol Hide Needed; // 0x898(0x01)
	char pad_899[0x7]; // 0x899(0x07)
	struct FMulticastInlineDelegate OnSetScopeScaleAlpha; // 0x8a0(0x10)
	struct FMulticastInlineDelegate OnSetRevolverChamberRotate; // 0x8b0(0x10)
	float CosmeticShotTraceDist; // 0x8c0(0x04)
	char pad_8C4[0x4]; // 0x8c4(0x04)
	struct TArray<struct UParticleSystemComponent*> CartridgeEjectParticles; // 0x8c8(0x10)
	struct TArray<struct UParticleSystemComponent*> 1PMuzzleFlashParticles; // 0x8d8(0x10)
	struct TArray<struct UParticleSystemComponent*> 3pMuzzleFlashParticles; // 0x8e8(0x10)
	bool bShouldPlayADSFire; // 0x8f8(0x01)
	char pad_8F9[0x3]; // 0x8f9(0x03)
	float ADSFirePlayPosition; // 0x8fc(0x04)
	float AOSFirePlayPosition; // 0x900(0x04)
	float ADSFireDelay; // 0x904(0x04)
	struct FMulticastInlineDelegate OnSetLobbyState; // 0x908(0x10)
	bool DropMagazineLockout; // 0x918(0x01)
	char pad_919[0x7]; // 0x919(0x07)
	struct UObject* 3P Camera Shake Hi; // 0x920(0x08)
	struct UObject* FireCameraModifier; // 0x928(0x08)
	struct TArray<struct FFullFireRepData> QueuedAimData; // 0x930(0x10)
	struct TArray<struct FHitResult> ValidHits_Event; // 0x940(0x10)
	bool Should Play Impact Sound; // 0x950(0x01)
	bool Should Hide On Holster; // 0x951(0x01)
	enum class EFireAudioMode FireAudioMode; // 0x952(0x01)
	bool AllowNewShotAudio; // 0x953(0x01)
	float Post Reload Delay Period; // 0x954(0x04)
	bool Folded Stock; // 0x958(0x01)
	char pad_959[0x3]; // 0x959(0x03)
	struct FRotator Stock Rotation; // 0x95c(0x0c)
	struct FRotator Stock alt Rotation; // 0x968(0x0c)
	bool Multi Stage Reload Lockout; // 0x974(0x01)
	char pad_975[0x3]; // 0x975(0x03)
	struct FVector ViewPawnForwardDir; // 0x978(0x0c)
	struct FVector ViewPawnLeftDir; // 0x984(0x0c)
	float LastBulletMissTime; // 0x990(0x04)
	float LoopingFireAudioCheckTriggerDelay; // 0x994(0x04)
	int32_t LoopingFireAudioFadeOutDuration; // 0x998(0x04)
	bool IsFirstShot; // 0x99c(0x01)
	bool IsPlayerControlled; // 0x99d(0x01)
	bool Lunging Active; // 0x99e(0x01)
	char pad_99F[0x1]; // 0x99f(0x01)
	struct TArray<struct UParticleSystemComponent*> 1PAuxMuzzleFlashParticles; // 0x9a0(0x10)
	struct TArray<struct UParticleSystemComponent*> 3pAuxMuzzleFlashParticles; // 0x9b0(0x10)
	bool ShouldPlayBlockedImpactSound; // 0x9c0(0x01)
	char pad_9C1[0x7]; // 0x9c1(0x07)
	struct FTimerHandle Revolving timer; // 0x9c8(0x08)
	struct FRotator Eval Target Shell Housing Spin; // 0x9d0(0x0c)
	bool ShouldComputeCosmeticHits; // 0x9dc(0x01)
	bool On Init Hide Magazine; // 0x9dd(0x01)
	bool Use laser sight; // 0x9de(0x01)
	char pad_9DF[0x1]; // 0x9df(0x01)
	struct UMaterialInstanceDynamic* Reticle Material; // 0x9e0(0x08)
	enum class ECombatState RetrieveCombatState; // 0x9e8(0x01)
	char pad_9E9[0x7]; // 0x9e9(0x07)
	struct FTimerHandle Post Reload Timer; // 0x9f0(0x08)
	enum class EWeaponStateNew Old State; // 0x9f8(0x01)
	char pad_9F9[0x3]; // 0x9f9(0x03)
	struct FVector TracerStartPointLocalToOwner; // 0x9fc(0x0c)
	float TracerMinimumOffsetLocallyViewed; // 0xa08(0x04)
	float TracerMaximumOffsetLocallyViewed; // 0xa0c(0x04)
	float TracerMinimumOffsetNPC; // 0xa10(0x04)
	float TracerMaximumOffsetNPC; // 0xa14(0x04)
	float Combat State Change Time; // 0xa18(0x04)
	bool Mirror Deattach Slot Active; // 0xa1c(0x01)
	char pad_A1D[0x3]; // 0xa1d(0x03)
	struct FName Mirror Deattach Slot Name; // 0xa20(0x08)
	struct UObject* ScopeWidgetClass; // 0xa28(0x08)
	struct AActor* ScopeWidgetActor; // 0xa30(0x08)
	struct FMulticastInlineDelegate OnSetShieldActive; // 0xa38(0x10)
	enum class EGamepadTriggerType PS5 Trigger Type; // 0xa48(0x01)
	char PS5 Trigger Start Position; // 0xa49(0x01)
	char PS5 Trigger Stop Position; // 0xa4a(0x01)
	char PS5 Trigger Haptic Strength; // 0xa4b(0x01)
	bool Disable Alternate Mirroring; // 0xa4c(0x01)
	char pad_A4D[0x3]; // 0xa4d(0x03)
	float CurrentFirePlayPosition; // 0xa50(0x04)
	char pad_A54[0x4]; // 0xa54(0x04)
	struct UParticleSystem* Tracer Particle System; // 0xa58(0x08)
	struct UMaterialInterface* Friendly Tracer Material; // 0xa60(0x08)
	struct UMaterialInterface* Enemy Tracer MaterialInst; // 0xa68(0x08)
	bool NewVar_1; // 0xa70(0x01)
	bool K2Node_CustomEvent_bBlockingHit_2; // 0xa71(0x01)
	char pad_A72[0x6]; // 0xa72(0x06)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits_2; // 0xa78(0x10)
	struct FVector K2Node_CustomEvent_Start_2; // 0xa88(0x0c)
	struct FVector K2Node_CustomEvent_End_2; // 0xa94(0x0c)
	bool K2Node_CustomEvent_bBlockingHit; // 0xaa0(0x01)
	char pad_AA1[0x7]; // 0xaa1(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits; // 0xaa8(0x10)
	struct FVector K2Node_CustomEvent_Start; // 0xab8(0x0c)
	struct FVector K2Node_CustomEvent_End; // 0xac4(0x0c)
	struct FHitResult K2Node_CustomEvent_Hit; // 0xad0(0x88)
	struct FName Temp_name_Variable; // 0xb58(0x08)
	bool CallFunc_BreakHitResult_bBlockingHit; // 0xb60(0x01)
	bool CallFunc_BreakHitResult_bInitialOverlap; // 0xb61(0x01)
	char pad_B62[0x2]; // 0xb62(0x02)
	float CallFunc_BreakHitResult_Time; // 0xb64(0x04)
	float CallFunc_BreakHitResult_Distance; // 0xb68(0x04)
	struct FVector CallFunc_BreakHitResult_Location; // 0xb6c(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactPoint; // 0xb78(0x0c)
	struct FVector CallFunc_BreakHitResult_Normal; // 0xb84(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactNormal; // 0xb90(0x0c)
	char pad_B9C[0x4]; // 0xb9c(0x04)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat; // 0xba0(0x08)
	struct AActor* CallFunc_BreakHitResult_HitActor; // 0xba8(0x08)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent; // 0xbb0(0x08)
	struct FName CallFunc_BreakHitResult_HitBoneName; // 0xbb8(0x08)
	int32_t CallFunc_BreakHitResult_HitItem; // 0xbc0(0x04)
	int32_t CallFunc_BreakHitResult_FaceIndex; // 0xbc4(0x04)
	struct FVector CallFunc_BreakHitResult_TraceStart; // 0xbc8(0x0c)
	struct FVector CallFunc_BreakHitResult_TraceEnd; // 0xbd4(0x0c)
	bool CallFunc_BreakHitResult_bBlockingHit_2; // 0xbe0(0x01)
	bool CallFunc_BreakHitResult_bInitialOverlap_2; // 0xbe1(0x01)
	char pad_BE2[0x2]; // 0xbe2(0x02)
	float CallFunc_BreakHitResult_Time_2; // 0xbe4(0x04)
	float CallFunc_BreakHitResult_Distance_2; // 0xbe8(0x04)
	struct FVector CallFunc_BreakHitResult_Location_2; // 0xbec(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2; // 0xbf8(0x0c)
	struct FVector CallFunc_BreakHitResult_Normal_2; // 0xc04(0x0c)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2; // 0xc10(0x0c)
	char pad_C1C[0x4]; // 0xc1c(0x04)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2; // 0xc20(0x08)
	struct AActor* CallFunc_BreakHitResult_HitActor_2; // 0xc28(0x08)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2; // 0xc30(0x08)
	struct FName CallFunc_BreakHitResult_HitBoneName_2; // 0xc38(0x08)
	int32_t CallFunc_BreakHitResult_HitItem_2; // 0xc40(0x04)
	int32_t CallFunc_BreakHitResult_FaceIndex_2; // 0xc44(0x04)
	struct FVector CallFunc_BreakHitResult_TraceStart_2; // 0xc48(0x0c)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2; // 0xc54(0x0c)
	struct FHitDecalInfo CallFunc_Get_Decal_Material_Decal_Info; // 0xc60(0x28)
	bool K2Node_CustomEvent_bBlockingHit_3; // 0xc88(0x01)
	char pad_C89[0x7]; // 0xc89(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits_3; // 0xc90(0x10)
	struct FVector K2Node_CustomEvent_Start_3; // 0xca0(0x0c)
	struct FVector K2Node_CustomEvent_End_3; // 0xcac(0x0c)
	struct FFullFireRepData K2Node_CustomEvent_Data; // 0xcb8(0x68)
	bool K2Node_CustomEvent_Blocking_Hit; // 0xd20(0x01)
	char pad_D21[0x7]; // 0xd21(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Out_Hits; // 0xd28(0x10)
	struct FVector K2Node_CustomEvent_Start_4; // 0xd38(0x0c)
	struct FVector K2Node_CustomEvent_End_4; // 0xd44(0x0c)
	bool K2Node_CustomEvent_Allow_Spangs; // 0xd50(0x01)
	bool K2Node_CustomEvent_Allow_Tracers; // 0xd51(0x01)
	bool K2Node_CustomEvent_Allow_Decals; // 0xd52(0x01)
	char pad_D53[0x5]; // 0xd53(0x05)
	struct TArray<struct FHitResult> CallFunc_Filter_Cosmetic_Hit_Results_Filtered_Hit_Results; // 0xd58(0x10)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller; // 0xd68(0x08)
	bool K2Node_DynamicCast_bSuccess; // 0xd70(0x01)
	char pad_D71[0x7]; // 0xd71(0x07)
	struct UKSDefaultAimTargetingModule* K2Node_DynamicCast_AsKSDefault_Aim_Targeting_Module; // 0xd78(0x08)
	bool K2Node_DynamicCast_bSuccess_2; // 0xd80(0x01)
	char pad_D81[0x3]; // 0xd81(0x03)
	struct FVector CallFunc_IsWallMarkerActive_WallLocation; // 0xd84(0x0c)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Hits; // 0xd90(0x10)
	struct FVector K2Node_CustomEvent_Start_5; // 0xda0(0x0c)
	struct FVector K2Node_CustomEvent_End_5; // 0xdac(0x0c)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Hits_2; // 0xdb8(0x10)
	struct FVector K2Node_CustomEvent_Trace_End; // 0xdc8(0x0c)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate; // 0xdd4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2; // 0xde4(0x10)
	float K2Node_Event_DeltaSeconds; // 0xdf4(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3; // 0xdf8(0x10)
	enum class EWeaponStateNew K2Node_Event_OldState; // 0xe08(0x01)
	enum class EWeaponStateNew K2Node_Event_NewState; // 0xe09(0x01)
	bool K2Node_SwitchEnum_CmpSuccess; // 0xe0a(0x01)
	char pad_E0B[0x5]; // 0xe0b(0x05)
	struct FFullFireRepData K2Node_Event_Data; // 0xe10(0x68)
	struct TArray<struct FHitResult> K2Node_CustomEvent_Hits_3; // 0xe78(0x10)
	bool K2Node_SwitchEnum_CmpSuccess_2; // 0xe88(0x01)
	char pad_E89[0x3]; // 0xe89(0x03)
	int32_t CallFunc_GetAnimMontage_Priority; // 0xe8c(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_2; // 0xe90(0x04)
	int32_t Temp_int_Loop_Counter_Variable; // 0xe94(0x04)
	bool K2Node_CustomEvent_bBlockingHit_4; // 0xe98(0x01)
	char pad_E99[0x7]; // 0xe99(0x07)
	struct TArray<struct FHitResult> K2Node_CustomEvent_OutHits_4; // 0xea0(0x10)
	struct FVector K2Node_CustomEvent_Start_6; // 0xeb0(0x0c)
	struct FVector K2Node_CustomEvent_End_6; // 0xebc(0x0c)
	int32_t Temp_int_Array_Index_Variable; // 0xec8(0x04)
	char pad_ECC[0x4]; // 0xecc(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item; // 0xed0(0x08)
	int32_t CallFunc_GetBool_Priority; // 0xed8(0x04)
	char pad_EDC[0x4]; // 0xedc(0x04)
	struct FFullFireRepData K2Node_CustomEvent_Fire_Data; // 0xee0(0x68)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst; // 0xf48(0x08)
	int32_t CallFunc_GetBool_Priority_2; // 0xf50(0x04)
	char pad_F54[0x4]; // 0xf54(0x04)
	struct APawn* K2Node_CustomEvent_ViewPawn; // 0xf58(0x08)
	enum class ECombatState K2Node_CustomEvent_NewState; // 0xf60(0x01)
	char pad_F61[0x7]; // 0xf61(0x07)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_2; // 0xf68(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_3; // 0xf70(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_4; // 0xf78(0x08)
	int32_t Temp_int_Variable; // 0xf80(0x04)
	int32_t Temp_int_Array_Index_Variable_2; // 0xf84(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_2; // 0xf88(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4; // 0xf90(0x10)
	int32_t CallFunc_GetAudioEvent_Priority; // 0xfa0(0x04)
	int32_t CallFunc_GetAudioEvent_Priority_2; // 0xfa4(0x04)
	int32_t CallFunc_GetAudioEvent_Priority_3; // 0xfa8(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_3; // 0xfac(0x04)
	struct UAnimMontage* CallFunc_Get_Player_1P_Fire_Montage_Montage; // 0xfb0(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_4; // 0xfb8(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_5; // 0xfbc(0x04)
	struct USkinnableSkeletalMeshComponent* K2Node_Event_SkinnableSkelComp; // 0xfc0(0x08)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable; // 0xfc8(0x10)
	int32_t Temp_int_Array_Index_Variable_3; // 0xfd8(0x04)
	int32_t Temp_int_Loop_Counter_Variable_2; // 0xfdc(0x04)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5; // 0xfe0(0x10)
	int32_t Temp_int_Array_Index_Variable_4; // 0xff0(0x04)
	char pad_FF4[0x4]; // 0xff4(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_3; // 0xff8(0x08)
	int32_t Temp_int_Loop_Counter_Variable_3; // 0x1000(0x04)
	struct FDelegate Temp_delegate_Variable; // 0x1004(0x10)
	char pad_1014[0x4]; // 0x1014(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2; // 0x1018(0x10)
	bool K2Node_SwitchEnum_CmpSuccess_3; // 0x1028(0x01)
	char pad_1029[0x3]; // 0x1029(0x03)
	int32_t Temp_int_Loop_Counter_Variable_4; // 0x102c(0x04)
	struct TArray<struct AActor*> Temp_object_Variable; // 0x1030(0x10)
	int32_t Temp_int_Array_Index_Variable_5; // 0x1040(0x04)
	char pad_1044[0x4]; // 0x1044(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_4; // 0x1048(0x08)
	enum class EEndPlayReason K2Node_Event_EndPlayReason; // 0x1050(0x01)
	char pad_1051[0x7]; // 0x1051(0x07)
	struct AKSCharacterFoundation* K2Node_CustomEvent_KillerCharacter; // 0x1058(0x08)
	struct AKSCharacterFoundation* K2Node_CustomEvent_KilledCharacter; // 0x1060(0x08)
	bool K2Node_SwitchEnum_CmpSuccess_4; // 0x1068(0x01)
	char pad_1069[0x7]; // 0x1069(0x07)
	struct AController* K2Node_CustomEvent_NewController; // 0x1070(0x08)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller; // 0x1078(0x08)
	bool K2Node_DynamicCast_bSuccess_3; // 0x1080(0x01)
	char pad_1081[0x3]; // 0x1081(0x03)
	struct FDelegate Temp_delegate_Variable_2; // 0x1084(0x10)
	char pad_1094[0x4]; // 0x1094(0x04)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3; // 0x1098(0x10)
	struct FDelegate Temp_delegate_Variable_3; // 0x10a8(0x10)
	int32_t Temp_int_Loop_Counter_Variable_5; // 0x10b8(0x04)
	int32_t CallFunc_GetBool_Priority_3; // 0x10bc(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_6; // 0x10c0(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_7; // 0x10c4(0x04)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_5; // 0x10c8(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_6; // 0x10d0(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_8; // 0x10d8(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_9; // 0x10dc(0x04)
	bool Temp_bool_Variable; // 0x10e0(0x01)
	char pad_10E1[0x3]; // 0x10e1(0x03)
	int32_t CallFunc_GetBool_Priority_4; // 0x10e4(0x04)
	struct UAnimMontage* K2Node_Select_Default; // 0x10e8(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_10; // 0x10f0(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_11; // 0x10f4(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_12; // 0x10f8(0x04)
	int32_t CallFunc_GetAnimMontage_Priority_13; // 0x10fc(0x04)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_7; // 0x1100(0x08)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_8; // 0x1108(0x08)
	int32_t CallFunc_GetAnimMontage_Priority_14; // 0x1110(0x04)
	char pad_1114[0x4]; // 0x1114(0x04)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue; // 0x1118(0x10)
	int32_t CallFunc_GetAnimMontage_Priority_15; // 0x1128(0x04)
	char pad_112C[0x4]; // 0x112c(0x04)
	struct UMaterialInterface* CallFunc_Array_Get_Item_5; // 0x1130(0x08)
	struct UMaterialInstanceDynamic* K2Node_DynamicCast_AsMaterial_Instance_Dynamic; // 0x1138(0x08)
	bool K2Node_DynamicCast_bSuccess_4; // 0x1140(0x01)
	char pad_1141[0x3]; // 0x1141(0x03)
	int32_t Temp_int_Variable_2; // 0x1144(0x04)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_9; // 0x1148(0x08)
	bool CallFunc_End_Reload_Weapon_Cancelled_A_Reload; // 0x1150(0x01)
	char pad_1151[0x7]; // 0x1151(0x07)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_10; // 0x1158(0x08)
	int32_t Temp_int_Array_Index_Variable_6; // 0x1160(0x04)
	char pad_1164[0x4]; // 0x1164(0x04)
	struct UParticleSystemComponent* CallFunc_Array_Get_Item_6; // 0x1168(0x08)
	int32_t Temp_int_Variable_3; // 0x1170(0x04)
	int32_t CallFunc_GetAudioEvent_Priority_4; // 0x1174(0x04)
	bool Temp_bool_Variable_2; // 0x1178(0x01)
	char pad_1179[0x7]; // 0x1179(0x07)
	struct UAnimMontage* K2Node_Select_Default_2; // 0x1180(0x08)
	struct UTexture2D* Temp_object_Variable_2; // 0x1188(0x08)
	bool Temp_bool_Variable_3; // 0x1190(0x01)
	enum class ECombatState K2Node_CustomEvent_OldCombatState; // 0x1191(0x01)
	enum class ECombatState K2Node_CustomEvent_NewCombatState; // 0x1192(0x01)
	char pad_1193[0x5]; // 0x1193(0x05)
	struct UTexture2D* K2Node_Select_Default_3; // 0x1198(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6; // 0x11a0(0x10)
	struct FDelegate Temp_delegate_Variable_4; // 0x11b0(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4; // 0x11c0(0x10)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_11; // 0x11d0(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7; // 0x11d8(0x10)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst_12; // 0x11e8(0x08)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8; // 0x11f0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9; // 0x1200(0x10)
	struct UKSWeaponAnimInstance* K2Node_DynamicCast_AsKSWeapon_Anim_Instance; // 0x1210(0x08)
	bool K2Node_DynamicCast_bSuccess_5; // 0x1218(0x01)
	char pad_1219[0x3]; // 0x1219(0x03)
	int32_t Temp_int_Loop_Counter_Variable_6; // 0x121c(0x04)
	struct UAnimMontage* CallFunc_Get_Player_3P_Fire_Montage_Montage; // 0x1220(0x08)
	char pad_1228[0x8]; // 0x1228(0x08)

	void OnSetShieldActive__DelegateSignature(bool bpp__ShieldIsActive__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetShieldActive__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnSetScopeScaleAlpha__DelegateSignature(float bpp__NewxAlpha__pfT); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetScopeScaleAlpha__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnSetRevolverChamberRotate__DelegateSignature(struct FRotator bpp__NewxRevolverxChamberxRotator__pfTTT); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetRevolverChamberRotate__DelegateSignature // (Public|Delegate|HasDefaults) // @ game+0x24d5b40
	void OnSetLobbyState__DelegateSignature(bool bpp__LobbyxState__pfT); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnSetLobbyState__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void Update Tracer Start Point(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Update Tracer Start Point // (Native|Public|BlueprintCallable) // @ game+0x184a7d0
	void Update Fire Anim on MIrror Pose Changed(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Update Fire Anim on MIrror Pose Changed // (Native|Public|BlueprintCallable) // @ game+0x184a7b0
	void Update Combat State(enum class ECombatState bpp__NewState__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Update Combat State // (Native|Public|BlueprintCallable) // @ game+0x9f2f90
	void UpdateMagDropBoneVelocity(float bpp__DeltaTime__pf, int32_t bpp__Index__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.UpdateMagDropBoneVelocity // (Native|Public|BlueprintCallable) // @ game+0x184a6e0
	void UpdateAimDownSightsBlurValues(); // Function Master_WeaponComponent.Master_WeaponComponent_C.UpdateAimDownSightsBlurValues // (Native|Event|Public|BlueprintCallable) // @ game+0x184a6c0
	void TryDisableCameraModifier(struct UObject* bpp__CameraxModifier__pfT, int32_t bpp__PlayerxIndex__pfT, bool& bpp__Found__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.TryDisableCameraModifier // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x184a5b0
	void SyncComputeCosmeticHits(struct FFullFireRepData bpp__FireData__pf, struct TArray<struct FHitResult>& bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SyncComputeCosmeticHits // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x184a480
	void Spawn Tracers Simple(struct TArray<struct FHitResult>& bpp__Hits__pf, struct FVector bpp__TracexEnd__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Spawn Tracers Simple // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x184a370
	void Spawn Tracer(struct FVector bpp__EndPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Spawn Tracer // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x184a2e0
	void Spawn Spangs and Decals(struct FFullFireRepData& bpp__Data__pf__const, struct TArray<struct FHitResult>& bpp__Hits__pf, struct FFullFireRepData& bpp__OutxData__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Spawn Spangs and Decals // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x184a140
	void SpawnTracers(struct TArray<struct FHitResult>& bpp__Hits__pf, struct TArray<struct FFullFireRepData>& bpp__AimData__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SpawnTracers // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x184a000
	void SpawnSpangs(struct TArray<struct FHitResult>& bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SpawnSpangs // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1849f50
	void SpawnDecals(struct TArray<struct FHitResult>& bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.SpawnDecals // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1849ea0
	void ShouldPlayFireAnim1P(bool& bpp__Playx1PxFire__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.ShouldPlayFireAnim1P // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1849de0
	void Set Scope Scale Alpha(float bpp__NewxAlpha__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Set Scope Scale Alpha // (Native|Public|BlueprintCallable) // @ game+0x1849d60
	void Set Revolver Chamber Rotate(struct FRotator bpp__TargetxRotator__pfT, bool bpp__ResetxRotation__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Set Revolver Chamber Rotate // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x1849c80
	void Set Muzzle Flash Emitter and Offset(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Set Muzzle Flash Emitter and Offset // (Native|Public|BlueprintCallable) // @ game+0xa6a6a0
	void Setup Tracers(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Setup Tracers // (Native|Public|BlueprintCallable) // @ game+0x1849c60
	void Setup Character Mirror Anims(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Setup Character Mirror Anims // (Native|Public|BlueprintCallable) // @ game+0x1849c40
	void Setup Character Anim Init Callback(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Setup Character Anim Init Callback // (Native|Public|BlueprintCallable) // @ game+0x1849c20
	void SetupMultiPrimary(); // Function Master_WeaponComponent.Master_WeaponComponent_C.SetupMultiPrimary // (Native|Public|BlueprintCallable) // @ game+0x1849c00
	void SetUIWidget(); // Function Master_WeaponComponent.Master_WeaponComponent_C.SetUIWidget // (Native|Public|BlueprintCallable) // @ game+0x1849be0
	struct UAnimMontage* Select Weapon Reload Montage(bool bpp__IsxQuickxReload__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Select Weapon Reload Montage // (Native|Public|BlueprintCallable) // @ game+0x1849b40
	void Select Character Reload Montage(struct UAnimMontage*& bpp__ReloadMontage__pf, struct UAnimMontage*& bpp__QuickReloadMontage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Select Character Reload Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1849a60
	void Retrieve Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Retrieve Weapon // (Native|Public|BlueprintCallable) // @ game+0x1849a40
	void Reticle Rotate(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reticle Rotate // (Native|Public|BlueprintCallable) // @ game+0x1849a20
	void Reset Variables at Start of Firing Instance(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reset Variables at Start of Firing Instance // (Native|Public|BlueprintCallable) // @ game+0x1849a00
	void Reload Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reload Weapon // (Native|Public|BlueprintCallable) // @ game+0x18499e0
	void Reload Cooldown Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Reload Cooldown Weapon // (Native|Public|BlueprintCallable) // @ game+0x18499c0
	void ReceiveTick(float bpp__DeltaSeconds__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ReceiveTick // (Native|Event|Public) // @ game+0x1849940
	void ReceiveEndPlay(enum class EEndPlayReason bpp__EndPlayReason__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ReceiveEndPlay // (Native|Event|Public) // @ game+0x1849840
	void ReceiveBeginPlay(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ReceiveBeginPlay // (Native|Event|Public) // @ game+0x1849820
	void Pre Fire Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Pre Fire Weapon // (Native|Public|BlueprintCallable) // @ game+0x1849800
	void Prepare Next Tracer Spawn(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Prepare Next Tracer Spawn // (Native|Public|BlueprintCallable) // @ game+0x18497e0
	void Post Fire Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Post Fire Weapon // (Native|Public|BlueprintCallable) // @ game+0x18497c0
	void Play Weapon Reload animation(float bpp__PlayRate__pf, bool bpp__IsxQuickxReload__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Weapon Reload animation // (Native|Public|BlueprintCallable) // @ game+0x18496f0
	void Play Reload MultiStage(float bpp__PlayxRate__pfT, struct UAnimMontage* bpp__SelectedxMontage__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Reload MultiStage // (Native|Public|BlueprintCallable) // @ game+0x1849620
	void Play Reload Logic(struct UAnimMontage* bpp__ReloadxMontage__pfT, struct UAnimMontage* bpp__QuickReloadxMontage__pfT, bool bpp__IsxMultixStagexReloadx__pfTTTzy); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Reload Logic // (Native|Public|BlueprintCallable) // @ game+0x1849520
	void Play Reload Base(float bpp__PlayxRate__pfT, struct UAnimMontage* bpp__SelectedxMontage__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Reload Base // (Native|Public|BlueprintCallable) // @ game+0x1849450
	void Play Post Reload(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Post Reload // (Native|Public|BlueprintCallable) // @ game+0x1849430
	void Play Fire Tail Sound(enum class EAkCallbackType bpp__CallbackxType__pfT, struct UAkCallbackInfo* bpp__CallbackxInfo__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Fire Tail Sound // (Native|Public|BlueprintCallable) // @ game+0x1849360
	void Play Fire Camera Shakes(bool bpp__LocalOnly__pf, struct UObject* bpp__PrimaryxShake__pfT, struct UObject* bpp__HiFreqxShake__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Fire Camera Shakes // (Native|Public|BlueprintCallable) // @ game+0x1849250
	void Play Casing Sound(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Casing Sound // (Native|Public|BlueprintCallable) // @ game+0x1849230
	void Play Bullet Impact SFX(struct FHitResult bpp__HitResult__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Play Bullet Impact SFX // (Native|Public|BlueprintCallable) // @ game+0x1849100
	void PlayInvalidFireSound(); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayInvalidFireSound // (Native|Public|BlueprintCallable) // @ game+0x18490e0
	void PlayFireSound(struct FAimData& bpp__InputPin__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayFireSound // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1849030
	void PlayEmptyFireAudio(); // Function Master_WeaponComponent.Master_WeaponComponent_C.PlayEmptyFireAudio // (Native|Public|BlueprintCallable) // @ game+0x1849010
	void On Cosmetic Trace Complete Internal(bool bpp__BlockingxHit__pfT__const, struct TArray<struct FHitResult>& bpp__OutxHits__pfT, struct FVector bpp__Start__pf__const, struct FVector bpp__End__pf__const, bool bpp__AllowxSpangs__pfT, bool bpp__AllowxTracers__pfT, bool bpp__AllowxDecals__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.On Cosmetic Trace Complete Internal // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1848db0
	void On Comestic Trace Complete(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult>& bpp__OutHits__pf__const, struct FVector& bpp__Start__pf__const, struct FVector& bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.On Comestic Trace Complete // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1848c10
	void On Character Anim Initialized(); // Function Master_WeaponComponent.Master_WeaponComponent_C.On Character Anim Initialized // (Native|Public|BlueprintCallable) // @ game+0x1848bf0
	void OnPossessedBy_Event_1(struct AController* bpp__NewController__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.OnPossessedBy_Event_1 // (Native|Public|BlueprintCallable) // @ game+0x1848b60
	void OnMirrorPoseChanged(); // Function Master_WeaponComponent.Master_WeaponComponent_C.OnMirrorPoseChanged // (Native|Event|Public) // @ game+0x1848b40
	void OnKilled_Event_1(struct AKSCharacterFoundation* bpp__KillerCharacter__pf__const, struct AKSCharacterFoundation* bpp__KilledCharacter__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.OnKilled_Event_1 // (Native|Public|BlueprintCallable) // @ game+0x1848a70
	void NotifyStopFireReceived(); // Function Master_WeaponComponent.Master_WeaponComponent_C.NotifyStopFireReceived // (BlueprintCosmetic|Native|Event|Public) // @ game+0x9f3030
	bool IsDropMeshValid(int32_t bpp__Index__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.IsDropMeshValid // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x18489d0
	void IdleWeapon(enum class EWeaponStateNew bpp__OldState__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.IdleWeapon // (Native|Public|BlueprintCallable) // @ game+0x1848950
	void Holster Weapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Holster Weapon // (Native|Public|BlueprintCallable) // @ game+0xb482b0
	void Hide Magazine(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Hide Magazine // (Native|Public|BlueprintCallable) // @ game+0x1848930
	void HasUIWidget(bool& bpp__HasUIWidget__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.HasUIWidget // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1848890
	void HandleWeaponFiringClientEffects(struct FFullFireRepData bpp__Data__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.HandleWeaponFiringClientEffects // (Native|Public|BlueprintCallable) // @ game+0x18487e0
	void Get Tracer Offset(float& bpp__Offset__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Tracer Offset // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1848740
	void Get Spang Particle System(struct FHitResult bpp__Hit__pf, struct UParticleSystem*& bpp__SpangxToxUse__pfTT, bool& bpp__PlayOnHitCharacter__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Spang Particle System // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x18485a0
	void Get Scaled Reload Playrate(struct UAnimMontage* bpp__AnimxMontage__pfT, float& bpp__ScaledxPlayrate__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Scaled Reload Playrate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x18484c0
	void Get Scaled Post Reload Playrate(struct UAnimMontage* bpp__AnimxMontage__pfT, float& bpp__ScaledxPlayrate__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Scaled Post Reload Playrate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x18483e0
	void Get Scaled Multistage Reload Playrate(struct UAnimMontage* bpp__AnimxMontage__pfT, float& bpp__ScaledxPlayrate__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Scaled Multistage Reload Playrate // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1848300
	void Get Reticle Material(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Reticle Material // (Native|Public|BlueprintCallable) // @ game+0x1848200
	void Get Post Reload Weapon Section Time(struct UAnimMontage* bpp__AnimxMontage__pfT, float& bpp__PostxReloadxPosition__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Post Reload Weapon Section Time // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1848120
	void Get Player 3P Lunge Montage(struct UAnimMontage*& bpp__Montage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Player 3P Lunge Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1848080
	void Get Player 3P Fire Montage(struct UAnimMontage*& bpp__Montage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Player 3P Fire Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847fe0
	void Get Player 1P Fire Montage(struct UAnimMontage*& bpp__Montage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Player 1P Fire Montage // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847f40
	void Get Holster Visibility(bool& bpp__Visibility__pf, struct UKSWeaponComponent*& bpp__WeaponComponent__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Holster Visibility // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847e60
	void Get Expected Aim Data(struct FAimData& bpp__AimData__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Expected Aim Data // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1847db0
	void Get Decal Material(struct FHitResult bpp__Hit__pf, struct FHitDecalInfo& bpp__DecalxInfo__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Decal Material // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847c30
	void Get Deattach Slot Name(struct AKSCharacter* bpp__KSCharacter__pf, struct FName& bpp__SlotxName__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Deattach Slot Name // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847b50
	void Get Character Anim Instance(struct UKSCharacterAnimInst*& bpp__AnimxInst__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Character Anim Instance // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847ab0
	void Get Character 3p Fire Section(struct FName& bpp__3pxFirexSection__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Character 3p Fire Section // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1847a10
	void Get Character 1p Fire Section(struct FName& bpp__1pxFirexSection__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Character 1p Fire Section // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1847970
	void Get Attach Slot Name(struct AKSCharacter* bpp__KSCharacter__pf, struct FName& bpp__SlotxName__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Get Attach Slot Name // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847890
	void GetTracerStartPoint(struct FVector& bpp__TracerStartLocation__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetTracerStartPoint // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1847800
	void GetTableRowNameForHit(struct FHitResult bpp__Hit__pf, struct FName bpp__RowNamePrefix__pf, struct FName& bpp__RowName__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetTableRowNameForHit // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847680
	void GetPercentRemainingAmmo(float& bpp__Percent__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetPercentRemainingAmmo // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x18475e0
	void GetMagDropBoneRotation(int32_t bpp__Index__pf, struct FRotator& bpp__WorldRotation__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetMagDropBoneRotation // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1847470
	void GetMagDropBoneLocation(int32_t bpp__Index__pf, struct FVector& bpp__WorldLocation__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetMagDropBoneLocation // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x18473a0
	void GetMagazineDropBoneName(struct FName& bpp__Name__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetMagazineDropBoneName // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847540
	struct UAkAudioEvent* GetFirstShotAudioEvent(); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetFirstShotAudioEvent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1847370
	struct UAkAudioEvent* GetFireAudioEvent(); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetFireAudioEvent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1847340
	struct UAkAudioEvent* GetEchoAudioEvent(); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetEchoAudioEvent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x1847310
	void GetDropVelocity(int32_t bpp__Index__pf, struct FVector& bpp__WorldVelocity__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetDropVelocity // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x1847240
	void GetDropMesh(int32_t bpp__Index__pf, struct USkeletalMesh*& bpp__SkelMesh__pf, struct UStaticMesh*& bpp__StaticMesh__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.GetDropMesh // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1847120
	void Force Exit ADS Pose(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Force Exit ADS Pose // (Native|Public|BlueprintCallable) // @ game+0x1847100
	void Force ADS Scope(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Force ADS Scope // (Native|Public|BlueprintCallable) // @ game+0x18470e0
	void ForceRetrieveWeapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceRetrieveWeapon // (Native|Event|Public|BlueprintCallable) // @ game+0x18470c0
	void ForceRetrieveState(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceRetrieveState // (Native|Event|Public|BlueprintCallable) // @ game+0x18470a0
	void ForceHolsterWeapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceHolsterWeapon // (Native|Event|Public|BlueprintCallable) // @ game+0x9f2ef0
	void ForceAttachWeaponToHolsterSocket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceAttachWeaponToHolsterSocket // (Native|Event|Public|BlueprintCallable) // @ game+0x1847080
	void ForceAttachWeaponToActiveSocket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.ForceAttachWeaponToActiveSocket // (Native|Event|Public|BlueprintCallable) // @ game+0x1847060
	void Fixup Laser Sight(struct USkinnableSkeletalMeshComponent* bpp__MeshComponent__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fixup Laser Sight // (Native|Public|BlueprintCallable) // @ game+0x1846fd0
	void Fixup Attach Point(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fixup Attach Point // (Native|Public|BlueprintCallable) // @ game+0x1846fb0
	void Fire Weapon(struct FFullFireRepData bpp__Data__pf, bool bpp__PlayNoChainFireMontage__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fire Weapon // (Native|Public|BlueprintCallable) // @ game+0x1846ea0
	void Fire Montage Jump To Section(struct FString bpp__Section__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.Fire Montage Jump To Section // (Native|Public|BlueprintCallable) // @ game+0x1846e00
	void Filter Cosmetic Hit Results(struct TArray<struct FHitResult>& bpp__TracexHitxResults__pfTT, struct TArray<struct FHitResult>& bpp__FilteredxHitxResults__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Filter Cosmetic Hit Results // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1846ce0
	void ExecuteUbergraph_Master_WeaponComponent_6(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_6 // (Final|Native|Public) // @ game+0x1846c60
	void ExecuteUbergraph_Master_WeaponComponent_43(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_43 // (Final|Native|Public) // @ game+0x1846be0
	void ExecuteUbergraph_Master_WeaponComponent_41(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_41 // (Final|Native|Public) // @ game+0x1846b60
	void ExecuteUbergraph_Master_WeaponComponent_39(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_39 // (Final|Native|Public) // @ game+0x1846a60
	void ExecuteUbergraph_Master_WeaponComponent_35(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_35 // (Final|Native|Public) // @ game+0x18469e0
	void ExecuteUbergraph_Master_WeaponComponent_4(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_4 // (Final|Native|Public) // @ game+0x1846ae0
	void ExecuteUbergraph_Master_WeaponComponent_1(int32_t bpp__EntryPoint__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ExecuteUbergraph_Master_WeaponComponent_1 // (Final|Native|Public) // @ game+0x1846960
	void Evaluate Shield Mesh Anim State(bool bpp__ShieldxState__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Evaluate Shield Mesh Anim State // (Native|Public|BlueprintCallable) // @ game+0x1846850
	void Evaluate Revolver Chamber Rotate(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Evaluate Revolver Chamber Rotate // (Native|Public|BlueprintCallable) // @ game+0x1846830
	void End Reload Weapon(bool bpp__AbortxReloadxAnimation__pfTT, bool& bpp__CancelledxAxReload__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.End Reload Weapon // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1846750
	void EnableOrAddCameraModifier(struct UObject* bpp__Modifier__pf, int32_t bpp__PlayerIndex__pf, struct UCameraModifier*& bpp__ModifierxObject__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.EnableOrAddCameraModifier // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1846640
	void DropMagInternal(int32_t bpp__Index__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.DropMagInternal // (Native|Public|BlueprintCallable) // @ game+0x1846590
	void DropMagazine(); // Function Master_WeaponComponent.Master_WeaponComponent_C.DropMagazine // (Native|Event|Public|BlueprintCallable) // @ game+0x1846620
	void DetermineMagSize(); // Function Master_WeaponComponent.Master_WeaponComponent_C.DetermineMagSize // (Native|Public|BlueprintCallable) // @ game+0x1846570
	void Delay Spawn Tracers(struct TArray<struct FHitResult>& bpp__Hits__pf__const, struct FVector bpp__TracexEnd__pfT__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.Delay Spawn Tracers // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1846460
	void Delay Spawn Spangs(struct TArray<struct FHitResult>& bpp__Hits__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Delay Spawn Spangs // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x18463b0
	void Delay Spawn Decals(struct TArray<struct FHitResult>& bpp__Hits__pf__const, struct FVector bpp__Start__pf, struct FVector bpp__End__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Delay Spawn Decals // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1846250
	void CheckKillCamScope(struct APawn* bpp__ViewPawn__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.CheckKillCamScope // (Native|Public|BlueprintCallable) // @ game+0x1846130
	void Character Combat State Changed(enum class ECombatState bpp__OldCombatState__pf, enum class ECombatState bpp__NewCombatState__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Character Combat State Changed // (Native|Public|BlueprintCallable) // @ game+0x1846070
	void Can Spawn Tracer Now(bool& bpp__CanxSpawnxxTracer__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Can Spawn Tracer Now // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x1845fd0
	void CancelReloadCosmetic(); // Function Master_WeaponComponent.Master_WeaponComponent_C.CancelReloadCosmetic // (BlueprintCosmetic|Native|Event|Public|BlueprintCallable) // @ game+0x1845fb0
	void Calculate Reload Time(struct UAnimMontage* bpp__ReloadxMontage__pfT, struct UAnimMontage* bpp__QuickxReloadxMontage__pfTT, float& bpp__PlayRate__pf, struct UAnimMontage*& bpp__SelectedxMontage__pfT, bool& bpp__IsxQuickReload__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Calculate Reload Time // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1845de0
	void Calculate Multistage Reload Time(struct UAnimMontage* bpp__ReloadxMontage__pfT, struct UAnimMontage* bpp__QuickxReloadxMontage__pfTT, float& bpp__PlayRate__pf, struct UAnimMontage*& bpp__SelectedxMontage__pfT, bool& bpp__IsxQuickReload__pfT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Calculate Multistage Reload Time // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1845c10
	void BuildupWeapon(); // Function Master_WeaponComponent.Master_WeaponComponent_C.BuildupWeapon // (Native|Public|BlueprintCallable) // @ game+0x1845bf0
	void BlueprintPrepareKillCamPlayback(); // Function Master_WeaponComponent.Master_WeaponComponent_C.BlueprintPrepareKillCamPlayback // (Native|Event|Public) // @ game+0x1845bd0
	void BlueprintPersistentCosmeticsUpdate(); // Function Master_WeaponComponent.Master_WeaponComponent_C.BlueprintPersistentCosmeticsUpdate // (Native|Event|Public) // @ game+0x1845bb0
	void AudioOnCooldown(); // Function Master_WeaponComponent.Master_WeaponComponent_C.AudioOnCooldown // (Native|Public|BlueprintCallable) // @ game+0x1845b90
	void Attach Weapon To Holster Socket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Attach Weapon To Holster Socket // (Native|Public|BlueprintCallable) // @ game+0x1845b70
	void Attach Weapon To Active Socket(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Attach Weapon To Active Socket // (Native|Public|BlueprintCallable) // @ game+0x1845b50
	void AsyncComputeCosmeticHitsAndPlay(struct FFullFireRepData bpp__FirexData__pfT__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.AsyncComputeCosmeticHitsAndPlay // (Native|Public|BlueprintCallable) // @ game+0x1845aa0
	void Apply Spang From Hit Result(struct FHitResult bpp__Hit__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Apply Spang From Hit Result // (Native|Public|BlueprintCallable) // @ game+0x1845970
	void ApplyDecalFromHit(struct FHitResult bpp__Hit__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.ApplyDecalFromHit // (Native|Public|BlueprintCallable) // @ game+0x1845840
	void Anim Init Set Weapon State(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Weapon State // (Native|Public|BlueprintCallable) // @ game+0x18457b0
	void Anim Init Set Use Weapon Additive(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Use Weapon Additive // (Native|Public|BlueprintCallable) // @ game+0x1845720
	void Anim Init Set Shield Is Active(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Shield Is Active // (Native|Public|BlueprintCallable) // @ game+0x1845690
	void Anim Init Set Scope Mesh Scale(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Scope Mesh Scale // (Native|Public|BlueprintCallable) // @ game+0x1845600
	void Anim Init Set Lobby State(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT, struct UAnimInstance* bpp__BackupxAnimxInst__pfTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Lobby State // (Native|Public|BlueprintCallable) // @ game+0x1845530
	void Anim Init Set Hide Magazine(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Hide Magazine // (Native|Public|BlueprintCallable) // @ game+0x18454a0
	void Anim Init Set Folding Stock(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Folding Stock // (Native|Public|BlueprintCallable) // @ game+0x1845410
	void Anim Init Set Disable Alternate Mirroring (Temp)(struct UKSWeaponAnimInstance* bpp__KSxWeaponxAnimxInst__pfTTT); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init Set Disable Alternate Mirroring (Temp) // (Native|Public|BlueprintCallable) // @ game+0x1845380
	void Anim Init On Weapon Mesh(struct USkinnableSkeletalMeshComponent* bpp__SkelComp__pf, struct UAnimInstance* bpp__AnimInstance__pf); // Function Master_WeaponComponent.Master_WeaponComponent_C.Anim Init On Weapon Mesh // (Native|Public|BlueprintCallable) // @ game+0x18452b0
	void Ancillary Mesh Scale Set(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Ancillary Mesh Scale Set // (Native|Public|BlueprintCallable) // @ game+0x1845290
	void Aim Over Shoulder Check Point(); // Function Master_WeaponComponent.Master_WeaponComponent_C.Aim Over Shoulder Check Point // (Native|Public|BlueprintCallable) // @ game+0x1845270
	void After Spawn Tracers Delay(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult>& bpp__OutHits__pf__const, struct FVector& bpp__Start__pf__const, struct FVector& bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.After Spawn Tracers Delay // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x18450d0
	void After Spawn Spangs Delay(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult>& bpp__OutHits__pf__const, struct FVector& bpp__Start__pf__const, struct FVector& bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.After Spawn Spangs Delay // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1844f30
	void After Spawn Decals Delay(bool bpp__bBlockingHit__pf, struct TArray<struct FHitResult>& bpp__OutHits__pf__const, struct FVector& bpp__Start__pf__const, struct FVector& bpp__End__pf__const); // Function Master_WeaponComponent.Master_WeaponComponent_C.After Spawn Decals Delay // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x1844d90
	void OnWeaponComponentStateChanged__DelegateSignature(struct UKSWeaponComponent* bpp__WeaponComponent__pf, enum class EWeaponStateNew bpp__OldState__pf, enum class EWeaponStateNew bpp__NewState__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnWeaponComponentStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnPossessedBy__DelegateSignature(struct AController* bpp__NewController__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnPossessedBy__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnCombatStateChanged__DelegateSignature(enum class ECombatState bpp__OldCombatState__pf, enum class ECombatState bpp__NewCombatState__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnCombatStateChanged__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnCharacterFoundationKilled__DelegateSignature(struct AKSCharacterFoundation* bpp__KillerCharacter__pf, struct AKSCharacterFoundation* bpp__KilledCharacter__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnCharacterFoundationKilled__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnAnimInitializedOnSkinnableMesh__DelegateSignature(struct USkinnableSkeletalMeshComponent* bpp__SkinnableSkelComp__pf, struct UAnimInstance* bpp__AnimInstance__pf); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnAnimInitializedOnSkinnableMesh__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
	void OnAnimInitialized__DelegateSignature(); // DelegateFunction Master_WeaponComponent.Master_WeaponComponent_C.OnAnimInitialized__DelegateSignature // (Public|Delegate) // @ game+0x24d5b40
};

