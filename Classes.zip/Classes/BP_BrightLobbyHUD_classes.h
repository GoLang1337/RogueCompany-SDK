// BlueprintGeneratedClass BP_BrightLobbyHUD.BP_BrightLobbyHUD_C
// Size: 0x6f8 (Inherited: 0x6b8)
struct ABP_BrightLobbyHUD_C : ABP_BrightLobbyHUDMinimal_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b8(0x08)
	struct UBrightLobbyWidget_C* LobbyWidget; // 0x6c0(0x08)
	char Loadout Slot Edit; // 0x6c8(0x01)
	char pad_6C9[0x7]; // 0x6c9(0x07)
	struct FMulticastInlineDelegate Loadout Slot Change; // 0x6d0(0x10)
	struct FName MatchLoadingRouteName; // 0x6e0(0x08)
	struct TArray<struct FName> ClearPendingRouteDataOnSwap; // 0x6e8(0x10)

	bool Is in EOM View State(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Is in EOM View State // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void Show Lobby Radial Select(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Show Lobby Radial Select // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct UKSItem* GetDefaultPlayerAccountItem(enum class EPlayerAccountSlot ItemSlot); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetDefaultPlayerAccountItem // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetupQueueEvents(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.SetupQueueEvents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void CallRemoveTopViewRoute(bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.CallRemoveTopViewRoute // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void CallAddViewRoute(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.CallAddViewRoute // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SafeFrameSettingApplied(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.SafeFrameSettingApplied // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BindSettingCallbacks(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.BindSettingCallbacks // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InternalAddViewRoute(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, struct UObject* Data, bool& ViewChanged); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.InternalAddViewRoute // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnAcquisition(struct UKSAcquisition* Acquisition); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.OnAcquisition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct UKSContextBarWidget* GetContextBarWidget(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetContextBarWidget // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void SwapViewRoute(struct FName RouteName, struct FName SwapTargetRoute, bool ForceTransition); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.SwapViewRoute // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Remove Top View Route(bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Remove Top View Route // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Add View Route(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Add View Route // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandeEOMResults(bool ForceTransition); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandeEOMResults // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void GetCurrentTransitionRoute(struct FName& Current Route); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetCurrentTransitionRoute // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	struct UKSLobbyWidget* GetLobbyWidget(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetLobbyWidget // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Focus Home Screen(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Focus Home Screen // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Get Current View Route(struct FName& Current Route); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Get Current View Route // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void Focus Sticky Loadout Panel(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Focus Sticky Loadout Panel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Get Current Loadout Slot(char& Current Loadout Slot); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Get Current Loadout Slot // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void Cache Current Loadout Slot(char Loadout Slot Edit); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Cache Current Loadout Slot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void TempBootstrapFunctionality(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.TempBootstrapFunctionality // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void FallbackLogoutCleanup(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.FallbackLogoutCleanup // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct UPanelWidget*> GetFocusableWidgetContainers(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetFocusableWidgetContainers // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void Handle Login State Change(enum class EPUMG_LoginState Login State); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Handle Login State Change // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct UPUMG_PopupManager* GetPopupManager(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetPopupManager // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Handle Party Invite Received(struct UPUMG_PlayerInfo* Inviter); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Handle Party Invite Received // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleOpenTextChat(bool BeginChatCommand); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandleOpenTextChat // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OpenTextChatToPlayer(struct UPUMG_PlayerInfo* Player); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.OpenTextChatToPlayer // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ApplySafeFrameScale(float SafeFrameScale); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.ApplySafeFrameScale // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnCustomQueueJoin(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.OnCustomQueueJoin // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void EvaluateFocus(); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.EvaluateFocus // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleMatchStatusUpdated(enum class EPUMG_MatchStatus MatchStatus); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandleMatchStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void HandleRewardsReceived(struct FPlayerRewardsSummary PlayerRewardsSummary, struct FScoreboardStats ScoreboardStats); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandleRewardsReceived // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_BP_BrightLobbyHUD(int32_t EntryPoint); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.ExecuteUbergraph_BP_BrightLobbyHUD // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void Loadout Slot Change__DelegateSignature(char Loadout Slot Edit); // Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Loadout Slot Change__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

