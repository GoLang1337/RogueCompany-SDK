// BlueprintGeneratedClass FriendlyLobbyPreviewActor.FriendlyLobbyPreviewActor_C
// Size: 0x518 (Inherited: 0x510)
struct AFriendlyLobbyPreviewActor_C : AKSJobSelectPreviewActor_Lobby {
	struct UPlayerInfoPrevwLoadoutComponent* PlayerInfoLoadoutComponent; // 0x510(0x08)
};

