// WidgetBlueprintGeneratedClass PopupButton.PopupButton_C
// Size: 0x5c8 (Inherited: 0x518)
struct UPopupButton_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWidgetAnimation* Hover; // 0x520(0x08)
	struct UImage* background; // 0x528(0x08)
	struct UButton* Button; // 0x530(0x08)
	struct USizeBox* ButtonCallout; // 0x538(0x08)
	struct UImage* ButtonCalloutImage; // 0x540(0x08)
	struct UTextBlock* DisplayTextBlock; // 0x548(0x08)
	struct UImage* HoverImage; // 0x550(0x08)
	struct FText ButtonText; // 0x558(0x18)
	struct FLinearColor ButtonColor; // 0x570(0x10)
	int32_t Index; // 0x580(0x04)
	char pad_584[0x4]; // 0x584(0x04)
	struct FMulticastInlineDelegate OnClicked; // 0x588(0x10)
	struct FMulticastInlineDelegate OnNavigateBackAction; // 0x598(0x10)
	bool CapturesNavBack; // 0x5a8(0x01)
	bool DisableClickSound; // 0x5a9(0x01)
	char pad_5AA[0x6]; // 0x5aa(0x06)
	struct UAkAudioEvent* NavBackPopupBtnSFX; // 0x5b0(0x08)
	struct UAkAudioEvent* ClickPopupBtnSFX; // 0x5b8(0x08)
	struct UAkAudioEvent* HoverPopupBtnSFX; // 0x5c0(0x08)

	bool NavigateBack(); // Function PopupButton.PopupButton_C.NavigateBack // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ToggleGamepadCallout(bool Show); // Function PopupButton.PopupButton_C.ToggleGamepadCallout // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetDisplayText(struct FText InText); // Function PopupButton.PopupButton_C.SetDisplayText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetButtonCalloutImage(struct FName InActionName); // Function PopupButton.PopupButton_C.SetButtonCalloutImage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetFontSize(int32_t In Font Size); // Function PopupButton.PopupButton_C.SetFontSize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool NavigateConfirm(); // Function PopupButton.PopupButton_C.NavigateConfirm // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function PopupButton.PopupButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function PopupButton.PopupButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function PopupButton.PopupButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function PopupButton.PopupButton_C.BndEvt__Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void GamepadHover(); // Function PopupButton.PopupButton_C.GamepadHover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadUnhover(); // Function PopupButton.PopupButton_C.GamepadUnhover // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void GamepadPress(); // Function PopupButton.PopupButton_C.GamepadPress // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnNavBack(); // Function PopupButton.PopupButton_C.OnNavBack // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Construct(); // Function PopupButton.PopupButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_PopupButton(int32_t EntryPoint); // Function PopupButton.PopupButton_C.ExecuteUbergraph_PopupButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
	void OnNavigateBackAction__DelegateSignature(); // Function PopupButton.PopupButton_C.OnNavigateBackAction__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnClicked__DelegateSignature(int32_t Index); // Function PopupButton.PopupButton_C.OnClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

