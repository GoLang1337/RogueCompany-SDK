// ScriptStruct NetCore.NetAnalyticsDataConfig
// Size: 0x0c (Inherited: 0x00)
struct FNetAnalyticsDataConfig {
	struct FName DataName; // 0x00(0x08)
	bool bEnabled; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

