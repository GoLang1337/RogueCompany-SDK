// Enum E_StorePanelSize.E_StorePanelSize
enum class E_StorePanelSize : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_MAX = 3
};

