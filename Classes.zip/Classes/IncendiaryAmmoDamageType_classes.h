// BlueprintGeneratedClass IncendiaryAmmoDamageType.IncendiaryAmmoDamageType_C
// Size: 0x140 (Inherited: 0x140)
struct UIncendiaryAmmoDamageType_C : UMasterFire_DamageType_C {
};

