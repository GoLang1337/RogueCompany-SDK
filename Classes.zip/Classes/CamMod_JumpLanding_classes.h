// BlueprintGeneratedClass CamMod_JumpLanding.CamMod_JumpLanding_C
// Size: 0x71 (Inherited: 0x68)
struct UCamMod_JumpLanding_C : UCamMod_Master_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x68(0x08)
	bool WasJumping; // 0x70(0x01)

	void ShouldModifyCamera(bool& bSuccess); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.ShouldModifyCamera // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayTimeline(); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.PlayTimeline // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnCamModFinished(); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.OnCamModFinished // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_CamMod_JumpLanding(int32_t EntryPoint); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.ExecuteUbergraph_CamMod_JumpLanding // (Final|UbergraphFunction) // @ game+0x24d5b40
};

