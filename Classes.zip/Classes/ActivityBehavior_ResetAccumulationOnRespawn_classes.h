// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C
// Size: 0x40 (Inherited: 0x38)
struct UActivityBehavior_ResetAccumulationOnRespawn_C : UKSActivityBehavior {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x38(0x08)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.HandleBehaviorInitialized // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandlePlayerRespawned(struct AKSPlayerState* PlayerState, struct AKSCharacterBase* Character); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.HandlePlayerRespawned // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRespawn(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRespawn // (Final|UbergraphFunction) // @ game+0x24d5b40
};

