// BlueprintGeneratedClass EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C
// Size: 0x230 (Inherited: 0x208)
struct UEventTracker_TripleThreatChallenge_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	struct TArray<int32_t> ItemIds; // 0x210(0x10)
	struct TArray<int32_t> LootTableItemIds; // 0x220(0x10)

	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_TripleThreatChallenge(int32_t EntryPoint); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.ExecuteUbergraph_EventTracker_TripleThreatChallenge // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

