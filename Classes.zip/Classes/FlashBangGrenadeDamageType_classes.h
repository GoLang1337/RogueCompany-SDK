// BlueprintGeneratedClass FlashBangGrenadeDamageType.FlashBangGrenadeDamageType_C
// Size: 0x140 (Inherited: 0x140)
struct UFlashBangGrenadeDamageType_C : UKSDamageTypeFlashBang {
};

