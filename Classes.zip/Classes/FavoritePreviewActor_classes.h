// BlueprintGeneratedClass FavoritePreviewActor.FavoritePreviewActor_C
// Size: 0x518 (Inherited: 0x510)
struct AFavoritePreviewActor_C : AKSJobSelectPreviewActor_Lobby {
	struct UFavoritePreviewLoadoutComponent* FavoritePreviewLoadout; // 0x510(0x08)
};

