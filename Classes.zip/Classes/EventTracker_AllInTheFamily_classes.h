// BlueprintGeneratedClass EventTracker_AllInTheFamily.EventTracker_AllInTheFamily_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_AllInTheFamily_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_AllInTheFamily.EventTracker_AllInTheFamily_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_AllInTheFamily.EventTracker_AllInTheFamily_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_AllInTheFamily.EventTracker_AllInTheFamily_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_AllInTheFamily(int32_t EntryPoint); // Function EventTracker_AllInTheFamily.EventTracker_AllInTheFamily_C.ExecuteUbergraph_EventTracker_AllInTheFamily // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

