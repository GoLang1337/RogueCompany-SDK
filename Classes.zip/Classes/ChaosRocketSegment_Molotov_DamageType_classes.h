// BlueprintGeneratedClass ChaosRocketSegment_Molotov_DamageType.ChaosRocketSegment_Molotov_DamageType_C
// Size: 0x140 (Inherited: 0x140)
struct UChaosRocketSegment_Molotov_DamageType_C : UMasterFire_DamageType_C {
};

