// Enum EGamepadPromptType.EGamepadPromptType
enum class EGamepadPromptType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	EGamepadPromptType_MAX = 4
};

