// BlueprintGeneratedClass SettingsInfo_AutoPickup.SettingsInfo_AutoPickup_C
// Size: 0x118 (Inherited: 0x118)
struct USettingsInfo_AutoPickup_C : UKSSettingsInfo_Generic {
};

