// WidgetBlueprintGeneratedClass LoginDownloadProgressBar.LoginDownloadProgressBar_C
// Size: 0x268 (Inherited: 0x248)
struct ULoginDownloadProgressBar_C : UKSDownloadProgressWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x248(0x08)
	struct UWidgetAnimation* Installing; // 0x250(0x08)
	struct UProgressBar* LoadingBar_2; // 0x258(0x08)
	struct UTextBlock* ProgressText; // 0x260(0x08)

	void Make Progress Text(float Percent, float Seconds, bool Supports ETA, struct FText& Text); // Function LoginDownloadProgressBar.LoginDownloadProgressBar_C.Make Progress Text // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x24d5b40
	void Construct(); // Function LoginDownloadProgressBar.LoginDownloadProgressBar_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void UpdatedDownloadProgress(float Progress, float Total, float Eta, bool bSupportsEta); // Function LoginDownloadProgressBar.LoginDownloadProgressBar_C.UpdatedDownloadProgress // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void UpdateFinished(); // Function LoginDownloadProgressBar.LoginDownloadProgressBar_C.UpdateFinished // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoginDownloadProgressBar(int32_t EntryPoint); // Function LoginDownloadProgressBar.LoginDownloadProgressBar_C.ExecuteUbergraph_LoginDownloadProgressBar // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

