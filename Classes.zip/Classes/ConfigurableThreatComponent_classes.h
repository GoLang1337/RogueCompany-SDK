// DynamicClass ConfigurableThreatComponent.ConfigurableThreatComponent_C
// Size: 0x190 (Inherited: 0x190)
struct UConfigurableThreatComponent_C : UKSThreatComponent {
};

