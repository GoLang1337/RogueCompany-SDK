// BlueprintGeneratedClass NearMissCameraShake_FromBack.NearMissCameraShake_FromBack_C
// Size: 0x160 (Inherited: 0x160)
struct UNearMissCameraShake_FromBack_C : UCameraShake {
};

