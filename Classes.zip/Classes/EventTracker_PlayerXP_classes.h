// BlueprintGeneratedClass EventTracker_PlayerXP.EventTracker_PlayerXP_C
// Size: 0x240 (Inherited: 0x208)
struct UEventTracker_PlayerXP_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	float BaseProgress; // 0x210(0x04)
	char pad_214[0x4]; // 0x214(0x04)
	struct AKSPlayerState* PlayerState; // 0x218(0x08)
	float AccumulatedProgress; // 0x220(0x04)
	float XpPerMinute; // 0x224(0x04)
	float PremiumBoostMultiplier; // 0x228(0x04)
	float WinMultiplier; // 0x22c(0x04)
	struct FString BonusKey; // 0x230(0x10)

	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessEventBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.IsWinningTeam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessWinBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessQueueBonus // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessBoosterBonuses // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ComputeBaseProgess(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ComputeBaseProgess // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_PlayerXP(int32_t EntryPoint); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ExecuteUbergraph_EventTracker_PlayerXP // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

