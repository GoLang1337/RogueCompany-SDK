// DynamicClass MainCharacterThreatComponent.MainCharacterThreatComponent_C
// Size: 0x220 (Inherited: 0x190)
struct UMainCharacterThreatComponent_C : UConfigurableThreatComponent_C {
	struct TMap<int32_t, struct FLinearColor> DebugColorMap; // 0x190(0x50)
	bool DebuggingVisuals; // 0x1e0(0x01)
	char pad_1E1[0x3]; // 0x1e1(0x03)
	struct FLinearColor K2Node_MakeStruct_LinearColor; // 0x1e4(0x10)
	float K2Node_Event_DeltaSeconds; // 0x1f4(0x04)
	bool K2Node_Event_Show; // 0x1f8(0x01)
	char pad_1F9[0x3]; // 0x1f9(0x03)
	struct FLinearColor K2Node_MakeStruct_LinearColor_2; // 0x1fc(0x10)
	struct FLinearColor CallFunc_Map_Find_Value; // 0x20c(0x10)
	char pad_21C[0x4]; // 0x21c(0x04)

	void ReceiveTick(float bpp__DeltaSeconds__pf); // Function MainCharacterThreatComponent.MainCharacterThreatComponent_C.ReceiveTick // (Native|Event|Public) // @ game+0x18498c0
	void DebugThreatLevels(bool bpp__Show__pf); // Function MainCharacterThreatComponent.MainCharacterThreatComponent_C.DebugThreatLevels // (Native|Event|Public) // @ game+0x18461c0
};

