// Enum EPlayerStatusOption.EPlayerStatusOption
enum class EPlayerStatusOption : uint8 {
	NewEnumerator0 = 0,
	EPlayerStatusOption_MAX = 1
};

