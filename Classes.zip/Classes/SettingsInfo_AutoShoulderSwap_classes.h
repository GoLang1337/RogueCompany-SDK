// BlueprintGeneratedClass SettingsInfo_AutoShoulderSwap.SettingsInfo_AutoShoulderSwap_C
// Size: 0x118 (Inherited: 0x118)
struct USettingsInfo_AutoShoulderSwap_C : UKSSettingsInfo_Generic {
};

