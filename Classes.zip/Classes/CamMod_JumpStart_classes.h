// BlueprintGeneratedClass CamMod_JumpStart.CamMod_JumpStart_C
// Size: 0x70 (Inherited: 0x68)
struct UCamMod_JumpStart_C : UCamMod_Master_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x68(0x08)

	void ShouldModifyCamera(bool& bSuccess); // Function CamMod_JumpStart.CamMod_JumpStart_C.ShouldModifyCamera // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void PlayTimeline(); // Function CamMod_JumpStart.CamMod_JumpStart_C.PlayTimeline // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_CamMod_JumpStart(int32_t EntryPoint); // Function CamMod_JumpStart.CamMod_JumpStart_C.ExecuteUbergraph_CamMod_JumpStart // (Final|UbergraphFunction) // @ game+0x24d5b40
};

