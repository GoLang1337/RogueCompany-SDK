// BlueprintGeneratedClass EventTracker_NoRespect.EventTracker_NoRespect_C
// Size: 0x210 (Inherited: 0x210)
struct UEventTracker_NoRespect_C : UEventTrackerAbstract_InstigatedDamage_C {

	void IsValidCombatEvent(struct FCombatEventInfo& EventInfo, bool& IsValid); // Function EventTracker_NoRespect.EventTracker_NoRespect_C.IsValidCombatEvent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

