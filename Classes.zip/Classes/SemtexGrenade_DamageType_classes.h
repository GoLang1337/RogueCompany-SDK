// BlueprintGeneratedClass SemtexGrenade_DamageType.SemtexGrenade_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct USemtexGrenade_DamageType_C : UMasterExplosion_DamageType_C {
};

