// BlueprintGeneratedClass SettingsInfo_BindDodgeRoll.SettingsInfo_BindDodgeRoll_C
// Size: 0x128 (Inherited: 0x128)
struct USettingsInfo_BindDodgeRoll_C : UKSSettingsInfo_Binding {
};

