// WidgetBlueprintGeneratedClass LoginEula.LoginEula_C
// Size: 0x5d8 (Inherited: 0x518)
struct ULoginEula_C : UKSWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UWidgetAnimation* MobileLayout; // 0x520(0x08)
	struct UWBP_StandardButtonLarge_C* AcceptNew; // 0x528(0x08)
	struct UImage* ArrowDown; // 0x530(0x08)
	struct UImage* ArrowUp; // 0x538(0x08)
	struct UWBP_StandardButtonLarge_C* BackNew; // 0x540(0x08)
	struct UImage* bkg; // 0x548(0x08)
	struct UCheckbox_C* CheckBox; // 0x550(0x08)
	struct UImage* Divider; // 0x558(0x08)
	struct UScrollBox* EulaContainer; // 0x560(0x08)
	struct UTextBlock* EulaText_Mobile; // 0x568(0x08)
	struct UTextBlock* EulaText_PC; // 0x570(0x08)
	struct UImage* Image_190; // 0x578(0x08)
	struct UInvalidationBox* InvalidationBox_Mobile; // 0x580(0x08)
	struct UInvalidationBox* InvalidationBox_PC; // 0x588(0x08)
	struct UWidgetSwitcher* NextSwitcher; // 0x590(0x08)
	struct UImage* ScrollCalloutDown; // 0x598(0x08)
	struct UWidgetSwitcher* ScrollCalloutSwitcher; // 0x5a0(0x08)
	struct UImage* ScrollCalloutUp; // 0x5a8(0x08)
	struct UImage* StudioLogo; // 0x5b0(0x08)
	struct UImage* TitleLogo; // 0x5b8(0x08)
	struct UVerticalBox* VerticalBox_1; // 0x5c0(0x08)
	struct UWBP_PanelDefault_C* WBP_PanelDefault; // 0x5c8(0x08)
	struct FTimerHandle CalloutTimer; // 0x5d0(0x08)

	void EnableAcceptButton(bool Enable); // Function LoginEula.LoginEula_C.EnableAcceptButton // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ShowArrows(float Value, float MaxValue); // Function LoginEula.LoginEula_C.ShowArrows // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ChangeFontSizeText(); // Function LoginEula.LoginEula_C.ChangeFontSizeText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HandleCalloutSwitcher(); // Function LoginEula.LoginEula_C.HandleCalloutSwitcher // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function LoginEula.LoginEula_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function LoginEula.LoginEula_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function LoginEula.LoginEula_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetButtonListeners(); // Function LoginEula.LoginEula_C.InitializeWidgetButtonListeners // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ScrollUpPressed(); // Function LoginEula.LoginEula_C.ScrollUpPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ScrollDownPressed(); // Function LoginEula.LoginEula_C.ScrollDownPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ScrollUpReleased(); // Function LoginEula.LoginEula_C.ScrollUpReleased // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ScrollDownReleased(); // Function LoginEula.LoginEula_C.ScrollDownReleased // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Handle Input State Changed(enum class PGAME_INPUT_STATE InputState); // Function LoginEula.LoginEula_C.Handle Input State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void SetActiveScrollCallout(); // Function LoginEula.LoginEula_C.SetActiveScrollCallout // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__FormBackButton_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(int32_t Index); // Function LoginEula.LoginEula_C.BndEvt__FormBackButton_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__FormNextButton_K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature(int32_t Index); // Function LoginEula.LoginEula_C.BndEvt__FormNextButton_K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__Checkbox_K2Node_ComponentBoundEvent_0_OnCheckChanged__DelegateSignature(bool Checked); // Function LoginEula.LoginEula_C.BndEvt__Checkbox_K2Node_ComponentBoundEvent_0_OnCheckChanged__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__AcceptNew_K2Node_ComponentBoundEvent_5_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginEula.LoginEula_C.BndEvt__AcceptNew_K2Node_ComponentBoundEvent_5_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__BackNew_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature(struct UWidget* Widget); // Function LoginEula.LoginEula_C.BndEvt__BackNew_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_LoginEula(int32_t EntryPoint); // Function LoginEula.LoginEula_C.ExecuteUbergraph_LoginEula // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

