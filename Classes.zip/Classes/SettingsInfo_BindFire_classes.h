// BlueprintGeneratedClass SettingsInfo_BindFire.SettingsInfo_BindFire_C
// Size: 0x128 (Inherited: 0x128)
struct USettingsInfo_BindFire_C : UKSSettingsInfo_Binding {
};

