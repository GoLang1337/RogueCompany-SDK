// BlueprintGeneratedClass P12K_DamageType.P12K_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UP12K_DamageType_C : UMasterPistol_DamageType_C {
};

