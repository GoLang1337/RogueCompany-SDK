// BlueprintGeneratedClass Landed_CameraShake.Landed_CameraShake_C
// Size: 0x180 (Inherited: 0x180)
struct ULanded_CameraShake_C : UKSCharacterCameraShake {
};

