// BlueprintGeneratedClass NearMissCameraShake_FromRight.NearMissCameraShake_FromRight_C
// Size: 0x160 (Inherited: 0x160)
struct UNearMissCameraShake_FromRight_C : UCameraShake {
};

