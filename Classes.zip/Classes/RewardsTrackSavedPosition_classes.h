// BlueprintGeneratedClass RewardsTrackSavedPosition.RewardsTrackSavedPosition_C
// Size: 0x40 (Inherited: 0x28)
struct URewardsTrackSavedPosition_C : UObject {
	int32_t Page; // 0x28(0x04)
	int32_t Index; // 0x2c(0x04)
	struct FString Context; // 0x30(0x10)
};

