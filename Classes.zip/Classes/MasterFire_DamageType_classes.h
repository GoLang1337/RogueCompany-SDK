// BlueprintGeneratedClass MasterFire_DamageType.MasterFire_DamageType_C
// Size: 0x140 (Inherited: 0x140)
struct UMasterFire_DamageType_C : UKSDamageTypeFire {
};

