// BlueprintGeneratedClass Reviver_InteractionType.Reviver_InteractionType_C
// Size: 0x328 (Inherited: 0x328)
struct UReviver_InteractionType_C : UInteractionTypeBase_C {
};

