// BlueprintGeneratedClass RogueScreenLobbyCharacter.RogueScreenLobbyCharacter_C
// Size: 0x3ee0 (Inherited: 0x3ed2)
struct ARogueScreenLobbyCharacter_C : ALocalPlayerLobbyCharacter_C {
	char pad_3ED2[0x6]; // 0x3ed2(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3ed8(0x08)

	void ReceiveBeginPlay(); // Function RogueScreenLobbyCharacter.RogueScreenLobbyCharacter_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_RogueScreenLobbyCharacter(int32_t EntryPoint); // Function RogueScreenLobbyCharacter.RogueScreenLobbyCharacter_C.ExecuteUbergraph_RogueScreenLobbyCharacter // (Final|UbergraphFunction) // @ game+0x24d5b40
};

