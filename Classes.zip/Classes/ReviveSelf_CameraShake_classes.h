// BlueprintGeneratedClass ReviveSelf_CameraShake.ReviveSelf_CameraShake_C
// Size: 0x160 (Inherited: 0x160)
struct UReviveSelf_CameraShake_C : UCameraShake {
};

