// WidgetBlueprintGeneratedClass NewStartMenu.NewStartMenu_C
// Size: 0x570 (Inherited: 0x518)
struct UNewStartMenu_C : UKSNewStartMenuWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x518(0x08)
	struct UVerticalBox* ButtonBox; // 0x520(0x08)
	struct UWBP_StandardButton_02_C* ButtonContracts; // 0x528(0x08)
	struct UWBP_StandardButton_02_C* ButtonNews; // 0x530(0x08)
	struct UWBP_StandardButton_02_C* ButtonQuit; // 0x538(0x08)
	struct UWBP_StandardButton_02_C* ButtonSettings; // 0x540(0x08)
	struct UImage* logo; // 0x548(0x08)
	struct UOverlay* MenuContainer; // 0x550(0x08)
	struct UTextBlock* VersionDisplay; // 0x558(0x08)
	struct FName CachedLastRoute; // 0x560(0x08)
	struct UAkAudioEvent* BackClickNewStartMenuSFX; // 0x568(0x08)

	void Set Version Text(); // Function NewStartMenu.NewStartMenu_C.Set Version Text // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	bool NavigateBack(); // Function NewStartMenu.NewStartMenu_C.NavigateBack // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ShowMenuAnim(float ElapsedTime, float ElapsedAlpha); // Function NewStartMenu.NewStartMenu_C.ShowMenuAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ShowMenuFinished(); // Function NewStartMenu.NewStartMenu_C.ShowMenuFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitHideAnimation(); // Function NewStartMenu.NewStartMenu_C.InitHideAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HideMenuFinished(); // Function NewStartMenu.NewStartMenu_C.HideMenuFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void HideMenuAnim(float ElapsedTime, float ElapsedAlpha); // Function NewStartMenu.NewStartMenu_C.HideMenuAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StartHideAnim(); // Function NewStartMenu.NewStartMenu_C.StartHideAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function NewStartMenu.NewStartMenu_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidgetNavigation(); // Function NewStartMenu.NewStartMenu_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BackToLastScreen(); // Function NewStartMenu.NewStartMenu_C.BackToLastScreen // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function NewStartMenu.NewStartMenu_C.StartShowSequence // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function NewStartMenu.NewStartMenu_C.StartHideSequence // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void InitializeTickAnimations(); // Function NewStartMenu.NewStartMenu_C.InitializeTickAnimations // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void StartShowAnim(); // Function NewStartMenu.NewStartMenu_C.StartShowAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void Construct(); // Function NewStartMenu.NewStartMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__ButtonNews_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonNews_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__ButtonQuit_K2Node_ComponentBoundEvent_5_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonQuit_K2Node_ComponentBoundEvent_5_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__ButtonSettings_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonSettings_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void OnBackButton(); // Function NewStartMenu.NewStartMenu_C.OnBackButton // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__ButtonContracts_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(struct UWidget* Widget); // Function NewStartMenu.NewStartMenu_C.BndEvt__ButtonContracts_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_NewStartMenu(int32_t EntryPoint); // Function NewStartMenu.NewStartMenu_C.ExecuteUbergraph_NewStartMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

