// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression.ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression_C
// Size: 0x44 (Inherited: 0x38)
struct UActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression_C : UKSActivityBehavior {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x38(0x08)
	int32_t LastAccumulatedProgress; // 0x40(0x04)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression.ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression_C.HandleBehaviorInitialized // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void HandleWeaponFiredPostDamage(); // Function ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression.ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression_C.HandleWeaponFiredPostDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression.ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression // (Final|UbergraphFunction) // @ game+0x24d5b40
};

