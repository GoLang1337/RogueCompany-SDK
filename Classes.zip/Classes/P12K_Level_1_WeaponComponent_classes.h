// BlueprintGeneratedClass P12K_Level_1_WeaponComponent.P12K_Level_1_WeaponComponent_C
// Size: 0x1230 (Inherited: 0x1230)
struct UP12K_Level_1_WeaponComponent_C : UP12K_WeaponComponent_C {
};

