// Enum KillstreakAnimGraphRuntime.EPoseMirrorPlane
enum class EPoseMirrorPlane : uint8 {
	XZ = 0,
	XY = 1,
	YZ = 2,
	EPoseMirrorPlane_MAX = 3
};

// Enum KillstreakAnimGraphRuntime.ERecoilAllowMirror
enum class ERecoilAllowMirror : uint8 {
	Both = 0,
	UnmirroredOnly = 1,
	MirroredOnly = 2,
	ERecoilAllowMirror_MAX = 3
};

// Enum KillstreakAnimGraphRuntime.ERecoilStart
enum class ERecoilStart : uint8 {
	ERS_SpecifyOffset = 0,
	ERS_Random = 1,
	ERS_SpecifyOffsetRandom = 2
};

// ScriptStruct KillstreakAnimGraphRuntime.BoneMirrorConfig
// Size: 0x20 (Inherited: 0x00)
struct FBoneMirrorConfig {
	struct TArray<struct FBoneReference> UnpairedMirrorBones; // 0x00(0x10)
	struct TArray<struct FBoneMirrorPair> PairedMirrorBones; // 0x10(0x10)
};

// ScriptStruct KillstreakAnimGraphRuntime.BoneMirrorPair
// Size: 0x2c (Inherited: 0x00)
struct FBoneMirrorPair {
	struct FBoneReference BoneOne; // 0x00(0x10)
	struct FBoneReference BoneTwo; // 0x10(0x10)
	struct FVector RotationFlipAxis; // 0x20(0x0c)
};

// ScriptStruct KillstreakAnimGraphRuntime.KSAnimNode_Mirror
// Size: 0x120 (Inherited: 0xd8)
struct FKSAnimNode_Mirror : FAnimNode_SkeletalControlBase {
	struct FBoneMirrorConfig BoneMirrorConfig; // 0xd8(0x20)
	enum class EPoseMirrorPlane MirrorPlane; // 0xf8(0x01)
	bool bAlternateMirroring; // 0xf9(0x01)
	char pad_FA[0x6]; // 0xfa(0x06)
	struct FBoneMirrorConfig MirrorConfigCache; // 0x100(0x20)
};

// ScriptStruct KillstreakAnimGraphRuntime.KSAnimNode_OrientationWarp
// Size: 0x120 (Inherited: 0xd8)
struct FKSAnimNode_OrientationWarp : FAnimNode_SkeletalControlBase {
	float Angle; // 0xd8(0x04)
	float OrientationAlphaOverride; // 0xdc(0x04)
	struct FAnimOrientationWarpDefinition WarpSettings; // 0xe0(0x38)
	bool bUseOrientationAlphaOverride; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
};

// ScriptStruct KillstreakAnimGraphRuntime.AnimOrientationWarpDefinition
// Size: 0x38 (Inherited: 0x00)
struct FAnimOrientationWarpDefinition {
	enum class EAxis YawRotationAxis; // 0x00(0x01)
	bool UseBoneSpaceForSpineWarp; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	float OrientationAlpha; // 0x04(0x04)
	struct TArray<struct FBoneReference> SpineBones; // 0x08(0x10)
	struct FBoneReference IkFootRoot; // 0x18(0x10)
	struct TArray<struct FBoneReference> IkFootBones; // 0x28(0x10)
};

// ScriptStruct KillstreakAnimGraphRuntime.KSAnimNode_Recoil
// Size: 0x1c0 (Inherited: 0xd8)
struct FKSAnimNode_Recoil : FAnimNode_SkeletalControlBase {
	struct FBoneReference m_BoneToRecoil; // 0xd8(0x10)
	bool m_bBoneSpaceRecoil; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	float RotTimeToGo; // 0xec(0x04)
	float PosTimeToGo; // 0xf0(0x04)
	struct FRecoilInfo m_Recoil; // 0xf4(0x60)
	bool m_bApplyControl; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
	float m_fBlendInTime; // 0x158(0x04)
	float m_fBlendInRemainingTime; // 0x15c(0x04)
	struct FVector m_vBlendLoc; // 0x160(0x0c)
	struct FRotator m_rBlendRot; // 0x16c(0x0c)
	struct FRotator RotOffset; // 0x178(0x0c)
	char pad_184[0xc]; // 0x184(0x0c)
	struct FVector LocOffset; // 0x190(0x0c)
	char pad_19C[0xc]; // 0x19c(0x0c)
	int32_t m_nFireImpulseCounter; // 0x1a8(0x04)
	enum class ERecoilAllowMirror m_eMirrorPermissions; // 0x1ac(0x01)
	enum class EPoseMirrorPlane m_eMirrorPlane; // 0x1ad(0x01)
	char pad_1AE[0x2]; // 0x1ae(0x02)
	struct FVector m_vRotationFlipAxis; // 0x1b0(0x0c)
	int32_t m_nInternalFireImpulseCounter; // 0x1bc(0x04)
};

// ScriptStruct KillstreakAnimGraphRuntime.RecoilInfo
// Size: 0x60 (Inherited: 0x00)
struct FRecoilInfo {
	float TimeDurationPos; // 0x00(0x04)
	float TimeDurationRot; // 0x04(0x04)
	struct FVector RotAmplitude; // 0x08(0x0c)
	struct FVector RotFrequency; // 0x14(0x0c)
	struct FRecoilParams RotParams; // 0x20(0x10)
	struct FVector LocAmplitude; // 0x30(0x0c)
	struct FVector LocFrequency; // 0x3c(0x0c)
	struct FRecoilParams LocParams; // 0x48(0x10)
	float BlendInTime; // 0x58(0x04)
	bool Enabled; // 0x5c(0x01)
	bool Mirrored; // 0x5d(0x01)
	char pad_5E[0x2]; // 0x5e(0x02)
};

// ScriptStruct KillstreakAnimGraphRuntime.RecoilParams
// Size: 0x10 (Inherited: 0x00)
struct FRecoilParams {
	struct FVector PhaseOffset; // 0x00(0x0c)
	enum class ERecoilStart X; // 0x0c(0x01)
	enum class ERecoilStart Y; // 0x0d(0x01)
	enum class ERecoilStart Z; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
};

// ScriptStruct KillstreakAnimGraphRuntime.KSAnimNode_SpeedWarp
// Size: 0x130 (Inherited: 0xd8)
struct FKSAnimNode_SpeedWarp : FAnimNode_SkeletalControlBase {
	float SpeedScaling; // 0xd8(0x04)
	struct FVector SpeedWarpForwardAxis; // 0xdc(0x0c)
	struct FAnimSpeedWarpDefinition SpeedWarpSettings; // 0xe8(0x48)
};

// ScriptStruct KillstreakAnimGraphRuntime.AnimSpeedWarpDefinition
// Size: 0x48 (Inherited: 0x00)
struct FAnimSpeedWarpDefinition {
	struct FBoneReference IkFootRootBone; // 0x00(0x10)
	struct TArray<struct FBoneReference> IkFootBones; // 0x10(0x10)
	struct FBoneReference PelvisBone; // 0x20(0x10)
	float PelvisAdjustmentAlpha; // 0x30(0x04)
	int32_t PelvisAdjustmentMaxIterations; // 0x34(0x04)
	float PelvisAdjustmentStiffness; // 0x38(0x04)
	float PelvisAdjustmentDamping; // 0x3c(0x04)
	struct FName DisableSpeedWarpCurveName; // 0x40(0x08)
};

// ScriptStruct KillstreakAnimGraphRuntime.RecoilProfile
// Size: 0x1ec (Inherited: 0x00)
struct FRecoilProfile {
	struct FRecoilInfo PelvisRecoil; // 0x00(0x60)
	struct FRecoilInfo SpineRecoil; // 0x60(0x60)
	struct FRecoilInfo NeckRecoil; // 0xc0(0x60)
	struct FRecoilInfo HandRecoil; // 0x120(0x60)
	struct FRecoilInfo RightClavicleRecoil; // 0x180(0x60)
	float Spine1RecoilAlpha; // 0x1e0(0x04)
	float Spine2RecoilAlpha; // 0x1e4(0x04)
	float Spine3RecoilAlpha; // 0x1e8(0x04)
};

