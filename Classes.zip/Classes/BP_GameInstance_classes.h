// BlueprintGeneratedClass BP_GameInstance.BP_GameInstance_C
// Size: 0x568 (Inherited: 0x548)
struct UBP_GameInstance_C : UKSGameInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x548(0x08)
	struct UAkAudioEvent* Begin Loading Music; // 0x550(0x08)
	struct UAkAudioEvent* End Loading Music; // 0x558(0x08)
	struct UAkAudioEvent* Play Music Event; // 0x560(0x08)

	void EndLoading(); // Function BP_GameInstance.BP_GameInstance_C.EndLoading // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BeginLoading(struct FString mapName); // Function BP_GameInstance.BP_GameInstance_C.BeginLoading // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_BP_GameInstance(int32_t EntryPoint); // Function BP_GameInstance.BP_GameInstance_C.ExecuteUbergraph_BP_GameInstance // (Final|UbergraphFunction) // @ game+0x24d5b40
};

