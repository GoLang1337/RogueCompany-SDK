// BlueprintGeneratedClass Lobby_LightingHQ.Lobby_LightingHQ_C
// Size: 0x228 (Inherited: 0x228)
struct ALobby_LightingHQ_C : ALevelScriptActor {
};

