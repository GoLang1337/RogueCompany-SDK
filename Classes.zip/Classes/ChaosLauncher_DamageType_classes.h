// BlueprintGeneratedClass ChaosLauncher_DamageType.ChaosLauncher_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UChaosLauncher_DamageType_C : UMasterSMG_DamageType_C {
};

