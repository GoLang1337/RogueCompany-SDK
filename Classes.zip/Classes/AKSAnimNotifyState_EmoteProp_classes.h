// BlueprintGeneratedClass AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C
// Size: 0x98 (Inherited: 0x98)
struct UAKSAnimNotifyState_EmoteProp_C : UKSAnimNotifyState_EmoteProp {

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.Received_NotifyBegin // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	void OnStaticMeshComponentInitialized(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration, struct UStaticMeshComponent* SpawnedStaticMeshComponent); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.OnStaticMeshComponentInitialized // (Event|Protected|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
	void OnSkeletalMeshComponentInitialized(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration, struct USkeletalMeshComponent* SpawnedSkeletalMeshComponent); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.OnSkeletalMeshComponentInitialized // (Event|Protected|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

