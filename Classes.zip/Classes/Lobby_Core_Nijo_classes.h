// BlueprintGeneratedClass Lobby_Core_Nijo.Lobby_Core_Nijo_C
// Size: 0x230 (Inherited: 0x228)
struct ALobby_Core_Nijo_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)

	void BndEvt__MainLobbyCamera_K2Node_ActorBoundEvent_0_TakeRadialDamageSignature__DelegateSignature(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct FVector Origin, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function Lobby_Core_Nijo.Lobby_Core_Nijo_C.BndEvt__MainLobbyCamera_K2Node_ActorBoundEvent_0_TakeRadialDamageSignature__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_Lobby_Core_Nijo(int32_t EntryPoint); // Function Lobby_Core_Nijo.Lobby_Core_Nijo_C.ExecuteUbergraph_Lobby_Core_Nijo // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

