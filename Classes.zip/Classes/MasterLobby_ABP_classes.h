// AnimBlueprintGeneratedClass MasterLobby_ABP.MasterLobby_ABP_C
// Size: 0x2732 (Inherited: 0x10f0)
struct UMasterLobby_ABP_C : UKSCharacterAnimInst {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x10f0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x10f8(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x1138(0x88)
	struct FAnimNode_SequenceSkinned AnimGraphNode_SequenceSkinned; // 0x11c0(0x160)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x1320(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x1360(0xc0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4; // 0x1420(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4; // 0x1450(0x30)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x1480(0xd0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x1550(0x88)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2; // 0x15d8(0x100)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone; // 0x16d8(0x100)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3; // 0x17d8(0xc8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5; // 0x18a0(0x38)
	bool __CustomProperty_bIsLobby_90FBADB5424A5A00D7B0F4B018D67A66; // 0x18d8(0x01)
	bool __CustomProperty_bIsServer_90FBADB5424A5A00D7B0F4B018D67A66; // 0x18d9(0x01)
	char pad_18DA[0x6]; // 0x18da(0x06)
	struct FAnimNode_LinkedAnimGraph AnimGraphNode_SubInstance; // 0x18e0(0xb0)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x1990(0x58)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x19e8(0xb0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3; // 0x1a98(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3; // 0x1ac8(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x1af8(0x118)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0x1c10(0xc8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4; // 0x1cd8(0x38)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0x1d10(0x38)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x1d48(0xb0)
	char pad_1DF8[0x8]; // 0x1df8(0x08)
	struct FAnimNode_RigidBodySkipServer AnimGraphNode_RigidBodySkipServer; // 0x1e00(0x5b0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2; // 0x23b0(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2; // 0x23e0(0x30)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x2410(0xc8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x24d8(0x38)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x2510(0x38)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x2548(0x58)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x25a0(0x118)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x26b8(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x26e8(0x30)
	float R_Prop_Lock_Alpha; // 0x2718(0x04)
	float L_Prop_Lock_Alpha; // 0x271c(0x04)
	bool bIsServer; // 0x2720(0x01)
	bool SkinUseCharacterScale; // 0x2721(0x01)
	char pad_2722[0x2]; // 0x2722(0x02)
	struct FVector CharacterScale; // 0x2724(0x0c)
	bool ChildPhysicsAssetEnable; // 0x2730(0x01)
	bool RemoveHeadAccessory; // 0x2731(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_Lobby_Unlock_LProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Unlock_LProp // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_Lobby_Unlock_RProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Unlock_RProp // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_Lobby_Lock_LProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Lock_LProp // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void AnimNotify_Lobby_Lock_RProp(); // Function MasterLobby_ABP.MasterLobby_ABP_C.AnimNotify_Lobby_Lock_RProp // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void BlueprintInitializeAnimation(); // Function MasterLobby_ABP.MasterLobby_ABP_C.BlueprintInitializeAnimation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void Set Skinned Local Parameters(struct TSet<struct FName>& Keywords); // Function MasterLobby_ABP.MasterLobby_ABP_C.Set Skinned Local Parameters // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void UpdateTurnInPlace(float DeltaSeconds); // Function MasterLobby_ABP.MasterLobby_ABP_C.UpdateTurnInPlace // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_MasterLobby_ABP(int32_t EntryPoint); // Function MasterLobby_ABP.MasterLobby_ABP_C.ExecuteUbergraph_MasterLobby_ABP // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

