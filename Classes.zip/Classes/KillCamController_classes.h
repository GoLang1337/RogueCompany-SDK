// BlueprintGeneratedClass KillCamController.KillCamController_C
// Size: 0xf10 (Inherited: 0xf08)
struct AKillCamController_C : AKSKillCamController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xf08(0x08)

	void ReceiveBeginPlay(); // Function KillCamController.KillCamController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_KillCamController(int32_t EntryPoint); // Function KillCamController.KillCamController_C.ExecuteUbergraph_KillCamController // (Final|UbergraphFunction) // @ game+0x24d5b40
};

