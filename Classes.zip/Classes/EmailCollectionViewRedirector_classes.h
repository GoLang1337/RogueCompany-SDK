// BlueprintGeneratedClass EmailCollectionViewRedirector.EmailCollectionViewRedirector_C
// Size: 0x60 (Inherited: 0x60)
struct UEmailCollectionViewRedirector_C : UKSEmailCollection_ViewRedirector {

	struct UKSActivityManagerBase* GetRelevantActivityManager(struct UKSGameInstance* GameInstance); // Function EmailCollectionViewRedirector.EmailCollectionViewRedirector_C.GetRelevantActivityManager // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x24d5b40
};

