// BlueprintGeneratedClass Katana_DamageType.Katana_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UKatana_DamageType_C : UMasterMelee_DamageType_C {
};

