// Class SelectiveAkAudioEventCommon.AnimNotify_SelectiveAkEvent
// Size: 0x50 (Inherited: 0x38)
struct UAnimNotify_SelectiveAkEvent : UAnimNotify {
	struct FName AttachName; // 0x38(0x08)
	struct USelectiveAkAudioEvent* Event; // 0x40(0x08)
	bool bFollow; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class SelectiveAkAudioEventCommon.SelectiveAkAudioEvent
// Size: 0x28 (Inherited: 0x28)
struct USelectiveAkAudioEvent : UObject {
};

// Class SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct USelectiveAkGameplayStatics : UBlueprintFunctionLibrary {

	void PostSelectiveEventStopToAkComponent(struct USelectiveAkAudioEvent* SelectiveEvent, struct UAkComponent* AkComponent); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.PostSelectiveEventStopToAkComponent // (Final|BlueprintCosmetic|Native|Static|Private|BlueprintCallable) // @ game+0xc6f910
	void PostSelectiveEventStop(struct USelectiveAkAudioEvent* SelectiveEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.PostSelectiveEventStop // (Final|BlueprintCosmetic|Native|Static|Private|BlueprintCallable) // @ game+0xc6f810
	int32_t PostSelectiveEventPlayToAkComponent(struct USelectiveAkAudioEvent* SelectiveEvent, struct UAkComponent* AkComponent); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.PostSelectiveEventPlayToAkComponent // (Final|BlueprintCosmetic|Native|Static|Private|BlueprintCallable) // @ game+0xc6f750
	int32_t PostSelectiveEventPlay(struct USelectiveAkAudioEvent* SelectiveEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.PostSelectiveEventPlay // (Final|BlueprintCosmetic|Native|Static|Private|BlueprintCallable) // @ game+0xc6f660
	void GetStopEventsFromSelectiveEventForAkComponent(struct TArray<struct FSelectiveEventStopPair>& OutStopEvents, struct USelectiveAkAudioEvent* SelectiveEvent, struct UAkComponent* AkComponent); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.GetStopEventsFromSelectiveEventForAkComponent // (Final|BlueprintCosmetic|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xc6f510
	void GetStopEventsFromSelectiveEvent(struct TArray<struct FSelectiveEventStopPair>& OutStopEvents, struct USelectiveAkAudioEvent* SelectiveEvent, struct AActor* Actor); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.GetStopEventsFromSelectiveEvent // (Final|BlueprintCosmetic|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xc6f3c0
	struct UAkAudioEvent* GetPlayEventFromSelectiveEventForAkComponent(struct USelectiveAkAudioEvent* SelectiveEvent, struct UAkComponent* AkComponent, struct FString& OutEventName); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.GetPlayEventFromSelectiveEventForAkComponent // (Final|BlueprintCosmetic|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xc6f290
	struct UAkAudioEvent* GetPlayEventFromSelectiveEvent(struct USelectiveAkAudioEvent* SelectiveEvent, struct AActor* Actor, struct FString& OutEventName); // Function SelectiveAkAudioEventCommon.SelectiveAkGameplayStatics.GetPlayEventFromSelectiveEvent // (Final|BlueprintCosmetic|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xc6f160
};

// Class SelectiveAkAudioEventCommon.ViewDependentAkAudioEvent
// Size: 0x50 (Inherited: 0x28)
struct UViewDependentAkAudioEvent : USelectiveAkAudioEvent {
	struct UViewDependentAkEventRules* Rules; // 0x28(0x08)
	struct UAkAudioEvent* FirstPersonAkEventPlay; // 0x30(0x08)
	struct UAkAudioEvent* ThirdPersonAkEventPlay; // 0x38(0x08)
	struct UAkAudioEvent* FirstPersonAkEventStop; // 0x40(0x08)
	struct UAkAudioEvent* ThirdPersonAkEventStop; // 0x48(0x08)
};

// Class SelectiveAkAudioEventCommon.ViewDependentAkEventRules
// Size: 0x28 (Inherited: 0x28)
struct UViewDependentAkEventRules : UObject {
};

// Class SelectiveAkAudioEventCommon.ViewDependentRules_IsViewTarget
// Size: 0x28 (Inherited: 0x28)
struct UViewDependentRules_IsViewTarget : UViewDependentAkEventRules {
};

