// BlueprintGeneratedClass EventTracker_Conditional_Death.EventTracker_Conditional_Death_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_Conditional_Death_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Conditional_Death.EventTracker_Conditional_Death_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Conditional_Death.EventTracker_Conditional_Death_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnPlayerDeath(struct FCombatEventInfo EventInfo); // Function EventTracker_Conditional_Death.EventTracker_Conditional_Death_C.OnPlayerDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Conditional_Death(int32_t EntryPoint); // Function EventTracker_Conditional_Death.EventTracker_Conditional_Death_C.ExecuteUbergraph_EventTracker_Conditional_Death // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

