// BlueprintGeneratedClass EventTracker_Moneybags.EventTracker_Moneybags_C
// Size: 0x215 (Inherited: 0x208)
struct UEventTracker_Moneybags_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)
	int32_t EarnTarget; // 0x210(0x04)
	bool HasTriggered; // 0x214(0x01)

	bool DidPlayerWinMatch(); // Function EventTracker_Moneybags.EventTracker_Moneybags_C.DidPlayerWinMatch // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_Moneybags.EventTracker_Moneybags_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_Moneybags.EventTracker_Moneybags_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void OnCashChanged_Event_1(int32_t Money, int32_t Delta); // Function EventTracker_Moneybags.EventTracker_Moneybags_C.OnCashChanged_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_Moneybags(int32_t EntryPoint); // Function EventTracker_Moneybags.EventTracker_Moneybags_C.ExecuteUbergraph_EventTracker_Moneybags // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

