// BlueprintGeneratedClass InteractionTypeBase.InteractionTypeBase_C
// Size: 0x328 (Inherited: 0x328)
struct UInteractionTypeBase_C : UKSInteractionType {
};

