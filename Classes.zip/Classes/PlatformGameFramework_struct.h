// Enum PlatformGameFramework.EGameLocalizationType
enum class EGameLocalizationType : uint8 {
	Unknown = 0,
	PC = 1,
	XboxOne = 2,
	PS4_SIEA = 3,
	PS4_SIEE = 4,
	Switch = 5,
	Mobile = 6,
	EGameLocalizationType_MAX = 7
};

// Enum PlatformGameFramework.EGameBits
enum class EGameBits : uint8 {
	NoStoreUI = 0,
	UseAltUI = 1,
	UseAltQueueUI = 2,
	UseSpectator = 3,
	EGameBits_MAX = 4
};

// Enum PlatformGameFramework.EPGame_CustomMovement
enum class EPGame_CustomMovement : uint8 {
	PLATMOVE_Tween = 0,
	PLATMOVE_Charge = 1,
	PLATMOVE_MAX = 2
};

// Enum PlatformGameFramework.ECombatLogType
enum class ECombatLogType : uint8 {
	JSON = 0,
	AWS = 1,
	DEFAULT = 0,
	ECombatLogType_MAX = 2
};

// Enum PlatformGameFramework.EEffectGroupApplicationRule
enum class EEffectGroupApplicationRule : uint8 {
	STACKABLE = 0,
	NEWEST = 1,
	STRONGEST = 2,
	REFRESH = 3,
	STACK_IN_PLACE = 4,
	STACK_IN_PLACE_INSTIGATOR = 5,
	STRONGEST_BEFORE_NEWEST = 6,
	EEffectGroupApplicationRule_MAX = 7
};

// Enum PlatformGameFramework.EFubarRewardRecipients
enum class EFubarRewardRecipients : uint8 {
	None = 0,
	PostedPlayers = 1,
	PostLoginPlayers = 2,
	EFubarRewardRecipients_MAX = 3
};

// Enum PlatformGameFramework.EFubarReason
enum class EFubarReason : uint8 {
	NotFubar = 0,
	CPUSaturation = 1,
	GameModePlayersDisconnectedBothSides = 2,
	GameModePlayersDisconnected = 3,
	GameModeGeneral = 4,
	MultipleBadConnections = 5,
	Test = 6,
	DefaultMapLoadFailure = 7,
	FailedToListenForConnections = 8,
	EFubarReason_MAX = 9
};

// Enum PlatformGameFramework.EPGame_EPropertyType
enum class EPGame_EPropertyType : uint8 {
	PROPTYPE_Modifier = 0,
	PROPTYPE_Percent = 1,
	PROPTYPE_Value = 2,
	PROPTYPE_Delta = 3,
	PROPTYPE_MAX = 4
};

// Enum PlatformGameFramework.ESonyMatchState
enum class ESonyMatchState : uint8 {
	NotStarted = 0,
	MatchIdRequested = 1,
	Playing = 2,
	SendPauseOrCancelMatch = 3,
	SendCompleteMatch = 4,
	Complete = 5,
	ESonyMatchState_MAX = 6
};

// Enum PlatformGameFramework.PGAME_INPUT_STATE
enum class PGAME_INPUT_STATE : uint8 {
	PIS_KEYMOUSE = 0,
	PIS_GAMEPAD = 1,
	PIS_TOUCH = 2,
	PIS_UNKNOWN = 3,
	PIS_MAX = 4
};

// Enum PlatformGameFramework.EPositionHistoryRecordMode
enum class EPositionHistoryRecordMode : uint8 {
	OnTick = 0,
	Manual = 1,
	EPositionHistoryRecordMode_MAX = 2
};

// Enum PlatformGameFramework.EPGame_ReplicateTimerState
enum class EPGame_ReplicateTimerState : uint8 {
	Inactive = 0,
	Active = 1,
	Overtime = 2,
	Unlimited = 3,
	Paused = 4,
	EPGame_MAX = 5
};

// ScriptStruct PlatformGameFramework.PGame_ReplicatedTimerId
// Size: 0x01 (Inherited: 0x00)
struct FPGame_ReplicatedTimerId {
	char ID; // 0x00(0x01)
};

// ScriptStruct PlatformGameFramework.PGame_BlueprintableLightingChannels
// Size: 0x03 (Inherited: 0x00)
struct FPGame_BlueprintableLightingChannels {
	bool bChannel0; // 0x00(0x01)
	bool bChannel1; // 0x01(0x01)
	bool bChannel2; // 0x02(0x01)
};

// ScriptStruct PlatformGameFramework.ChargeInfo
// Size: 0x1c (Inherited: 0x00)
struct FChargeInfo {
	struct FVector ChargeInitialLocation; // 0x00(0x0c)
	float ChargeInitialYaw; // 0x0c(0x04)
	float ChargeSpeed; // 0x10(0x04)
	float ChargeRange; // 0x14(0x04)
	char ChargeType; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
};

// ScriptStruct PlatformGameFramework.TweenInfo
// Size: 0x14 (Inherited: 0x00)
struct FTweenInfo {
	char TweenType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVector TweenDestination; // 0x04(0x0c)
	float TweenTime; // 0x10(0x04)
};

// ScriptStruct PlatformGameFramework.PGame_InstantEffectRepData
// Size: 0x40 (Inherited: 0x00)
struct FPGame_InstantEffectRepData {
	struct UPGame_EffectGroup* EffectGroupBlueprint; // 0x00(0x08)
	struct UPGame_EffectAttachment* AttachmentBlueprint; // 0x08(0x08)
	uint16_t EffectGroupId; // 0x10(0x02)
	char pad_12[0x6]; // 0x12(0x06)
	struct AActor* SourceActor; // 0x18(0x08)
	struct FVector HitLocation; // 0x20(0x0c)
	struct FVector HitNormal; // 0x2c(0x0c)
	uint32_t ReplicatedEffectFlags; // 0x38(0x04)
	uint16_t SkinId; // 0x3c(0x02)
	char pad_3E[0x2]; // 0x3e(0x02)
};

// ScriptStruct PlatformGameFramework.PGame_PersistentEffectRepDataContainer
// Size: 0x120 (Inherited: 0x108)
struct FPGame_PersistentEffectRepDataContainer : FFastArraySerializer {
	struct TArray<struct FPGame_PersistentEffectRepData> Items; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct PlatformGameFramework.PGame_PersistentEffectRepData
// Size: 0x58 (Inherited: 0x0c)
struct FPGame_PersistentEffectRepData : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct UPGame_EffectGroup* EffectGroupBlueprint; // 0x10(0x08)
	struct UPGame_EffectAttachment* AttachmentBlueprint; // 0x18(0x08)
	uint16_t EffectGroupId; // 0x20(0x02)
	char pad_22[0x2]; // 0x22(0x02)
	float fTimeRemainingInitial; // 0x24(0x04)
	char pad_28[0x4]; // 0x28(0x04)
	char nNumStacks; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	struct AActor* SourceActor; // 0x30(0x08)
	uint32_t ReplicatedEffectFlags; // 0x38(0x04)
	uint16_t SkinId; // 0x3c(0x02)
	char pad_3E[0x12]; // 0x3e(0x12)
	struct UPGame_EffectAttachment* pAttachment; // 0x50(0x08)
};

// ScriptStruct PlatformGameFramework.PGame_EffectManagerPropertyContainer
// Size: 0x170 (Inherited: 0x108)
struct FPGame_EffectManagerPropertyContainer : FFastArraySerializer {
	struct TArray<struct FPGame_Property> Properties; // 0x108(0x10)
	char pad_118[0x58]; // 0x118(0x58)
};

// ScriptStruct PlatformGameFramework.PGame_Property
// Size: 0x24 (Inherited: 0x0c)
struct FPGame_Property : FFastArraySerializerItem {
	struct FPlatformPropertyId PropertyId; // 0x0c(0x02)
	enum class EPGame_EPropertyType Type; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
	float Base; // 0x10(0x04)
	float RawFlat; // 0x14(0x04)
	float RawPercent; // 0x18(0x04)
	float Minimum; // 0x1c(0x04)
	float Maximum; // 0x20(0x04)
};

// ScriptStruct PlatformGameFramework.PlatformPropertyId
// Size: 0x02 (Inherited: 0x00)
struct FPlatformPropertyId {
	uint16_t ID; // 0x00(0x02)
};

// ScriptStruct PlatformGameFramework.PGame_EffectManagerCurrentProperty
// Size: 0x08 (Inherited: 0x00)
struct FPGame_EffectManagerCurrentProperty {
	struct FPlatformPropertyId propId; // 0x00(0x02)
	char pad_2[0x2]; // 0x02(0x02)
	float propValue; // 0x04(0x04)
};

// ScriptStruct PlatformGameFramework.PGame_SonyMatchData
// Size: 0x18 (Inherited: 0x00)
struct FPGame_SonyMatchData {
	struct FString MatchID; // 0x00(0x10)
	char pad_10[0x8]; // 0x10(0x08)
};

// ScriptStruct PlatformGameFramework.PGame_InactivePlayerStateEntry
// Size: 0x10 (Inherited: 0x00)
struct FPGame_InactivePlayerStateEntry {
	char pad_0[0x8]; // 0x00(0x08)
	struct APlayerState* PlayerState; // 0x08(0x08)
};

// ScriptStruct PlatformGameFramework.PGame_PlayerProfile
// Size: 0x20 (Inherited: 0x00)
struct FPGame_PlayerProfile {
	struct FSerializedMctsNetId MctsPlayerId; // 0x00(0x08)
	struct FString PlayerName; // 0x08(0x10)
	uint16_t AccessFlags; // 0x18(0x02)
	bool bSpectator; // 0x1a(0x01)
	bool bDebugPlayer; // 0x1b(0x01)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct PlatformGameFramework.CollisionDebugInfo
// Size: 0x40 (Inherited: 0x00)
struct FCollisionDebugInfo {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct PlatformGameFramework.PrimitivePriority
// Size: 0x20 (Inherited: 0x00)
struct FPrimitivePriority {
	struct UPrimitiveComponent* Primitive; // 0x00(0x08)
	int32_t Priority; // 0x08(0x04)
	char pad_C[0x14]; // 0x0c(0x14)
};

// ScriptStruct PlatformGameFramework.PGame_ReplicatedTimer
// Size: 0x38 (Inherited: 0x00)
struct FPGame_ReplicatedTimer {
	char pad_0[0x8]; // 0x00(0x08)
	enum class EPGame_ReplicateTimerState TimerState; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float InitialTime; // 0x0c(0x04)
	float TimeRemaining; // 0x10(0x04)
	char pad_14[0x24]; // 0x14(0x24)
};

// ScriptStruct PlatformGameFramework.PGame_ReplicatedTimerManagerBase
// Size: 0x120 (Inherited: 0x108)
struct FPGame_ReplicatedTimerManagerBase : FFastArraySerializer {
	struct TArray<struct FPGame_ReplicatedTimerManagerEntry> Timers; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct PlatformGameFramework.PGame_ReplicatedTimerManagerEntry
// Size: 0x58 (Inherited: 0x0c)
struct FPGame_ReplicatedTimerManagerEntry : FFastArraySerializerItem {
	struct FPGame_ReplicatedTimerId ID; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FPGame_ReplicatedTimer Timer; // 0x10(0x38)
	char pad_48[0x10]; // 0x48(0x10)
};

// ScriptStruct PlatformGameFramework.PGame_ReplicatedTimerManagerSlave
// Size: 0x170 (Inherited: 0x120)
struct FPGame_ReplicatedTimerManagerSlave : FPGame_ReplicatedTimerManagerBase {
	char pad_120[0x50]; // 0x120(0x50)
};

// ScriptStruct PlatformGameFramework.PGame_ReplicatedTimerManager
// Size: 0x128 (Inherited: 0x120)
struct FPGame_ReplicatedTimerManager : FPGame_ReplicatedTimerManagerBase {
	char NextTimerId; // 0x120(0x01)
	char pad_121[0x7]; // 0x121(0x07)
};

