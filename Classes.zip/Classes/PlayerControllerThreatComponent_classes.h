// DynamicClass PlayerControllerThreatComponent.PlayerControllerThreatComponent_C
// Size: 0x190 (Inherited: 0x190)
struct UPlayerControllerThreatComponent_C : UConfigurableThreatComponent_C {
};

