// BlueprintGeneratedClass MirvGrenade_DamageType.MirvGrenade_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UMirvGrenade_DamageType_C : UGrenade_DamageType_C {
};

