// BlueprintGeneratedClass BP_LobbyState.BP_LobbyState_C
// Size: 0x2a8 (Inherited: 0x290)
struct ABP_LobbyState_C : AGameState {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	struct AKSEmoteMusicManager* EmoteMusicManager; // 0x2a0(0x08)

	struct AKSEmoteMusicManager* GetEmoteMusicManager(); // Function BP_LobbyState.BP_LobbyState_C.GetEmoteMusicManager // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x24d5b40
	void ReceiveBeginPlay(); // Function BP_LobbyState.BP_LobbyState_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_BP_LobbyState(int32_t EntryPoint); // Function BP_LobbyState.BP_LobbyState_C.ExecuteUbergraph_BP_LobbyState // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

