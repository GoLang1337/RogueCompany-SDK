// BlueprintGeneratedClass Master_DamageType.Master_DamageType_C
// Size: 0x138 (Inherited: 0x138)
struct UMaster_DamageType_C : UKSDamageTypeBase {
};

