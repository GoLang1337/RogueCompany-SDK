// BlueprintGeneratedClass RogueScreenPreviewActor.RogueScreenPreviewActor_C
// Size: 0x518 (Inherited: 0x518)
struct ARogueScreenPreviewActor_C : AKSJobSelectPrvwActor_RogueScrn {
};

