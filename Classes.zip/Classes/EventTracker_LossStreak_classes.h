// BlueprintGeneratedClass EventTracker_LossStreak.EventTracker_LossStreak_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_LossStreak_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_LossStreak.EventTracker_LossStreak_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_LossStreak.EventTracker_LossStreak_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_LossStreak.EventTracker_LossStreak_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_LossStreak(int32_t EntryPoint); // Function EventTracker_LossStreak.EventTracker_LossStreak_C.ExecuteUbergraph_EventTracker_LossStreak // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

