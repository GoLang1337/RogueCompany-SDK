// BlueprintGeneratedClass MLXMark4_CameraShake.MLXMark4_CameraShake_C
// Size: 0x160 (Inherited: 0x160)
struct UMLXMark4_CameraShake_C : UCameraShake {
};

