// BlueprintGeneratedClass EventTracker_MinutesPlayed.EventTracker_MinutesPlayed_C
// Size: 0x210 (Inherited: 0x208)
struct UEventTracker_MinutesPlayed_C : UKSEventTracker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x208(0x08)

	void HandleTrackerInitialized(struct TMap<struct FString, float>& Config, struct TMap<struct FString, struct FString>& StringConfig); // Function EventTracker_MinutesPlayed.EventTracker_MinutesPlayed_C.HandleTrackerInitialized // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x24d5b40
	void HandleLostPlayerController(); // Function EventTracker_MinutesPlayed.EventTracker_MinutesPlayed_C.HandleLostPlayerController // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void MatchHasEnded_Event(); // Function EventTracker_MinutesPlayed.EventTracker_MinutesPlayed_C.MatchHasEnded_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_EventTracker_MinutesPlayed(int32_t EntryPoint); // Function EventTracker_MinutesPlayed.EventTracker_MinutesPlayed_C.ExecuteUbergraph_EventTracker_MinutesPlayed // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

