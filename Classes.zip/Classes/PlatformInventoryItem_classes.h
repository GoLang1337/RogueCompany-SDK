// Class PlatformInventoryItem.ItemCollection
// Size: 0x98 (Inherited: 0x30)
struct UItemCollection : UPrimaryDataAsset {
	struct FPrimaryAssetRules Rules; // 0x30(0x0c)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FGameplayTagQuery CollectionQuery; // 0x40(0x48)
	struct FName PrimaryAssetType; // 0x88(0x08)
	char pad_90[0x8]; // 0x90(0x08)
};

// Class PlatformInventoryItem.PInv_AssetManager
// Size: 0x6c8 (Inherited: 0x440)
struct UPInv_AssetManager : UAssetManager {
	char pad_440[0xa0]; // 0x440(0xa0)
	bool bHasCompletedInitialAssetScan; // 0x4e0(0x01)
	char pad_4E1[0x1e7]; // 0x4e1(0x1e7)
};

// Class PlatformInventoryItem.PlatformInventoryItem
// Size: 0x1b8 (Inherited: 0x30)
struct UPlatformInventoryItem : UPrimaryDataAsset {
	int32_t ItemId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FText ItemDisplayName; // 0x38(0x18)
	struct FText ItemDescription; // 0x50(0x18)
	struct FString FriendlySearchName; // 0x68(0x10)
	bool IsOwnableInventoryItem; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TArray<int64_t> DisplayableLootIds; // 0x80(0x10)
	struct TSoftObjectPtr<UTexture2D> ItemIcon; // 0x90(0x28)
	struct FSoftObjectPath ItemIconPath; // 0xb8(0x18)
	struct TSoftObjectPtr<UTexture2D> LegacyItemIconTexture; // 0xd0(0x28)
	struct TArray<struct FIconReference> Icons; // 0xf8(0x10)
	struct FGameplayTagContainer CollectionContainer; // 0x108(0x20)
	struct TMap<enum class EExternalSkuSource, struct FString> ExternalProductSkus; // 0x128(0x50)
	bool OnlyDisplayAcqusitionIfWhitelisted; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
	struct TArray<int64_t> BlackListedLootIds; // 0x180(0x10)
	char pad_190[0x28]; // 0x190(0x28)

	bool ShouldDisplayToUser(int64_t LootId); // Function PlatformInventoryItem.PlatformInventoryItem.ShouldDisplayToUser // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf44a0
	void SetFriendlySearchName(struct FString InFriendlyName); // Function PlatformInventoryItem.PlatformInventoryItem.SetFriendlySearchName // (Final|Native|Public|BlueprintCallable) // @ game+0xaf4400
	void SetCollectionContainer(struct FGameplayTagContainer& InContainer); // Function PlatformInventoryItem.PlatformInventoryItem.SetCollectionContainer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaf4340
	bool IsItemTempDisabled(); // Function PlatformInventoryItem.PlatformInventoryItem.IsItemTempDisabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf4310
	bool IsItemDisabled(bool bIncludeTempDisabled); // Function PlatformInventoryItem.PlatformInventoryItem.IsItemDisabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf4280
	void GetTextureAsync(struct TSoftObjectPtr<UTexture2D>& Texture, struct FDelegate& IconLoadedEvent); // Function PlatformInventoryItem.PlatformInventoryItem.GetTextureAsync // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaf4150
	struct FSoftObjectPath GetSoftItemIconAsPath(); // Function PlatformInventoryItem.PlatformInventoryItem.GetSoftItemIconAsPath // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf40b0
	struct TSoftObjectPtr<UTexture2D> GetSoftItemIcon(); // Function PlatformInventoryItem.PlatformInventoryItem.GetSoftItemIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf4070
	bool GetSoftIconByName(struct FName IconType, struct TSoftObjectPtr<UTexture2D>& Icon); // Function PlatformInventoryItem.PlatformInventoryItem.GetSoftIconByName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3f70
	bool GetSoftIconAsPathByName(struct FName IconType, struct FSoftObjectPath& Icon); // Function PlatformInventoryItem.PlatformInventoryItem.GetSoftIconAsPathByName // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3e70
	struct FString GetItemNameAsString(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemNameAsString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3d20
	struct FText GetItemName(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3c70
	int32_t GetItemId(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3c50
	struct FString GetItemDescriptionAsString(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemDescriptionAsString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3b20
	struct FText GetItemDescription(); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemDescription // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3a70
	struct TSoftObjectPtr<UPlatformInventoryItem> GetItemByFriendlyName(struct FString InFriendlyName); // Function PlatformInventoryItem.PlatformInventoryItem.GetItemByFriendlyName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaf3950
	struct FGameplayTagContainer GetCollectionContainer(); // Function PlatformInventoryItem.PlatformInventoryItem.GetCollectionContainer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3920
};

// Class PlatformInventoryItem.PlatformStoreAsset
// Size: 0x1c8 (Inherited: 0x1b8)
struct UPlatformStoreAsset : UPlatformInventoryItem {
	int32_t LootId; // 0x1b8(0x04)
	struct FPrimaryAssetRules Rules; // 0x1bc(0x0c)

	int32_t GetLootId(); // Function PlatformInventoryItem.PlatformStoreAsset.GetLootId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaf3e50
};

