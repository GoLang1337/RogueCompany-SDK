// WidgetBlueprintGeneratedClass FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C
// Size: 0x510 (Inherited: 0x4b8)
struct UFirstTimeSafeZoneWidget_C : UPUMG_Widget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b8(0x08)
	struct UImage* Decro; // 0x4c0(0x08)
	struct UImage* Image_3; // 0x4c8(0x08)
	struct UImage* Image_159; // 0x4d0(0x08)
	struct UOverlay* SettingsWidgetContainer; // 0x4d8(0x08)
	struct UTextBlock* Title; // 0x4e0(0x08)
	struct UWBP_StandardButtonMedium_C* WBP_StandardButtonMedium; // 0x4e8(0x08)
	struct FKSSettingsWidgetConfig SettingsWidgetConfig; // 0x4f0(0x10)
	struct UKSSettingsInfoBase* SettingsInfo; // 0x500(0x08)
	struct UKSSettingsWidget* SettingsWidget; // 0x508(0x08)

	void InitializeWidgetNavigation(); // Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.InitializeWidgetNavigation // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void InitializeWidget(struct APUMG_HUD* HUD); // Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.InitializeWidget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	void OnShown(); // Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.OnShown // (Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature // (BlueprintEvent) // @ game+0x24d5b40
	void PreConstruct(bool IsDesignTime); // Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x24d5b40
	void ExecuteUbergraph_FirstTimeSafeZoneWidget(int32_t EntryPoint); // Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.ExecuteUbergraph_FirstTimeSafeZoneWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0x24d5b40
};

