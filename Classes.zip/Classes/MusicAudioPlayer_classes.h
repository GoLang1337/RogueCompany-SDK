// BlueprintGeneratedClass MusicAudioPlayer.MusicAudioPlayer_C
// Size: 0x500 (Inherited: 0x500)
struct AMusicAudioPlayer_C : AKSAudioPlayer {

	void Append String to Event Array(struct FString AppendStringIn, struct TArray<struct FString>& EventNameArrayIn, struct TArray<struct FString>& EventNameArrayOut); // Function MusicAudioPlayer.MusicAudioPlayer_C.Append String to Event Array // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	void PrependStringToEventArray(struct FString PrependStringIn, struct TArray<struct FString>& EventNameArrayIn, struct TArray<struct FString>& EventNameArrayOut); // Function MusicAudioPlayer.MusicAudioPlayer_C.PrependStringToEventArray // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x24d5b40
	struct TArray<struct FString> ComposeEventNamePriorityArray(struct FString EventName, struct UKSAudioPlayerStateParameterData* CurrentStateParameters); // Function MusicAudioPlayer.MusicAudioPlayer_C.ComposeEventNamePriorityArray // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
	struct TArray<struct FString> ComposeBankNamePriorityArray(struct FString BankPrefix, struct UKSAudioPlayerStateParameterData* CurrentStateParameters); // Function MusicAudioPlayer.MusicAudioPlayer_C.ComposeBankNamePriorityArray // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x24d5b40
};

